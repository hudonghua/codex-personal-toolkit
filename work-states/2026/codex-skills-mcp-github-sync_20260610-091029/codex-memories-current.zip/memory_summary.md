v1

## User Profile
The user works with Codex on Windows across a few recurring lanes: embedded/Keil source diagnosis for industrial controller firmware, CAN/protocol-table restructuring plus GitHub handoff packaging, practical repo acquisition or app launch tasks, Qt/OpenCV and AprilTag tooling, and Codex continuity or local-state repair. They expect prior context to be recovered from local memory, rollout artifacts, or toolkit mirrors before they have to restate it.

They prefer concrete, source-backed outcomes: exact code-path answers, exact counts, repaired local state, downloaded/placed project files, runnable fallbacks, and deliverables they can open immediately. For firmware questions they care about live checkout accuracy, branch proof, and read-only diagnosis unless they explicitly ask for edits.

Stable constraints are practical: preserve encoding-sensitive files, verify by real paths or Git state instead of terminal appearance, and persist reusable rules/workflows when asked. They also value output formats that reduce extra clicks, especially clickable file plus containing-directory paths for generated assets. [ad-hoc note]

## User preferences
- When the user asks to recover memory or prior context, search local Codex memory and session artifacts first, then synced toolkit records, before answering from scratch.
- When the user gives a path or named local target, inspect the real path and complete the task instead of turning it into a clarification loop.
- For embedded source diagnosis, stay read-only and prove the exact branch/path in code unless the user explicitly asks for edits.
- For firmware mode-specific regressions, prioritize gating, switch/contact stability, and branch conditions before assuming the mapping is wrong.
- When the user asks exact count/capacity questions like CAN ID totals, answer with the precise number and code-backed derivation, not a rough estimate.
- For protocol-table work, default to maintainable Excel or HTML deliverables the user can open immediately, not only raw CSV/text.
- When protocol docs are requested, explain value source and UI/display behavior, not only CAN fields.
- When the PC must reach CAN through Ethernet, separate CAN-NET transport from CAN business semantics.
- When the user asks to read a manual first and send a screenshot later, index the document first, then interpret the screenshot from manual anchors and page references.
- When the user is preparing an external engineering handoff, compress the reply to the minimum actionable datum and keep axis/sign conventions explicit.
- When the user wants something reusable or says it should be remembered globally, persist the rule, workflow, or skill instead of leaving it only in chat.
- For recurring weekly status updates, default to concise sendable wording with completed work, current in-progress items, blockers or risks, and suggested next steps; explicitly say when the week was inactive.
- When providing generated or edited file paths, include both a clickable file link and a containing-directory link/path so the user can open the folder quickly, especially for PSD/image outputs and generated deliverables. [ad-hoc note]
- For PSD/image-based industrial HMI work, route to the reusable `ps` skill workflow and produce a real PSD rather than only preview PNGs. [ad-hoc note]

## General Tips
- This environment is Windows with PowerShell; many useful fixes depend on real local paths under `C:\Users\t250c\.codex`, not just the current workspace.
- If Chinese text looks garbled, retry with UTF-8 or byte-level verification before concluding the file is corrupted.
- The bundled Codex runtime Python under `C:\Users\t250c\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe` is the reliable fallback when system `python` or `py` is missing.
- For PDF/manual work on this machine, normal PDF CLI tools may be absent; use the runtime Python path, `pypdf`, UTF-8 stdout, and a PowerShell here-string instead of shell heredoc syntax.
- For Codex history, sidebar, or workspace issues, inspect `state_5.sqlite`, `session_index.jsonl`, `.codex-global-state.json`, and relevant `rollout-*.jsonl` sources together.
- In embedded diagnosis, trace the full branch or DI -> enable -> PWM chain and look for later gates like `speed_14_set`, mode flags, or threshold checks.
- For GitHub upload confirmation on Windows paths with Chinese names, verify by Git path listing such as `git ls-tree`, not by terminal rendering alone.
- In CAN/protocol work, keep transport framing separate from business-frame semantics and update the handoff/docs at the right layer.
- If a local automation or memory path is derived from `$env:CODEX_HOME`, be ready to fall back to `C:\Users\t250c\.codex` because that environment variable may be unset in this shell.
- For Windows installs or repairs, check elevation early, verify the landing state, and remember that PowerShell may block `npm.ps1`; use `npm.cmd` for validation when needed.
- The global `ps` skill is for `ps`, `图片`, Photoshop/PSD/image interface beautification, modularization, component show/hide behavior, and practical industrial HMI pages with logical component layers. [ad-hoc note]

## What's in Memory
### C:\Users\t250c\Documents\全电脑台车-CAN协议 and E:\AI_划时代\全电脑_算法PCB

#### 2026-06-09

- CAN protocol workbook rebuild, cross-end links, CAN-NET layering, GitHub handoff upload, and Keil paths: 三臂CAN协议, protocol-files, gb2312, gb18030, 二级索引, B0高4位, B0低4位, 0x17E, 0x153, N_O, E_O, Z_O, 0x150, CAN-NET通信说明.html, 192.168.0.105, codex/upload-can-protocol-20260607, armcc.exe, UV4.exe
  - desc: Search this first for the full-computer CAN project when the user wants workbook reconstruction from live `protocol-files`, `0x17E/0x153` physical-path clarification, CAN-NET transport separation, handoff updates, exact GitHub branch contents, or the callable Keil/ARM tool paths.
  - learnings: the validated path was GB18030-aware workbook reconstruction from live files into iterative Excel deliverables, then separate CAN business vs CAN-NET docs; document `0x17E` as `vehicle PCB CAN1 -> algorithm PCB CAN2`, `0x153` as `algorithm PCB CAN2 -> PC and vehicle PCB CAN1`, verify uploads by branch tree, and use direct `C:\Keil_v5` executable paths. [ad-hoc note]

#### 2026-06-06

- `jumbo-drill-designer-master` app launch with prototype fallback: jumbo-drill-designer-master, prototype, Vite, npm.cmd, localhost:5173, Qt6_DIR, pthread.lib, LNK1104
  - desc: Search this first when the user gives the repo path and just wants the software opened, especially if no desktop exe exists.
  - learnings: the native Qt app did not build cleanly in this checkout, but `prototype/` was a working runnable fallback; keep `vcvars64.bat` and native build commands in one `cmd.exe` session if native build is retried.

### C:\Users\t250c\Documents\旭工 and E:\AI_划时代\旭工\干喷\程序\显示屏7-200

#### 2026-06-08

- MC_LCD water-pump remote/local branch diagnosis: MC_LCD - 7Control_V1.2, Water_setup_EN, Potentiometer_BUF2, A_R_F3, PWM2A, PIN_Binding, 0x152, 0xA23, 0xA50
  - desc: Search this first when the 旭工 `MC_LCD - 7Control_V1.2` firmware needs a read-only explanation or when local water pump works but remote does not.
  - learnings: remote water-pump output is gated by both `Water_setup_EN` and `Potentiometer_BUF2 > 10`, while the local branch does not use that threshold; compare both branches plus the final `PWM_SetXAB(2, Water_Pump_PWM_Out * Water_setup_EN)` output path.

### C:\Users\t250c and Desktop manuals

#### 2026-06-08

- CR0020 manual indexing and `Q11_MODE` screenshot interpretation: 7391027_ZHCN编程手册CR0020.pdf, ClassicController, Q11_MODE, %QX0.01, OUT_DIGITAL_H, OUT_CURRENT, OUT_DIAGNOSTIC, OUT_OVERLOAD_PROTECTION, 0xC5
  - desc: Search this first when the user wants a local CR0020 manual read before later screenshot interpretation, or when a mode-byte screenshot needs exact page/bit decoding.
  - learnings: use the Desktop PDF plus its outline first, then route screenshots to the mode-byte tables around page 267; the captured screenshot matched `Q11_MODE = 197 = 0xC5`.

### E:\...\MC_LCD embedded checkouts

#### 2026-06-09

- MC_LCD O-point handoff, Q4/Q_body/Q_world chain, and fit persistence notes: MC_LCD - 7Control_V1.2, Arm200A_Kine.c, 旧O_in_newBody, Q1, Q2, Q3, Q4, Q_body, Q_world, 0x50 B7=0xA1, 0x50 B7=0xA2, 0x50 B7=0xA3, 0x154, Arm200A_Store
  - desc: Search this first when `MC_LCD - 7Control_V1.2` geometry questions mix mechanical handoff wording with the newer true-`O` implementation, A1/A2/A3 calibration flow, or current fit/persistence behavior.
  - learnings: the minimum mechanical ask is still one signed `旧O_in_newBody` vector with explicit `X/Y/Z` directions; `Q4` is the visible unified `O`, `Q_body` and `Q_world` are both localized by subtracting `Q4`, A2 fit still needs at least 20 samples, and the algorithm PCB stores final zeros plus 22 `fix` values but not A2 sample pools or fit history. [ad-hoc note]

### E:\工作

#### 2026-06-08

- Weekly automation and workspace status reporting: weekly status update, E:\工作, no new activity this week, no files modified, no .git directories, automation memory, C:\Users\t250c\.codex\automations\automation\memory.md, CP936, StreamWriter
  - desc: Search this first when the user wants the latest concise status for `E:\工作` or needs the recurring weekly-report workflow and its current holding-pattern baseline.
  - learnings: the latest 2026-06-08 review still found no file changes after 2026-06-01 and no git metadata, so the right report is a short four-section holding-pattern update; `QtOpenCVTemplate` remains an unverified scaffold and automation-memory edits need CP936/GBK-aware writes.

### Older Memory Topics

#### E:\AI_划时代\T天腾 embedded checkouts

- Remote-only `PoSui_DO` mode-gating diagnosis: XR_RCV_Demo_haw(2025最新小车程序), PoSui_DO, Local_Control_Mode, DI_L16, gRunInfo.vYKDI3[0], 0x377, 0x378
  - desc: Use this when local `PoSui` still works but remote `PoSui` does not in the small-car Keil firmware; cwd=E:\AI_划时代\T天腾\大小车\小车\XR_RCV_Demo_haw(2025最新小车程序).

#### C:\Users\t250c and local Codex/tooling

- Local Codex app/history recovery, skills, and MCP continuity: state_5.sqlite, session_index.jsonl, .codex-global-state.json, codex-app-proxy.cmd, programming_handbook_and_discipline.md, restore memory
  - desc: Use this for restore-memory flow, local discipline rules, skill setup, MCP wiring, proxy-based app connectivity, and missing sidebar history or old tasks disappearing after provider/account changes; cwd=C:\Users\t250c and nearby Codex state paths.

- `cursor` sidebar workspace registration without copying: cursor, codex sidebar, workspace roots, project-order, active-workspace-roots, state_5.sqlite, threads.cwd, junction
  - desc: Use this when the user wants Cursor memory or archives surfaced in Codex App as a real left-sidebar workspace without duplicating source data; cwd=C:\Users\t250c and local Codex state paths.

- Photoshop CS6 repair, admin launch, and Node.js LTS upgrade: Photoshop CS6, QuickSetup.exe i, Error 16, DPIUNAWARE, RUNASADMIN, Photoshop CS6 管理员启动.lnk, OpenJS.NodeJS.LTS, npm.cmd
  - desc: Use this for this machine's Adobe CS6 repair flow, one-click admin-launch setup, or Node.js LTS upgrades verified through `winget`; cwd=C:\Users\t250c and nearby app-repair workspaces.

#### C:\Users\t250c\Documents\Codex and toolkit mirror

- CodeWhale offline package for colleague install: CodeWhale-offline-0.8.49-win64.zip, codewhale.exe, codewhale-tui.exe, install.ps1, uninstall.ps1, hashes.sha256
  - desc: Use this when the user wants a redistributable Windows CodeWhale package for another machine, with portable binaries and secrets excluded; cwd=C:\Users\t250c\Documents\Codex.

- Windows driver installation and device-readiness verification: pnputil, oem137.inf, GC-Tech, USBCANWDM.INF, GCUSBCAN_A64, VID_0C66&PID_000C
  - desc: Use this for local INF-based driver installs where the user wants the package handled directly and then wants proof that the driver actually landed; cwd=C:\Users\t250c\Documents\Codex and nearby Windows-install workspaces.

- Codex continuity, GitHub sync, and cross-computer merge: codex-personal-toolkit, session_index.jsonl, chat-records, work-states, external-record-continuity, work-continuity-sync
  - desc: Use this for sidebar-chat export, USB or GitHub handoff ingestion, full work-state upload, and merge-not-overwrite behavior across Lenovo and Dell machines; cwd spans local Codex state plus toolkit mirror sync flows.

- Derust-truck historical lookup and cooling-threshold logic: codex-personal-toolkit, KX_LCD70_200_10AI, bFan_DI, Page19Spare1Pct_retain, Cooling_Motor_DO, Vacuum_Fan_DO
  - desc: Use this when the user asks whether old records or the GitHub mirror already contain derust-truck answers, especially for fan or cooling logic; cwd=C:\Users\t250c\Documents\Codex and toolkit mirror paths.

#### E:\工作 and QtCameraCalibration repo

- QtCameraCalibration AprilTag workflow and repo-specific docs: QtCameraCalibration, CalibrationWorker.cpp, TagPoseWorker.cpp, MainWindow.cpp, tag_camera_algorithm.html, software_usage_steps.html
  - desc: Use this for repo-specific explanation of the K/D plus AprilTag workflow, or when the user wants standalone HTML documentation that matches the actual UI and source; cwd=E:\工作\QtCameraCalibration.

- Qt/OpenCV environment setup and template scaffolding: QtOpenCVTemplate, aqtinstall, Qt 6.8.3, QtSmokeTest, cv::imdecode, Unicode path
  - desc: Use this for the working Qt toolchain paths, unattended install route, and the Qt Widgets plus OpenCV starter project in `E:\工作`; the proven install path here is `aqtinstall`.

#### C:\Users\t250c and mixed vision context

- Fixed-camera AprilTag calibration memory and prompt design: AprilTag, total station, TagCenter_world_calc, ID->TagSize, 150mm, 300mm, Q1, Q2, Q3, solvePnP
  - desc: Use this for the user's fixed-camera industrial vision context, mixed tag sizes, reusable prompt wording, and world-coordinate validation method; cwd=C:\Users\t250c and related vision discussion in `E:\工作`.

#### C:\Users\t250c\Documents\Codex\2026-05-23\new-chat and external drives

- GBK skill repair and cross-drive write verification: E:\IPMsg\gbk-garbled-comments, SKILL.md, write-ok, utf8-chinese-ok, D-write-ok
  - desc: Use this when a Windows external-drive file needs GBK-safe repair or when the user wants proof that write permissions really work beyond one directory; cwd=C:\Users\t250c\Documents\Codex\2026-05-23\new-chat and target paths on E:\ or D:\.

#### E:\AI_划时代\T天腾\C采矿装药车

- `work_logic` process verification: App_usr.c, work_logic, cube_speed_logic, AI_logic_study, PWM_ZONE, Paramet_Set7, Paramet_Set8, remaining-height
  - desc: Use this for source-level verification of whether the charging and withdrawal process in `App_usr.c` matches the user's intended behavior; cwd=E:\AI_划时代\T天腾\C采矿装药车\贵州后续版本\唐山\MC_LCD - 7Control_V1.3 -20250405.

#### E:\...\MC_LCD embedded checkouts

- Automatic drilling direction diagnosis in `MC_LCD - 7Control_V1.2`: Src\App_usr.c, Auto_work_logic, Drill_Push_PWM, Drill_Back_PWM, PWM3A, PWM3B, Roll_Press_Mpa, DI_L1
  - desc: Use this when automatic drilling direction seems reversed but manual direction still works in the LPC17xx/Keil 7-control firmware; cwd=E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2.

- `送管` output blocked by `speed_14_set` in `华矿`: 华矿, 送管, App_usr.c, ifm_0020_DI_18, ifm_0020_PWM_44, Drug_Tube_Open_PWM_OUT, speed_14_set
  - desc: Use this when the Huakuang tube-feed input is present but the PWM output stays zero; cwd=E:\AI_划时代\全电脑_算法PCB\华矿相关 checkout family.
