thread_id: 019e5dfb-aacf-7a33-b5fd-9dbeaddd75e0
updated_at: 2026-06-01T13:45:32+00:00
rollout_path: C:\Users\t250c\.codex\sessions\2026\05\25\rollout-2026-05-25T15-13-54-019e5dfb-aacf-7a33-b5fd-9dbeaddd75e0.jsonl
cwd: \\?\E:\工作

# Work_logic 工艺核对与图谱收窄

Rollout context: 用户在 `E:\AI_划时代\T天腾\C采矿装药车\乳化装药车` 相关工程里，先让助手读程序和 Word/Excel 文档，后面又要求把图谱收窄到 `App_usr.c`，进一步只看 `work_logic`，并最终核对“到余高停机、理论装药量和实际装药量是否一致、是否存在实时调节”这些工艺问题。工作目录多次切换，但核心代码都在 `App_usr.c`。

## Task 1: 读取工程与文档，建立装药/遥控项目认知

Outcome: success

Preference signals:

- 用户先让读“里面的程序和 word 文档”，后续又持续追问工艺是否写对，说明他更在意从代码和文档核实真实逻辑，而不是只要概述。
- 用户随后明确要求“重点分析 work_logic 的图。其他的不需要”，表明这类任务里应主动收窄范围，别继续铺开到整套工程。

Key steps:

- 先定位目录结构，确认存在多个 Keil 工程、Word、Excel、BIN、图片和资源文件。
- 通过 `uvproj` 和 `main.c` 识别出 `App_usr.c` 是装药主逻辑核心，`MyLogic_10ms` 是主周期入口，`work_logic` 是关键控制函数。
- 读取 Word/Excel 里的接口定义与动作表，得到“装药控制器 / 遥控器接收机 / AMP 接口 / 119 扩展 IO”这套工艺背景。

Failures and how to do differently:

- `doc/.xls` 老格式用 COM 读取时会遇到 `RPC_E_CALL_REJECTED`，要准备降级到 `xlrd` 或其他只读方式。
- 中文长路径和 PowerShell/Node 之间存在编码坑，读取图谱 JSON 时需要注意 BOM 与路径传递。

Reusable knowledge:

- 该目录下最有价值的两个入口是 `FSJ_666` 与 `XR_RCV_Demo_haw-XR - 2`，但用户后续关注的是 `App_usr.c` 这一条主线。
- `App_usr.c` 内的 `MyLogic_10ms`、`CAN_receive_data`、`PIN_Binding`、`App_BengS_times`、`work_logic`、`cube_speed_logic`、`CAN_Send_data`、`CAN2_IO_pinding` 是装药工艺里最关键的一组。

References:

- [1] `XR_RCV_Demo_haw-XR - 2\HDH_RCV_SPJ.uvproj`：`<Device>LPC1768</Device>` / 另一路 `LPC1764` 旧工程；包含 `main.c`、`App_usr.c`、`App_Logic.c` 等。
- [2] `7寸屏200A接口定义母版（）V1.0.docx`：接口定义包含 `DO1/PWM3-A`、`DO2/PWM4-A`、`DO3/PWM4-B`、`AD0~AD5`、`Paramet_Set` 类模拟量/电流输入说明。
- [3] `KX119扩展Io协议.xls`：`0x318`、`0x31A` 等 CAN 报文对应功能位。

## Task 2: 将图谱收窄到 work_logic，并说明备注机制

Outcome: success

Preference signals:

- 用户要求“我不要你补，你看下程序，是不是这么写的”，说明他更想要对代码本身的核对，而不是继续做展示性改写。
- 用户明确说“其他的不需要”，因此以后类似任务应默认只保留目标函数相关的上下游，不要再展开整套主链图。

Key steps:

- 在本地 HTML 图谱里把默认焦点改成 `App_usr.c:work_logic`，并把页面标题、说明、默认选中节点和筛选逻辑都收窄为 work_logic 视图。
- 增加了每个函数的本地备注输入区，备注保存在浏览器 `localStorage`，用于后续按备注回看和改代码。
- 后续又把页面进一步压缩成 `work_logic` 专用图，只保留 `MyLogic_10ms -> work_logic -> AI_logic_study / Limit_Min_Max / on_off_time` 这条视图。

Failures and how to do differently:

- 直接依赖 `understand-dashboard` 的接口在这台 Windows 环境里不稳定，接口返回过 `{"error":"No knowledge graph found. Run /understand first."}`；最终靠本地单文件 HTML 规避。
- 备注存到浏览器本地，不会自动写回 HTML 文件；如果未来用户要求“备注落文件”，要额外做导出/导入或旁路文件。

Reusable knowledge:

- `work_logic` 相关页面里，最有价值的上下游只剩：上游 `MyLogic_10ms`，下游 `AI_logic_study`、`Limit_Min_Max`、`on_off_time`。
- `App_usr.c` 的业务说明可以按函数级别补，但用户后续更关心的是“是否写对代码”和“工艺是否闭环”，而不是页面本身的花样。

References:

- `装药主链图谱_本地.html`：最终变成 `work_logic 图谱（本地版）`，默认 `selectNode("function:App_usr.c:work_logic")`。
- 本地备注键：`drug-graph-function-notes-v1`。
- 右侧写死的说明链：`MyLogic_10ms`、`work_logic`、`AI_logic_study`、`Limit_Min_Max`、`on_off_time`。

## Task 3: 核对 work_logic 的工艺是否按用户描述实现

Outcome: partial

Preference signals:

- 用户连续追问“是不是这么写的”“这是最后的停止条件”“现在这块是不是没有调节，是同一个管子速度在跑？”说明他要的是代码事实核对，而不是推测。
- 用户强调“到了余高必须都得停掉”，这是以后解释这类控制逻辑时的优先结论。

Key steps:

- 在 `App_usr.c` 中直接核对 `work_logic()` 与 `cube_speed_logic()`。
- 看到理论量/理论速度计算在 `cube_speed_logic()`：用孔截面积、`Length_push` 或 `Hole_deep_over*`、余高 `H_set[]`、密度 `Paramet_Set7` 计算 `logic_kg_no[]` 和 `tube_Set_Speed`。
- 在 `work_logic()` 中看到自动模式先开药，再经过约 3 秒延时后才开始自动收管；收管 PWM 主要由 `AI_logic_study()` + `PWM_ZONE` 选择 `Paramet_Set8~14`，再可手动上下微调。
- 看到余高停止条件确实存在：`Length_push/10.0 < H_set[Kong_NO_Step]` 或 `Length_push < 10` 时，`Tube_close_PWM = 0`、`Auto_Work_Flags_start = 0`、`Tube_Close_CAN2_Hold = 0`、`Tube_Open_CAN2_Hold = 0`、`Drug_close_enable_auto_flags = 0` 等一并清掉。

Failures and how to do differently:

- 当前实现不是“实际装药量实时逼近理论装药量”的闭环；注释掉的一大段速度偏差自调逻辑没有生效。
- 用户说的“理论装药量和实际装药量保持一致”是工艺目标，但在代码里更像“按理论算出速度后，用标定档位跑，再到余高停机”，并没有看到真正按实际量闭环修正。
- `Paramet_Set7` 不是退管 PWM 标定值，而是参与理论量/速度计算的密度因子；真正的收管标定主要是 `Paramet_Set8~14`。
- `work_logic()` 当前更多像“固定标定档位 + 人工微调 + 余高停机”，不是“同一根管子速度实时自适应调节到理论量一致”。

Reusable knowledge:

- `cube_speed_logic()` 的核心公式：
  - `logic_kg_no[Kong_NO_Step] = PaoKong_area * (长度或实际孔深 - 余高) * 密度`。
  - `tube_Set_Speed = Aomo_Zone_V / PaoKong_area`。
- `work_logic()` 的自动流程：
  - 先 `Drug_Work_Start_DO = 1`。
  - 约 3 秒后才进入自动收管/退管。
  - 用 `AI_logic_study((int)(tube_Set_Speed * 10))` 选择 `Paramet_Set8~14`。
  - 余高条件触发后统一停管、停药、关联锁。
- 这版程序的结论更准确地说是：
  - `到余高必须停掉`，这个有写；
  - `理论量算出来后用标定速度去跑`，这个有写；
  - `实际量与理论量做闭环实时调节`，这个没真正启用。

References:

- [1] `Src\App_usr.c:1881-1992` 的 `cube_speed_logic()`：可见 `Paramet_Set7`、`Hole_deep_over*`、`Length_push`、`H_set[]`、`logic_kg_no[]`、`tube_Set_Speed` 的计算。
- [2] `Src\App_usr.c:2793-3065` 的 `work_logic()`：可见 `Auto_Work_Flags_start`、`Drug_Work_Start_DO`、`Tube_close_dly`、`AI_logic_study((int)(tube_Set_Speed *10))`、`Paramet_Set8~14`、`Length_push/10.0 < H_set[Kong_NO_Step]` 的停机条件。
- [3] `Src\App_usr.c:3036` 左右：余高停止时统一清 `Tube_close_PWM`、`Auto_Work_Flags_start`、`Tube_Close_CAN2_Hold`、`Tube_Open_CAN2_Hold`、`Drug_close_enable_auto_flags`。
- [4] `Src\App_usr.c:2953-2979`：人工加减档会影响 `Tube_close_PWM`，说明当前存在人工微调但不是完整闭环。
