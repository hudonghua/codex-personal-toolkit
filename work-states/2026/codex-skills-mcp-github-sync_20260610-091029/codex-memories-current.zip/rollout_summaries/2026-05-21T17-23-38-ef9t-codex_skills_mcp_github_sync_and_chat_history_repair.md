thread_id: 019e4b90-74db-7e31-9c40-b40d5bcc9397
updated_at: 2026-05-31T15:34:02+00:00
rollout_path: C:\Users\t250c\.codex\archived_sessions\rollout-2026-05-22T01-23-38-019e4b90-74db-7e31-9c40-b40d5bcc9397.jsonl
cwd: \\?\C:\Users\t250c\Documents\Codex\2026-05-22\new-chat

# A long multi-part rollout focused on discovering and installing useful skills/MCP tooling, then fixing Codex history/UI state after a CC/API-entry switch.

Rollout context: The user was working in `C:\Users\t250c\Documents\Codex\2026-05-22\new-chat` initially, later other dated Codex sessions were involved. The thread covered skill discovery/installation, local MCP setup, GitHub sync for a portable personal toolkit, and finally diagnosing why the left-side chat history disappeared after switching API entry via CC.

## Task 1: Discover and install vision/OpenCV/embedded/survey/bin-reverse skills, plus memory-skill automation

Outcome: success

Preference signals:
- the user repeatedly asked to find/install skills for specific domains (`OpenCV`, visual work, `Excel`, `PPT`, `Photoshop`, `MDK C`, `全站仪标定`, `bin/二进制`, `GPIO/芯片嵌入式开发`) -> they want domain-specific reusable skills rather than ad hoc one-off answers.
- after the user said “我都要”, “好。按你的建议”, “继续 按你的意思办”, and later “严格执行”, that indicates they want the assistant to proactively build out the reusable skill/tooling stack instead of stopping at recommendations.
- after asking that task learnings be preserved “另外跟skill一样。在处理完任务后，需要沉淀。” -> they want task lessons preserved as durable global behavior, not only in chat.
- after asking for multiple computers and later for merge behavior, it suggests they expect reusable infrastructure rather than manually re-specifying the environment each time.

Key steps:
- searched local skills and plugin caches for OpenCV/vision-related entries; found no built-in OpenCV skill, but did find browser vision, imagegen, and embedded/C-related skills.
- searched the web for OpenCV/vision skills and installed/created several skill folders under `C:\Users\t250c\.codex\skills`, including:
  - `opencv-g1joshi`
  - `opencv-terminalskills`
  - `senior-computer-vision`
  - `robot-perception` (local fallback content when upstream path 404’d)
- created survey and total-station focused skills:
  - `survey-data-processor`
  - `total-station-calibration`
- created firmware/binary/reverse-engineering skills:
  - `reverse_engineer`
  - `radare2`
  - `firmware-binary-reverse`
- created embedded/GPIO skills:
  - `embedded-systems`
  - `esp32`
  - `arm-cortex-expert`
  - `mcu-gpio-peripheral`
- created `workflow-memory-skillsmith` to force future agents to check for reusable lessons at task end and save them into skills and MCP-backed memory/SQLite when appropriate.
- later created `chat-transcript-uploader`, `work-continuity-sync`, and `multi-computer-toolkit-merge` skills to support explicit upload/sync/merge workflows.

Failures and how to do differently:
- several external skill sources returned 404 or were not directly installable; the successful pattern was to fall back to local skill creation when a public path or API endpoint was unstable.
- installed skill names sometimes duplicated or collided; unique names were needed (`opencv-g1joshi`, `opencv-terminalskills`).
- some web-based registry results looked real but were not directly downloadable; verify the actual GitHub path before relying on a registry page.

Reusable knowledge:
- `C:\Users\t250c\.codex\skills` is the local global skill root, and the assistant successfully built/installed many durable skill folders there.
- `keil5-embedded-c` already existed and is the main embedded-C/GBK/Keil safety skill for Chinese-comment firmware work.
- The local skills directory ended up with 26 skills by the end of the rollout.
- `workflow-memory-skillsmith` now explicitly says that reusable lessons should be saved both as global skills and, when available, to MCP memory/SQLite records.
- The general pattern for durable task knowledge is now: if the solution was a repeated workaround or a tool discovery, promote it into a skill; if it was a one-off artifact, keep it in the toolkit repository and/or memory DB.

References:
- [1] Local skill root verified by scans: `C:\Users\t250c\.codex\skills\...\SKILL.md` (26 skills at the end).
- [2] `workflow-memory-skillsmith` was added to enforce post-task knowledge capture.
- [3] `firmware-binary-reverse` and `mcu-gpio-peripheral` were added as durable embedded workflows.

## Task 2: Build local MCP memory/SQLite servers and wire them into Codex config

Outcome: success

Preference signals:
- the user explicitly asked to “沉淀” task knowledge and later said it should be like skills, so future tasks should also be stored in memory records.
- the user accepted the idea of using MCP for “能随时可以用” and “丰富下”, indicating a preference for long-term, queryable state.

Key steps:
- inspected `C:\Users\t250c\.codex\config.toml` and found that Codex already used a TOML config with `mcp_servers` sections.
- discovered the bundled Python path: `C:\Users\t250c\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`.
- built two local stdio MCP servers in `C:\Users\t250c\.codex\mcp_servers`:
  - `codex_memory_mcp.py` with tools `memory_add`, `memory_search`, `memory_list`, `memory_delete`
  - `codex_sqlite_mcp.py` with tools `sqlite_query`, `sqlite_add_record`, `sqlite_schema`
- configured both in `C:\Users\t250c\.codex\config.toml` and verified the TOML parsed successfully.
- tested both servers directly; they returned their tool lists correctly.
- stored initial memory/SQLite entries about the MCP installation itself.

Failures and how to do differently:
- first attempts to use system Python or npm/git-based installers failed or were unavailable; the successful route was to rely on the bundled Codex Python and avoid dependencies on system Python/npm/git.
- PowerShell script execution policy blocked some scripts; direct inline execution or bundled-Python scripts were more reliable.

Reusable knowledge:
- `session_index.jsonl`, `history.jsonl`, `.codex-global-state.json`, `config.toml`, and bundled Python/Node are all useful inspection points under `C:\Users\t250c\.codex` and the Codex runtime cache.
- the MCP config entries that worked used the bundled Python executable with stdio servers and `startup_timeout_sec = 30`.
- memory and SQLite records are now backed by actual files at `C:\Users\t250c\.codex\mcp_data\memory.sqlite` and `C:\Users\t250c\.codex\mcp_data\records.sqlite`.

References:
- [1] `C:\Users\t250c\.codex\config.toml` was updated with `[mcp_servers.codex_memory]` and `[mcp_servers.codex_sqlite]`.
- [2] Tool list verification returned JSON tool definitions for both MCP servers.
- [3] First recorded memory/record entries were written successfully (ids incremented during the rollout).

## Task 3: Create and publish a cross-computer personal toolkit repository with skills, MCP servers, install scripts, and work-state sync

Outcome: success

Preference signals:
- the user said they use multiple computers and want to “随时可以用”, meaning the system should be portable and resumable across machines.
- after the user clarified that “上传” means all work should be uploaded so another computer can seamlessly continue, the workflow should default to full state sync, not just chat export.
- the user repeatedly asked for the work to be uploaded and later for another computer to “无缝对接进度” and merge its own tasks/skills without overwriting.

Key steps:
- created a repository folder at `C:\Users\t250c\Documents\Codex\codex-personal-toolkit` with:
  - `skills/`
  - `mcp_servers/`
  - `mcp_config_snippets/`
  - `records/`
  - `README.md`
  - `.gitignore`
  - `install.ps1`
  - `backup.ps1`
- copied all non-system skills and the local MCP server scripts into the toolkit.
- added a portable GitHub CLI and portable MinGit under `C:\Users\t250c\.codex\tools\gh` and `C:\Users\t250c\.codex\tools\mingit` after `winget` install attempts got stuck at administrator/UAC prompts.
- authenticated GitHub CLI via device flow; the account shown in the output was `hudonghua`.
- created a private GitHub repository: `hudonghua/codex-personal-toolkit`.
- pushed the toolkit there successfully.
- added a chat/work upload flow:
  - `chat-transcript-uploader` skill for explicit chat archival
  - `work-continuity-sync` skill for the user’s broader meaning of `上传`
  - `multi-computer-toolkit-merge` skill for merging toolkits from multiple computers non-destructively
- added scripts in the toolkit:
  - `scripts/export_chat_archive.py`
  - `upload-chat.ps1`
  - `scripts/export_work_state.py`
  - `upload-work.ps1`
  - `scripts/merge_toolkit.py`
  - `merge-toolkit.ps1`
- produced a work-state snapshot under `work-states/2026/codex-skills-mcp-github-sync_20260523-224944` and pushed it to the private repo.
- later built a merge workflow so that uploads from other computers can be integrated by copying new files, preserving local-only files, and saving conflicts as timestamped incoming copies.

Failures and how to do differently:
- PowerShell script execution policy blocked `.ps1` scripts; direct invocation with the bundled Python and explicit commands was more reliable for export/upload.
- GitHub upload via plain `winget` installation of Git/GitHub CLI stalled on UAC; portable downloads worked better.
- the first transcript-only export was too narrow for the user’s real intent; the correct long-term rule became “上传 = work continuity sync.”
- the first attempt to export raw chat hit a sensitive-content guard because the transcript contained password/token/secret-like words discussed during setup; the user clarified they meant general work continuity, so the workflow was broadened to work-state snapshots rather than narrow transcript archiving.

Reusable knowledge:
- the canonical sync repository is `https://github.com/hudonghua/codex-personal-toolkit`.
- the toolkit includes 26 skills by the end of the rollout and is the source of truth for portable reuse.
- the work-state export format now includes: current workspace zip, readable transcript, raw session JSONL, skill list, MCP summary, optional Memory/SQLite data, manifest, and restore README.
- the merge workflow explicitly avoids destructive overwrite and uses conflict copies with timestamps.
- `upload` should now be interpreted as “export the full work state for cross-computer continuation,” not just chat archival.

References:
- [1] GitHub repo URL: `https://github.com/hudonghua/codex-personal-toolkit` (private).
- [2] Successful work-state snapshot path: `work-states/2026/codex-skills-mcp-github-sync_20260523-224944`.
- [3] Commit hashes observed during rollout include `8623056`, `f772968`, `7d7b42c`, `09f9c0e`, and `ad795da`.
- [4] Portable tools installed under `C:\Users\t250c\.codex\tools\gh` and `C:\Users\t250c\.codex\tools\mingit`.

## Task 4: Diagnose and repair the missing left-side chat history after CC/API-entry switch

Outcome: success

Preference signals:
- the user said the left-side chat record disappeared after switching the API entry via CC and asked for a “确切的方案” that would actually work, so the agent should prefer direct state repair over speculation.
- the user was dissatisfied with abstract diagnosis and wanted a concrete, implementable fix.

Key steps:
- checked that the actual session files still existed under `C:\Users\t250c\.codex\sessions\...\*.jsonl`; no chat data was deleted.
- checked `C:\Users\t250c\.codex\session_index.jsonl`, `history.jsonl`, `config.toml`, and `.codex-global-state.json`.
- found that `session_index.jsonl` had 25 lines but 3 invalid JSON rows, caused by broken/garbled `thread_name` values; this could break the left chat list renderer.
- backed up and rebuilt `session_index.jsonl` from the actual session files so it contained 24 valid rows with 24 unique IDs and 0 bad JSON.
- discovered the global UI state was pointing at a remote/other workspace (`E:\工作` rendered as garbled text) and a selected remote host with auto-connect enabled, which likely caused the history view to filter away the local chat list.
- backed up `.codex-global-state.json` and changed it to point back to the local Codex root `C:\Users\t250c\Documents\Codex`:
  - `projectless-thread-ids` set to all 24 session IDs
  - `thread-workspace-root-hints` set to the local Codex root for all IDs
  - `electron-saved-workspace-roots`, `project-order`, and `active-workspace-roots` set to the local Codex root
  - removed `selected-remote-host-id`
  - cleared `remote-connection-auto-connect-by-host-id`
- verified that the JSON parsed successfully after the change and that the session index remained valid.

Failures and how to do differently:
- the first repair (index fix only) was not enough; the real issue also involved the global workspace/remote selection state.
- inline PowerShell/Python one-liners sometimes failed because of quoting/escape issues; writing a small temporary Python repair script was more reliable for state-file edits.
- the UI likely needs an app restart to re-read the repaired state; without restart, the left-side history may still appear stale.

Reusable knowledge:
- `session_index.jsonl` is a critical index file for chat history; bad JSON entries can make history look missing even when session files exist.
- `.codex-global-state.json` controls workspace/remote routing and can hide local history if it points at an unexpected workspace or remote host.
- the relevant safe repair sequence is: back up the state file, rebuild the index from actual session JSONL files, then reset workspace roots and remote auto-connect to the local Codex root.
- the final verified state had 24 session index entries, 24 unique IDs, and 0 bad JSON lines.

References:
- [1] Session files still existed under `C:\Users\t250c\.codex\sessions\...`.
- [2] `session_index.jsonl` was repaired from 25 lines with 3 bad JSON rows to 24 valid rows, 24 unique IDs, 0 bad JSON.
- [3] Global state now points back to `C:\Users\t250c\Documents\Codex` and clears remote auto-connect.
- [4] If the UI still looks empty after restart, the next place to inspect is the app log/history-list parser rather than the raw sessions themselves.
