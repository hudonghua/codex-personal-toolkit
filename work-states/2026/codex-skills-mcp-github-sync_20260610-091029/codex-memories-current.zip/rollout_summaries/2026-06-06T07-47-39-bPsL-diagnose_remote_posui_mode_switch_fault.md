thread_id: 019e9be6-de6e-7970-9f64-9e0bd2aa1c5b
updated_at: 2026-06-06T08:25:48+00:00
rollout_path: C:\Users\t250c\.codex\sessions\2026\06\06\rollout-2026-06-06T15-47-44-019e9be6-de6e-7970-9f64-9e0bd2aa1c5b.jsonl
cwd: \\?\C:\Users\t250c\Documents\天腾大小车
git_branch: master

# Diagnose remote-only PoSui/boom behavior in the 2025 small-car Keil firmware

Rollout context: The user worked in `E:\AI_划时代\T天腾\大小车\小车\XR_RCV_Demo_haw(2025最新小车程序)` and asked about a remote-only failure where the crushing/impact output (`PoSui_DO`) behaved differently from local mode. The assistant inspected the Keil/Cortex-M3 embedded C project, the CAN receive/send path, and the local/remote mode switching logic.

## Task 1: Trace remote `PoSui_DO` behavior and compare with local mode

Outcome: partial

Preference signals:
- The user repeatedly narrowed the problem from general firmware analysis to a specific output path (`PoSui_DO`) and then to a mode-switching suspicion, indicating they want code-path-based diagnosis rather than generic guesses.
- When the user said the same remote mapping had worked before, that suggested future analysis should treat “mapping is wrong” as a lower-priority hypothesis and instead check mode gating, switch contacts, or version-specific logic changes first.
- When the user asked whether the local/remote switch could be bad or have poor contact, that suggests the user wants hardware-vs-software fault separation grounded in the control flow, not just code inspection.

Key steps:
- Confirmed the project is an LPC17xx/Cortex-M3 Keil firmware and located the active source tree under `XR_RCV_Demo_haw(2025最新小车程序)`.
- Traced the main loop in `main.c`: the 10 ms branch calls `Usr_Can_Rcv()`, `Usr_Can_Send()`, and `app_Logic()`.
- Traced `app_Logic()` in `App_Logic.c`: it runs `DI_Byte_DO()`, `Pinding()`, `Hand_Shank_logic()`, and `Logic_work()` each cycle.
- Traced remote `PoSui` logic:
  - `App_Can.c` receives remote frame 3 into `gRunInfo.vYKDI1/2/3`, with `gRunInfo.vYKDI3[0] = CAN1_RBuf[4]`.
  - `Logic_work()` sets `PoSui_DI_Remote = _BitV(gRunInfo.vYKDI3[0], 0)`.
  - Final output is `PoSui_DI = PoSui_DI_Local || PoSui_DI_Remote`, then `PoSui_DO = PoSui_DI`, then `DO_H4 = PoSui_DO`, then `DOx_Set(2, 1)`.
- Verified that local mode uses a different input path: `PoSui_DI_Local = DI_L3`.
- Observed that when `Local_Control_Mode == 0` (remote mode), the code also explicitly clears many remote inputs when the mode changes.
- Compared the 2025 latest source with older/newer sibling copies and found the `PoSui` mapping is consistent across versions; no obvious code-level remap was found.

Failures and how to do differently:
- The analysis could not be fully validated on hardware, so the final conclusion remained a hypothesis rather than a confirmed root cause.
- The assistant initially leaned toward mapping mismatch, but the user’s “it used to work” feedback means future agents should pivot earlier to mode-switch stability and input gating checks when a previously working remote action becomes intermittent.
- Because the same remote path is reused for other actions, a failure isolated to remote `PoSui` but not local `PoSui` points away from the valve/DO hardware and toward the remote-mode logic or the specific remote bit arriving at `vYKDI3[0]`.

Reusable knowledge:
- In this firmware, remote `PoSui` is not a dedicated hardware output path; it is software-gated through `Local_Control_Mode`, `gRunInfo.vYKDI3[0]`, and the `PoSui_DI` OR-combine logic.
- `Local_Control_Mode` comes from `DI_L16`; if the switch/contact is unstable, the code can fall back to local mode and clear remote outputs, which would make remote-only actions fail while local actions still work.
- The most useful runtime checks for this fault are the CAN feedback frames `0x377` and `0x378`:
  - `0x378` byte 5 mirrors raw `gRunInfo.vYKDI3[0]`.
  - `0x377` bit0 mirrors parsed `PoSui_DI_Remote`.
- If `0x378` shows the raw bit but `0x377` does not, the issue is gating/mode logic rather than the transmitter’s visible UI state.
- If local `PoSui` works and remote `PoSui` does not, the code strongly suggests checking `DI_L16` switch wiring/contact and any mode-jitter behavior before changing the output hardware.

References:
- [1] `main.c:199-209` — 10 ms cycle calls `Usr_Can_Rcv()`, `Usr_Can_Send()`, `app_Logic()`, and watchdog feed.
- [2] `App_Logic.c:1328-1370` — `app_Logic()` call order and periodic counters.
- [3] `App_Logic.c:847-879` — remote mode gating and `PoSui_DI_Remote = _BitV(gRunInfo.vYKDI3[0], 0)`.
- [4] `App_Logic.c:1109-1143` — local/remote OR-combine into `PoSui_DI`, then `PoSui_DO`.
- [5] `App_Logic.c:722-743` — `Local_Control_Mode = DI_L16`, local input setup including `PoSui_DI_Local = DI_L3`.
- [6] `App_Logic.c:961-1013` — mode-switch handling clears remote inputs including `PoSui_DI_Remote = 0`.
- [7] `App_Logic.c:808-814` and `App_Logic.c:466-493` — `DO_H4 = PoSui_DO` and the `DOx_Set(2, 1)` physical output mapping.
- [8] `App_Can.c:507-515` — remote receive frame 3 fills `gRunInfo.vYKDI1/2/3`, especially `gRunInfo.vYKDI3[0] = CAN1_RBuf[4]`.
- [9] `App_Can.c:344-366` — `0x377` sends parsed remote states; `0x378` sends raw `gRunInfo.vYKDI3[0]`.
- [10] User observation: the same remote control had worked previously, and local `PoSui` still works, which supports a mode-switch/gating fault hypothesis over a hardware-valve fault.
