thread_id: 019e5f65-1061-7cc3-842a-3ba2dd71d81e
updated_at: 2026-06-02T06:18:24+00:00
rollout_path: C:\Users\t250c\.codex\sessions\2026\05\25\rollout-2026-05-25T21-48-39-019e5f65-1061-7cc3-842a-3ba2dd71d81e.jsonl
cwd: \\?\E:\工作

# Unify Codex sidebar history across provider/account switches

Rollout context: the user kept asking where prior records were and why the Codex desktop app sidebar could not resume old tasks after switching between providers/accounts (described as `ikun`, `chatgpt`, and later `gpt` vs `ikun`). The work happened in `C:\Users\t250c\Documents\Codex` and mostly targeted the local Codex state under `C:\Users\t250c\.codex`.

## Task 1: Find where the sidebar history actually lives and why records appeared to disappear

Outcome: success

Preference signals:
- when the user said the records should still exist but switching accounts/providers broke resuming tasks, the user later insisted: "不要分流，要在一起。" -> this indicates they want one unified local history view, not separate sidebar buckets per provider/account.
- when the user clarified "只要不影响我切换账户" -> this suggests the user wants history unification without changing login/auth state or making account switching harder.
- when the user said "应该没问题了" after the fix, that is acceptance of the workflow of editing local state to restore continuity.

Key steps:
- inspected `C:\Users\t250c\.codex\state_5.sqlite`, `session_index.jsonl`, `C:\Users\t250c\.codex\.codex-global-state.json`, and `sessions` / `archived_sessions` rollout files instead of guessing.
- found that sidebar-visible threads are tracked in the local `threads` table, which includes `model_provider`, `archived`, `cwd`, `title`, `updated_at`, `source`, and `thread_source`.
- found that the local global state included `agent-mode-by-host-id` and `selected-remote-host-id`, but the actual history problem was not login/auth; it was local metadata and filtering.
- discovered the app was rewriting thread metadata from JSONL rollouts back into the SQLite state, so changing only the database was not durable.

Failures and how to do differently:
- initial attempts changed only one layer (SQLite or the index), and the app could restore the old provider/title state from `rollout-*.jsonl`; future similar fixes should update both the database and the source rollout files together.
- a few runs misread or over-assumed the provider split; the durable fix was to verify the exact local state fields and then edit them directly.
- when `rg` was pointed at Windows paths, it sometimes failed due to path syntax or regex issues; use narrower, correctly quoted paths or Python/SQLite for verification instead.

Reusable knowledge:
- the sidebar history is backed by local state, not just the visible chat UI: `C:\Users\t250c\.codex\state_5.sqlite`, `C:\Users\t250c\.codex\session_index.jsonl`, `C:\Users\t250c\.codex\.codex-global-state.json`, plus the per-thread `rollout-*.jsonl` files.
- the `threads` table is the decisive source for sidebar-visible history; its schema includes `model_provider`, `archived`, `cwd`, `title`, `updated_at`, `source`, `thread_source`, `preview`, and `has_user_event`.
- the app can scan rollout JSONL files and repopulate thread metadata, so a durable history change must keep SQLite and the rollout file in sync.
- the local state includes a host-level mode selector (`agent-mode-by-host-id`) and remote host tracking, but the user’s issue here was solved by normalizing local history metadata rather than altering auth or remote connection state.

References:
- [1] `C:\Users\t250c\.codex\state_5.sqlite` table schema check showed `threads(id, rollout_path, created_at, updated_at, source, model_provider, cwd, title, archived, archived_at, ... , preview)`.
- [2] `C:\Users\t250c\.codex\.codex-global-state.json` contained `agent-mode-by-host-id:{"local":"custom"}`, `selected-remote-host-id`, `project-order`, `active-workspace-roots`, and `thread-workspace-root-hints`.
- [3] The provider split was confirmed by querying the local DB, which at one point showed `('openai', 37)`, `('cc-shared', 1)`, then after unification `('openai', 38)`.
- [4] The rollback source was the rollout metadata itself: the first JSON object in each `rollout-*.jsonl` carried `payload.model_provider`, and that had to be updated alongside the database.
- [5] The user’s decisive steering was: "不要分流，要在一起。" and later "好。只要不影响我切换账户。"

## Task 2: Merge provider-specific history into one visible sidebar history

Outcome: success

Preference signals:
- the user explicitly rejected provider-based separation and wanted continuity preserved across switching accounts/providers -> future work should default to unifying local history metadata instead of preserving provider splits.
- the user asked that switching accounts not be impacted -> future edits should avoid `auth.json` and login state and focus on local history metadata only.

Key steps:
- backed up the affected local files before editing: `state_5.sqlite`, `session_index.jsonl`, and `.codex-global-state.json`.
- changed provider metadata in the local `threads` table so historical threads no longer split by provider; later the DB ended up with `model_provider = openai` for all 38 threads.
- updated per-thread rollout source files under `sessions` and `archived_sessions` so the provider scan repair would not revert the DB changes.
- unified the remaining archived/custom threads by moving them to `openai` and then unarchiving the relevant ones so they reappeared in the main sidebar list.
- repaired titles on the same local history set so the sidebar entries were readable instead of mojibake/garbled, keeping the DB, `session_index.jsonl`, and rollout files aligned.

Failures and how to do differently:
- a few steps initially changed the DB but not the rollout source, which allowed the app to repair the old state back in; the durable pattern is: edit SQLite + edit the rollout JSONL source + verify both.
- changing `session_index.jsonl` alone was not enough; it is a secondary index, not the source of truth.
- the app can preserve or restore `archived` state separately from provider; if the goal is to make history visible in the sidebar, unarchiving may be required after provider normalization.

Reusable knowledge:
- the provider split was local metadata, not login credentials: the final successful normalization changed local history files and DB without touching `auth.json`.
- the only durable fix for sidebar continuity was to normalize provider labels to a single value across all local history sources.
- for visible continuity, both `archived` and `updated_at` matter: after unarchiving, bumping `updated_at` made the restored threads appear near the top of the sidebar.
- titles can be repaired in the same pass as provider unification; keep the local DB and rollout files consistent to avoid re-encoding/repair drift.

References:
- [1] Backup files created before the final merge/unarchive pass: `C:\Users\t250c\.codex\state_5.sqlite.bak-history-provider-unify-20260602-1408xx`, `C:\Users\t250c\.codex\session_index.jsonl.bak-history-provider-unify-20260602-1408xx`, and `C:\Users\t250c\.codex\.codex-global-state.json.bak-history-provider-unify-20260602-1408xx`.
- [2] Final DB state check: `select model_provider, count(*) from threads group by model_provider` returned only `('openai', 38)`.
- [3] The final verification on the local state showed no remaining `custom` / `cc-shared` history labels in the thread table; the user’s target behavior was achieved by keeping old tasks visible and resumable after account/provider switching.
- [4] The title repair pass updated the readable labels for the sidebar-visible threads, while keeping `session_index.jsonl` and rollout metadata aligned.
- [5] The user’s acceptance after the unification was explicit: "这才对啊。" and later "应该没问题了。"
