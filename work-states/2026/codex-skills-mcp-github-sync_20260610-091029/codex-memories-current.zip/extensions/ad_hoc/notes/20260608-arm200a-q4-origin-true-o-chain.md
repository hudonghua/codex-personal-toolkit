# Arm200A Q4/O and true O chain note

Date: 2026-06-08

Project:

`E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2`

Key decisions and current implementation:

- Q4 is the visible unified origin O. The upper PC sends Q1-Q4 only; B0=4 means Q4/O. B0=0 O is obsolete.
- Algorithm PCB localizes incoming Q points as:
  - `O = Q4_raw`
  - `Q1_local = Q1_raw - Q4_raw`
  - `Q2_local = Q2_raw - Q4_raw`
  - `Q3_local = Q3_raw - Q4_raw`
  - `Q4_local = 0,0,0`
- EEPROM store version is `0x00010008`; older versions are migrated by treating old Q4 as new O and clearing local Q4.
- Important correction: after O is computed, all downstream points must be based on the real O coordinate, not on old V1 display coordinate `O - O0`.
  - Correct chain: `B = O + OB`, then `A = B + rotated(BA)`, `C = A + rotated(AC)`, ... `H = G1 + rotated(G1H)`.
  - Firmware correction in `Src\Arm200A_Kine.c`: for both side arms, `calc_o = out->o`.
  - Body->World correction: `B/A/C/.../H/H1` are already real Body coordinates, so `arm_body_to_world_result()` must directly apply `arm_apply_coord_point(body_out->b, in)` etc.; do not add `O0` again.
- Left/right base constants were updated:
  - Left O0 `(-1037, 340, 1040)`, O0->O1 `(0, 670.342, -1867.324)`, O1->O `(597, 50, 1005)`.
  - Right O0 `(-1037, -340, 1040)`, O0->O1 `(0, -670.342, -1867.324)`, O1->O `(597, -50, 1005)`.
- HTML calculator `E:\AI_划时代\全电脑_算法PCB\V1_参考点.html` is the current matching calculator. It uses the true O chain and was checked with `B-O=(165,0,702.5)`.
- Keil FLASH builds after the changes passed with 0 errors and only the existing `messageshow` warning.

When resuming this project, verify against the live files, but preserve this coordinate rule: Q4 defines O, and O->B plus the rest of the chain are fixed relative to real O.
