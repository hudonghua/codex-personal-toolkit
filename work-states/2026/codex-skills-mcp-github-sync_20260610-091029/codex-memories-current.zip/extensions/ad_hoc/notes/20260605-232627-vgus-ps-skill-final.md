The user explicitly asked to save the confirmed diesel-engine instrument PSD workflow as a skill for future similar images.

Updated global skill:
- `C:\Users\t250c\.codex\skills\ps\SKILL.md`
- Added reusable script: `C:\Users\t250c\.codex\skills\ps\scripts\generate_vgus_diesel_grayscale_psd.py`

Final confirmed workflow:
- Similar "ps", "图片", engineering instrument, VGUS, HMI, PSD tasks should use the `ps` skill.
- For VGUS screens, output static-background PSDs and avoid baking dynamic values into the image.
- Split parameter cards into `box`, `label`, and `unit` layers, so labels like `水温` and units like `℃` can be edited later.
- Split `MONO ENGINEERING` or similar header text into its own layer.
- Keep gauge scale/ticks separate from `tachometer_pointer`.
- Pointer is a visual highlight: use one restrained highlight color, keep it slim, and also export a pointer PNG when useful.
- Navigation bar must include 8 button slots, including two blank slot buttons when unused.
- Use `psd-tools` RGBA `create_pixel_layer` workflow with cropped alpha bounds.
- Always provide clickable file and directory links in final responses.
