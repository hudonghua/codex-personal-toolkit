# Arm200A mechanical error fitting priority and storage

Project: `E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2`

On 2026-06-08, the mechanical error fitting policy was changed after discussion with the user:

- The sample pool still requires at least 20 samples before mechanical error fitting.
- Fitting still compares `H_ref = H_total_station - Q4_total_station` against the algorithm result after `Body->World`; this is the correct referee standard because the total-station value is in World axes.
- A2 CAN sample intake is intentionally left for a later step.
- The 22 mechanical error scalars are now fitted with priority:
  - Stage 0 opens only the O-E/main-structure scalars, indices 0-14 where available.
  - If Stage 0 already satisfies `fit->ok` (`count >= 20` and `max_mm <= 30`), Stage 1 is skipped.
  - Stage 1 opens the rear/end scalars, indices 15-21, as fine adjustment only when Stage 0 is not enough.
  - Mid arm has no O0 chain, so indices 0-4 remain disabled.
- This prevents rear/end parameters such as F-G and G1-H from absorbing errors that should belong to the O-E main structure.

Source change:

- `Src\Arm200A_Kine.c`
  - Added `arm_fit_stage_index_enabled()`.
  - Added `arm_init_fix_stage_step()`.
  - Updated `arm_fit_one()` to run two fitting stages.

Persistence check:

- `Src\Arm200A_Store.c` already persists and restores:
  - left/mid/right `fix` arrays,
  - left/mid/right mechanical error sample pools,
  - left/mid/right fitting info.
- No store version bump was needed because no persistent structure layout changed.

Verification:

- Keil FLASH build was run with `C:\Keil_v5\UV4\UV4.exe`.
- Build log: `keil_rebuild_FLASH_fit_priority.log`.
- Result: 0 errors, 1 existing warning for deprecated `messageshow` declaration.
