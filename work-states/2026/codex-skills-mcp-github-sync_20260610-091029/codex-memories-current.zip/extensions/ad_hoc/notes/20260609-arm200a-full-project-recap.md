# Arm200A full project recap memory

For `E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2`, the current project-level handoff is in `Codex_无缝交接_20260607-201828\14_全项目复盘_协议算法_20260609.md`.

Core current rules:

- `Q4` is the unified reference origin `O`. `Q_body` is factory/mechanical local prism data sent by `0x50/B7=0xA1`; `Q_world` is site total-station data sent by `0x50/B7=0xA3`. Algorithm PCB localizes both by subtracting Q4.
- Algorithm PCB first computes Body forward kinematics, then applies Body->World R/T. `Arm200A_CoordCalib()` requires both `Q_body` and `Q_world`; Q1-Q3 build bases, Q4 is origin/residual. A3 success feedback is `0x150/B0=0xE0/B1=0x00/B2=0x03/B3=0x00/B4=0x04/B7=0xA3`.
- Dual-axis roll/pitch from `0x28F` is not absolute compensation before A3. A3 success locks current dual-axis values as zero; later only roll/pitch deltas are applied.
- A2 mechanical error samples use `0x50/B7=0xA2`; Qt sends `H_ref = H_total_station - Q4_total_station`. Algorithm PCB grabs current encoder pose when the A2 sample arrives. Minimum fit count is 20.
- Mechanical fit uses 22 fix scalars with staged priority: stage 0 opens indexes 0-14 for O-E main structure; stage 1 opens 15-21 for F-H tail fine tuning only if needed. Success is count >=20 and max error <=30mm.
- Algorithm PCB persists zero config, Q/R-T/dual-axis zero, and final left/mid/right 22 fix values. It does not persist A2 sample pools, fit temporary stats, or sample pose history; Qt owns those records and can use `0x154` snapshots.
- `0x17E` and `0x153` are cross-end links: `0x17E` is vehicle PCB CAN1 -> algorithm PCB CAN2 self-parallel init trigger (`B7 b0/b1/b2`), and `0x153` is algorithm PCB CAN2 -> PC and vehicle PCB CAN1 (B0-B5 depth, B6-B7 self-parallel direction).
- User clarified `0x71/0x75/0x7A/0x50(B7=0x51)` do not need per-frame ACK because they are continually sent on the bus. For start/reset result handling, use existing vehicle status/alarm/interlock bits once mapped.
- `gArmG1HLenMm` exists as a code parameter defaulting to 1831.5mm, but protocol downlink and persistence were not found; treat it as reserved but not product-chain complete.
