# Automation: 每周工作状态更新 Automation ID: automation Automation me

- Session id: `019e5cf4-1b3d-7400-94fd-6bfc60d1c3fd`
- Source cwd: `E:\工作`
- Model provider: `openai`
- Exported at: `2026-05-27T17:28:25`
- Local source: `C:\Users\t250c\.codex\sessions\2026\05\25\rollout-2026-05-25T10-26-02-019e5cf4-1b3d-7400-94fd-6bfc60d1c3fd.jsonl`

## Transcript

### developer 2026-05-25T02:26:05.623Z

```text
<permissions instructions>
Filesystem sandboxing defines which files can be read or written. `sandbox_mode` is `danger-full-access`: No filesystem sandboxing - all commands are permitted. Network access is enabled.
Approval policy is currently never. Do not provide the `sandbox_permissions` for any reason, commands will be rejected.
</permissions instructions>
Response MUST end with a remark-directive block.

## Responding

- Answer the user normally and concisely. Explain what you found, what you did, and what the user should focus on now.
- Automations: use the memory file at `$CODEX_HOME/automations/<automation_id>/memory.md` (create it if missing).
  - Read it first (if present) to avoid repeating recent work, especially for "changes since last run" tasks.
  - Memory is important: some tasks must build on prior work, and others must avoid duplicating prior focus.
  - Before returning the directive, write a concise summary of what you did/decided plus the current run time.
  - Use the `Automation ID:` value provided in the message to locate/update this file.
- REQUIRED: End with a valid remark-directive block on its own line (not inline).
  - Always include an inbox item directive:
    `::inbox-item{title="Sample title" summary="Place description here"}`

## Choosing return value

- For recurring/bg threads (e.g., "pull datadog logs and fix any new bugs", "address the PR comments"):
  - Always return `::inbox-item{...}` with the title/summary the user should see.

## Guidelines

- Directives MUST be on their own line.
- Output exactly ONE inbox-item directive.
- Do NOT use invalid remark-directive formatting.
- DO NOT place commas between arguments.
  - Valid: `::inbox-item{title="Sample title" summary="Place description here"}`
  - Invalid: `::inbox-item{title="Sample title",summary="Place description here"}`
- When referring to files, use full absolute filesystem links in Markdown (not relative paths).
  - Valid: [`/Users/alice/project/src/main.ts`](/Users/alice/project/src/main.ts)
  - Invalid: `src/main.ts` or `[main](src/main.ts)`
- Try not to ask the user for more input if possible to infer.
- If a PR is opened by the automation, add the `codex-automation` label when available alongside the normal `codex` label.
- Inbox item copy should be glanceable and specific (avoid "Update", "Done", "FYI", "Following up").
  - Title: what this thread now _is_ (state + object). Aim ~4-8 words.
  - Title should explain what was built or what happened.
- Summary: what the user should _do/know next_ (next step, blocker, or waiting-on). Aim ~6-14 words.
- Summary should usually match the general automation name or prompt summary.
- Both title and summary should be fairly short; usually avoid one-word titles/summaries.
  - Prefer concrete nouns + verbs; include a crisp status cue when helpful: "blocked", "needs decision", "ready for review".

## Examples (inbox-item)

- Work needed:
  - `::inbox-item{title="Fix flaky checkout tests" summary="Repro isolated; needs CI run + patch"}`
- Waiting on user decision:
  - `::inbox-item{title="Choose API shape for filters" summary="Two options drafted; pick A vs B"}`
- Status update with next step:
  - `::inbox-item{title="PR comments addressed" summary="Ready for re-review; focus on auth edge case"}`

<app-context>
# Codex desktop context
- You are running inside the Codex (desktop) app, which allows some additional features not available in the CLI alone:

### Images/Visuals/Files
- In the app, the model can display images and videos using standard Markdown image syntax: ![alt](url)
- When sending or referencing a local image or video, always use an absolute filesystem path in the Markdown image tag (e.g., ![alt](/absolute/path.png)); relative paths and plain text will not render the media.
- When referencing code or workspace files in responses, always use full absolute file paths instead of relative paths.
- If a user asks about an image, or asks you to create an image, it is often a good idea to show the image to them in your response.
- Use mermaid diagrams to represent complex diagrams, graphs, or workflows. Use quoted Mermaid node labels when text contains parentheses or punctuation.
- Return web URLs as Markdown links (e.g., [label](https://example.com)).

### Automations
- This app supports recurring automations, reminders, monitors, follow-ups, and thread wakeups. When the user asks to create, view, update, delete, or ask about automations, search for the `automation_update` tool first, then follow its schema instead of writing raw automation directives by hand.

### Inline Code Comments
- Use the ::code-comment{...} directive when you need to attach feedback directly to specific code lines.
- Emit one directive per inline comment; emit none when there are no actionable inline comments.
- Required attributes: title (short label), body (one-paragraph explanation), file (path to the file).
- Optional attributes: start, end (1-based line numbers), priority (0-3).
- file should be an absolute path or include the workspace folder segment so it can be resolved relative to the workspace.
- Keep line ranges tight; end defaults to start.
- Example: ::code-comment{title="[P2] Off-by-one" body="Loop iterates past the end when length is 0." file="/path/to/foo.ts" start=10 end=11 priority=2}

### Archiving
- If a user specifically asks you to end a thread/conversation, you can return the archive directive ::archive{...} to archive the thread/conversation.
- Example: ::archive{reason="User requested to end conversation"}
</app-context>
<apps_instructions>
## Apps (Connectors)
Apps (Connectors) can be explicitly triggered in user messages in the format `[$app-name](app://{connector_id})`. Apps can also be implicitly triggered as long as the context suggests usage of available apps.
An app is equivalent to a set of MCP tools within the `codex_apps` MCP.
An installed app's MCP tools are either provided to you already, or can be lazy-loaded through the `tool_search` tool. If `tool_search` is available, the apps that are searchable by `tools_search` will be listed by it.
Do not additionally call list_mcp_resources or list_mcp_resource_templates for apps.
</apps_instructions>
<skills_instructions>
## Skills
A skill is a set of local instructions to follow that is stored in a `SKILL.md` file. Below is the list of skills that can be used. Each entry includes a name, description, and file path so you can open the source for full instructions when using a specific skill.
### Available skills
- imagegen: Generate or edit raster images when the task benefits from AI-created bitmap visuals such as photos, illustrations, textures, sprites, mockups, or transparent-background cutouts. Use when Codex should create a brand-new image, transform an existing image, or derive visual variants from references, and the output should be a bitmap asset rather than repo-native code or vector. Do not use when the task is better handled by editing existing SVG/vector/code-native assets, extending an established icon or logo system, or building the visual directly in HTML/CSS/canvas. (file: C:/Users/t250c/.codex/skills/.system/imagegen/SKILL.md)
- openai-docs: Use when the user asks how to build with OpenAI products or APIs and needs up-to-date official documentation with citations, help choosing the latest model for a use case, or model upgrade and prompt-upgrade guidance; prioritize OpenAI docs MCP tools, use bundled references only as helper context, and restrict any fallback browsing to official OpenAI domains. (file: C:/Users/t250c/.codex/skills/.system/openai-docs/SKILL.md)
- plugin-creator: Create and scaffold plugin directories for Codex with a required `.codex-plugin/plugin.json`, optional plugin folders/files, valid manifest defaults, and personal-marketplace entries by default. Use when Codex needs to create a new personal plugin, add optional plugin structure, or generate or update marketplace entries for plugin ordering and availability metadata. (file: C:/Users/t250c/.codex/skills/.system/plugin-creator/SKILL.md)
- skill-creator: Guide for creating effective skills. This skill should be used when users want to create a new skill (or update an existing skill) that extends Codex's capabilities with specialized knowledge, workflows, or tool integrations. (file: C:/Users/t250c/.codex/skills/.system/skill-creator/SKILL.md)
- skill-installer: Install Codex skills into $CODEX_HOME/skills from a curated list or a GitHub repo path. Use when a user asks to list installable skills, install a curated skill, or install a skill from another repo (including private repos). (file: C:/Users/t250c/.codex/skills/.system/skill-installer/SKILL.md)
- arm-cortex-expert: ARM Cortex-M embedded development guidance for startup, vector table, NVIC, SysTick, low power, DMA, cache coherency, MPU, fault diagnosis, GPIO/peripheral registers, STM32/nRF/SAMD/RP2040-style MCUs, and real-time firmware debugging. (file: C:/Users/t250c/.codex/skills/arm-cortex-expert/SKILL.md)
- browser:browser: Browser automation for the Codex in-app browser. Use to open, navigate, inspect, test, click, type, screenshot, or verify local targets such as localhost, 127.0.0.1, ::1, file://, the current in-app browser tab, and websites shown side by side inside Codex. (file: C:/Users/t250c/.codex/plugins/cache/openai-bundled/browser/26.519.41501/skills/browser/SKILL.md)
- chat-transcript-uploader: Export local Codex chat/session records to timestamped documents and upload them to the user's GitHub toolkit repository. Use for explicit chat transcript/archive requests. For standalone "上传", prefer work-continuity-sync. (file: C:/Users/t250c/.codex/skills/chat-transcript-uploader/SKILL.md)
- documents:documents: Create, edit, redline, and comment on `.docx`, Word, and Google Docs-targeted document artifacts inside the container, with a strict render-and-verify workflow. Use `render_docx.py` to generate page PNGs (and optional PDF) for visual QA, then iterate until layout is flawless before delivering the final document. (file: C:/Users/t250c/.codex/plugins/cache/openai-primary-runtime/documents/26.521.10419/skills/documents/SKILL.md)
- embedded-systems: Use when developing firmware for microcontrollers, implementing RTOS applications, or optimizing power consumption. Invoke for STM32, ESP32, FreeRTOS, bare-metal, power optimization, real-time systems, configure peripherals, write interrupt handlers, implement DMA transfers, debug timing issues. (file: C:/Users/t250c/.codex/skills/embedded-systems/SKILL.md)
- esp32: ESP32 embedded development guidance focused on GPIO conflicts, strapping pins, ADC2 with WiFi, deep sleep wake pins, FreeRTOS pitfalls, memory, peripherals, OTA, and power stability. (file: C:/Users/t250c/.codex/skills/esp32/SKILL.md)
- external-record-continuity: Use when the user provides records from a USB drive, GitHub toolkit upload, Cursor/Codex transcripts, or old-machine skill folders and asks Codex to read them, learn them, merge useful lessons, or continue previous work. (file: C:/Users/t250c/.codex/skills/external-record-continuity/SKILL.md)
- firmware-binary-reverse: MCU and embedded firmware binary workflow for .bin/.hex/.elf/.axf analysis, byte patching, version comparison, checksum/CRC repair, Keil/MDK firmware verification, fixed-address parameter edits, and safe documentation. Use for user-owned firmware images and pair with keil5-embedded-c for source-level work. (file: C:/Users/t250c/.codex/skills/firmware-binary-reverse/SKILL.md)
- github:gh-address-comments: Address actionable GitHub pull request review feedback. Use when the user wants to inspect unresolved review threads, requested changes, or inline review comments on a PR, then implement selected fixes. Use the GitHub app for PR metadata and flat comment reads, and use the bundled GraphQL script via `gh` whenever thread-level state, resolution status, or inline review context matters. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/github/6188456f/skills/gh-address-comments/SKILL.md)
- github:gh-fix-ci: Use when a user asks to debug or fix failing GitHub PR checks that run in GitHub Actions. Use the GitHub app from this plugin for PR metadata and patch context, and use `gh` for Actions check and log inspection before implementing any approved fix. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/github/6188456f/skills/gh-fix-ci/SKILL.md)
- github:github: Triage and orient GitHub repository, pull request, and issue work through the connected GitHub app. Use when the user asks for general GitHub help, wants PR or issue summaries, or needs repository context before choosing a more specific GitHub workflow. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/github/6188456f/skills/github/SKILL.md)
- github:yeet: Publish local changes to GitHub by confirming scope, committing intentionally, pushing the branch, and opening a draft PR through the GitHub app from this plugin, with `gh` used only as a fallback where connector coverage is insufficient. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/github/6188456f/skills/yeet/SKILL.md)
- keil5-embedded-c: Keil5 and embedded C firmware workflow for hardware-related work. Use when Codex works on Keil/uVision projects, C51/ARM/MCU/单片机 code, GBK C files, timers/定时器, interrupts/中断, IO/ADC/PWM/CAN/UART/RS485 protocols/硬件协议, screen/屏端 integration, bin/hex verification, protocol documents/协议文档, or embedded C code changes where correctness depends on real code paths and device behavior. (file: C:/Users/t250c/.codex/skills/keil5-embedded-c/SKILL.md)
- mcu-gpio-peripheral: MCU GPIO and peripheral bring-up workflow for embedded C/Keil/MDK projects. Covers input/output, pullup/pulldown, push-pull/open-drain, alternate functions, EXTI interrupts, debounce, ADC/PWM/UART/I2C/SPI pin conflicts, schematics, register/HAL checks, and Chinese embedded-code conventions. (file: C:/Users/t250c/.codex/skills/mcu-gpio-peripheral/SKILL.md)
- multi-computer-toolkit-merge: Merge Codex toolkit uploads from multiple computers. Use when another computer has its own skills, MCP servers, work-states, memory/sqlite records, or task snapshots that need to be integrated without overwriting local work. (file: C:/Users/t250c/.codex/skills/multi-computer-toolkit-merge/SKILL.md)
- openai-developers:agents-sdk: Build, run, deploy, and evaluate OpenAI Agents SDK apps from Codex. Use when the user asks to create or adapt an Agents SDK app, build from a prompt or Codex thread, prepare a runnable agent prototype, add a focused eval harness, or deploy locally through the Agents SDK Deployment Manager. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/openai-developers/6188456f/skills/agents-sdk/SKILL.md)
- openai-developers:build-chatgpt-app: Build, scaffold, refactor, and troubleshoot ChatGPT Apps SDK applications that combine an MCP server and widget UI. Use when Codex needs to design tools, register UI resources, wire the MCP Apps bridge or ChatGPT compatibility APIs, apply Apps SDK metadata or CSP or domain settings, or produce a docs-aligned project scaffold. Prefer a docs-first workflow by invoking the openai-docs skill or OpenAI developer docs MCP tools before generating code. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/openai-developers/6188456f/skills/build-chatgpt-app/SKILL.md)
- openai-developers:chatgpt-app-submission: Inspect a ChatGPT Apps MCP server codebase and generate chatgpt-app-submission.json with app info suggestions, tool hint justifications, test cases, and negative test cases, then report review-check findings and outputSchema warnings for submission review. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/openai-developers/6188456f/skills/chatgpt-app-submission/SKILL.md)
- openai-developers:openai-api-troubleshooting: Use when an OpenAI API request fails and Codex needs to classify the likely cause, explain the next step, and route to the right follow-up. Covers common runtime failures such as blocked outbound network access, invalid credentials, exhausted API quota or credits, rate limits, and model, project, or organization access issues; delegate key provisioning to openai-platform-api-key and current documentation lookups to openai-docs. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/openai-developers/6188456f/skills/openai-api-troubleshooting/SKILL.md)
- openai-developers:openai-platform-api-key=***REDACTED*** for building, running, testing, debugging, or configuring apps, UIs, scripts, CLIs, generators, and tools that use AI, including AI-powered apps, apps that generate output with AI, and user-input-driven AI features. Treat unspecified AI in build requests as OpenAI API usage unless the user names another provider or says not to use OpenAI. First inspect credentials safely, then ask whether to reuse an existing key or create one before API-dependent implementation. Also use for OPENAI_API_KEY or sk-proj setup requests. Never expose plaintext. (file: C:/Users/t250c/.codex/plugins/cache/openai-curated/openai-developers/6188456f/skills/openai-platform-api-key/SKILL.md)
- opencv: OpenCV computer vision library. Use for image processing. (file: C:/Users/t250c/.codex/skills/opencv-g1joshi/SKILL.md)
- opencv: You are an expert in OpenCV (Open Source Computer Vision Library), the most popular library for real-time computer vision. You help developers build image processing pipelines, object detection systems, video analysis tools, augmented reality, and document processing using OpenCV's 2,500+ algorithms for image manipulation, feature detection, camera calibration, 3D reconstruction, and DNN inference — in Python, C++, or JavaScript. (file: C:/Users/t250c/.codex/skills/opencv-terminalskills/SKILL.md)
- pdf: Use when tasks involve reading, creating, or reviewing PDF files where rendering and layout matter; prefer visual checks by rendering pages (Poppler) and use Python tools such as `reportlab`, `pdfplumber`, and `pypdf` for generation and extraction. (file: C:/Users/t250c/.codex/skills/pdf/SKILL.md)
- presentations:Presentations: Build PowerPoint PPTX decks with artifact-tool presentation JSX (file: C:/Users/t250c/.codex/plugins/cache/openai-primary-runtime/presentations/26.521.10419/skills/presentations/SKILL.md)
- radare2: Radare2 reverse-engineering workflow for binary analysis, disassembly, function discovery, strings, cross references, binary diffing, and safe patch planning. Use when analyzing or patching executables, firmware blobs, ELF/PE/Mach-O files, or raw binaries with r2/rabin2/rahash2/radiff2/rasm2. (file: C:/Users/t250c/.codex/skills/radare2/SKILL.md)
- reverse_engineer: Systematic binary reverse engineering toolkit. Extract source code, understand functions, document protocols, compare versions. Uses strings, symbols, disassembly, and differential verification. (file: C:/Users/t250c/.codex/skills/reverse_engineer/SKILL.md)
- security-best-practices: Perform language and framework specific security best-practice reviews and suggest improvements. Trigger only when the user explicitly requests security best practices guidance, a security review/report, or secure-by-default coding help. Trigger only for supported languages (python, javascript/typescript, go). Do not trigger for general code review, debugging, or non-security tasks. (file: C:/Users/t250c/.codex/skills/security-best-practices/SKILL.md)
- security-threat-model: Repository-grounded threat modeling that enumerates trust boundaries, assets, attacker capabilities, abuse paths, and mitigations, and writes a concise Markdown threat model. Trigger only when the user explicitly asks to threat model a codebase or path, enumerate threats/abuse paths, or perform AppSec threat modeling. Do not trigger for general architecture summaries, code review, or non-security design work. (file: C:/Users/t250c/.codex/skills/security-threat-model/SKILL.md)
- senior-computer-vision: Computer vision engineering skill for object detection, image segmentation, and visual AI systems. Covers CNN and Vision Transformer architectures, YOLO/Faster R-CNN/DETR detection, Mask R-CNN/SAM segmentation, and production deployment with ONNX/TensorRT. Includes PyTorch, torchvision, Ultralytics, Detectron2, and MMDetection frameworks. Use when building detection pipelines, training custom models, optimizing inference, or deploying vision systems. (file: C:/Users/t250c/.codex/skills/senior-computer-vision/SKILL.md)
- spreadsheets:Spreadsheets: Use this skill when a user requests to create, modify, analyze, visualize, or work with spreadsheet files (`.xlsx`, `.xls`, `.csv`, `.tsv`) or Google Sheets-targeted spreadsheet artifacts with formulas, formatting, charts, tables, and recalculation. (file: C:/Users/t250c/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.521.10419/skills/spreadsheets/SKILL.md)
- survey-data-processor: Survey data processing for total-station, GNSS, leveling, point clouds, DTM/TIN generation, coordinate transformation, traverse adjustment, level-loop adjustment, contour generation, and survey deliverables. Use when processing field survey observations, control points, adjusted coordinates, or measurement workbooks. (file: C:/Users/t250c/.codex/skills/survey-data-processor/SKILL.md)
- total-station-calibration: Total station calibration and error-analysis workflow. Use for total-station instrument checks, collimation error, trunnion-axis error, vertical-index error, EDM additive/multiplicative constants, prism constant, atmospheric correction, two-face observations, resection checks, calibration records, and Excel-based calibration calculations. (file: C:/Users/t250c/.codex/skills/total-station-calibration/SKILL.md)
- work-continuity-sync: Triggered when the user says "上传" as a standalone command or asks for seamless work handoff across computers. Create and upload a complete work-state snapshot including current workspace, session transcript/raw record, skills/MCP/toolkit state, Memory/SQLite records when available, and restore instructions. (file: C:/Users/t250c/.codex/skills/work-continuity-sync/SKILL.md)
- workflow-memory-skillsmith: Mandatory workflow for turning repeated task lessons, tool discoveries, failure fixes, user-specific procedures, and practical troubleshooting records into global Codex skills under ~/.codex/skills. Use after tasks that reveal reusable methods, recurring failure patterns, installation fixes, domain procedures, or user-provided operational notes. (file: C:/Users/t250c/.codex/skills/workflow-memory-skillsmith/SKILL.md)
### How to use skills
- Discovery: The list above is the skills available in this session (name + description + file path). Skill bodies live on disk at the listed paths.
- Trigger rules: If the user names a skill (with `$SkillName` or plain text) OR the task clearly matches a skill's description shown above, you must use that skill for that turn. Multiple mentions mean use them all. Do not carry skills across turns unless re-mentioned.
- Missing/blocked: If a named skill isn't in the list or the path can't be read, say so briefly and continue with the best fallback.
- How to use a skill (progressive disclosure):
  1) After deciding to use a skill, open its `SKILL.md`. Read only enough to follow the workflow.
  2) When `SKILL.md` references relative paths (e.g., `scripts/foo.py`), resolve them relative to the skill directory listed above first, and only consider other paths if needed.
  3) If `SKILL.md` points to extra folders such as `references/`, load only the specific files needed for the request; don't bulk-load everything.
  4) If `scripts/` exist, prefer running or patching them instead of retyping large code blocks.
  5) If `assets/` or templates exist, reuse them instead of recreating from scratch.
- Coordination and sequencing:
  - If multiple skills apply, choose the minimal set that covers the request and state the order you'll use them.
  - Announce which skill(s) you're using and why (one short line). If you skip an obvious skill, say why.
- Context hygiene:
  - Keep context small: summarize long sections instead of pasting them; only load extra files when needed.
  - Avoid deep reference-chasing: prefer opening only files directly linked from `SKILL.md` unless you're blocked.
  - When variants exist (frameworks, providers, domains), pick only the relevant reference file(s) and note that choice.
- Safety and fallback: If a skill can't be applied cleanly (missing files, unclear instructions), state the issue, pick the next-best approach, and continue.
</skills_instructions>
<plugins_instructions>
## Plugins
A plugin is a local bundle of skills, MCP servers, and apps. Below is the list of plugins that are enabled and available in this session.
### Available plugins
- `Browser`: Browser / browser-use plugin Aliases: @browser, @browser-use, browser-use, Browser, in-app browser. Use Browser, the Codex in-app browser, when the user asks to open, inspect, navigate, test, click, type, or screenshot local web targets such as localhost, 127.0.0.1, ::1, file:// URLs, or the current in-app browser tab. After significant frontend changes to a local app, use Browser to open the relevant local target when it is known or obvious, unless the user asks for another browser tool. For requests like "open localhost:3000" or "open to localhost:4000", navigate the in-app browser to http://localhost:3000 or http://localhost:4000. Do not satisfy explicit @browser or @browser-use requests with macOS `open`, shell commands, or generic web browsing unless the user asks for another browser tool or approves a fallback.
- `Documents`: Create and edit document artifacts in Codex, including Word files and Google Docs.
- `GitHub`: Inspect repositories, triage pull requests and issues, debug CI, and publish changes through a hybrid GitHub connector and CLI workflow.
- `OpenAI Developers`: Build with OpenAI APIs, Agents SDK, and ChatGPT Apps, and create and save OpenAI API keys from Codex.
- `Presentations`: Create, edit, render, verify, and export presentation slide decks. Use when Codex needs to build or modify a deck, slidedeck, presentation deck, slide deck, slides, PowerPoint, Google Slides, PPT, PPTX, .ppt, or .pptx file.
- `Spreadsheets`: Create, edit, analyze, visualize, render, and export spreadsheets or Google Sheets-ready workbooks in Codex.
### How to use plugins
- Discovery: The list above is the plugins available in this session.
- Skill naming: If a plugin contributes skills, those skill entries are prefixed with `plugin_name:` in the Skills list.
- Trigger rules: If the user explicitly names a plugin, prefer capabilities associated with that plugin for that turn.
- Relationship to capabilities: Plugins are not invoked directly. Use their underlying skills, MCP tools, and app tools to help solve the task.
- Preference: When a relevant plugin is available, prefer using capabilities associated with that plugin over standalone capabilities that provide similar functionality.
- Missing/blocked: If the user requests a plugin that is not listed above, or the plugin does not have relevant callable capabilities for the task, say so briefly and continue with the best fallback.
</plugins_instructions>
## Memory

You have access to a memory folder with guidance from prior runs. It can save
time and help you stay consistent. Use it whenever it is likely to help.

Decision boundary: should you use memory for a new user query?

- Skip memory ONLY when the request is clearly self-contained and does not need
  workspace history, conventions, or prior decisions.
- Hard skip examples: current time/date, simple translation, simple sentence
  rewrite, one-line shell command, trivial formatting.
- Use memory by default when ANY of these are true:
  - the query mentions workspace/repo/module/path/files in MEMORY_SUMMARY below,
  - the user asks for prior context / consistency / previous decisions,
  - the task is ambiguous and could depend on earlier project choices,
  - the ask is a non-trivial and related to MEMORY_SUMMARY below.
- If unsure, do a quick memory pass.

Memory layout (general -> specific):

- C:\Users\t250c\.codex\memories/memory_summary.md (already provided below; do NOT open again)
- C:\Users\t250c\.codex\memories/MEMORY.md (searchable registry; primary file to query)
- C:\Users\t250c\.codex\memories/skills/<skill-name>/ (skill folder)
  - SKILL.md (entrypoint instructions)
  - scripts/ (optional helper scripts)
  - examples/ (optional example outputs)
  - templates/ (optional templates)
- C:\Users\t250c\.codex\memories/rollout_summaries/ (per-rollout recaps + evidence snippets)
  - The paths of these entries can be found in C:\Users\t250c\.codex\memories/MEMORY.md or C:\Users\t250c\.codex\memories/rollout_summaries/ as `rollout_path`
  - These files are append-only `jsonl`: `session_meta.payload.id` identifies the session, `turn_context` marks turn boundaries, `event_msg` is the lightweight status stream, and `response_item` contains actual messages, tool calls, and tool outputs.
  - For efficient lookup, prefer matching the filename suffix or `session_meta.payload.id`; avoid broad full-content scans unless needed.

Quick memory pass (when applicable):

1. Skim the MEMORY_SUMMARY below and extract task-relevant keywords.
2. Search C:\Users\t250c\.codex\memories/MEMORY.md using those keywords.
3. Only if MEMORY.md directly points to rollout summaries/skills, open the 1-2
   most relevant files under C:\Users\t250c\.codex\memories/rollout_summaries/ or
   C:\Users\t250c\.codex\memories/skills/.
4. If above are not clear and you need exact commands, error text, or precise evidence, search over `rollout_path` for more evidence.
5. If there are no relevant hits, stop memory lookup and continue normally.

Quick-pass budget:

- Keep memory lookup lightweight: ideally <= 4-6 search steps before main work.
- Avoid broad scans of all rollout summaries.

During execution: if you hit repeated errors, confusing behavior, or suspect
relevant prior context, redo the quick memory pass.

How to decide whether to verify memory:

- Consider both risk of drift and verification effort.
- If a fact is likely to drift and is cheap to verify, verify it before
  answering.
- If a fact is likely to drift but verification is expensive, slow, or
  disruptive, it is acceptable to answer from memory in an interactive turn,
  but you should say that it is memory-derived, note that it may be stale, and
  consider offering to refresh it live.
- If a fact is lower-drift and expensive to verify, it is usually fine to
  answer from memory directly.

When answering from memory without current verification:

- If you rely on memory for a fact that you did not verify in the current turn,
  say so briefly in the final answer.
- If that fact is plausibly drift-prone or comes from an older note, older
  snapshot, or prior run summary, say that it may be stale or outdated.
- If live verification was skipped and a refresh would be useful in the
  interactive context, consider offering to verify or refresh it live.
- Do not present unverified memory-derived facts as confirmed-current.
- Prefer a short refresh offer for interactive questions, especially about prior
  results, commands, timing, or older snapshots.

Memory citation requirements:

- If ANY relevant memory files were used: append exactly one
`<oai-mem-citation>` block as the VERY LAST content of the final reply.
  Normal responses should include the answer first, then append the
`<oai-mem-citation>` block at the end.
- Use this exact structure for programmatic parsing:
```
<oai-mem-citation>
<citation_entries>
MEMORY.md:234-236|note=[responsesapi citation extraction code pointer]
rollout_summaries/2026-02-17T21-23-02-LN3m-example.md:10-12|note=[weekly report format]
</citation_entries>
<rollout_ids>
019c6e27-e55b-73d1-87d8-4e01f1f75043
019c7714-3b77-74d1-9866-e1f484aae2ab
</rollout_ids>
</oai-mem-citation>
```
- `citation_entries` is for rendering:
  - one citation entry per line
  - format: `<file>:<line_start>-<line_end>|note=[<how memory was used>]`
  - use file paths relative to the memory base path (for example, `MEMORY.md`,
    `rollout_summaries/...`, `skills/...`)
  - only cite files actually used under the memory base path (do not cite
    workspace files as memory citations)
  - if you used `MEMORY.md` and then a rollout summary/skill file, cite both
  - list entries in order of importance (most important first)
  - `note` should be short, single-line, and use simple characters only (avoid
    unusual symbols, no newlines)
- `rollout_ids` is for us to track what previous rollouts you find useful:
  - include one rollout id per line
  - rollout ids should look like UUIDs (for example,
    `019c6e27-e55b-73d1-87d8-4e01f1f75043`)
  - include unique ids only; do not repeat ids
  - an empty `<rollout_ids>` section is allowed if no rollout ids are available
  - you can find rollout ids in rollout summary files and MEMORY.md
  - do not include file paths or notes in this section
  - For every `citation_entries`, try to find and cite the corresponding rollout id if possible
- Never include memory citations inside pull-request messages.
- Never cite blank lines; double-check ranges.

Updating memories:

You can update the memories **only** when explicitly asked by the user. This must always come from a direct request from the user.
- Write your update in C:\Users\t250c\.codex\memories/extensions/ad_hoc/notes/
- Each update must be one small file containing what you want to add/delete/update from the memories.
- The name of this file must be `<timestamp>-<short slug>.md`
- Do not try to edit the memory files yourself, only add one update note in C:\Users\t250c\.codex\memories/extensions/ad_hoc/notes/

========= MEMORY_SUMMARY BEGINS =========
v1

## User Profile
The user uses Codex as a practical Windows-side engineering partner. Their recurring work spans Keil/uVision embedded C, GBK/GB2312 legacy files, Codex desktop/tooling setup, GitHub-backed cross-computer continuity, and an industrial AprilTag + total-station calibration workflow. They care more about real evidence and runnable fixes than polished explanations.

They often work by pointing at a real path, repo, log, or device and expect the agent to inspect it directly. They also invest in durable reuse: when a rule, workflow, or imported record is valuable, they want it absorbed into memory/skills so future sessions and even other computers can continue with less re-explanation. In design work, they push the agent to challenge weak assumptions and define concrete validation metrics instead of preserving fragile legacy steps.

## User preferences
- When the user gives a literal path like `F:\memory` or a local project path, inspect that exact path first and report concrete findings before abstract discussion.
- When the user asks whether the agent can access or modify a program, answer with direct filesystem/project confirmation first.
- When the user says "restore memory", load local durable memory first, then confirm what was recovered before continuing.
- When the user mentions `skill` or gives a new task, infer needed skills proactively, search official/GitHub sources, and install or create the right one instead of waiting for exact skill names.
- Standalone "upload" means full work-state sync for cross-computer continuation, not transcript archiving.
- For embedded/code-edit tasks, proactively apply the learned discipline: backup first, preserve GBK/GB2312 when needed, trace real call paths, keep function boundaries tight, and verify after edits.
- When troubleshooting, start with read-only inspection of logs, processes, versions, and dependency state before proposing larger changes.
- In the AprilTag workflow, define error in world coordinates, challenge weak geometry directly, and prefer a prioritized execution plan over open-ended brainstorming.

## General Tips
- Environment baseline: Windows, PowerShell, user profile rooted at `C:\Users\t250c`; `cmd /c ...` or `codex.cmd ...` can be a safer fallback when PowerShell wrapper/policy issues appear.
- Cross-machine continuity lives around `C:\Users\t250c\.codex`, `C:\Users\t250c\Documents\Codex\codex-personal-toolkit`, and the private repo `hudonghua/codex-personal-toolkit`.
- If system `python`/`git` is missing, prefer bundled Python, portable Git/GitHub CLI, or PowerShell archive-copy workflows rather than blocking.
- For imported USB/old-machine records, search `.codex/history.jsonl`, `.codex/memories/MEMORY.md`, `.cursor/memory`, recent `agent-transcripts`, and `SKILL.md` files first; old transcripts are clues, not proof of current state.
- For Windows path/encoding issues, separate ACL/ownership, Codex writable scope, and terminal encoding as three different layers.
- For Codex desktop issues on this machine, `codex doctor --all` plus the newest package log under `...OpenAI.Codex_2p2nqsd0c76g0...\Logs\YYYY\MM\DD\` is the fastest first check.

## What's in Memory
### E:\工作

#### 2026-05-23

- GitHub-backed continuity from USB records: external-record-continuity, upload-work.ps1, work-states, F:\.codex\history.jsonl, agent-transcripts
  - desc: Search this first for "continue from uploaded records", USB/old-machine imports, or cross-computer resume/merge flows from `cwd=E:\工作`.
  - learnings: Jump straight to high-signal `.codex`/`.cursor` records, learn from them instead of copying blindly, then push a timestamped work-state snapshot to the toolkit repo.

- Embedded editing rules and camera-project recall check: backup before edit, GBK, call path, TagCenter_world_calc, total-station validation
  - desc: Routes to the user asking what to watch for during code edits and how much Codex already knows about the camera project from imported records.
  - learnings: Restate the exact embedded safety rules directly; treat remembered camera context as background until live files are re-read.

### C:\Users\t250c\Documents\Codex\2026-05-23\new-chat

#### 2026-05-23

- GBK skill repair and Windows permission layers: E:\IPMsg\gbk-garbled-comments, takeown, icacls, write-ok, utf8-chinese-ok
  - desc: Search this first for garbled Chinese skill/source files, E:/D: write-access questions, or "do I need to restart Codex after permission changes?" cases.
  - learnings: Separate ACLs, Codex writable scope, and terminal encoding; verify with a tiny temp-file write before the real overwrite.

- Lenovo Windows Hello face-login diagnosis: Lenovo Legion Y9000P IRX9, 83DF, pnputil, Biometric, SunplusIT, FaceCredentialProvider
  - desc: Routes to the hardware/driver-based answer for whether this exact laptop supports Windows Hello face login.
  - learnings: Vendor specs plus `pnputil` beat WMI/CIM here; software face-provider entries are not proof of IR hardware.

### C:\Users\t250c

#### 2026-05-23

- Codex desktop startup and connectivity troubleshooting: codex doctor --all, 127.0.0.1:10809, codex-app-proxy.cmd, ready-to-show, hasUpdate=true, git not in PATH
  - desc: Search this first for `codex app` login/connectivity/startup hangs from `cwd=C:\Users\t250c`.
  - learnings: Confirm proxy inheritance in the real environment first; if logs already show `ready-to-show` and `main frame finished load`, pivot to post-load/update/dependency issues.

#### 2026-05-21

- Skill auto-discovery, official installs, and toolkit setup: skill, openai/skills, keil5-embedded-c, pdf, security-best-practices, codex-personal-toolkit
  - desc: Covers the durable "infer needed skills and install them" default plus the first round of local skill/toolkit setup from `cwd=C:\Users\t250c`.
  - learnings: PowerShell archive-copy install worked when system Python was missing; the user expects proactive skill selection, not passive waiting.

- F: memory inspection, discipline import, and mixed-size AprilTag prompt: F:\memory, F:\skills, Get-Content -Encoding UTF8 -Raw, TagSize, 150mm, 300mm
  - desc: Search here for the original discipline-file ingestion flow and the first reusable camera-scheme prompt with mixed tag sizes.
  - learnings: Re-read suspect Chinese files with explicit UTF-8; mixed-size tags require explicit per-ID `TagSize` mapping.

### C:\Users\t250c\Documents\Codex\2026-05-22\new-chat-2

#### 2026-05-22

- Fixed-camera AprilTag validation plan: Q points, TagCenter_world_calc, TagCenter_world_measured, held-out tags, world-coordinate error
  - desc: Search this first for the deeper calibration/validation workflow when the user wants design direction rather than just a prompt.
  - learnings: Prefer direct world-measured control over weak shell references, and evaluate success with world-coordinate error rather than vague distance checks.

### Older Memory Topics

#### C:\Users\t250c

- Desktop Keil repo orientation and local login persistence: C:\Users\t250c\Desktop\KX_LCD70_200_10AI, MC_LCD7 - 10AI_V1.1.uvprojx, LPC1768, Src\main.c, auth.json
  - desc: Use this for the first-pass map of the desktop embedded project and the fact that local Codex CLI login state already existed under `cwd=C:\Users\t250c`.
========= MEMORY_SUMMARY ENDS =========

When memory is likely relevant, start with the quick memory pass above before
deep repo exploration.
```

### user 2026-05-25T02:26:05.623Z

```text
<environment_context>
  <cwd>E:\工作</cwd>
  <shell>powershell</shell>
  <current_date>2026-05-25</current_date>
  <timezone>Asia/Shanghai</timezone>
</environment_context>
```

### user 2026-05-25T02:26:05.628Z

```text
Automation: 每周工作状态更新
Automation ID: automation
Automation memory: $CODEX_HOME/automations/automation/memory.md
Last run: never

Review recent work activity in the workspace and draft a brief weekly status update. Summarize completed work, current in-progress items, blockers or risks, and suggested next steps. Keep it concise and ready to send or adapt.
```

### assistant 2026-05-25T02:26:16.215Z

```text
I’m reviewing recent activity under `E:\工作` and the automation memory first, then I’ll pull concrete workspace signals like git status, recent commits, and recently modified files to draft a concise weekly update.
```

### assistant 2026-05-25T02:26:28.915Z

```text
I’ve confirmed the workspace has two active Qt-related project folders updated on May 24-25. Next I’m checking git history and recent file changes inside each so the status update is grounded in actual work, not just folder timestamps.
```

### assistant 2026-05-25T02:26:43.801Z

```text
Neither project is a git repo, so the weekly summary needs to rely on source timestamps, build outputs, and the Qt setup scripts/logs in the workspace. I’m reading the project files and recent setup artifacts now to separate actual code work from environment setup.
```

### assistant 2026-05-25T02:26:55.729Z

```text
The concrete picture so far is: a Qt 6.8.3 toolchain was installed and verified with a built `QtSmokeTest.exe`, while the OpenCV-based template has source work but no matching build artifacts yet. I’m doing one last pass on build directories and dependency presence so the weekly note can call out the real blocker cleanly.
```

### assistant 2026-05-25T02:27:02.430Z

```text
I’ve confirmed there is no `QtOpenCVTemplate\build` directory and no separate OpenCV SDK path surfaced under `E:\`, so the main risk looks like dependency readiness rather than code churn. I’m packaging this into a short weekly update and then I’ll persist a concise run note into the automation memory.
```

### assistant 2026-05-25T02:27:13.051Z

```text
I’ve finished the evidence pass. I’m writing a short automation memory entry with the key findings so next week’s run can build on this instead of re-deriving the same Qt/toolchain context.
```

### assistant 2026-05-25T02:27:40.035Z

```text
每周状态更新草稿如下，已按 `E:\工作` 的实际文件活动整理，可直接发送或稍作改写：

本周完成：
- Qt 6.8.3 开发环境已落地到 `E:\Qt`，包含 Qt Creator、CMake、Ninja 和 MinGW 工具链。
- `QtSmokeTest` 已成功配置并生成可执行文件，说明 Qt 本地编译链路可用。
- 新建了 `QtOpenCVTemplate`，完成了基础 CMake 工程、主窗口框架、图片打开、灰度处理和 Canny 边缘显示示例。

当前进行中：
- 正在把 OpenCV 接入 Qt 模板，代码骨架已就位，但模板项目还没有生成 `build` 目录，暂未完成实际联调验证。

阻塞/风险：
- 目前主要风险不是 Qt，而是 OpenCV 依赖尚未明确就绪；工作区里还没看到可直接用于 `find_package(OpenCV)` 的独立 OpenCV SDK 路径。
- 两个项目都不是 Git 仓库，当前进展只能依赖本地时间戳和文件状态，后续追踪会比较弱。

下周建议：
- 先确认 OpenCV SDK 安装位置并完成 `QtOpenCVTemplate` 首次配置编译。
- 跑通一次真实图片加载与处理流程，确认运行时 DLL/`PATH` 配置。
- 视情况把两个项目纳入 Git，避免后续周报只能靠文件修改时间回溯。

::inbox-item{title="Qt environment and template status" summary="OpenCV hookup is next; verify first template build"}
```

### assistant 2026-05-25T02:27:40.045Z

```text
每周状态更新草稿如下，已按 `E:\工作` 的实际文件活动整理，可直接发送或稍作改写：

本周完成：
- Qt 6.8.3 开发环境已落地到 `E:\Qt`，包含 Qt Creator、CMake、Ninja 和 MinGW 工具链。
- `QtSmokeTest` 已成功配置并生成可执行文件，说明 Qt 本地编译链路可用。
- 新建了 `QtOpenCVTemplate`，完成了基础 CMake 工程、主窗口框架、图片打开、灰度处理和 Canny 边缘显示示例。

当前进行中：
- 正在把 OpenCV 接入 Qt 模板，代码骨架已就位，但模板项目还没有生成 `build` 目录，暂未完成实际联调验证。

阻塞/风险：
- 目前主要风险不是 Qt，而是 OpenCV 依赖尚未明确就绪；工作区里还没看到可直接用于 `find_package(OpenCV)` 的独立 OpenCV SDK 路径。
- 两个项目都不是 Git 仓库，当前进展只能依赖本地时间戳和文件状态，后续追踪会比较弱。

下周建议：
- 先确认 OpenCV SDK 安装位置并完成 `QtOpenCVTemplate` 首次配置编译。
- 跑通一次真实图片加载与处理流程，确认运行时 DLL/`PATH` 配置。
- 视情况把两个项目纳入 Git，避免后续周报只能靠文件修改时间回溯。

::inbox-item{title="Qt environment and template status" summary="OpenCV hookup is next; verify first template build"}
<oai-mem-citation>
<citation_entries>
MEMORY.md:109-111|note=[used prior workspace context for E-workspace AprilTag and active project continuity]
MEMORY.md:20-21|note=[used E-workspace continuity context to decide lightweight memory pass before live inspection]
</citation_entries>
<rollout_ids>
019e5557-3947-7a13-9966-302a1436f635
</rollout_ids>
</oai-mem-citation>
```
