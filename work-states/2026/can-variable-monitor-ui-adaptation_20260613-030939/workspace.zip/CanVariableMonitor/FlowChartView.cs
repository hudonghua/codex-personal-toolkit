using System.Drawing.Drawing2D;

namespace CanVariableMonitor;

internal sealed record FlowChartNode(string Id, string Text, RectangleF Bounds, ushort TraceId, string FunctionName = "", string Kind = "normal");

internal sealed record FlowChartEdge(string FromId, string ToId, string Label = "");

internal sealed class FlowChartView : ScrollableControl
{
    private readonly System.Windows.Forms.Timer _animationTimer = new();
    private IReadOnlyList<FlowChartNode> _nodes = Array.Empty<FlowChartNode>();
    private IReadOnlyList<FlowChartEdge> _edges = Array.Empty<FlowChartEdge>();
    private Dictionary<string, FlowChartNode> _nodeById = new(StringComparer.OrdinalIgnoreCase);
    private ushort _highlightTraceId = ushort.MaxValue;
    private int _animatedEdgeIndex;
    private float _animationProgress;
    private bool _animationEnabled;
    private Color _surface = Color.FromArgb(15, 23, 42);
    private Color _surfaceAlt = Color.FromArgb(20, 30, 48);
    private Color _ink = Color.FromArgb(229, 231, 235);
    private Color _muted = Color.FromArgb(148, 163, 184);
    private Color _accent = Color.FromArgb(14, 165, 233);
    private Color _line = Color.FromArgb(58, 50, 34);

    public event EventHandler<FlowChartNode>? NodeClick;
    public event EventHandler<FlowChartNode>? NodeDoubleClick;

    public FlowChartView()
    {
        DoubleBuffered = true;
        AutoScroll = true;
        BackColor = _surface;
        Font = new Font("Microsoft YaHei UI", 8.5f, FontStyle.Bold);
        _animationTimer.Interval = 140;
        _animationTimer.Tick += delegate
        {
            AdvanceAnimation();
        };
    }

    public void SetPalette(Color surface, Color surfaceAlt, Color ink, Color muted, Color accent, Color line)
    {
        _surface = surface;
        _surfaceAlt = surfaceAlt;
        _ink = ink;
        _muted = muted;
        _accent = accent;
        _line = line;
        BackColor = _surface;
        Invalidate();
    }

    public void SetGraph(IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges)
    {
        _nodes = nodes;
        _edges = edges;
        _nodeById = nodes.ToDictionary(n => n.Id, StringComparer.OrdinalIgnoreCase);
        _animatedEdgeIndex = 0;
        _animationProgress = 0f;
        RectangleF bounds = RectangleF.Empty;
        foreach (FlowChartNode node in nodes)
        {
            bounds = bounds == RectangleF.Empty ? node.Bounds : RectangleF.Union(bounds, node.Bounds);
        }
        AutoScrollMinSize = new Size((int)Math.Ceiling(bounds.Right + 40), (int)Math.Ceiling(bounds.Bottom + 40));
        UpdateAnimationTimer();
        Invalidate();
    }

    public void SetAnimationEnabled(bool enabled)
    {
        if (_animationEnabled == enabled)
        {
            UpdateAnimationTimer();
            return;
        }

        _animationEnabled = enabled;
        UpdateAnimationTimer();
        Invalidate();
    }

    public void SetHighlight(ushort traceId)
    {
        if (_highlightTraceId == traceId)
        {
            return;
        }

        _highlightTraceId = traceId;
        Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _animationTimer.Dispose();
        }
        base.Dispose(disposing);
    }

    protected override void OnVisibleChanged(EventArgs e)
    {
        base.OnVisibleChanged(e);
        UpdateAnimationTimer();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        g.TranslateTransform(AutoScrollPosition.X, AutoScrollPosition.Y);

        using var edgePen = new Pen(Color.FromArgb(155, _line), 1.6f)
        {
            CustomEndCap = new AdjustableArrowCap(4, 5)
        };
        using var highlightPen = new Pen(_accent, 2.4f)
        {
            CustomEndCap = new AdjustableArrowCap(4, 5)
        };

        foreach (FlowChartEdge edge in _edges)
        {
            if (!_nodeById.TryGetValue(edge.FromId, out FlowChartNode from) || !_nodeById.TryGetValue(edge.ToId, out FlowChartNode to))
            {
                continue;
            }
            bool hot = from.TraceId == _highlightTraceId || to.TraceId == _highlightTraceId;
            DrawEdge(g, from.Bounds, to.Bounds, hot ? highlightPen : edgePen, edge.Label, hot);
        }

        DrawAnimationPulse(g);

        foreach (FlowChartNode node in _nodes)
        {
            DrawNode(g, node);
        }
    }

    protected override void OnMouseClick(MouseEventArgs e)
    {
        base.OnMouseClick(e);
        FlowChartNode? node = HitTest(e.Location);
        if (node != null)
        {
            NodeClick?.Invoke(this, node);
        }
    }

    protected override void OnMouseDoubleClick(MouseEventArgs e)
    {
        base.OnMouseDoubleClick(e);
        FlowChartNode? node = HitTest(e.Location);
        if (node != null)
        {
            NodeDoubleClick?.Invoke(this, node);
        }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        Cursor = HitTest(e.Location) == null ? Cursors.Default : Cursors.Hand;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        int notches = e.Delta / 120;
        if (notches == 0)
        {
            notches = e.Delta > 0 ? 1 : -1;
        }
        int step = -notches * 96;
        Point current = AutoScrollPosition;
        AutoScrollPosition = new Point(-current.X, Math.Max(0, -current.Y + step));
        Invalidate();
    }

    private FlowChartNode? HitTest(Point location)
    {
        PointF logical = new PointF(location.X - AutoScrollPosition.X, location.Y - AutoScrollPosition.Y);
        for (int i = _nodes.Count - 1; i >= 0; i--)
        {
            FlowChartNode node = _nodes[i];
            if (node.Bounds.Contains(logical))
            {
                return node;
            }
        }

        return null;
    }

    private void AdvanceAnimation()
    {
        if (!_animationEnabled || !Visible || _edges.Count == 0 || _nodes.Count == 0)
        {
            UpdateAnimationTimer();
            return;
        }
        _animationProgress += 0.035f;
        if (_animationProgress >= 1f)
        {
            _animationProgress = 0f;
            _animatedEdgeIndex = (_animatedEdgeIndex + 1) % _edges.Count;
        }
        Invalidate();
    }

    private void UpdateAnimationTimer()
    {
        bool shouldRun = _animationEnabled && Visible && _edges.Count > 0 && _nodes.Count > 0;
        if (shouldRun && !_animationTimer.Enabled)
        {
            _animationTimer.Start();
        }
        else if (!shouldRun && _animationTimer.Enabled)
        {
            _animationTimer.Stop();
        }
    }

    private void DrawNode(Graphics g, FlowChartNode node)
    {
        bool hot = node.TraceId == _highlightTraceId;
        RectangleF rect = node.Bounds;
        using GraphicsPath path = RoundedRect(rect, 8);
        (Color fillColor, Color borderColor, Color badgeColor, string badge) = PaletteForNode(node.Kind);
        using var fill = new SolidBrush(hot ? Blend(fillColor, _accent, 0.35f) : fillColor);
        using var border = new Pen(hot ? _accent : borderColor, hot ? 2.2f : 1.2f);
        g.FillPath(fill, path);
        g.DrawPath(border, path);
        using var badgeBrush = new SolidBrush(hot ? _accent : badgeColor);
        g.FillRectangle(badgeBrush, rect.Left, rect.Top, 5, rect.Height);
        using var badgeTextBrush = new SolidBrush(_muted);
        using var badgeFont = new Font(Font.FontFamily, 7f, FontStyle.Bold);
        g.DrawString(badge, badgeFont, badgeTextBrush, new RectangleF(rect.Left + 10, rect.Top + 4, rect.Width - 16, 12));
        using var textBrush = new SolidBrush(_ink);
        using var format = new StringFormat
        {
            Alignment = StringAlignment.Center,
            LineAlignment = StringAlignment.Center,
            Trimming = StringTrimming.EllipsisCharacter
        };
        RectangleF textRect = new RectangleF(rect.Left + 8, rect.Top + 15, rect.Width - 16, rect.Height - 18);
        g.DrawString(node.Text, Font, textBrush, textRect, format);
    }

    private (Color Fill, Color Border, Color Badge, string Label) PaletteForNode(string kind)
    {
        return kind switch
        {
            "main" => (Color.FromArgb(31, 48, 78), Color.FromArgb(96, 165, 250), Color.FromArgb(96, 165, 250), "MAIN"),
            "disp" => (Color.FromArgb(58, 38, 64), Color.FromArgb(244, 114, 182), Color.FromArgb(244, 114, 182), "DISP"),
            "period10" => (Color.FromArgb(56, 48, 28), Color.FromArgb(250, 204, 21), Color.FromArgb(250, 204, 21), "10ms"),
            "entry" => (Color.FromArgb(34, 45, 70), Color.FromArgb(96, 165, 250), Color.FromArgb(96, 165, 250), "入口"),
            "business" => (Color.FromArgb(40, 55, 42), Color.FromArgb(74, 222, 128), Color.FromArgb(74, 222, 128), "业务"),
            "can" => (Color.FromArgb(38, 48, 64), Color.FromArgb(56, 189, 248), Color.FromArgb(56, 189, 248), "CAN"),
            "io" => (Color.FromArgb(53, 42, 32), Color.FromArgb(251, 146, 60), Color.FromArgb(251, 146, 60), "IO"),
            "storage" => (Color.FromArgb(49, 40, 58), Color.FromArgb(192, 132, 252), Color.FromArgb(192, 132, 252), "存储"),
            "timer" => (Color.FromArgb(52, 50, 33), Color.FromArgb(250, 204, 21), Color.FromArgb(250, 204, 21), "周期"),
            "driver" => (Color.FromArgb(31, 36, 47), Color.FromArgb(100, 116, 139), Color.FromArgb(100, 116, 139), "底层"),
            _ => (_surfaceAlt, _line, _muted, "函数")
        };
    }

    private static Color Blend(Color a, Color b, float ratio)
    {
        ratio = Math.Clamp(ratio, 0f, 1f);
        float keep = 1f - ratio;
        return Color.FromArgb(
            (int)(a.R * keep + b.R * ratio),
            (int)(a.G * keep + b.G * ratio),
            (int)(a.B * keep + b.B * ratio));
    }

    private void DrawEdge(Graphics g, RectangleF from, RectangleF to, Pen pen, string label, bool hot)
    {
        using var path = new GraphicsPath();
        PointF[] points = GetEdgePoints(from, to);
        path.AddLines(points);
        g.DrawPath(pen, path);

        if (label.Length > 0)
        {
            using var brush = new SolidBrush(hot ? _accent : _muted);
            using var smallFont = new Font(Font.FontFamily, 7.5f, FontStyle.Regular);
            PointF mid = points[1];
            g.DrawString(label, smallFont, brush, new PointF(mid.X + 4, mid.Y - 15));
        }
    }

    private void DrawAnimationPulse(Graphics g)
    {
        if (!_animationEnabled || _edges.Count == 0)
        {
            return;
        }
        FlowChartEdge edge = _edges[Math.Clamp(_animatedEdgeIndex, 0, _edges.Count - 1)];
        if (!_nodeById.TryGetValue(edge.FromId, out FlowChartNode from) || !_nodeById.TryGetValue(edge.ToId, out FlowChartNode to))
        {
            return;
        }
        PointF[] points = GetEdgePoints(from.Bounds, to.Bounds);
        PointF pulse = PointOnPolyline(points, _animationProgress);
        using var glow = new SolidBrush(Color.FromArgb(95, _accent));
        using var core = new SolidBrush(_accent);
        g.FillEllipse(glow, pulse.X - 8, pulse.Y - 8, 16, 16);
        g.FillEllipse(core, pulse.X - 4, pulse.Y - 4, 8, 8);
    }

    private static PointF[] GetEdgePoints(RectangleF from, RectangleF to)
    {
        if (to.Left >= from.Right - 8)
        {
            PointF start = new PointF(from.Right, from.Top + from.Height / 2);
            PointF end = new PointF(to.Left, to.Top + to.Height / 2);
            float midX = start.X + (end.X - start.X) / 2;
            return new[]
            {
                start,
                new PointF(midX, start.Y),
                new PointF(midX, end.Y),
                end
            };
        }

        PointF verticalStart = new PointF(from.Left + from.Width / 2, from.Bottom);
        PointF verticalEnd = new PointF(to.Left + to.Width / 2, to.Top);
        float midY = verticalStart.Y + (verticalEnd.Y - verticalStart.Y) / 2;
        return new[]
        {
            verticalStart,
            new PointF(verticalStart.X, midY),
            new PointF(verticalEnd.X, midY),
            verticalEnd
        };
    }

    private static PointF PointOnPolyline(PointF[] points, float progress)
    {
        progress = Math.Clamp(progress, 0f, 1f);
        float total = 0f;
        for (int i = 1; i < points.Length; i++)
        {
            total += Distance(points[i - 1], points[i]);
        }
        float target = total * progress;
        float walked = 0f;
        for (int i = 1; i < points.Length; i++)
        {
            PointF a = points[i - 1];
            PointF b = points[i];
            float segment = Distance(a, b);
            if (walked + segment >= target && segment > 0)
            {
                float local = (target - walked) / segment;
                return new PointF(a.X + (b.X - a.X) * local, a.Y + (b.Y - a.Y) * local);
            }
            walked += segment;
        }
        return points[^1];
    }

    private static float Distance(PointF a, PointF b)
    {
        float dx = b.X - a.X;
        float dy = b.Y - a.Y;
        return MathF.Sqrt(dx * dx + dy * dy);
    }

    private static GraphicsPath RoundedRect(RectangleF rect, float radius)
    {
        float d = radius * 2;
        var path = new GraphicsPath();
        path.AddArc(rect.X, rect.Y, d, d, 180, 90);
        path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
        path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
        path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }
}
