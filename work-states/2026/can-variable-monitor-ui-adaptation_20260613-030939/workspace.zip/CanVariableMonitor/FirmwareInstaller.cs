﻿using System.Text;

using System.Diagnostics;

namespace CanVariableMonitor;

internal class FirmwareInstallResult
{
    public bool Success { get; set; }
    public List<string> Messages { get; } = new();
}

internal sealed class FirmwareBinaryResult : FirmwareInstallResult
{
    public string BinPath { get; set; } = "";
}

internal static class FirmwareInstaller
{
    private const string AgentFileName = "can_monitor_agent.c";

    public static FirmwareInstallResult Install(string projectRoot, string agentSourcePath)
    {
        var result = new FirmwareInstallResult();

        if (!Directory.Exists(projectRoot))
        {
            result.Messages.Add("工程目录不存在。");
            return result;
        }

        string? projectFile = FindProjectFile(projectRoot);
        if (projectFile == null)
        {
            result.Messages.Add("没有找到 .uvproj 或 .uvprojx。");
            return result;
        }

        string projectDir = Path.GetDirectoryName(projectFile)!;
        string srcDir = FindSourceDirectory(projectRoot, projectDir);
        Directory.CreateDirectory(srcDir);

        string agentDest = Path.Combine(srcDir, AgentFileName);
        InstallPlan installPlan = FindInstallPlan(projectRoot);
        string? receiveFile = installPlan.FilePath;
        uint bundledAgentVersion = ReadAgentVersion(agentSourcePath);
        uint installedAgentVersion = File.Exists(agentDest) ? ReadAgentVersion(agentDest) : 0;
        bool agentFileExists = File.Exists(agentDest);
        bool projectHasAgent = ContainsAscii(projectFile, AgentFileName);
        bool agentVersionIsCurrent = agentFileExists && bundledAgentVersion != 0 && installedAgentVersion == bundledAgentVersion;
        List<TraceTarget> traceTargets = FindTraceTargets(projectRoot);
        int missingTraceCount = CountMissingTraceCalls(traceTargets);
        FirmwareShape shape = AnalyzeProject(projectRoot, installPlan);
        HookAudit hookAudit = AnalyzeHooks(projectRoot);
        BusinessGatePlan businessGatePlan = FindBusinessGatePlan(projectRoot);
        bool processHasCall = hookAudit.ProcessCalls > 0;
        if (processHasCall && !shape.HasReceiveFile)
        {
            shape.MarkReceiveSatisfiedByExistingHook();
        }
        bool businessGateNeedsInstall = hookAudit.BusinessGateCalls == 0 && businessGatePlan.Found;
        var backups = new List<(string Original, string Backup)>();
        var createdFiles = new List<string>();

        result.Messages.Add($"固件代理版本：工程 {FormatVersion(installedAgentVersion)}，软件内置 {FormatVersion(bundledAgentVersion)}。");
        result.Messages.Add(shape.Summary);
        result.Messages.Add(hookAudit.Summary);
        if (!string.IsNullOrWhiteSpace(installPlan.Description))
        {
            result.Messages.Add("安装方案：" + installPlan.Description);
        }
        if (!string.IsNullOrWhiteSpace(businessGatePlan.Description))
        {
            result.Messages.Add("业务强制方案：" + businessGatePlan.Description);
        }
        if (hookAudit.BusinessGateCalls > 1)
        {
            result.Messages.Add("注意：检测到多个 CanMonitor_BusinessGate()，本次不会继续增加；建议最终只保留一个业务入口门控。");
        }
        if (traceTargets.Count > 0)
        {
            result.Messages.Add($"业务位置追踪：识别到 {traceTargets.Count} 个业务入口，待补 {missingTraceCount} 个。");
        }

        if (!shape.IsCompatible)
        {
            foreach (string missing in shape.MissingItems)
            {
                result.Messages.Add("未安装固件：" + missing);
            }
            result.Messages.Add("该工程 CAN 接口与当前低耦合代理不匹配，未修改客户工程。");
            result.Success = false;
            return result;
        }

        if (agentFileExists && projectHasAgent && processHasCall && !businessGateNeedsInstall && agentVersionIsCurrent && missingTraceCount == 0)
        {
            result.Messages.Add("检测到该工程固件代理已是最新，本次未做任何修改。");
            result.Success = true;
            return result;
        }

        BuildCheck beforeBuild = BuildProject(projectFile);
        result.Messages.Add(beforeBuild.Message);
        if (!beforeBuild.Success)
        {
            result.Messages.Add("原工程当前未通过 Keil 编译，未安装固件。");
            result.Success = false;
            return result;
        }

        if (!agentFileExists)
        {
            File.WriteAllBytes(agentDest, PrepareAgentBytes(agentSourcePath, shape));
            createdFiles.Add(agentDest);
            installedAgentVersion = bundledAgentVersion;
            agentVersionIsCurrent = true;
            result.Messages.Add("已复制固件代理：" + agentDest);
        }
        else
        {
            if (!agentVersionIsCurrent)
            {
                backups.Add((agentDest, Backup(agentDest)));
                File.WriteAllBytes(agentDest, PrepareAgentBytes(agentSourcePath, shape));
                installedAgentVersion = bundledAgentVersion;
                agentVersionIsCurrent = true;
                result.Messages.Add("已升级固件代理到最新版本：" + agentDest);
            }
            else
            {
                result.Messages.Add("固件代理已是最新，未覆盖：" + agentDest);
            }
        }

        if (!projectHasAgent)
        {
            backups.Add((projectFile, Backup(projectFile)));
            int projectInsertCount = AddAgentToKeilProject(projectFile, projectDir, agentDest);
            result.Messages.Add(projectInsertCount > 0
                ? $"已加入 Keil 工程：{projectInsertCount} 个目标源码组。"
                : "Keil 工程中已存在固件文件。");
        }
        else
        {
            result.Messages.Add("Keil 工程中已存在固件文件，未重复添加。");
        }

        if (receiveFile == null && !processHasCall)
        {
            result.Messages.Add("没有自动找到安全的 CAN 后台轮询入口，请手工调用 CanMonitor_Process()。");
            result.Success = false;
            return result;
        }

        if (!processHasCall)
        {
            backups.Add((receiveFile!, Backup(receiveFile!)));
            int callInsertCount = InsertProcessCall(installPlan);
            if (callInsertCount <= 0)
            {
                Rollback(backups, createdFiles);
                result.Messages.Add("没有找到可安全插入 CanMonitor_Process 的接收位置，已回滚。");
                result.Success = false;
                return result;
            }
            result.Messages.Add(callInsertCount > 0
                ? $"已插入 CanMonitor_Process 调用：{receiveFile}，{callInsertCount} 处。"
                : "接收函数中已存在 CanMonitor_Process 调用。");
        }
        else
        {
            result.Messages.Add($"已检测到 CanMonitor_Process 调用 {hookAudit.ProcessCalls} 处，未重复添加。");
        }

        if (businessGateNeedsInstall)
        {
            BackupOnce(backups, businessGatePlan.FilePath!);
            int gateInsertCount = InsertBusinessGateCall(businessGatePlan);
            if (gateInsertCount <= 0)
            {
                Rollback(backups, createdFiles);
                result.Messages.Add("没有找到可安全插入 CanMonitor_BusinessGate 的业务入口，已回滚。");
                result.Success = false;
                return result;
            }

            result.Messages.Add($"已插入业务强制/单步门控：{businessGatePlan.FilePath}，{gateInsertCount} 处。");
        }
        else if (hookAudit.BusinessGateCalls > 0)
        {
            result.Messages.Add($"已检测到 CanMonitor_BusinessGate 调用 {hookAudit.BusinessGateCalls} 处，未重复添加。");
        }
        else
        {
            result.Messages.Add("未识别到安全业务入口，变量读写可用；强制/暂停/单步需要手工接入 CanMonitor_BusinessGate()。");
        }

        if (missingTraceCount > 0)
        {
            foreach (string traceFile in traceTargets.Where(t => !TraceCallExists(t)).Select(t => t.FilePath).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                backups.Add((traceFile, Backup(traceFile)));
            }

            int traceInsertCount = InsertTraceCalls(traceTargets);
            result.Messages.Add(traceInsertCount > 0
                ? $"已插入业务实时位置标记：{traceInsertCount} 处。"
                : "业务实时位置标记已存在，未重复添加。");
        }
        else if (traceTargets.Count > 0)
        {
            result.Messages.Add("业务实时位置标记已存在，未重复添加。");
        }
        else
        {
            result.Messages.Add("未识别到 MyLogic_10ms 等业务入口，未插入业务实时位置标记。");
        }

        result.Messages.Add("低耦合安装：未修改 CAN ID 初始化函数。");

        BuildCheck afterBuild = BuildProject(projectFile);
        result.Messages.Add(afterBuild.Message);
        if (!afterBuild.Success)
        {
            Rollback(backups, createdFiles);
            result.Messages.Add("固件安装后 Keil 编译未通过，已自动恢复安装前状态。");
            result.Success = false;
            return result;
        }

        result.Messages.Add("安装完成，Keil 编译验证已通过。");
        result.Success = true;
        return result;
    }

    public static FirmwareBinaryResult BuildBinaryForDownload(string projectRoot)
    {
        var result = new FirmwareBinaryResult();

        if (!Directory.Exists(projectRoot))
        {
            result.Messages.Add("工程目录不存在。");
            return result;
        }

        string? projectFile = FindProjectFile(projectRoot);
        if (projectFile == null)
        {
            result.Messages.Add("没有找到 .uvproj 或 .uvprojx。");
            return result;
        }

        BuildCheck build = BuildProject(projectFile);
        result.Messages.Add(build.Message);
        if (!build.Success)
        {
            result.Messages.Add("Keil 编译未通过，未生成下载文件。");
            return result;
        }

        string projectDir = Path.GetDirectoryName(projectFile)!;
        string? targetBin = FindCurrentTargetBin(projectFile, build.TargetName);
        if (IsUsableFreshBin(targetBin, build.StartedUtc))
        {
            result.BinPath = targetBin!;
            result.Messages.Add("使用当前 Target 本次生成 bin：" + targetBin);
            result.Messages.Add("bin 大小：" + new FileInfo(targetBin!).Length + " 字节。");
            result.Success = true;
            return result;
        }

        string? keilBin = FindLatestFreshBinFile(projectDir, build.StartedUtc) ?? FindLatestFreshBinFile(projectRoot, build.StartedUtc);
        if (keilBin != null)
        {
            result.BinPath = keilBin;
            result.Messages.Add("使用本次 Keil 编译更新 bin：" + keilBin);
            result.Messages.Add("bin 大小：" + new FileInfo(keilBin).Length + " 字节。");
            result.Success = true;
            return result;
        }

        if (IsUsableBin(targetBin))
        {
            result.BinPath = targetBin!;
            result.Messages.Add("本次编译未更新 bin，使用当前 Target 输出 bin：" + targetBin);
            result.Messages.Add("bin 大小：" + new FileInfo(targetBin!).Length + " 字节。");
            result.Success = true;
            return result;
        }

        result.Messages.Add("Keil 编译完成，但没有找到工程输出的 .bin 文件。");
        result.Messages.Add("下载必须使用 Keil 已生成的 bin，上位机不会从 axf 另行转换。");
        return result;
    }

    private static string? FindLatestFreshBinFile(string root, DateTime buildStartedUtc)
    {
        if (!Directory.Exists(root))
        {
            return null;
        }

        DateTime cutoff = buildStartedUtc.AddSeconds(-3);
        return EnumerateUsableBinFiles(root)
            .Where(f => f.LastWriteTimeUtc >= cutoff)
            .OrderByDescending(f => f.LastWriteTimeUtc)
            .ThenBy(f => f.FullName.Length)
            .Select(f => f.FullName)
            .FirstOrDefault();
    }

    private static IEnumerable<FileInfo> EnumerateUsableBinFiles(string root)
    {
        return Directory.EnumerateFiles(root, "*.bin", SearchOption.AllDirectories)
            .Where(p => !Path.GetFileName(p).Contains(".bak", StringComparison.OrdinalIgnoreCase))
            .Select(p => new FileInfo(p))
            .Where(f => f.Exists && f.Length > 0);
    }

    private static bool IsUsableFreshBin(string? path, DateTime buildStartedUtc)
    {
        if (!IsUsableBin(path))
        {
            return false;
        }

        return File.GetLastWriteTimeUtc(path!) >= buildStartedUtc.AddSeconds(-3);
    }

    private static bool IsUsableBin(string? path)
    {
        return !string.IsNullOrWhiteSpace(path) && File.Exists(path) && new FileInfo(path).Length > 0;
    }

    private static string? FindCurrentTargetBin(string projectFile, string targetName)
    {
        if (targetName.Length == 0)
        {
            return null;
        }

        TargetOutputInfo? output = FindTargetOutputInfo(projectFile, targetName);
        if (output == null)
        {
            return null;
        }

        string projectDir = Path.GetDirectoryName(projectFile)!;
        string outputDir = ResolveProjectPath(projectDir, output.OutputDirectory);
        string outputName = output.OutputName.Length > 0 ? output.OutputName : Path.GetFileNameWithoutExtension(projectFile);
        return Path.Combine(outputDir, outputName + ".bin");
    }

    private sealed class TargetOutputInfo
    {
        public string OutputDirectory { get; init; } = "";
        public string OutputName { get; init; } = "";
    }

    private static TargetOutputInfo? FindTargetOutputInfo(string projectFile, string targetName)
    {
        string text = File.ReadAllText(projectFile, Encoding.Default);
        int pos = 0;
        while (true)
        {
            int start = text.IndexOf("<Target>", pos, StringComparison.OrdinalIgnoreCase);
            if (start < 0)
            {
                return null;
            }

            int end = text.IndexOf("</Target>", start, StringComparison.OrdinalIgnoreCase);
            if (end < 0)
            {
                return null;
            }

            string block = text.Substring(start, end - start);
            string name = ExtractTagValue(block, "TargetName");
            if (name.Equals(targetName, StringComparison.OrdinalIgnoreCase))
            {
                return new TargetOutputInfo
                {
                    OutputDirectory = ExtractTagValue(block, "OutputDirectory"),
                    OutputName = ExtractTagValue(block, "OutputName")
                };
            }

            pos = end + "</Target>".Length;
        }
    }

    private static string ExtractTagValue(string text, string tag)
    {
        string open = "<" + tag + ">";
        string close = "</" + tag + ">";
        int start = text.IndexOf(open, StringComparison.OrdinalIgnoreCase);
        if (start < 0)
        {
            return "";
        }

        start += open.Length;
        int end = text.IndexOf(close, start, StringComparison.OrdinalIgnoreCase);
        if (end < 0)
        {
            return "";
        }

        return System.Net.WebUtility.HtmlDecode(text.Substring(start, end - start)).Trim();
    }

    private static string ResolveProjectPath(string projectDir, string path)
    {
        path = path.Trim().Trim('"').Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar);
        if (path.Length == 0)
        {
            return projectDir;
        }

        return Path.GetFullPath(Path.IsPathRooted(path) ? path : Path.Combine(projectDir, path));
    }

    private static string? FindProjectFile(string root)
    {
        return Directory.EnumerateFiles(root, "*.*", SearchOption.AllDirectories)
            .Where(p =>
                p.EndsWith(".uvproj", StringComparison.OrdinalIgnoreCase) ||
                p.EndsWith(".uvprojx", StringComparison.OrdinalIgnoreCase))
            .Where(p => !Path.GetFileName(p).Contains(".bak", StringComparison.OrdinalIgnoreCase))
            .OrderBy(p => p.Length)
            .FirstOrDefault();
    }

    private static string? FindLatestAxfFile(string root)
    {
        if (!Directory.Exists(root))
        {
            return null;
        }

        return Directory.EnumerateFiles(root, "*.axf", SearchOption.AllDirectories)
            .Where(p => !Path.GetFileName(p).Contains(".bak", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault();
    }

    private static string FindSourceDirectory(string root, string projectDir)
    {
        string direct = Path.Combine(projectDir, "Src");
        if (Directory.Exists(direct))
        {
            return direct;
        }

        string? appCan = Directory.EnumerateFiles(root, "App_Can.c", SearchOption.AllDirectories).FirstOrDefault();
        if (appCan != null)
        {
            return Path.GetDirectoryName(appCan)!;
        }

        string? canOpen = Directory.EnumerateFiles(root, "CanOpen.c", SearchOption.AllDirectories).FirstOrDefault();
        if (canOpen != null)
        {
            return Path.GetDirectoryName(canOpen)!;
        }

        return direct;
    }

    private enum InstallPlanKind
    {
        None,
        UsrCanReceive,
        CanReceiveScheduler
    }

    private sealed class InstallPlan
    {
        public string? FilePath { get; set; }
        public InstallPlanKind Kind { get; set; }
        public string Anchor { get; set; } = "";
        public string Description { get; set; } = "";
        public bool Found => FilePath != null && Kind != InstallPlanKind.None;
    }

    private static InstallPlan FindInstallPlan(string root)
    {
        string[] sourceFiles = Directory.EnumerateFiles(root, "*.c", SearchOption.AllDirectories)
            .Where(IsCustomerSourceFile)
            .OrderBy(SourceFilePriority)
            .ThenBy(p => p.Length)
            .ToArray();

        string? appCan = sourceFiles.FirstOrDefault(p =>
            Path.GetFileName(p).Equals("App_Can.c", StringComparison.OrdinalIgnoreCase) &&
            ContainsAscii(p, "Usr_Can_Rcv") &&
            ContainsAscii(p, "CAN1_Get_Data"));
        if (appCan != null)
        {
            return new InstallPlan
            {
                FilePath = appCan,
                Kind = InstallPlanKind.UsrCanReceive,
                Anchor = "CAN1_Get_Data",
                Description = "识别到 App_Can.c 的用户 CAN 接收轮询，按接收函数挂载。"
            };
        }

        string? usrReceive = sourceFiles.FirstOrDefault(p =>
            ContainsAscii(p, "Usr_Can_Rcv") &&
            ContainsAscii(p, "CAN1_Get_Data"));
        if (usrReceive != null)
        {
            return new InstallPlan
            {
                FilePath = usrReceive,
                Kind = InstallPlanKind.UsrCanReceive,
                Anchor = "CAN1_Get_Data",
                Description = "识别到用户 CAN 接收轮询函数，按接收函数挂载。"
            };
        }

        string? scheduler = sourceFiles.FirstOrDefault(p =>
            ContainsAscii(p, "CAN1RxDone") &&
            ContainsAscii(p, "Can_Prog_Rcv"));
        if (scheduler != null)
        {
            return new InstallPlan
            {
                FilePath = scheduler,
                Kind = InstallPlanKind.CanReceiveScheduler,
                Anchor = "CAN1RxDone",
                Description = "识别到 CAN 收包后台调度点，按后台轮询函数挂载。"
            };
        }

        string? canDataScheduler = sourceFiles.FirstOrDefault(p =>
            ContainsAscii(p, "CAN1RxDone") &&
            ContainsAscii(p, "CAN1_Get_Data"));
        if (canDataScheduler != null)
        {
            return new InstallPlan
            {
                FilePath = canDataScheduler,
                Kind = InstallPlanKind.CanReceiveScheduler,
                Anchor = "CAN1RxDone",
                Description = "识别到 CAN 接收标志处理点，按后台轮询函数挂载。"
            };
        }

        return new InstallPlan
        {
            Description = "已扫描客户源码，但没有找到安全的 CAN 后台轮询入口。"
        };
    }

    private static bool IsCustomerSourceFile(string path)
    {
        string name = Path.GetFileName(path);
        return !name.Equals(AgentFileName, StringComparison.OrdinalIgnoreCase) &&
            !name.Contains(".bak", StringComparison.OrdinalIgnoreCase) &&
            !name.Contains("canmon_bak", StringComparison.OrdinalIgnoreCase);
    }

    private static int SourceFilePriority(string path)
    {
        string name = Path.GetFileName(path);
        if (name.Equals("App_Can.c", StringComparison.OrdinalIgnoreCase))
        {
            return 0;
        }
        if (name.Equals("App_sys.c", StringComparison.OrdinalIgnoreCase) ||
            name.Equals("App_Sys.c", StringComparison.OrdinalIgnoreCase))
        {
            return 1;
        }
        if (name.Equals("main.c", StringComparison.OrdinalIgnoreCase))
        {
            return 2;
        }
        if (name.Contains("can", StringComparison.OrdinalIgnoreCase))
        {
            return 3;
        }
        return 9;
    }

    private sealed class HookAudit
    {
        public int ProcessCalls { get; set; }
        public int BusinessGateCalls { get; set; }
        public int TraceCalls { get; set; }

        public string Summary =>
            "固件钩子检查：后台轮询 " + ProcessCalls +
            " 处，业务门控 " + BusinessGateCalls +
            " 处，位置标记 " + TraceCalls + " 处。";
    }

    private sealed class BusinessGatePlan
    {
        public string? FilePath { get; set; }
        public string FunctionName { get; set; } = "";
        public string Anchor { get; set; } = "";
        public int InsertPosition { get; set; } = -1;
        public string Description { get; set; } = "";
        public bool Found => FilePath != null && InsertPosition >= 0;
    }

    private static HookAudit AnalyzeHooks(string root)
    {
        var audit = new HookAudit();
        foreach (string file in Directory.EnumerateFiles(root, "*.c", SearchOption.AllDirectories).Where(IsCustomerSourceFile))
        {
            audit.ProcessCalls += CountNonExternLineOccurrences(file, "CanMonitor_Process();");
            audit.BusinessGateCalls += CountNonExternLineOccurrences(file, "CanMonitor_BusinessGate()");
            audit.TraceCalls += CountNonExternLineOccurrences(file, "CanMonitor_Trace(");
        }

        return audit;
    }

    private static int CountNonExternLineOccurrences(string file, string pattern)
    {
        int count = 0;
        foreach (string line in File.ReadLines(file, Encoding.Default))
        {
            string trimmed = line.TrimStart();
            if (trimmed.StartsWith("extern ", StringComparison.Ordinal))
            {
                continue;
            }

            int pos = 0;
            while (true)
            {
                int hit = line.IndexOf(pattern, pos, StringComparison.Ordinal);
                if (hit < 0)
                {
                    break;
                }

                count++;
                pos = hit + pattern.Length;
            }
        }

        return count;
    }

    private static BusinessGatePlan FindBusinessGatePlan(string root)
    {
        string[] sourceFiles = Directory.EnumerateFiles(root, "*.c", SearchOption.AllDirectories)
            .Where(IsCustomerSourceFile)
            .OrderBy(SourceFilePriority)
            .ThenBy(p => p.Length)
            .ToArray();

        string[] entryFunctions =
        {
            "MyLogic_10ms",
            "MyLogic_1ms",
            "app10ms",
            "App_10ms",
            "app_Ctrl",
            "work_logic"
        };

        string[] businessAnchors =
        {
            "work_logic",
            "ASS_logic",
            "app_Ctrl",
            "App_JiTing",
            "app_Logic",
            "app_ctrl_dfs",
            "APP_DO_DFS"
        };

        foreach (string entry in entryFunctions)
        {
            foreach (string file in sourceFiles)
            {
                BusinessGatePlan plan = TryCreateBusinessGatePlan(file, entry, businessAnchors);
                if (plan.Found)
                {
                    return plan;
                }
            }
        }

        return new BusinessGatePlan
        {
            Description = "已扫描 MyLogic_10ms/MyLogic_1ms 等入口，但没有找到可自动插入的安全业务门控位置。"
        };
    }

    private static BusinessGatePlan TryCreateBusinessGatePlan(string file, string functionName, string[] anchors)
    {
        byte[] data = File.ReadAllBytes(file);
        int openBrace = FindFunctionOpenBrace(data, functionName);
        if (openBrace < 0)
        {
            return new BusinessGatePlan();
        }

        int closeBrace = FindMatchingBrace(data, openBrace);
        if (closeBrace < 0)
        {
            return new BusinessGatePlan();
        }

        int existing = IndexOf(data, Encoding.ASCII.GetBytes("CanMonitor_BusinessGate"), openBrace);
        if (existing >= 0 && existing < closeBrace)
        {
            return new BusinessGatePlan
            {
                FilePath = file,
                FunctionName = functionName,
                Anchor = "CanMonitor_BusinessGate",
                InsertPosition = existing,
                Description = functionName + " 中已存在业务门控。"
            };
        }

        foreach (string anchor in anchors)
        {
            if (anchor.Equals(functionName, StringComparison.Ordinal))
            {
                continue;
            }

            int anchorPos = FindCallInRange(data, anchor, openBrace, closeBrace);
            if (anchorPos < 0)
            {
                continue;
            }

            int insertPos = FindLineStart(data, anchorPos);
            if (!IsC90SafeInsertionPoint(data, openBrace, insertPos, closeBrace))
            {
                continue;
            }

            return new BusinessGatePlan
            {
                FilePath = file,
                FunctionName = functionName,
                Anchor = anchor,
                InsertPosition = insertPos,
                Description = "识别到 " + functionName + "，将在 " + anchor + "() 前挂业务强制/单步门控。"
            };
        }

        if (functionName.Equals("app_Ctrl", StringComparison.OrdinalIgnoreCase) ||
            functionName.Equals("work_logic", StringComparison.OrdinalIgnoreCase))
        {
            int insertPos = FindAfterLocalDeclarations(data, openBrace);
            if (IsC90SafeInsertionPoint(data, openBrace, insertPos, closeBrace))
            {
                return new BusinessGatePlan
                {
                    FilePath = file,
                    FunctionName = functionName,
                    Anchor = functionName,
                    InsertPosition = insertPos,
                    Description = "识别到业务函数 " + functionName + "，将在函数入口挂业务强制/单步门控。"
                };
            }
        }

        return new BusinessGatePlan();
    }

    private static int FindCallInRange(byte[] data, string functionName, int start, int end)
    {
        byte[] nameBytes = Encoding.ASCII.GetBytes(functionName);
        int pos = start;
        while (pos >= 0 && pos < end)
        {
            int name = IndexOf(data, nameBytes, pos);
            if (name < 0 || name >= end)
            {
                return -1;
            }

            if (!IsIdentifierBoundary(data, name - 1) || !IsIdentifierBoundary(data, name + nameBytes.Length))
            {
                pos = name + nameBytes.Length;
                continue;
            }

            int next = SkipWhiteSpace(data, name + nameBytes.Length);
            if (next < end && data[next] == (byte)'(')
            {
                return name;
            }

            pos = name + nameBytes.Length;
        }

        return -1;
    }

    private static bool IsC90SafeInsertionPoint(byte[] data, int openBrace, int insertPos, int closeBrace)
    {
        int depth = 1;
        int pos = FindLineEnd(data, openBrace);

        while (pos < closeBrace)
        {
            int lineEnd = FindLineEnd(data, pos);
            if (pos >= insertPos)
            {
                string line = Encoding.ASCII.GetString(data, pos, lineEnd - pos);
                string trimmed = line.Trim();
                if (depth == 1 && IsLocalDeclarationLine(trimmed))
                {
                    return false;
                }
            }

            for (int i = pos; i < lineEnd && i < closeBrace; i++)
            {
                if (data[i] == (byte)'{')
                {
                    depth++;
                }
                else if (data[i] == (byte)'}' && depth > 0)
                {
                    depth--;
                }
            }

            pos = lineEnd;
        }

        return true;
    }

    private sealed class TraceTarget
    {
        public required string FunctionName { get; init; }
        public required string FilePath { get; init; }
        public ushort TraceId { get; init; }
    }

    private static List<TraceTarget> FindTraceTargets(string root)
    {
        (string Name, ushort Id)[] preferred =
        {
            ("MyLogic_10ms", 0x2100),
            ("MyLogic_1ms", 0x2106),
            ("app_Ctrl", 0x2102),
            ("App_JiTing", 0x2101),
            ("app_Logic", 0x2103),
            ("app_ctrl_dfs", 0x2104),
            ("App_PWM", 0x2105)
        };

        string[] sourceFiles = Directory.EnumerateFiles(root, "*.c", SearchOption.AllDirectories)
            .Where(IsCustomerSourceFile)
            .OrderBy(SourceFilePriority)
            .ThenBy(p => p.Length)
            .ToArray();

        var result = new List<TraceTarget>();
        foreach ((string name, ushort id) in preferred)
        {
            string? file = sourceFiles.FirstOrDefault(path => FunctionDefinitionExists(path, name));
            if (file == null)
            {
                continue;
            }

            result.Add(new TraceTarget
            {
                FunctionName = name,
                FilePath = file,
                TraceId = id
            });
        }

        return result;
    }

    private static int CountMissingTraceCalls(List<TraceTarget> traceTargets)
    {
        int count = 0;
        foreach (TraceTarget target in traceTargets)
        {
            if (!TraceCallExists(target))
            {
                count++;
            }
        }
        return count;
    }

    private static bool FunctionDefinitionExists(string path, string functionName)
    {
        byte[] data = File.ReadAllBytes(path);
        return FindFunctionOpenBrace(data, functionName) >= 0;
    }

    private sealed class FirmwareShape
    {
        public bool HasReceiveFile { get; set; }
        public bool HasCanOpenHeader { get; set; }
        public bool HasCan1RBuf { get; set; }
        public bool HasCan1GetData { get; set; }
        public bool HasCanSendXLen { get; set; }
        public bool HasCan2RBuf { get; set; }
        public bool HasCan2GetData { get; set; }
        public bool HasCan2SendXLen { get; set; }
        public bool HasCan2ReceiveIdTable { get; set; }
        public bool HasReceiveIdTable { get; set; }
        public bool HasReceiveIdCount { get; set; }
        public List<string> MissingItems { get; } = new();
        public bool IsCompatible => MissingItems.Count == 0;
        public bool HasCan2Interface => HasCan2RBuf && HasCan2GetData && HasCan2SendXLen && HasCan2ReceiveIdTable;

        public string Summary =>
            "已自动读取工程代码：CAN接收入口 " + Mark(HasReceiveFile) +
            "，CanOpen.h " + Mark(HasCanOpenHeader) +
            "，接收缓冲 " + Mark(HasCan1RBuf) +
            "，接收函数 " + Mark(HasCan1GetData) +
            "，发送函数 " + Mark(HasCanSendXLen) +
            "，接收ID表 " + Mark(HasReceiveIdTable && HasReceiveIdCount) +
            "，CAN2可选支持 " + Mark(HasCan2Interface) + "。";

        public void MarkReceiveSatisfiedByExistingHook()
        {
            HasReceiveFile = true;
            MissingItems.RemoveAll(x => x.Contains("CAN 接收轮询函数", StringComparison.Ordinal));
        }

        private static string Mark(bool value) => value ? "OK" : "缺失";
    }

    private static FirmwareShape AnalyzeProject(string root, InstallPlan installPlan)
    {
        var shape = new FirmwareShape
        {
            HasReceiveFile = installPlan.Found
        };

        IEnumerable<string> sourceFiles = Directory.EnumerateFiles(root, "*.*", SearchOption.AllDirectories)
            .Where(p =>
                (p.EndsWith(".c", StringComparison.OrdinalIgnoreCase) ||
                 p.EndsWith(".h", StringComparison.OrdinalIgnoreCase)) &&
                !Path.GetFileName(p).Contains(".bak", StringComparison.OrdinalIgnoreCase) &&
                !Path.GetFileName(p).Contains("canmon_bak", StringComparison.OrdinalIgnoreCase));

        foreach (string file in sourceFiles)
        {
            string name = Path.GetFileName(file);
            shape.HasCanOpenHeader |= name.Equals("CanOpen.h", StringComparison.OrdinalIgnoreCase);
            shape.HasCan1RBuf |= ContainsAscii(file, "CAN1_RBuf");
            shape.HasCan1GetData |= ContainsAscii(file, "CAN1_Get_Data");
            shape.HasCanSendXLen |= ContainsAscii(file, "CAN_SendXLen");
            shape.HasCan2RBuf |= ContainsAscii(file, "CAN2_RBuf");
            shape.HasCan2GetData |= ContainsAscii(file, "CAN2_Get_Data");
            shape.HasCan2SendXLen |= ContainsAscii(file, "CAN2_SendXLen");
            shape.HasCan2ReceiveIdTable |= ContainsAscii(file, "gRcvCan2ID");
            shape.HasReceiveIdTable |= ContainsAscii(file, "gRcvCanID");
            shape.HasReceiveIdCount |= ContainsAscii(file, "ID_RCV_NUM");
        }

        if (!shape.HasReceiveFile)
        {
            shape.MissingItems.Add("没有自动找到 CAN 接收轮询函数。");
        }
        if (!shape.HasCanOpenHeader)
        {
            shape.MissingItems.Add("没有找到 CanOpen.h。");
        }
        if (!shape.HasCan1RBuf)
        {
            shape.MissingItems.Add("没有找到 CAN1_RBuf 接收数据缓冲。");
        }
        if (!shape.HasCan1GetData)
        {
            shape.MissingItems.Add("没有找到 CAN1_Get_Data 接收函数。");
        }
        if (!shape.HasCanSendXLen)
        {
            shape.MissingItems.Add("没有找到 CAN_SendXLen 发送函数。");
        }
        if (!shape.HasReceiveIdTable || !shape.HasReceiveIdCount)
        {
            shape.MissingItems.Add("没有找到 gRcvCanID/ID_RCV_NUM 接收 ID 表。");
        }

        return shape;
    }

    private static byte[] PrepareAgentBytes(string agentSourcePath, FirmwareShape shape)
    {
        string text = File.ReadAllText(agentSourcePath, Encoding.ASCII);
        string can2Value = shape.HasCan2Interface ? "1" : "0";
        text = text.Replace("#define CAN_MONITOR_ENABLE_CAN2 0", "#define CAN_MONITOR_ENABLE_CAN2 " + can2Value);
        return Encoding.ASCII.GetBytes(text);
    }

    private static bool ContainsAscii(string path, string text)
    {
        byte[] bytes = File.ReadAllBytes(path);
        return IndexOf(bytes, Encoding.ASCII.GetBytes(text), 0) >= 0;
    }

    internal static uint ReadAgentVersion(string path)
    {
        if (!File.Exists(path))
        {
            return 0;
        }

        byte[] bytes = File.ReadAllBytes(path);
        byte[] key = Encoding.ASCII.GetBytes("CAN_MONITOR_AGENT_VERSION");
        int pos = IndexOf(bytes, key, 0);
        if (pos < 0)
        {
            return 0;
        }

        int lineEnd = FindLineEnd(bytes, pos);
        string line = Encoding.ASCII.GetString(bytes, pos, lineEnd - pos);
        string[] parts = line.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < parts.Length; i++)
        {
            if (!parts[i].Equals("CAN_MONITOR_AGENT_VERSION", StringComparison.Ordinal))
            {
                continue;
            }

            if (i + 1 >= parts.Length)
            {
                return 0;
            }

            string value = parts[i + 1].TrimEnd('U', 'u', 'L', 'l');
            if (value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) &&
                uint.TryParse(value.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out uint hexVersion))
            {
                return hexVersion;
            }

            if (uint.TryParse(value, out uint decVersion))
            {
                return decVersion;
            }
        }

        return 0;
    }

    internal static string FormatVersion(uint version)
    {
        return version == 0 ? "未知" : "0x" + version.ToString("X8");
    }

    private static string Backup(string path)
    {
        string backup = path + ".canmon_bak_" + DateTime.Now.ToString("yyyyMMddHHmmss");
        File.Copy(path, backup, overwrite: false);
        return backup;
    }

    private static void BackupOnce(List<(string Original, string Backup)> backups, string path)
    {
        if (backups.Any(x => x.Original.Equals(path, StringComparison.OrdinalIgnoreCase)))
        {
            return;
        }

        backups.Add((path, Backup(path)));
    }

    private static void Rollback(List<(string Original, string Backup)> backups, List<string> createdFiles)
    {
        foreach ((string original, string backup) in backups.AsEnumerable().Reverse())
        {
            if (File.Exists(backup))
            {
                File.Copy(backup, original, overwrite: true);
            }
        }

        foreach (string created in createdFiles.AsEnumerable().Reverse())
        {
            if (File.Exists(created))
            {
                File.Delete(created);
            }
        }
    }

    private sealed class BuildCheck
    {
        public bool Success { get; set; }
        public string Message { get; set; } = "";
        public string TargetName { get; set; } = "";
        public DateTime StartedUtc { get; set; } = DateTime.UtcNow;
    }

    private static BuildCheck BuildProject(string projectFile)
    {
        string? uv4 = FindKeilUv4();
        if (uv4 == null)
        {
            return new BuildCheck
            {
                Success = false,
                Message = "未找到 Keil UV4.exe，未修改工程。"
            };
        }

        string? target = FindBuildTarget(projectFile);
        if (target == null)
        {
            return new BuildCheck
            {
                Success = false,
                Message = "没有解析到 Keil Target，未修改工程。"
            };
        }

        string projectDir = Path.GetDirectoryName(projectFile)!;
        string logPath = Path.Combine(projectDir, "canmon_verify_build.log");
        if (File.Exists(logPath))
        {
            File.Delete(logPath);
        }

        using var process = new Process();
        process.StartInfo.FileName = uv4;
        process.StartInfo.Arguments = "-b \"" + projectFile + "\" -t \"" + target + "\" -o \"" + logPath + "\"";
        process.StartInfo.WorkingDirectory = projectDir;
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.CreateNoWindow = true;

        string? keilRoot = Path.GetDirectoryName(Path.GetDirectoryName(uv4)!);
        string armccBin = keilRoot == null ? "" : Path.Combine(keilRoot, "ARM", "ARMCC", "Bin");
        if (Directory.Exists(armccBin))
        {
            process.StartInfo.Environment["Path"] = armccBin + ";" + process.StartInfo.Environment["Path"];
        }

        DateTime startedUtc = DateTime.UtcNow;
        try
        {
            process.Start();
            if (!process.WaitForExit(180000))
            {
                try { process.Kill(); } catch { }
                return new BuildCheck
                {
                    Success = false,
                    TargetName = target,
                    StartedUtc = startedUtc,
                    Message = "Keil 编译超时，未确认工程安全。"
                };
            }
        }
        catch (Exception ex)
        {
            return new BuildCheck
            {
                Success = false,
                TargetName = target,
                StartedUtc = startedUtc,
                Message = "启动 Keil 编译失败：" + ex.Message
            };
        }

        string logText = File.Exists(logPath) ? File.ReadAllText(logPath, Encoding.Default) : "";
        bool hasZeroError = logText.Contains("0 Error(s)", StringComparison.OrdinalIgnoreCase);
        bool hasError = logText.Contains("Error:", StringComparison.OrdinalIgnoreCase) ||
            logText.Contains("*** Error", StringComparison.OrdinalIgnoreCase) ||
            logText.Contains("Target not created", StringComparison.OrdinalIgnoreCase);

        if (hasZeroError && !hasError)
        {
            return new BuildCheck
            {
                Success = true,
                TargetName = target,
                StartedUtc = startedUtc,
                Message = "Keil 编译验证通过：" + target
            };
        }

        return new BuildCheck
        {
            Success = false,
            TargetName = target,
            StartedUtc = startedUtc,
            Message = "Keil 编译验证失败：" + LastMeaningfulBuildLines(logText)
        };
    }

    private static string? FindKeilUv4()
    {
        return KeilToolLocator.FindUv4();
    }

    private static string? FindBuildTarget(string projectFile)
    {
        string text = File.ReadAllText(projectFile, Encoding.Default);
        var targets = new List<string>();
        int pos = 0;
        while (true)
        {
            int start = text.IndexOf("<TargetName>", pos, StringComparison.OrdinalIgnoreCase);
            if (start < 0)
            {
                break;
            }

            start += "<TargetName>".Length;
            int end = text.IndexOf("</TargetName>", start, StringComparison.OrdinalIgnoreCase);
            if (end < 0)
            {
                break;
            }

            string target = text.Substring(start, end - start).Trim();
            if (target.Length > 0)
            {
                targets.Add(target);
            }
            pos = end + "</TargetName>".Length;
        }

        return targets.FirstOrDefault(t => t.Contains("FLASH", StringComparison.OrdinalIgnoreCase)) ??
            targets.FirstOrDefault();
    }

    private static string LastMeaningfulBuildLines(string logText)
    {
        if (string.IsNullOrWhiteSpace(logText))
        {
            return "没有生成 Keil 编译日志。";
        }

        string[] lines = logText.Replace("\r", "").Split('\n')
            .Select(x => x.Trim())
            .Where(x => x.Length > 0)
            .TakeLast(8)
            .ToArray();

        return string.Join(" | ", lines);
    }

    private static int AddAgentToKeilProject(string projectFile, string projectDir, string agentPath)
    {
        byte[] data = File.ReadAllBytes(projectFile);
        if (IndexOf(data, Encoding.ASCII.GetBytes(AgentFileName), 0) >= 0)
        {
            return 0;
        }

        string relPath = MakeRelativeProjectPath(projectDir, agentPath);
        string entry =
            "\r\n            <File>" +
            "\r\n              <FileName>can_monitor_agent.c</FileName>" +
            "\r\n              <FileType>1</FileType>" +
            "\r\n              <FilePath>" + relPath + "</FilePath>" +
            "\r\n            </File>";

        byte[] entryBytes = Encoding.ASCII.GetBytes(entry);
        byte[] groupPattern = Encoding.ASCII.GetBytes("<GroupName>Source Code</GroupName>");
        byte[] filesEndPattern = Encoding.ASCII.GetBytes("</Files>");

        var insertPositions = new List<int>();
        int pos = 0;
        while (true)
        {
            int group = IndexOf(data, groupPattern, pos);
            if (group < 0)
            {
                break;
            }

            int end = IndexOf(data, filesEndPattern, group);
            if (end >= 0)
            {
                insertPositions.Add(end);
                pos = end + filesEndPattern.Length;
            }
            else
            {
                break;
            }
        }

        if (insertPositions.Count == 0)
        {
            int fallback = LastIndexOf(data, filesEndPattern);
            if (fallback >= 0)
            {
                insertPositions.Add(fallback);
            }
        }

        foreach (int insertPos in insertPositions.OrderByDescending(x => x))
        {
            data = InsertBytes(data, insertPos, entryBytes);
        }

        if (insertPositions.Count > 0)
        {
            File.WriteAllBytes(projectFile, data);
        }

        return insertPositions.Count;
    }

    private static string MakeRelativeProjectPath(string projectDir, string filePath)
    {
        string rel = Path.GetRelativePath(projectDir, filePath).Replace('/', '\\');
        if (!rel.StartsWith(".", StringComparison.Ordinal))
        {
            rel = ".\\" + rel;
        }
        return rel;
    }

    private static int InsertProcessCall(InstallPlan installPlan)
    {
        if (installPlan.FilePath == null)
        {
            return 0;
        }

        string receiveFile = installPlan.FilePath;
        byte[] data = File.ReadAllBytes(receiveFile);
        byte[] callPattern = Encoding.ASCII.GetBytes("CanMonitor_Process();");
        bool alreadyHasCall = IndexOf(data, callPattern, 0) >= 0;
        int insertCount = 0;

        if (IndexOf(data, Encoding.ASCII.GetBytes("extern void CanMonitor_Process(void);"), 0) < 0)
        {
            byte[] externBytes = Encoding.ASCII.GetBytes("extern void CanMonitor_Process(void);\r\n");
            data = InsertBytes(data, 0, externBytes);
        }

        if (!alreadyHasCall)
        {
            if (installPlan.Kind == InstallPlanKind.UsrCanReceive)
            {
                byte[] funcPattern = Encoding.ASCII.GetBytes("Usr_Can_Rcv");
                int pos = 0;
                while (true)
                {
                    int func = IndexOf(data, funcPattern, pos);
                    if (func < 0)
                    {
                        break;
                    }

                    int nextFunc = IndexOf(data, funcPattern, func + funcPattern.Length);
                    int scopeEnd = nextFunc > 0 ? nextFunc : data.Length;
                    int getData = IndexOf(data, Encoding.ASCII.GetBytes("CAN1_Get_Data"), func);
                    if (getData > 0 && getData < scopeEnd)
                    {
                        int lineStart = FindLineStart(data, getData);
                        byte[] callBytes = Encoding.ASCII.GetBytes("\tCanMonitor_Process();\r\n");
                        data = InsertBytes(data, lineStart, callBytes);
                        insertCount++;
                        pos = lineStart + callBytes.Length + 1;
                    }
                    else
                    {
                        pos = func + funcPattern.Length;
                    }
                }
            }
            else if (installPlan.Kind == InstallPlanKind.CanReceiveScheduler)
            {
                int anchor = IndexOf(data, Encoding.ASCII.GetBytes(installPlan.Anchor), 0);
                int openBrace = anchor >= 0 ? FindTopLevelOpenBraceBefore(data, anchor) : -1;
                if (openBrace >= 0)
                {
                    int insertPos = FindAfterLocalDeclarations(data, openBrace);
                    byte[] callBytes = Encoding.ASCII.GetBytes("\tCanMonitor_Process();\r\n");
                    data = InsertBytes(data, insertPos, callBytes);
                    insertCount++;
                }
            }
        }

        File.WriteAllBytes(receiveFile, data);
        return insertCount;
    }

    private static int InsertBusinessGateCall(BusinessGatePlan plan)
    {
        if (plan.FilePath == null || plan.InsertPosition < 0)
        {
            return 0;
        }

        string file = plan.FilePath;
        byte[] data = File.ReadAllBytes(file);
        int openBrace = FindFunctionOpenBrace(data, plan.FunctionName);
        if (openBrace < 0)
        {
            return 0;
        }

        int closeBrace = FindMatchingBrace(data, openBrace);
        if (closeBrace < 0)
        {
            return 0;
        }

        int existing = IndexOf(data, Encoding.ASCII.GetBytes("CanMonitor_BusinessGate"), openBrace);
        if (existing >= 0 && existing < closeBrace)
        {
            return 0;
        }

        string call =
            "\tif(!CanMonitor_BusinessGate())\r\n" +
            "\t{\r\n" +
            "\t\treturn;\r\n" +
            "\t}\r\n\r\n";
        data = InsertBytes(data, plan.InsertPosition, Encoding.ASCII.GetBytes(call));

        if (IndexOf(data, Encoding.ASCII.GetBytes("extern unsigned char CanMonitor_BusinessGate(void);"), 0) < 0)
        {
            byte[] externBytes = Encoding.ASCII.GetBytes("extern unsigned char CanMonitor_BusinessGate(void);\r\n");
            data = InsertBytes(data, 0, externBytes);
        }

        File.WriteAllBytes(file, data);
        return 1;
    }

    private static bool TraceCallExists(TraceTarget target)
    {
        byte[] data = File.ReadAllBytes(target.FilePath);
        int openBrace = FindFunctionOpenBrace(data, target.FunctionName);
        if (openBrace < 0)
        {
            return true;
        }

        int closeBrace = FindMatchingBrace(data, openBrace);
        if (closeBrace < 0)
        {
            closeBrace = data.Length;
        }

        string needle = "CanMonitor_Trace(" + FormatTraceId(target.TraceId) + ")";
        int pos = IndexOf(data, Encoding.ASCII.GetBytes("CanMonitor_Trace"), openBrace);
        return pos >= 0 && pos < closeBrace &&
            IndexOf(data, Encoding.ASCII.GetBytes(needle), openBrace) >= 0 &&
            IndexOf(data, Encoding.ASCII.GetBytes(needle), openBrace) < closeBrace;
    }

    private static int InsertTraceCalls(List<TraceTarget> traceTargets)
    {
        int total = 0;
        foreach (IGrouping<string, TraceTarget> group in traceTargets.GroupBy(t => t.FilePath, StringComparer.OrdinalIgnoreCase))
        {
            byte[] data = File.ReadAllBytes(group.Key);
            if (IndexOf(data, Encoding.ASCII.GetBytes("extern void CanMonitor_Trace(unsigned short traceId);"), 0) < 0)
            {
                byte[] externBytes = Encoding.ASCII.GetBytes("extern void CanMonitor_Trace(unsigned short traceId);\r\n");
                data = InsertBytes(data, 0, externBytes);
            }

            var inserts = new List<(int Position, TraceTarget Target)>();
            foreach (TraceTarget target in group)
            {
                int openBrace = FindFunctionOpenBrace(data, target.FunctionName);
                if (openBrace < 0)
                {
                    continue;
                }

                int closeBrace = FindMatchingBrace(data, openBrace);
                if (closeBrace < 0)
                {
                    continue;
                }

                string needle = "CanMonitor_Trace(" + FormatTraceId(target.TraceId) + ")";
                int existing = IndexOf(data, Encoding.ASCII.GetBytes(needle), openBrace);
                if (existing >= 0 && existing < closeBrace)
                {
                    continue;
                }

                int insertPos = FindAfterLocalDeclarations(data, openBrace);
                inserts.Add((insertPos, target));
            }

            foreach ((int position, TraceTarget target) in inserts.OrderByDescending(x => x.Position))
            {
                string call = "\tCanMonitor_Trace(" + FormatTraceId(target.TraceId) + ");\r\n";
                data = InsertBytes(data, position, Encoding.ASCII.GetBytes(call));
                total++;
            }

            File.WriteAllBytes(group.Key, data);
        }

        return total;
    }

    private static string FormatTraceId(ushort traceId)
    {
        return "0x" + traceId.ToString("X4");
    }

    private static int FindFunctionOpenBrace(byte[] data, string functionName)
    {
        byte[] nameBytes = Encoding.ASCII.GetBytes(functionName);
        int pos = 0;
        while (true)
        {
            int name = IndexOf(data, nameBytes, pos);
            if (name < 0)
            {
                return -1;
            }

            if (!IsIdentifierBoundary(data, name - 1) || !IsIdentifierBoundary(data, name + nameBytes.Length))
            {
                pos = name + nameBytes.Length;
                continue;
            }

            int next = SkipWhiteSpace(data, name + nameBytes.Length);
            if (next >= data.Length || data[next] != (byte)'(')
            {
                pos = name + nameBytes.Length;
                continue;
            }

            int closeParen = FindClosingParen(data, next);
            if (closeParen < 0)
            {
                return -1;
            }

            int afterParen = SkipWhiteSpace(data, closeParen + 1);
            if (afterParen < data.Length && data[afterParen] == (byte)'{')
            {
                return afterParen;
            }

            pos = closeParen + 1;
        }
    }

    private static int FindClosingParen(byte[] data, int openParen)
    {
        int depth = 0;
        for (int i = openParen; i < data.Length; i++)
        {
            if (data[i] == (byte)'(')
            {
                depth++;
            }
            else if (data[i] == (byte)')')
            {
                depth--;
                if (depth == 0)
                {
                    return i;
                }
            }
        }

        return -1;
    }

    private static int FindMatchingBrace(byte[] data, int openBrace)
    {
        int depth = 0;
        for (int i = openBrace; i < data.Length; i++)
        {
            if (data[i] == (byte)'{')
            {
                depth++;
            }
            else if (data[i] == (byte)'}')
            {
                depth--;
                if (depth == 0)
                {
                    return i;
                }
            }
        }

        return -1;
    }

    private static int SkipWhiteSpace(byte[] data, int index)
    {
        int i = index;
        while (i < data.Length && (data[i] == (byte)' ' || data[i] == (byte)'\t' || data[i] == (byte)'\r' || data[i] == (byte)'\n'))
        {
            i++;
        }
        return i;
    }

    private static bool IsIdentifierBoundary(byte[] data, int index)
    {
        if (index < 0 || index >= data.Length)
        {
            return true;
        }

        byte c = data[index];
        return !((c >= (byte)'a' && c <= (byte)'z') ||
                 (c >= (byte)'A' && c <= (byte)'Z') ||
                 (c >= (byte)'0' && c <= (byte)'9') ||
                 c == (byte)'_');
    }

    private static int FindTopLevelOpenBraceBefore(byte[] data, int index)
    {
        int depth = 0;
        int lastOpen = -1;
        for (int i = 0; i < index && i < data.Length; i++)
        {
            if (data[i] == (byte)'{')
            {
                if (depth == 0)
                {
                    lastOpen = i;
                }
                depth++;
            }
            else if (data[i] == (byte)'}' && depth > 0)
            {
                depth--;
            }
        }
        return lastOpen;
    }

    private static int FindAfterLocalDeclarations(byte[] data, int openBrace)
    {
        int pos = FindLineEnd(data, openBrace);
        int insertPos = pos;

        while (pos < data.Length)
        {
            int lineEnd = FindLineEnd(data, pos);
            string line = Encoding.ASCII.GetString(data, pos, lineEnd - pos);
            string trimmed = line.Trim();

            if (trimmed.Length == 0 || IsCommentOnlyLine(trimmed))
            {
                insertPos = lineEnd;
                pos = lineEnd;
                continue;
            }

            if (IsLocalDeclarationLine(trimmed))
            {
                insertPos = lineEnd;
                pos = lineEnd;
                continue;
            }

            break;
        }

        return insertPos;
    }

    private static bool IsCommentOnlyLine(string trimmed)
    {
        return trimmed.StartsWith("//", StringComparison.Ordinal) ||
            trimmed.StartsWith("/*", StringComparison.Ordinal) ||
            trimmed.StartsWith("*", StringComparison.Ordinal) ||
            trimmed.StartsWith("*/", StringComparison.Ordinal);
    }

    private static bool IsLocalDeclarationLine(string trimmed)
    {
        if (!trimmed.EndsWith(";", StringComparison.Ordinal))
        {
            return false;
        }

        string[] executablePrefixes =
        {
            "if", "for", "while", "switch", "return", "do", "break", "continue",
            "goto", "case", "default"
        };
        string firstToken = FirstToken(trimmed);
        foreach (string prefix in executablePrefixes)
        {
            if (firstToken.Equals(prefix, StringComparison.Ordinal))
            {
                return false;
            }
        }

        string[] declarationPrefixes =
        {
            "auto", "register", "static", "extern", "const", "volatile",
            "signed", "unsigned", "char", "short", "int", "long", "float", "double",
            "void", "struct", "union", "enum",
            "uint8_t", "uint16_t", "uint32_t", "int8_t", "int16_t", "int32_t",
            "UINT8", "UINT16", "UINT32", "INT8", "INT16", "INT32",
            "u8", "u16", "u32", "s8", "s16", "s32",
            "BOOL", "bool"
        };
        foreach (string prefix in declarationPrefixes)
        {
            if (firstToken.Equals(prefix, StringComparison.Ordinal) ||
                firstToken.Equals(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        int semicolon = trimmed.IndexOf(';');
        int paren = trimmed.IndexOf('(');
        return semicolon >= 0 && (paren < 0 || paren > semicolon) && !trimmed.Contains("=", StringComparison.Ordinal);
    }

    private static string FirstToken(string text)
    {
        int i = 0;
        while (i < text.Length && (char.IsLetterOrDigit(text[i]) || text[i] == '_'))
        {
            i++;
        }
        return text.Substring(0, i);
    }

    private static int FindLineStart(byte[] data, int index)
    {
        int i = index;
        while (i > 0 && data[i - 1] != (byte)'\n')
        {
            i--;
        }
        return i;
    }

    private static int FindLineEnd(byte[] data, int index)
    {
        int i = index;
        while (i < data.Length && data[i] != (byte)'\n')
        {
            i++;
        }

        return i < data.Length ? i + 1 : data.Length;
    }

    private static byte[] InsertBytes(byte[] source, int index, byte[] insert)
    {
        byte[] output = new byte[source.Length + insert.Length];
        Buffer.BlockCopy(source, 0, output, 0, index);
        Buffer.BlockCopy(insert, 0, output, index, insert.Length);
        Buffer.BlockCopy(source, index, output, index + insert.Length, source.Length - index);
        return output;
    }

    private static int IndexOf(byte[] source, byte[] pattern, int start)
    {
        for (int i = Math.Max(0, start); i <= source.Length - pattern.Length; i++)
        {
            bool ok = true;
            for (int j = 0; j < pattern.Length; j++)
            {
                if (source[i + j] != pattern[j])
                {
                    ok = false;
                    break;
                }
            }
            if (ok) return i;
        }
        return -1;
    }

    private static int LastIndexOf(byte[] source, byte[] pattern)
    {
        for (int i = source.Length - pattern.Length; i >= 0; i--)
        {
            bool ok = true;
            for (int j = 0; j < pattern.Length; j++)
            {
                if (source[i + j] != pattern[j])
                {
                    ok = false;
                    break;
                }
            }
            if (ok) return i;
        }
        return -1;
    }
}
