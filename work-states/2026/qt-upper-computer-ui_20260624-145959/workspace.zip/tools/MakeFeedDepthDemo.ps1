param(
    [double]$TargetM = 4.0,
    [int]$FrameCount = 25,
    [int]$FrameDelayMs = 120,
    [double]$Scale = 1.0,
    [string]$OutDir = ""
)

$ErrorActionPreference = 'Stop'

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
if ([string]::IsNullOrWhiteSpace($OutDir)) {
    $OutDir = Join-Path $repoRoot 'build\feed-depth-demo'
}
$frameDir = Join-Path $OutDir 'frames'
New-Item -ItemType Directory -Force -Path $frameDir | Out-Null

$exe = Join-Path $repoRoot 'build\QdnUpperComputerUi.exe'
if (-not (Test-Path -LiteralPath $exe)) {
    throw "Missing executable: $exe"
}

if ($FrameCount -lt 2) {
    $FrameCount = 2
}

for ($i = 0; $i -lt $FrameCount; $i++) {
    $progress = [double]$i / [double]($FrameCount - 1)
    $depth = [Math]::Round($TargetM * $progress, 3)
    $png = Join-Path $frameDir ('frame-{0:000}.png' -f $i)
    $txt = Join-Path $frameDir ('frame-{0:000}.txt' -f $i)
    & $exe `
        --screenshot $png `
        --screenshot-text $txt `
        --screenshot-demo-depth $depth $depth $depth `
        --screenshot-set-lineedit dashboard.drillMode.equalLength ([string]::Format('{0:0.###}', $TargetM)) `
        --screenshot-left-tab 0
    if ($LASTEXITCODE -ne 0) {
        throw "Screenshot frame $i failed with exit code $LASTEXITCODE"
    }
}

$gifPath = Join-Path $OutDir ('feed-depth-{0:0.###}m.gif' -f $TargetM)
$python = @'
import sys
from pathlib import Path
from PIL import Image

frame_dir = Path(sys.argv[1])
gif_path = Path(sys.argv[2])
delay_ms = int(sys.argv[3])
scale = float(sys.argv[4])

files = sorted(frame_dir.glob("frame-*.png"))
if not files:
    raise SystemExit("no frames")

frames = []
for file in files:
    image = Image.open(file).convert("RGB")
    if scale > 0 and abs(scale - 1.0) > 1e-6:
        w = max(1, int(image.width * scale))
        h = max(1, int(image.height * scale))
        image = image.resize((w, h), Image.Resampling.LANCZOS)
    frames.append(image)

gif_path.parent.mkdir(parents=True, exist_ok=True)
frames[0].save(
    gif_path,
    save_all=True,
    append_images=frames[1:],
    duration=delay_ms,
    loop=0,
    optimize=True,
)
'@
$pyPath = Join-Path $OutDir 'make_feed_depth_gif.py'
Set-Content -LiteralPath $pyPath -Value $python -Encoding UTF8
python $pyPath $frameDir $gifPath $FrameDelayMs $Scale
if ($LASTEXITCODE -ne 0) {
    throw "GIF generation failed with exit code $LASTEXITCODE"
}

Write-Output "frames=$frameDir"
Write-Output "gif=$gifPath"
