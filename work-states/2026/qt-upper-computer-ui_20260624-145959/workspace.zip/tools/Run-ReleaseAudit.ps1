﻿param(
    [string]$ExePath,
    [string]$PackageDir,
    [string]$ZipPath,
    [string]$OutDir,
    [switch]$HardwareCheck,
    [switch]$SimulatedHardwareCheck,
    [string]$HardwareHost = '192.168.0.105',
    [int]$HardwarePort = 503,
    [string]$MockHardwareHost = '127.0.0.1',
    [int]$MockHardwarePort = 1503,
    [byte]$HardwareUnitId = 255,
    [int]$HardwareAddressOffset = 1,
    [int]$HardwareTimeoutMs = 1000
)

$ErrorActionPreference = 'Stop'

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $repoRoot 'build\QdnUpperComputerUi.exe'
}
if ([string]::IsNullOrWhiteSpace($PackageDir)) {
    $releaseRoot = Join-Path $repoRoot 'release'
    $latestPackage = Get-ChildItem -LiteralPath $releaseRoot -Directory -Filter 'QdnUpperComputerUi_V*' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime, Name -Descending |
        Select-Object -First 1
    if ($latestPackage) {
        $PackageDir = $latestPackage.FullName
    } else {
        $PackageDir = Join-Path $releaseRoot 'QdnUpperComputerUi_V2026.06.22-A5'
    }
}
if ([string]::IsNullOrWhiteSpace($ZipPath)) {
    $ZipPath = $PackageDir + '.zip'
}
if ([string]::IsNullOrWhiteSpace($OutDir)) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $OutDir = Join-Path $repoRoot "build\release-audit-$stamp"
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$versionPattern = '文档版本\*{0,2}[：:]\s*V\d{4}\.\d{2}\.\d{2}|文档版本[：:]\s*V\d{4}\.\d{2}\.\d{2}|版本[：:]\s*V\d{4}\.\d{2}\.\d{2}'

function Write-Lines {
    param([string]$Path, [object[]]$Lines)
    $Lines | ForEach-Object { [string]$_ } | Set-Content -Path $Path -Encoding UTF8
}

function Invoke-Logged {
    param(
        [string]$Name,
        [scriptblock]$Script
    )
    $logPath = Join-Path $OutDir ($Name + '.log')
    Write-Host ("[audit] {0}" -f $Name)
    $output = & $Script 2>&1
    $exitCode = $LASTEXITCODE
    Write-Lines -Path $logPath -Lines $output
    if ($exitCode -ne 0) {
        throw "$Name failed, see $logPath"
    }
    return [pscustomobject]@{ Name = $Name; Log = $logPath; Output = $output }
}

function Get-VersionedDocResult {
    param([System.IO.FileInfo[]]$Files)
    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($file in $Files) {
        $text = [Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($file.FullName))
        if ($text -notmatch $versionPattern) {
            $missing.Add($file.FullName)
        }
    }
    [pscustomobject]@{ Total = $Files.Count; Missing = $missing }
}

function Get-SourceDocs {
    $handoffRoot = (Resolve-Path (Join-Path $repoRoot '..\external\can-variable-monitor') -ErrorAction SilentlyContinue)
    $roots = @(
        $repoRoot,
        (Join-Path $repoRoot 'docs'),
        $(if ($handoffRoot) { $handoffRoot.Path }),
        $(if ($handoffRoot) { Join-Path $handoffRoot.Path 'McgsModbusTool' }),
        $(if ($handoffRoot) { Join-Path $handoffRoot.Path 'QtCanToNetClient' }),
        $(if ($handoffRoot) { Join-Path $handoffRoot.Path 'CAN_TO_NET_QT_PACKAGE' }),
        $(if ($handoffRoot) { Join-Path $handoffRoot.Path 'CanVariableMonitor' }),
        'E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议',
        'E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2',
        'E:\AI_划时代\全电脑_算法PCB\正确资料_算法PCB_CAN协议\MC_LCD - 7Control_V1.2\docs'
    ) | Where-Object { Test-Path $_ }

    $files = @()
    foreach ($root in $roots) {
        $files += Get-ChildItem -LiteralPath $root -File | Where-Object {
            $_.Extension -in @('.md', '.html') -and
            $_.Name -notlike '*.bak_*' -and
            $_.Name -notlike 'Codex_无缝交接_*'
        }
    }
    $files | Sort-Object FullName -Unique
}

function Get-ExternalHandoffDocs {
    $handoffRoot = (Resolve-Path (Join-Path $repoRoot '..\external\can-variable-monitor') -ErrorAction SilentlyContinue)
    if (!$handoffRoot) {
        return @()
    }
    Get-ChildItem -LiteralPath $handoffRoot.Path -Recurse -File -Filter '*.md' | Where-Object {
        $_.Name -notlike '*.bak_*'
    } | Sort-Object FullName -Unique
}

function Get-DuplicateHandoffDocResult {
    param([System.IO.FileInfo[]]$Files)
    $bad = New-Object System.Collections.Generic.List[string]
    foreach ($file in $Files) {
        $h1Count = (Select-String -LiteralPath $file.FullName -Pattern '^#\s+' -ErrorAction SilentlyContinue).Count
        if ($h1Count -gt 1) {
            $bad.Add(('{0} ({1} top-level headings)' -f $file.FullName, $h1Count))
        }
    }
    [pscustomobject]@{ Total = $Files.Count; Bad = $bad }
}

function Get-PackageDocs {
    if (!(Test-Path $PackageDir)) {
        return @()
    }
    Get-ChildItem -LiteralPath $PackageDir -Recurse -File | Where-Object {
        $_.Extension -in @('.md', '.html', '.txt') -and
        $_.Name -notlike '*.bak_*'
    } | Sort-Object FullName -Unique
}

$vcvars = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$cmake = 'E:\Qt\Tools\CMake_64\bin\cmake.exe'
$buildDir = Join-Path $repoRoot 'build'
$buildCommand = '"' + $vcvars + '" >nul && "' + $cmake + '" --build "' + $buildDir + '" --config Release'

$steps = New-Object System.Collections.Generic.List[object]
$steps.Add((Invoke-Logged 'build-release' { & cmd.exe /d /s /c $buildCommand }))
$steps.Add((Invoke-Logged 'can-self-test' { & $ExePath --self-test-can }))
$steps.Add((Invoke-Logged 'ui-perf-self-test' { & $ExePath --self-test-ui-perf }))

$uiAuditDir = Join-Path $OutDir 'ui-audit'
$uiAuditScript = Join-Path $repoRoot 'tools\Run-UiAudit.ps1'
$uiAuditStep = Invoke-Logged 'ui-audit' {
    & powershell -ExecutionPolicy Bypass -File $uiAuditScript -ExePath $ExePath -OutDir $uiAuditDir -DemoData
}
$steps.Add($uiAuditStep)
$uiForbiddenTextStatus = if (($uiAuditStep.Output | Out-String) -match 'Forbidden text scan:\s+PASS') {
    'PASS'
} else {
    throw 'ui-audit did not prove worker-visible forbidden text scan PASS'
}

$hardwareStatus = 'NOT RUN'
$simulatedHardwareStatus = 'NOT RUN'
if ($SimulatedHardwareCheck) {
    $mockScript = Join-Path $repoRoot 'tools\Test-CanToNetMock.ps1'
    $steps.Add((Invoke-Logged 'simulated-can-to-net' {
        & powershell -NoProfile -ExecutionPolicy Bypass -File $mockScript `
            -TargetHost $MockHardwareHost `
            -Port $MockHardwarePort `
            -UnitId $HardwareUnitId `
            -AddressOffset $HardwareAddressOffset `
            -TimeoutMs $HardwareTimeoutMs
    }))
    $simulatedHardwareStatus = 'PASS'
}

if ($HardwareCheck) {
    $hardwareScript = Join-Path $repoRoot 'tools\Test-CanToNetFieldReady.ps1'
    $steps.Add((Invoke-Logged 'hardware-field-ready' {
        & powershell -ExecutionPolicy Bypass -File $hardwareScript `
            -TargetHost $HardwareHost `
            -Port $HardwarePort `
            -UnitId $HardwareUnitId `
            -AddressOffset $HardwareAddressOffset `
            -TimeoutMs $HardwareTimeoutMs
    }))
    $hardwareStatus = 'PASS'
}

$sourceDocs = @(Get-SourceDocs)
$sourceDocResult = Get-VersionedDocResult -Files $sourceDocs
if ($sourceDocResult.Missing.Count -ne 0) {
    throw "source docs missing version: $($sourceDocResult.Missing -join '; ')"
}

$packageDocs = @(Get-PackageDocs)
$packageDocResult = Get-VersionedDocResult -Files $packageDocs
if ($packageDocResult.Missing.Count -ne 0) {
    throw "package docs missing version: $($packageDocResult.Missing -join '; ')"
}

$externalHandoffDocs = @(Get-ExternalHandoffDocs)
$duplicateHandoffDocResult = Get-DuplicateHandoffDocResult -Files $externalHandoffDocs
if ($duplicateHandoffDocResult.Bad.Count -ne 0) {
    throw "external handoff docs look duplicated: $($duplicateHandoffDocResult.Bad -join '; ')"
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipEntryCount = 0
$zipHasExe = $false
$zipHasVersion = $false
if (!(Test-Path $ZipPath)) {
    throw "zip missing: $ZipPath"
}
$zip = [IO.Compression.ZipFile]::OpenRead((Resolve-Path $ZipPath))
try {
    $names = $zip.Entries | ForEach-Object FullName
    $zipEntryCount = $zip.Entries.Count
    $zipHasExe = [bool]($names | Where-Object { $_ -match '(^|/)QdnUpperComputerUi\.exe$' })
    $zipHasVersion = [bool]($names | Where-Object { $_ -match '(^|/)版本说明\.txt$' })
} finally {
    $zip.Dispose()
}
if (!$zipHasExe -or !$zipHasVersion) {
    throw 'zip sanity failed'
}

$report = New-Object System.Collections.Generic.List[string]
$report.Add('# Release Audit')
$report.Add('')
$report.Add(('Generated: {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
$report.Add(('Executable: {0}' -f (Resolve-Path $ExePath).Path))
$report.Add(('Package: {0}' -f (Resolve-Path $PackageDir).Path))
$report.Add(('Zip: {0}' -f (Resolve-Path $ZipPath).Path))
$report.Add('')
$report.Add('## Result')
$report.Add('')
$report.Add('- Build: PASS')
$report.Add('- CAN_TO_NET / business protocol self-test: PASS')
$report.Add('- UI response self-test: PASS')
$report.Add('- UI screenshot audit: PASS')
$report.Add(('- Worker-visible forbidden text scan: {0}' -f $uiForbiddenTextStatus))
$report.Add(('- Simulated CAN_TO_NET readiness: {0}' -f $simulatedHardwareStatus))
$report.Add(('- Hardware field readiness: {0}' -f $hardwareStatus))
$report.Add(('- Source docs version scan: PASS ({0} files)' -f $sourceDocResult.Total))
$report.Add(('- Package docs version scan: PASS ({0} files)' -f $packageDocResult.Total))
$report.Add(('- External handoff duplicate scan: PASS ({0} files)' -f $duplicateHandoffDocResult.Total))
$report.Add(('- Zip sanity: PASS ({0} entries)' -f $zipEntryCount))
$report.Add('')
$report.Add('## Logs')
foreach ($step in $steps) {
    $report.Add(('- {0}: {1}' -f $step.Name, $step.Log))
}
$reportPath = Join-Path $OutDir 'release-audit.md'
Write-Lines -Path $reportPath -Lines $report

Write-Host ("Release audit: PASS")
Write-Host ("Report: {0}" -f $reportPath)


