#pragma once

#include "CanBusModel.h"

#include <QPointF>
#include <QPointer>
#include <QString>
#include <QTimer>
#include <QVector>
#include <QWidget>

class QLineEdit;
class QMouseEvent;
class QButtonGroup;
class QCheckBox;
class QPushButton;
class QRadioButton;
class QResizeEvent;

struct SitonPlanPoint {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    bool valid = false;
};

struct SitonPlanHole {
    QString id;
    QString type;
    QStringList boomIds;
    SitonPlanPoint start;
    SitonPlanPoint end;
    double depthY = 0.0;
    bool mwdOn = false;
    bool completed = false;
    bool userAdded = false;
    bool constructionTraceRecorded = false;
    int constructionArm = -1;
    double constructionDepthM = 0.0;
    QString constructionTimestamp;
    QString constructionSource;
    SitonPlanPoint constructionStart;
    SitonPlanPoint constructionEnd;
};

struct SitonProfileSegment {
    QString profileType;
    QString lineSegId;
    SitonPlanPoint start;
    SitonPlanPoint end;
    double invertedRadius = 0.0;
    int linkNumber = 0;
    bool contourLine = false;
};

struct SitonTunnelPoint {
    double peg = 0.0;
    SitonPlanPoint point;
};

enum class SitonDrillViewMode {
    Face,
    Top,
    Left,
    Space
};

class SitonDrillMainView final : public QWidget {
    Q_OBJECT
public:
    explicit SitonDrillMainView(QWidget *parent = nullptr);
    void setLeftTabForScreenshot(int index);
    void setViewTabForScreenshot(int index);
    void setRealtimeState(const MachineRealtimeState &state);
    bool captureWorkBaseReferenceFromFarthestHPoint();
    void setHoleEditMode(bool enabled);
    bool isHoleEditMode() const;
    void setHoleEditTargetEndPoint(bool endPoint);
    bool holeEditTargetEndPoint() const;
    int selectedHoleIndex() const;
    SitonPlanHole selectedHole() const;
    bool selectHoleForScreenshot(int index);
    bool setSelectedHoleCoordinates(const SitonPlanPoint &start, const SitonPlanPoint &end);
    bool addHoleNearSelection();
    bool deleteSelectedHole();
    bool resetSelectedHoleEdit();
    bool resetAllHoleEdits();
    void reloadSavedHoleEdits();

signals:
    void editSelectionChanged();
    void editStatusChanged(const QString &message);

protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void leaveEvent(QEvent *event) override;

private:
    void loadDocFiles();
    bool parseDpFile(const QString &path);
    bool parseTlFile(const QString &path);

    void drawOuterLayout(QPainter &p, const QRectF &body, const QRect &dirtyRect);
    void drawLeftRail(QPainter &p, const QRectF &rail);
    void drawDataPanel(QPainter &p, const QRectF &panel);
    void drawDrillModePanel(QPainter &p, const QRectF &panel);
    void drawDrillParamPanel(QPainter &p, const QRectF &panel);
    void drawArmPanel(QPainter &p, const QRectF &panel);
    void drawFacePanel(QPainter &p, const QRectF &panel);
    void drawTopTabs(QPainter &p, const QRectF &panel);
    void drawDrillView(QPainter &p, const QRectF &plot, const QRectF &drawPlot, const QVector<SitonProfileSegment> &faceProfiles);
    void drawHPointOverlay(QPainter &p, const QRectF &plot, const QRectF &drawPlot, const QRectF &bounds);
    void updateDrillModeInputs(const QRectF &panel);
    void updateEditablePanelInputs(const QRectF &panel);
    void updateHoleLegendChecks(const QRectF &plot);
    void updateOverlayButtons(const QRectF &body);
    bool holeVisible(int index) const;

    QRectF planBounds(const QVector<SitonProfileSegment> &profiles) const;
    QRectF dataBounds(SitonDrillViewMode mode, const QVector<SitonProfileSegment> &profiles) const;
    QVector<QPointF> profilePoints(const SitonProfileSegment &segment) const;
    QPointF projectPoint(const SitonPlanPoint &point, SitonDrillViewMode mode) const;
    QPointF mapDataPoint(const SitonPlanPoint &point, const QRectF &plot, const QRectF &bounds, SitonDrillViewMode mode) const;
    QPointF mapProjectedPoint(const QPointF &point, const QRectF &plot, const QRectF &bounds) const;
    QPointF unmapProjectedPoint(const QPointF &screenPoint, const QRectF &plot, const QRectF &bounds) const;
    QRectF zoomBoundsAround(const QRectF &fullBounds, const QRectF &plot, const QPointF &center) const;
    SitonPlanPoint mouseDataPoint(const QPointF &screenPoint) const;
    int nearestHoleToMouse(const QPointF &screenPoint) const;
    int nearestEditableHoleToMouse(const QPointF &screenPoint, bool *endPoint) const;
    bool applySelectedHoleProjectedPoint(const QPointF &screenPoint);
    void setEditSelectedHole(int index);
    void emitEditSelectionChanged();
    QString holeEditSettingsGroup() const;
    QString holeEditKey(int index) const;
    void applySavedHoleEdits();
    QString constructionTraceSettingsGroup() const;
    void applySavedConstructionTraces();
    void saveConstructionTrace(int index);
    void removeConstructionTrace(int index);
    bool recordConstructionTraceForArm(int armIndex, int holeIndex, bool forceCompletion = false);
    double constructionTraceDepthMForArm(int armIndex, int holeIndex, const SitonPlanPoint &entry) const;
    SitonPlanPoint constructionTraceDirectionForArm(int armIndex, int holeIndex) const;
    SitonPlanPoint constructionTailPointForArm(int armIndex, int holeIndex, const SitonPlanPoint &entry) const;
    void saveHoleEdit(int index);
    void saveAddedHoles();
    void saveDeletedHoleIds(const QStringList &ids);
    QStringList deletedHoleIds() const;
    QString nextAddedHoleId() const;
    bool restoreHoleFromOriginal(int index);
    QVector<int> armHoleIndices() const;
    int defaultHoleIndexForArm(int armIndex) const;
    int activeHoleIndex() const;
    double configuredBaseDepthM() const;
    double configuredEqualDepthM() const;
    double planDepthMForHole(int holeIndex) const;
    double workBaseReferenceX() const;
    double holeEntryReferenceXForArm(int armIndex, int holeIndex) const;
    SitonPlanPoint drillDirectionForHole(int holeIndex) const;
    SitonPlanPoint drillDirectionForArm(int armIndex, int holeIndex) const;
    double baseLevelTargetDepthM(double entryX, double directionX) const;
    double targetDrillDepthMForHole(int holeIndex) const;
    double targetDrillDepthMForArm(int armIndex) const;
    bool captureHoleEntryReferenceForArm(int armIndex);
    void updateDrillingEntryReferences(const MachineRealtimeState &previous, const MachineRealtimeState &current);
    SitonPlanPoint hPointForArm(int armIndex) const;
    SitonPlanPoint hTailPointForArm(int armIndex, const SitonPlanPoint &hPoint) const;
    SitonPlanPoint currentHPoint() const;
    int hOverlapHoleIndex(const SitonPlanPoint &hPoint) const;
    QRectF dataTopBoxRect(const QRectF &panel) const;
    QRectF leftTabRect(const QRectF &panel, int index) const;
    QRectF viewTabRect(const QRectF &panel, int index) const;
    QRectF facePanelRect() const;

    QString docDir_;
    QString dpFileName_;
    QString tlFileName_;
    QString loadError_;
    int declaredHoleCount_ = 0;
    double drpLength_ = 0.0;
    SitonDrillViewMode currentView_ = SitonDrillViewMode::Face;
    int activeArm_ = 0;
    int leftTab_ = 0;
    int holeType_ = 0;
    int drillMode_ = 1;
    int dimTicks_ = 0;
    int hStep_ = 0;
    double workBaseReferenceX_ = 0.0;
    double holeEntryReferenceX_[3] = {0.0, 0.0, 0.0};
    double spaceYawDeg_ = -30.0;
    double spacePitchDeg_ = 18.0;
    bool spaceDragging_ = false;
    bool holeEditMode_ = false;
    bool holeEditTargetEndPoint_ = false;
    bool holeEditDragging_ = false;
    QPointF lastSpaceDrag_;
    QTimer hTimer_;
    QRectF lastPlot_;
    QRectF lastDrawPlot_;
    QRectF lastBounds_;
    QPointF mouseScreen_;
    SitonPlanPoint mousePoint_;
    SitonPlanPoint simulatedHPoints_[3];
    MachineRealtimeState realtimeState_;
    bool mouseInPlot_ = false;
    bool showCompletedHoles_ = true;
    bool showPendingHoles_ = true;
    bool workBaseReferenceXValid_ = false;
    bool holeEntryReferenceXValid_[3] = {false, false, false};
    bool simulatedHPointValid_[3] = {false, false, false};
    int mouseNearestHole_ = -1;
    int editSelectedHole_ = -1;
    int simulatedNearestHole_[3] = {-1, -1, -1};
    QRectF lastDataPanel_;
    QPointer<QLineEdit> baseLevelEdit_;
    QPointer<QLineEdit> equalLengthEdit_;
    QPointer<QButtonGroup> holeTypeGroup_;
    QPointer<QButtonGroup> drillModeGroup_;
    QVector<QPointer<QRadioButton>> holeTypeButtons_;
    QVector<QPointer<QRadioButton>> drillModeButtons_;
    QPointer<QPushButton> drillModeConfirm_;
    QPointer<QCheckBox> completedHoleCheck_;
    QPointer<QCheckBox> pendingHoleCheck_;
    QVector<QPointer<QLineEdit>> drillParamEdits_;
    QPointer<QPushButton> drillParamConfirm_;
    QVector<QPointer<QPushButton>> railButtons_;
    QVector<QPointer<QPushButton>> leftTabButtons_;
    QVector<QPointer<QPushButton>> viewTabButtons_;
    QVector<SitonPlanHole> holes_;
    QVector<SitonPlanHole> originalHoles_;
    QVector<SitonProfileSegment> profiles_;
    QVector<SitonTunnelPoint> tunnelPoints_;
};
