#include "SitonDrillMainView.h"

#include <algorithm>
#include <cstdio>
#include <limits>
#include <utility>

#include <QButtonGroup>
#include <QCheckBox>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QFontMetrics>
#include <QLineF>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPushButton>
#include <QRadioButton>
#include <QSettings>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtMath>

namespace {
QString u(const char *text) {
    return QString::fromUtf8(text);
}

constexpr double kInvalidLow = std::numeric_limits<double>::max();
constexpr double kInvalidHigh = std::numeric_limits<double>::lowest();
constexpr double kMinBaseLevelDirectionX = 0.12;
constexpr double kEditableTailProjectionM = 0.02;
const QColor kConstructionTraceColor("#9a6432");

bool hasEditableTail(const SitonPlanHole &hole) {
    if (!hole.start.valid || !hole.end.valid) {
        return false;
    }
    const double dx = hole.end.x - hole.start.x;
    const double dz = hole.end.z - hole.start.z;
    return qSqrt(dx * dx + dz * dz) > kEditableTailProjectionM;
}

QString latestFilePath(const QString &dirPath, const QString &pattern) {
    QDir dir(dirPath);
    const QFileInfoList files = dir.entryInfoList({pattern}, QDir::Files, QDir::Time);
    return files.isEmpty() ? QString() : files.first().absoluteFilePath();
}

double readDouble(QXmlStreamReader &xml) {
    bool ok = false;
    const double value = xml.readElementText(QXmlStreamReader::SkipChildElements).trimmed().toDouble(&ok);
    return ok ? value : 0.0;
}

int readInt(QXmlStreamReader &xml) {
    bool ok = false;
    const int value = xml.readElementText(QXmlStreamReader::SkipChildElements).trimmed().toInt(&ok);
    return ok ? value : 0;
}

bool readBool(QXmlStreamReader &xml) {
    return xml.readElementText(QXmlStreamReader::SkipChildElements).trimmed().compare(QStringLiteral("true"), Qt::CaseInsensitive) == 0;
}

void pulseButtonText(QPushButton *button, const QString &temporaryText, int delayMs = 750) {
    if (!button) {
        return;
    }
    const QString originalText = button->text();
    button->setText(temporaryText);
    QTimer::singleShot(delayMs, button, [button, originalText] {
        button->setText(originalText);
    });
}

SitonPlanPoint readPoint(QXmlStreamReader &xml) {
    SitonPlanPoint point;
    while (xml.readNextStartElement()) {
        const QStringView name = xml.name();
        if (name == QStringLiteral("PointX")) {
            point.x = readDouble(xml);
            point.valid = true;
        } else if (name == QStringLiteral("PointY")) {
            point.y = readDouble(xml);
            point.valid = true;
        } else if (name == QStringLiteral("PointZ")) {
            point.z = readDouble(xml);
            point.valid = true;
        } else {
            xml.skipCurrentElement();
        }
    }
    return point;
}

SitonPlanPoint normalizedDirection(double dx, double dy, double dz) {
    SitonPlanPoint direction;
    const double length = qSqrt(dx * dx + dy * dy + dz * dz);
    if (length <= 1e-9) {
        return direction;
    }
    direction.x = dx / length;
    direction.y = dy / length;
    direction.z = dz / length;
    direction.valid = true;
    return direction;
}

QString readText(QXmlStreamReader &xml) {
    return xml.readElementText(QXmlStreamReader::SkipChildElements).trimmed();
}

void expandRange(double value, double &low, double &high) {
    low = qMin(low, value);
    high = qMax(high, value);
}

void drawHardPanel(QPainter &p, const QRectF &rect, const QColor &fill = QColor("#555555"), double radius = 6.0) {
    p.setPen(QPen(QColor("#050505"), 3));
    p.setBrush(fill);
    p.drawRoundedRect(rect, radius, radius);
}

void drawSquareButton(QPainter &p, const QRectF &rect, const QString &text, bool active) {
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(active ? QColor("#020202") : QColor("#7a7a7a"));
    p.drawRoundedRect(rect, 3, 3);
    p.setPen(active ? QColor("#00c8ef") : QColor("#ffffff"));
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 15, QFont::Bold));
    p.drawText(rect, Qt::AlignCenter, text);
}

QString viewTitle(SitonDrillViewMode mode) {
    switch (mode) {
    case SitonDrillViewMode::Face:
        return u("主视图 X-Z");
    case SitonDrillViewMode::Top:
        return u("俯视图 X-Y");
    case SitonDrillViewMode::Left:
        return u("左视图 Y-Z");
    case SitonDrillViewMode::Space:
        return u("三维图 XYZ");
    }
    return QString();
}

QString coordText(const SitonPlanPoint &point) {
    return QStringLiteral("X:%1  Y:%2  Z:%3")
        .arg(point.x, 0, 'f', 2)
        .arg(point.y, 0, 'f', 2)
        .arg(point.z, 0, 'f', 2);
}

QString armShortName(int armIndex) {
    return QStringList{u("左臂"), u("中臂"), u("右臂")}.value(armIndex, u("臂"));
}

QColor armHColor(int armIndex, int activeArm) {
    return activeArm == armIndex ? QColor("#f6df4a") : QColor("#a9c5c0");
}

void drawHDirectionTail(QPainter &p, const QPointF &hScreen, const QPointF &tailReference,
                        const QColor &color, double length, double width) {
    QLineF tailLine(hScreen, tailReference);
    if (tailLine.length() < 1.0) {
        return;
    }
    tailLine.setLength(length);
    QColor tailColor = color;
    tailColor.setAlpha(220);
    p.save();
    p.setBrush(Qt::NoBrush);
    p.setPen(QPen(tailColor, width, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    p.drawLine(tailLine.p2(), tailLine.p1());
    p.setPen(QPen(tailColor, qMax(1.4, width * 0.65), Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    p.drawEllipse(tailLine.p2(), width * 0.85, width * 0.85);
    p.restore();
}

QString realtimeValueText(double value, int decimals = 0) {
    if (qAbs(value) < 0.0001) {
        return QStringLiteral("0");
    }
    return QString::number(value, 'f', decimals);
}

QString drillCommonValueText(const ArmRealtimeState &arm, int row) {
    switch (row) {
    case 0:
        return realtimeValueText(arm.impactPressure);
    case 1:
        return realtimeValueText(arm.thrustPressure);
    case 2:
        return realtimeValueText(arm.rotationPressure);
    case 3:
        return QStringLiteral("0");
    case 4:
        return realtimeValueText(arm.boomPressure);
    case 5:
        return realtimeValueText(arm.lubricationPressure);
    case 6:
        return QStringLiteral("0");
    case 7:
        return realtimeValueText(arm.waterFlow);
    case 8:
        return QStringLiteral("0");
    case 9:
        return realtimeValueText(arm.bufferPressure);
    default:
        return QStringLiteral("0");
    }
}

class LegendCheckBox final : public QCheckBox {
public:
    explicit LegendCheckBox(const QString &text, QWidget *parent = nullptr) : QCheckBox(text, parent) {
        setCursor(Qt::PointingHandCursor);
        setFixedHeight(24);
        setAttribute(Qt::WA_TranslucentBackground, true);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        const QRectF box(0, 4, 15, 15);
        p.setPen(QPen(QColor("#00b9de"), 1.5));
        p.setBrush(isChecked() ? QColor("#00b9de") : QColor("#252525"));
        p.drawRect(box);
        if (isChecked()) {
            p.setPen(QPen(QColor("#001016"), 2.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            p.drawLine(QPointF(box.left() + 3, box.center().y() + 1), QPointF(box.left() + 6, box.bottom() - 3));
            p.drawLine(QPointF(box.left() + 6, box.bottom() - 3), QPointF(box.right() - 2, box.top() + 3));
        }
        p.setPen(QColor("#ffffff"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 14, QFont::Bold));
        p.drawText(QRectF(24, 0, width() - 24, height()), Qt::AlignLeft | Qt::AlignVCenter, text());
    }
};
}

SitonDrillMainView::SitonDrillMainView(QWidget *parent) : QWidget(parent) {
    setMinimumSize(1024, 560);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setMouseTracking(true);
    auto setupModeEdit = [this](const QString &value, const QString &objectName) {
        auto *edit = new QLineEdit(value, this);
        edit->setObjectName(objectName);
        edit->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        edit->setProperty("class", "drillModeInput");
        edit->setStyleSheet(QStringLiteral(
            "QLineEdit[class=\"drillModeInput\"] { color: #ffffff; background: #020202; border: 2px solid #020202; "
            "border-radius: 4px; padding: 2px 10px; font-family: Consolas; font-size: 16px; font-weight: 800; }"
            "QLineEdit[class=\"drillModeInput\"]:focus { border-color: #00c8ef; }"));
        edit->hide();
        return edit;
    };
    baseLevelEdit_ = setupModeEdit(QStringLiteral("3"), QStringLiteral("dashboard.drillMode.baseLevel"));
    equalLengthEdit_ = setupModeEdit(QStringLiteral("2.5"), QStringLiteral("dashboard.drillMode.equalLength"));
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    drillMode_ = qBound(0, settings.value(QStringLiteral("dashboard/drillMode/mode"), drillMode_).toInt(), 2);
    bool workBaseOk = false;
    const double savedWorkBaseX = settings.value(QStringLiteral("dashboard/workBaseReferenceX")).toDouble(&workBaseOk);
    if (workBaseOk) {
        workBaseReferenceX_ = savedWorkBaseX;
        workBaseReferenceXValid_ = true;
    }

    auto setupModeRadio = [this](const QString &text) {
        auto *radio = new QRadioButton(text, this);
        radio->setCursor(Qt::PointingHandCursor);
        radio->setProperty("class", "drillModeRadio");
        radio->setStyleSheet(QStringLiteral(
            "QRadioButton[class=\"drillModeRadio\"] { color: #ffffff; background: transparent; "
            "font-family: \"Microsoft YaHei UI\"; font-size: 15px; font-weight: 800; spacing: 8px; }"
            "QRadioButton[class=\"drillModeRadio\"]::indicator { width: 18px; height: 18px; "
            "border-radius: 9px; background: #050505; border: 2px solid #050505; }"
            "QRadioButton[class=\"drillModeRadio\"]::indicator:checked { background: #00c8ef; "
            "border: 5px solid #050505; }"));
        radio->hide();
        return radio;
    };
    holeTypeGroup_ = new QButtonGroup(this);
    holeTypeGroup_->setExclusive(true);
    for (int i = 0; i < 3; ++i) {
        auto *radio = setupModeRadio(QStringList{u("爆破孔"), u("锚杆孔"), u("超前孔")}.at(i));
        holeTypeGroup_->addButton(radio, i);
        holeTypeButtons_.append(radio);
    }
    if (!holeTypeButtons_.isEmpty() && holeTypeButtons_.first()) {
        holeTypeButtons_.first()->setChecked(true);
    }
    connect(holeTypeGroup_, &QButtonGroup::idClicked, this, [this](int id) {
        holeType_ = id;
        dimTicks_ = 2;
        update();
    });

    drillModeGroup_ = new QButtonGroup(this);
    drillModeGroup_->setExclusive(true);
    for (int i = 0; i < 3; ++i) {
        auto *radio = setupModeRadio(QStringList{u("基准底平齐"), u("孔等长"), u("按布孔图打孔")}.at(i));
        drillModeGroup_->addButton(radio, i);
        drillModeButtons_.append(radio);
    }
    if (drillMode_ >= 0 && drillMode_ < drillModeButtons_.size() && drillModeButtons_.at(drillMode_)) {
        drillModeButtons_.at(drillMode_)->setChecked(true);
    }
    connect(drillModeGroup_, &QButtonGroup::idClicked, this, [this](int id) {
        drillMode_ = id;
        for (int arm = 0; arm < 3; ++arm) {
            holeEntryReferenceXValid_[arm] = false;
        }
        QSettings modeSettings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
        modeSettings.setValue(QStringLiteral("dashboard/drillMode/mode"), drillMode_);
        modeSettings.sync();
        dimTicks_ = 2;
        update();
    });

    drillModeConfirm_ = new QPushButton(u("确认"), this);
    drillModeConfirm_->setProperty("class", "drillModeConfirm");
    drillModeConfirm_->setCursor(Qt::PointingHandCursor);
    drillModeConfirm_->setStyleSheet(QStringLiteral(
        "QPushButton[class=\"drillModeConfirm\"] { color: #ffffff; background: #8b8b8b; border: 2px solid #050505; "
        "border-radius: 5px; font-family: \"Microsoft YaHei UI\"; font-size: 15px; font-weight: 800; }"
        "QPushButton[class=\"drillModeConfirm\"]:pressed { background: #6f6f6f; }"));
    drillModeConfirm_->hide();
    connect(drillModeConfirm_, &QPushButton::clicked, this, [this] {
        QSettings modeSettings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
        modeSettings.setValue(QStringLiteral("dashboard/drillMode/mode"), drillMode_);
        modeSettings.sync();
        pulseButtonText(drillModeConfirm_.data(), u("已确认"));
        dimTicks_ = 2;
        update();
    });

    auto refreshDepthTargets = [this](const QString &) {
        for (int arm = 0; arm < 3; ++arm) {
            holeEntryReferenceXValid_[arm] = false;
        }
        dimTicks_ = 2;
        update();
    };
    connect(baseLevelEdit_, &QLineEdit::textChanged, this, refreshDepthTargets);
    connect(equalLengthEdit_, &QLineEdit::textChanged, this, refreshDepthTargets);

    auto setupPanelEdit = [this](const QString &value, const QString &objectName) {
        auto *edit = new QLineEdit(value, this);
        edit->setObjectName(objectName);
        edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        edit->setProperty("class", "panelValueInput");
        edit->setStyleSheet(QStringLiteral(
            "QLineEdit[class=\"panelValueInput\"] { color: #ffffff; background: #020202; border: 2px solid #020202; "
            "border-radius: 4px; padding: 2px 8px; font-family: Consolas; font-size: 14px; font-weight: 800; }"
            "QLineEdit[class=\"panelValueInput\"]:focus { border-color: #00c8ef; }"));
        edit->hide();
        return edit;
    };
    const QStringList panelDefaults{QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"),
                                    QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), u("自动")};
    for (int i = 0; i < panelDefaults.size(); ++i) {
        drillParamEdits_.append(setupPanelEdit(
            panelDefaults.at(i),
            QStringLiteral("dashboard.drillParam.%1").arg(i, 2, 10, QLatin1Char('0'))));
    }
    drillParamConfirm_ = new QPushButton(u("确认"), this);
    drillParamConfirm_->setProperty("class", "autoConfirm");
    drillParamConfirm_->setCursor(Qt::PointingHandCursor);
    drillParamConfirm_->setStyleSheet(QStringLiteral(
        "QPushButton[class=\"autoConfirm\"] { color: #ffffff; background: #8b8b8b; border: 2px solid #050505; "
        "border-radius: 5px; font-family: \"Microsoft YaHei UI\"; font-size: 15px; font-weight: 800; }"
        "QPushButton[class=\"autoConfirm\"]:pressed { background: #6f6f6f; }"));
    drillParamConfirm_->hide();
    connect(drillParamConfirm_, &QPushButton::clicked, this, [this] {
        pulseButtonText(drillParamConfirm_.data(), u("已下发"));
        dimTicks_ = 2;
        update();
    });
    auto setupLegendCheck = [this](const QString &text) {
        auto *check = new LegendCheckBox(text, this);
        check->setChecked(true);
        check->setProperty("class", "holeLegendCheck");
        check->hide();
        return check;
    };
    completedHoleCheck_ = setupLegendCheck(u("已完成的孔"));
    pendingHoleCheck_ = setupLegendCheck(u("未完成的孔"));
    connect(completedHoleCheck_, &QCheckBox::toggled, this, [this](bool checked) {
        showCompletedHoles_ = checked;
        update();
    });
    connect(pendingHoleCheck_, &QCheckBox::toggled, this, [this](bool checked) {
        showPendingHoles_ = checked;
        update();
    });

    auto makeOverlayButton = [this](const QString &text) {
        auto *button = new QPushButton(text, this);
        button->setCursor(Qt::PointingHandCursor);
        button->setProperty("class", "sitonPaintedOverlay");
        button->hide();
        return button;
    };
    for (int i = 0; i < 3; ++i) {
        const QString text = QStringList{u("左\n臂"), u("中\n臂"), u("右\n臂")}.at(i);
        auto *button = makeOverlayButton(text);
        connect(button, &QPushButton::clicked, this, [this, i] {
            activeArm_ = i;
            hStep_ = 0;
            dimTicks_ = 2;
            update();
        });
        railButtons_.append(button);
    }
    for (int i = 0; i < 3; ++i) {
        const QString text = QStringList{u("常用数据"), u("钻机参数"), u("钻孔模式")}.at(i);
        auto *button = makeOverlayButton(text);
        connect(button, &QPushButton::clicked, this, [this, i] {
            leftTab_ = i;
            const QRectF topBox = dataTopBoxRect(lastDataPanel_);
            updateDrillModeInputs(leftTab_ == 2 ? topBox : QRectF());
            updateEditablePanelInputs(leftTab_ == 1 ? topBox : QRectF());
            update();
        });
        leftTabButtons_.append(button);
    }
    for (int i = 0; i < 4; ++i) {
        const QString text = QStringList{u("主视图"), u("俯视图"), u("左视图"), u("三维图")}.at(i);
        auto *button = makeOverlayButton(text);
        connect(button, &QPushButton::clicked, this, [this, i] {
            if (holeEditMode_ && i != 0) {
                currentView_ = SitonDrillViewMode::Face;
                update();
                return;
            }
            currentView_ = static_cast<SitonDrillViewMode>(i);
            update();
        });
        viewTabButtons_.append(button);
    }
    const QString packagedDocDir = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("DocFile"));
    docDir_ = QDir(packagedDocDir).exists()
        ? packagedDocDir
        : QStringLiteral("E:/AI_划时代/全电脑_算法PCB/上位机（siton）/DocFile");
    loadDocFiles();
    connect(&hTimer_, &QTimer::timeout, this, [this] {
        ++hStep_;
        if (dimTicks_ > 0) {
            --dimTicks_;
        }
        update();
    });
    hTimer_.start(850);
}

void SitonDrillMainView::setHoleEditMode(bool enabled) {
    if (holeEditMode_ == enabled) {
        return;
    }
    holeEditMode_ = enabled;
    holeEditDragging_ = false;
    spaceDragging_ = false;
    if (holeEditMode_) {
        currentView_ = SitonDrillViewMode::Face;
        leftTab_ = 0;
        showCompletedHoles_ = true;
        showPendingHoles_ = true;
        if (editSelectedHole_ < 0 && !holes_.isEmpty()) {
            setEditSelectedHole(0);
        }
    }
    emitEditSelectionChanged();
    update();
}

bool SitonDrillMainView::isHoleEditMode() const {
    return holeEditMode_;
}

void SitonDrillMainView::setHoleEditTargetEndPoint(bool endPoint) {
    if (holeEditTargetEndPoint_ == endPoint) {
        return;
    }
    holeEditTargetEndPoint_ = endPoint;
    emitEditSelectionChanged();
    update();
}

bool SitonDrillMainView::holeEditTargetEndPoint() const {
    return holeEditTargetEndPoint_;
}

int SitonDrillMainView::selectedHoleIndex() const {
    return editSelectedHole_;
}

SitonPlanHole SitonDrillMainView::selectedHole() const {
    if (editSelectedHole_ < 0 || editSelectedHole_ >= holes_.size()) {
        return {};
    }
    return holes_.at(editSelectedHole_);
}

bool SitonDrillMainView::selectHoleForScreenshot(int index) {
    if (index < 0 || index >= holes_.size()) {
        return false;
    }
    setEditSelectedHole(index);
    if (!hasEditableTail(holes_.at(index)) && holeEditTargetEndPoint_) {
        holeEditTargetEndPoint_ = false;
        emitEditSelectionChanged();
    }
    update();
    return true;
}

bool SitonDrillMainView::setSelectedHoleCoordinates(const SitonPlanPoint &start, const SitonPlanPoint &end) {
    if (editSelectedHole_ < 0 || editSelectedHole_ >= holes_.size()) {
        emit editStatusChanged(u("未选中孔位"));
        return false;
    }
    SitonPlanHole &hole = holes_[editSelectedHole_];
    hole.start = start;
    hole.end = end;
    hole.start.valid = true;
    hole.end.valid = end.valid;
    hole.depthY = hole.end.valid ? (hole.end.y - hole.start.y) : 0.0;
    saveHoleEdit(editSelectedHole_);
    if (hole.userAdded) {
        saveAddedHoles();
    }
    emitEditSelectionChanged();
    emit editStatusChanged(u("已保存到本机"));
    update();
    return true;
}

bool SitonDrillMainView::addHoleNearSelection() {
    SitonPlanHole hole;
    if (editSelectedHole_ >= 0 && editSelectedHole_ < holes_.size()) {
        hole = holes_.at(editSelectedHole_);
    } else if (!holes_.isEmpty()) {
        hole = holes_.first();
    } else {
        hole.start = {0.0, 0.0, 0.0, true};
        hole.end = {0.0, 4.0, 0.0, true};
        hole.depthY = 4.0;
    }

    hole.id = nextAddedHoleId();
    hole.completed = false;
    hole.userAdded = true;
    hole.constructionTraceRecorded = false;
    hole.constructionArm = -1;
    hole.constructionDepthM = 0.0;
    hole.constructionTimestamp.clear();
    hole.constructionSource.clear();
    hole.constructionStart = {};
    hole.constructionEnd = {};
    hole.start.x += 0.25;
    hole.start.z += 0.25;
    hole.end.x += 0.25;
    hole.end.z += 0.25;
    hole.start.valid = true;
    hole.end.valid = true;
    hole.depthY = hole.end.y - hole.start.y;
    holes_.append(hole);
    editSelectedHole_ = holes_.size() - 1;
    saveAddedHoles();
    saveHoleEdit(editSelectedHole_);
    emitEditSelectionChanged();
    emit editStatusChanged(u("已新增孔 H") + hole.id);
    update();
    return true;
}

bool SitonDrillMainView::deleteSelectedHole() {
    if (editSelectedHole_ < 0 || editSelectedHole_ >= holes_.size()) {
        emit editStatusChanged(u("未选中孔位"));
        return false;
    }
    const SitonPlanHole hole = holes_.at(editSelectedHole_);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    settings.remove(holeEditKey(editSelectedHole_));
    settings.endGroup();
    settings.sync();

    if (!hole.userAdded) {
        QStringList deleted = deletedHoleIds();
        if (!deleted.contains(hole.id)) {
            deleted.append(hole.id);
        }
        saveDeletedHoleIds(deleted);
    }
    removeConstructionTrace(editSelectedHole_);

    holes_.removeAt(editSelectedHole_);
    if (holes_.isEmpty()) {
        editSelectedHole_ = -1;
    } else {
        editSelectedHole_ = qMin(editSelectedHole_, holes_.size() - 1);
    }
    saveAddedHoles();
    emitEditSelectionChanged();
    emit editStatusChanged(u("已删除孔 H") + hole.id);
    update();
    return true;
}

bool SitonDrillMainView::resetSelectedHoleEdit() {
    if (editSelectedHole_ >= 0 && editSelectedHole_ < holes_.size() && holes_.at(editSelectedHole_).userAdded) {
        return deleteSelectedHole();
    }
    if (!restoreHoleFromOriginal(editSelectedHole_)) {
        emit editStatusChanged(u("未选中孔位"));
        return false;
    }
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    settings.remove(holeEditKey(editSelectedHole_));
    settings.endGroup();
    settings.sync();
    applySavedConstructionTraces();
    emitEditSelectionChanged();
    emit editStatusChanged(u("已恢复此孔"));
    update();
    return true;
}

bool SitonDrillMainView::resetAllHoleEdits() {
    if (originalHoles_.isEmpty()) {
        return false;
    }
    holes_ = originalHoles_;
    editSelectedHole_ = qBound(-1, editSelectedHole_, holes_.size() - 1);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.remove(holeEditSettingsGroup());
    settings.sync();
    applySavedConstructionTraces();
    emitEditSelectionChanged();
    emit editStatusChanged(u("已恢复全部孔位"));
    update();
    return true;
}

void SitonDrillMainView::reloadSavedHoleEdits() {
    if (!originalHoles_.isEmpty()) {
        holes_ = originalHoles_;
        applySavedHoleEdits();
        applySavedConstructionTraces();
        editSelectedHole_ = qBound(-1, editSelectedHole_, holes_.size() - 1);
        emitEditSelectionChanged();
        update();
    }
}

void SitonDrillMainView::setLeftTabForScreenshot(int index) {
    leftTab_ = qBound(0, index, 2);
    const QRectF topBox = dataTopBoxRect(lastDataPanel_);
    updateDrillModeInputs(leftTab_ == 2 ? topBox : QRectF());
    updateEditablePanelInputs(leftTab_ == 1 ? topBox : QRectF());
    update();
}

void SitonDrillMainView::setViewTabForScreenshot(int index) {
    currentView_ = static_cast<SitonDrillViewMode>(qBound(0, index, 3));
    spaceDragging_ = false;
    unsetCursor();
    update(facePanelRect().toAlignedRect().adjusted(-2, -2, 2, 2));
}

void SitonDrillMainView::setRealtimeState(const MachineRealtimeState &state) {
    const bool traceRealtime = qEnvironmentVariableIsSet("QDN_TRACE_DRILL_REALTIME");
    if (traceRealtime) {
        std::fprintf(stdout, "TRACE drill setRealtime begin r-valid=%d r-boom=%.2f r-comp=%.2f\n",
                     state.arms[2].boomPressureValid ? 1 : 0,
                     state.arms[2].boomPressure,
                     state.arms[2].compensationThrustPressure);
        std::fflush(stdout);
    }
    const MachineRealtimeState previous = realtimeState_;
    if (traceRealtime) {
        std::fprintf(stdout, "TRACE drill copied previous\n");
        std::fflush(stdout);
    }
    realtimeState_ = state;
    if (traceRealtime) {
        std::fprintf(stdout, "TRACE drill assigned current\n");
        std::fflush(stdout);
    }
    updateDrillingEntryReferences(previous, state);
    for (int arm = 0; arm < 3; ++arm) {
        if (!state.arms[arm].hValid) {
            continue;
        }
        const SitonPlanPoint hPoint = hPointForArm(arm);
        recordConstructionTraceForArm(arm, hOverlapHoleIndex(hPoint), false);
    }
    if (traceRealtime) {
        std::fprintf(stdout, "TRACE drill updated entry refs\n");
        std::fflush(stdout);
    }
    update();
    if (traceRealtime) {
        std::fprintf(stdout, "TRACE drill update posted\n");
        std::fflush(stdout);
    }
}

bool SitonDrillMainView::captureWorkBaseReferenceFromFarthestHPoint() {
    SitonPlanPoint reference;
    auto considerPoint = [&reference](const SitonPlanPoint &candidate) {
        if (!candidate.valid) {
            return;
        }
        if (!reference.valid || candidate.x > reference.x) {
            reference = candidate;
        }
    };

    for (int arm = 0; arm < 3; ++arm) {
        const ArmRealtimeState &state = realtimeState_.arms[arm];
        if (!state.hValid) {
            continue;
        }
        SitonPlanPoint point;
        point.x = state.hX;
        point.y = state.hY;
        point.z = state.hZ;
        point.valid = true;
        considerPoint(point);
    }
    if (!reference.valid) {
        for (int arm = 0; arm < 3; ++arm) {
            if (simulatedHPointValid_[arm]) {
                considerPoint(simulatedHPoints_[arm]);
            }
        }
    }
    if (!reference.valid) {
        return false;
    }

    workBaseReferenceX_ = reference.x;
    workBaseReferenceXValid_ = true;
    for (int arm = 0; arm < 3; ++arm) {
        holeEntryReferenceXValid_[arm] = false;
    }
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.setValue(QStringLiteral("dashboard/workBaseReferenceX"), workBaseReferenceX_);
    settings.sync();
    update();
    return true;
}

void SitonDrillMainView::loadDocFiles() {
    loadError_.clear();
    holes_.clear();
    originalHoles_.clear();
    profiles_.clear();
    tunnelPoints_.clear();
    declaredHoleCount_ = 0;
    drpLength_ = 0.0;

    const QString dpPath = latestFilePath(docDir_, QStringLiteral("*.dp"));
    const QString tlPath = latestFilePath(docDir_, QStringLiteral("*.tl"));
    if (dpPath.isEmpty()) {
        loadError_ = u("未找到 .dp 炮孔计划文件");
        return;
    }
    if (!parseDpFile(dpPath)) {
        return;
    }
    originalHoles_ = holes_;
    applySavedHoleEdits();
    applySavedConstructionTraces();
    if (!tlPath.isEmpty()) {
        parseTlFile(tlPath);
    }
}

bool SitonDrillMainView::parseDpFile(const QString &path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        loadError_ = u("无法打开 DP 文件：") + path;
        return false;
    }

    dpFileName_ = QFileInfo(path).fileName();
    QXmlStreamReader xml(&file);
    while (xml.readNextStartElement()) {
        if (xml.name() != QStringLiteral("DRPPlan")) {
            xml.skipCurrentElement();
            continue;
        }

        while (xml.readNextStartElement()) {
            if (xml.name() != QStringLiteral("DrillPlan")) {
                xml.skipCurrentElement();
                continue;
            }

            while (xml.readNextStartElement()) {
                const QStringView name = xml.name();
                if (name == QStringLiteral("NumberOfHoles")) {
                    declaredHoleCount_ = readInt(xml);
                } else if (name == QStringLiteral("DRPLength")) {
                    drpLength_ = readDouble(xml);
                } else if (name == QStringLiteral("Hole")) {
                    SitonPlanHole hole;
                    while (xml.readNextStartElement()) {
                        const QStringView holeName = xml.name();
                        if (holeName == QStringLiteral("HoleId")) {
                            hole.id = readText(xml);
                        } else if (holeName == QStringLiteral("StartPoint")) {
                            hole.start = readPoint(xml);
                        } else if (holeName == QStringLiteral("EndPoint")) {
                            hole.end = readPoint(xml);
                        } else if (holeName == QStringLiteral("TypeOfHole")) {
                            hole.type = readText(xml);
                        } else if (holeName == QStringLiteral("MwdOn")) {
                            hole.mwdOn = readBool(xml);
                        } else if (holeName == QStringLiteral("RollAngleTable")) {
                            while (xml.readNextStartElement()) {
                                if (xml.name() == QStringLiteral("RollAngle")) {
                                    while (xml.readNextStartElement()) {
                                        if (xml.name() == QStringLiteral("BoomId")) {
                                            hole.boomIds.append(readText(xml));
                                        } else {
                                            xml.skipCurrentElement();
                                        }
                                    }
                                } else {
                                    xml.skipCurrentElement();
                                }
                            }
                        } else {
                            xml.skipCurrentElement();
                        }
                    }
                    hole.depthY = hole.end.y - hole.start.y;
                    holes_.append(hole);
                } else if (name == QStringLiteral("LineTable")) {
                    QString profileType;
                    int tableId = 0;
                    while (xml.readNextStartElement()) {
                        const QStringView lineTableName = xml.name();
                        if (lineTableName == QStringLiteral("LineTableId")) {
                            tableId = readInt(xml);
                        } else if (lineTableName == QStringLiteral("ProfileType")) {
                            profileType = readText(xml);
                        } else if (lineTableName == QStringLiteral("Line")) {
                            SitonProfileSegment segment;
                            segment.profileType = profileType.isEmpty() ? QString::number(tableId) : profileType;
                            while (xml.readNextStartElement()) {
                                const QStringView lineName = xml.name();
                                if (lineName == QStringLiteral("LineSegId")) {
                                    segment.lineSegId = readText(xml);
                                } else if (lineName == QStringLiteral("StartPoint")) {
                                    segment.start = readPoint(xml);
                                } else if (lineName == QStringLiteral("EndPoint")) {
                                    segment.end = readPoint(xml);
                                } else if (lineName == QStringLiteral("InvertedRadius")) {
                                    segment.invertedRadius = readDouble(xml);
                                } else if (lineName == QStringLiteral("LinkNumber")) {
                                    segment.linkNumber = readInt(xml);
                                } else if (lineName == QStringLiteral("ContourLine")) {
                                    segment.contourLine = readBool(xml);
                                } else {
                                    xml.skipCurrentElement();
                                }
                            }
                            profiles_.append(segment);
                        } else {
                            xml.skipCurrentElement();
                        }
                    }
                } else {
                    xml.skipCurrentElement();
                }
            }
        }
    }

    if (xml.hasError()) {
        loadError_ = u("DP XML 解析失败：") + xml.errorString();
        return false;
    }
    if (holes_.isEmpty()) {
        loadError_ = u("DP 文件里没有解析到 Hole");
        return false;
    }
    return true;
}

bool SitonDrillMainView::parseTlFile(const QString &path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    tlFileName_ = QFileInfo(path).fileName();
    QXmlStreamReader xml(&file);
    while (xml.readNextStartElement()) {
        if (xml.name() != QStringLiteral("DRTunnelLine")) {
            xml.skipCurrentElement();
            continue;
        }

        while (xml.readNextStartElement()) {
            if (xml.name() == QStringLiteral("CurveTable")) {
                SitonTunnelPoint point;
                while (xml.readNextStartElement()) {
                    const QStringView name = xml.name();
                    if (name == QStringLiteral("PegNumber")) {
                        point.peg = readDouble(xml);
                    } else if (name == QStringLiteral("PointCoord")) {
                        point.point = readPoint(xml);
                    } else {
                        xml.skipCurrentElement();
                    }
                }
                tunnelPoints_.append(point);
            } else {
                xml.skipCurrentElement();
            }
        }
    }
    return !xml.hasError();
}

void SitonDrillMainView::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);
    p.fillRect(event->rect(), QColor("#000000"));

    const QRectF body = rect().adjusted(8, 10, -8, -10);
    drawOuterLayout(p, body, event->rect());
    if (dimTicks_ > 0) {
        p.fillRect(rect(), QColor(0, 0, 0, 90));
        p.setPen(QColor("#00c8ef"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 28, QFont::Bold));
        const QStringList names{u("左臂"), u("中臂"), u("右臂")};
        p.drawText(rect(), Qt::AlignCenter, names.value(activeArm_, u("左臂")));
    }
}

void SitonDrillMainView::resizeEvent(QResizeEvent *event) {
    QWidget::resizeEvent(event);
    updateOverlayButtons(rect().adjusted(8, 10, -8, -10));
}

void SitonDrillMainView::mousePressEvent(QMouseEvent *event) {
    if (holeEditMode_) {
        currentView_ = SitonDrillViewMode::Face;
        if (lastDrawPlot_.contains(event->position())) {
            bool targetEnd = false;
            const int nearest = nearestEditableHoleToMouse(event->position(), &targetEnd);
            if (nearest >= 0) {
                setEditSelectedHole(nearest);
                setHoleEditTargetEndPoint(targetEnd);
                holeEditDragging_ = true;
                mouseScreen_ = event->position();
                mouseInPlot_ = true;
                mousePoint_ = mouseDataPoint(event->position());
                mouseNearestHole_ = nearest;
                setCursor(Qt::ClosedHandCursor);
                event->accept();
                return;
            }
            emit editStatusChanged(u("未选中孔位"));
            return;
        }
        QWidget::mousePressEvent(event);
        return;
    }

    const QRectF body = rect().adjusted(8, 10, -8, -10);
    const double bottomH = 48.0;
    const double railW = 96.0;
    const double gap = 8.0;
    const QRectF main(body.left(), body.top(), body.width(), body.height() - bottomH - gap);
    const QRectF rail(main.left(), main.top(), railW, main.height());
    const QRectF content(rail.right() + gap, main.top(), main.width() - railW - gap, main.height());
    const double leftW = qBound(455.0, content.width() * 0.34, 525.0);
    const QRectF right(content.left() + leftW + gap, content.top(), content.width() - leftW - gap, content.height());

    const double armGap = 8.0;
    const double armH = (rail.height() - armGap * 2) / 3.0;
    for (int i = 0; i < 3; ++i) {
        const QRectF box(rail.left() + 3, rail.top() + i * (armH + armGap), rail.width() - 6, armH);
        if (box.contains(event->position())) {
            activeArm_ = i;
            hStep_ = 0;
            dimTicks_ = 2;
            update();
            return;
        }
    }

    if (lastDataPanel_.isValid()) {
        for (int i = 0; i < 4; ++i) {
            if (leftTabRect(lastDataPanel_, i).contains(event->position())) {
                if (i == 3) {
                    return;
                }
                leftTab_ = i;
                const QRectF topBox = dataTopBoxRect(lastDataPanel_);
                updateDrillModeInputs(leftTab_ == 2 ? topBox : QRectF());
                updateEditablePanelInputs(leftTab_ == 1 ? topBox : QRectF());
                update();
                return;
            }
        }

        if (leftTab_ == 2) {
            const QRectF modePanel = dataTopBoxRect(lastDataPanel_);
            if (modePanel.contains(event->position())) {
                const double left = modePanel.left() + 10;
                const double labelW = 96;
                const double x0 = left + labelW + 24;
                const double typeSpacing = qBound(84.0, (modePanel.right() - 110 - x0) / 2.0, 114.0);
                const double y0 = modePanel.top() + 38;
                for (int i = 0; i < 3; ++i) {
                    const QPointF center(x0 + typeSpacing * i, y0);
                    if (QRectF(center.x() - 16, center.y() - 18, 92, 36).contains(event->position())) {
                        holeType_ = i;
                        dimTicks_ = 2;
                        update();
                        return;
                    }
                }
                const double y1 = y0 + 66;
                const double y2 = y1 + 52;
                const double y3 = y2 + 52;
                const QVector<double> modeY{y1, y2, y3};
                for (int i = 0; i < modeY.size(); ++i) {
                    const QPointF center(x0, modeY.at(i));
                    if (QRectF(center.x() - 16, center.y() - 18, 210, 36).contains(event->position())) {
                        drillMode_ = i;
                        for (int arm = 0; arm < 3; ++arm) {
                            holeEntryReferenceXValid_[arm] = false;
                        }
                        QSettings modeSettings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
                        modeSettings.setValue(QStringLiteral("dashboard/drillMode/mode"), drillMode_);
                        modeSettings.sync();
                        dimTicks_ = 2;
                        update();
                        return;
                    }
                }
            }
        }
    }

    for (int i = 0; i < 4; ++i) {
        if (viewTabRect(right, i).contains(event->position())) {
            if (holeEditMode_ && i != 0) {
                currentView_ = SitonDrillViewMode::Face;
                update(facePanelRect().toAlignedRect().adjusted(-2, -2, 2, 2));
                return;
            }
            currentView_ = static_cast<SitonDrillViewMode>(i);
            spaceDragging_ = false;
            unsetCursor();
            update(facePanelRect().toAlignedRect().adjusted(-2, -2, 2, 2));
            return;
        }
    }
    if (currentView_ == SitonDrillViewMode::Space
        && lastDrawPlot_.contains(event->position())
        && event->button() == Qt::LeftButton) {
        spaceDragging_ = true;
        lastSpaceDrag_ = event->position();
        setCursor(Qt::ClosedHandCursor);
        event->accept();
        return;
    }
    if (currentView_ == SitonDrillViewMode::Face && lastDrawPlot_.contains(event->position())) {
        const int armIndex = qBound(0, activeArm_, 2);
        simulatedHPoints_[armIndex] = mouseDataPoint(event->position());
        simulatedHPointValid_[armIndex] = simulatedHPoints_[armIndex].valid;
        simulatedNearestHole_[armIndex] = nearestHoleToMouse(event->position());
        mouseScreen_ = event->position();
        mouseInPlot_ = true;
        mousePoint_ = simulatedHPoints_[armIndex];
        mouseNearestHole_ = simulatedNearestHole_[armIndex];
        // Temporary commissioning path: mouse click simulates H point completion until realtime data is connected.
        recordConstructionTraceForArm(armIndex, hOverlapHoleIndex(simulatedHPoints_[armIndex]), true);
        update();
        return;
    }
    QWidget::mousePressEvent(event);
}

void SitonDrillMainView::mouseMoveEvent(QMouseEvent *event) {
    if (holeEditMode_ && holeEditDragging_) {
        mouseScreen_ = event->position();
        mouseInPlot_ = lastPlot_.contains(mouseScreen_);
        if (applySelectedHoleProjectedPoint(event->position())) {
            mousePoint_ = mouseDataPoint(mouseScreen_);
            mouseNearestHole_ = editSelectedHole_;
        }
        event->accept();
        return;
    }
    if (spaceDragging_ && currentView_ == SitonDrillViewMode::Space) {
        const QPointF delta = event->position() - lastSpaceDrag_;
        spaceYawDeg_ -= delta.x() * 0.35;
        spacePitchDeg_ = qBound(-65.0, spacePitchDeg_ + delta.y() * 0.25, 70.0);
        lastSpaceDrag_ = event->position();
        mouseScreen_ = event->position();
        mouseInPlot_ = lastPlot_.contains(mouseScreen_);
        update();
        event->accept();
        return;
    }
    mouseScreen_ = event->position();
    mouseInPlot_ = lastPlot_.contains(mouseScreen_);
    if (mouseInPlot_) {
        mousePoint_ = mouseDataPoint(mouseScreen_);
        mouseNearestHole_ = nearestHoleToMouse(mouseScreen_);
    } else {
        mousePoint_ = {};
        mouseNearestHole_ = -1;
    }
    update();
}

void SitonDrillMainView::mouseReleaseEvent(QMouseEvent *event) {
    if (holeEditMode_ && holeEditDragging_ && event->button() == Qt::LeftButton) {
        holeEditDragging_ = false;
        unsetCursor();
        saveHoleEdit(editSelectedHole_);
        if (editSelectedHole_ >= 0 && editSelectedHole_ < holes_.size() && holes_.at(editSelectedHole_).userAdded) {
            saveAddedHoles();
        }
        emit editStatusChanged(u("已保存到本机"));
        emitEditSelectionChanged();
        event->accept();
        update();
        return;
    }
    if (spaceDragging_ && event->button() == Qt::LeftButton) {
        spaceDragging_ = false;
        unsetCursor();
        event->accept();
        update();
        return;
    }
    QWidget::mouseReleaseEvent(event);
}

void SitonDrillMainView::leaveEvent(QEvent *event) {
    if (holeEditMode_ && holeEditDragging_) {
        saveHoleEdit(editSelectedHole_);
        if (editSelectedHole_ >= 0 && editSelectedHole_ < holes_.size() && holes_.at(editSelectedHole_).userAdded) {
            saveAddedHoles();
        }
        emit editStatusChanged(u("已保存到本机"));
        emitEditSelectionChanged();
    }
    spaceDragging_ = false;
    holeEditDragging_ = false;
    unsetCursor();
    mouseInPlot_ = false;
    mousePoint_ = {};
    mouseNearestHole_ = -1;
    update();
    QWidget::leaveEvent(event);
}

void SitonDrillMainView::drawOuterLayout(QPainter &p, const QRectF &body, const QRect &dirtyRect) {
    if (holeEditMode_) {
        updateOverlayButtons(body);
        if (dirtyRect.intersects(body.toAlignedRect())) {
            drawFacePanel(p, body);
        }
        return;
    }

    const double bottomH = 48.0;
    const double railW = 96.0;
    const double gap = 8.0;
    const QRectF main(body.left(), body.top(), body.width(), body.height() - bottomH - gap);
    const QRectF rail(main.left(), main.top(), railW, main.height());
    const QRectF content(rail.right() + gap, main.top(), main.width() - railW - gap, main.height());
    const double leftW = qBound(455.0, content.width() * 0.34, 525.0);
    const QRectF left(content.left(), content.top(), leftW, content.height());
    const QRectF right(left.right() + gap, content.top(), content.width() - leftW - gap, content.height());
    const QRectF bottomLeft(content.left(), main.bottom() + gap, content.width() * 0.5 - gap / 2, bottomH);
    const QRectF bottomRight(bottomLeft.right() + gap, main.bottom() + gap, content.width() * 0.5 - gap / 2, bottomH);

    updateOverlayButtons(body);
    if (dirtyRect.intersects(rail.toAlignedRect())) {
        drawLeftRail(p, rail);
    }
    if (dirtyRect.intersects(left.toAlignedRect())) {
        drawDataPanel(p, left);
    }
    if (dirtyRect.intersects(right.toAlignedRect())) {
        drawFacePanel(p, right);
    }
    if (dirtyRect.intersects(bottomLeft.toAlignedRect())) {
        drawHardPanel(p, bottomLeft, QColor("#555555"), 6);
    }
    if (dirtyRect.intersects(bottomRight.toAlignedRect())) {
        drawHardPanel(p, bottomRight, QColor("#555555"), 6);
    }
}

QRectF SitonDrillMainView::facePanelRect() const {
    const QRectF body = rect().adjusted(8, 10, -8, -10);
    const double bottomH = 48.0;
    const double railW = 96.0;
    const double gap = 8.0;
    const QRectF main(body.left(), body.top(), body.width(), body.height() - bottomH - gap);
    const QRectF rail(main.left(), main.top(), railW, main.height());
    const QRectF content(rail.right() + gap, main.top(), main.width() - railW - gap, main.height());
    const double leftW = qBound(455.0, content.width() * 0.34, 525.0);
    return QRectF(content.left() + leftW + gap, content.top(), content.width() - leftW - gap, content.height());
}

void SitonDrillMainView::updateOverlayButtons(const QRectF &body) {
    const double bottomH = 48.0;
    const double railW = 96.0;
    const double gap = 8.0;
    const QRectF main(body.left(), body.top(), body.width(), body.height() - bottomH - gap);
    const QRectF rail(main.left(), main.top(), railW, main.height());
    const QRectF content(rail.right() + gap, main.top(), main.width() - railW - gap, main.height());
    const double leftW = qBound(455.0, content.width() * 0.34, 525.0);
    const QRectF left(content.left(), content.top(), leftW, content.height());
    const QRectF right(left.right() + gap, content.top(), content.width() - leftW - gap, content.height());

    if (holeEditMode_) {
        for (QPushButton *button : railButtons_) {
            if (button) {
                button->hide();
            }
        }
        for (QPushButton *button : leftTabButtons_) {
            if (button) {
                button->hide();
            }
        }
        for (QPushButton *button : viewTabButtons_) {
            if (button) {
                button->hide();
            }
        }
        return;
    }

    auto applyButtonStyle = [](QPushButton *button, bool active, int fontSize, const QString &extra = QString()) {
        if (!button) {
            return;
        }
        const bool disabled = !button->isEnabled();
        const QString background = disabled ? QStringLiteral("#4f4f4f") : (active ? QStringLiteral("#020202") : QStringLiteral("#7a7a7a"));
        const QString color = disabled ? QStringLiteral("#b8b8b8") : (active ? QStringLiteral("#00c8ef") : QStringLiteral("#ffffff"));
        button->setStyleSheet(QStringLiteral(
            "QPushButton[class=\"sitonPaintedOverlay\"] { color: %1; background: %2; border: 2px solid #050505; "
            "border-radius: 4px; font-family: \"Microsoft YaHei UI\"; font-size: %3px; font-weight: 900; padding: 0px; %4 }"
            "QPushButton[class=\"sitonPaintedOverlay\"]:pressed { background: #050505; color: #00c8ef; }")
            .arg(color, background).arg(fontSize).arg(extra));
    };

    const double armGap = 8.0;
    const double armH = (rail.height() - armGap * 2) / 3.0;
    for (int i = 0; i < railButtons_.size(); ++i) {
        QPushButton *button = railButtons_.at(i);
        if (!button) {
            continue;
        }
        const QRectF box(rail.left() + 3, rail.top() + i * (armH + armGap), rail.width() - 6, armH);
        button->setGeometry(box.toAlignedRect());
        applyButtonStyle(button, i < 3 && i == activeArm_, 18);
        button->show();
        button->raise();
    }

    for (int i = 0; i < leftTabButtons_.size(); ++i) {
        QPushButton *button = leftTabButtons_.at(i);
        if (!button) {
            continue;
        }
        button->setGeometry(leftTabRect(left, i).toAlignedRect());
        applyButtonStyle(button, i == leftTab_, 17);
        button->show();
        button->raise();
    }

    for (int i = 0; i < viewTabButtons_.size(); ++i) {
        QPushButton *button = viewTabButtons_.at(i);
        if (!button) {
            continue;
        }
        button->setGeometry(viewTabRect(right, i).toAlignedRect());
        button->setEnabled(!holeEditMode_ || i == 0);
        applyButtonStyle(button, static_cast<int>(currentView_) == i, 17);
        button->show();
        button->raise();
    }
}

void SitonDrillMainView::drawLeftRail(QPainter &p, const QRectF &rail) {
    p.setPen(Qt::NoPen);
    p.setBrush(QColor("#000000"));
    p.drawRoundedRect(rail, 7, 7);

    const QStringList names{u("左臂"), u("中臂"), u("右臂")};
    const double gap = 8.0;
    const double h = (rail.height() - gap * 2) / 3.0;
    for (int i = 0; i < names.size(); ++i) {
        const QRectF box(rail.left() + 3, rail.top() + i * (h + gap), rail.width() - 6, h);
        const bool active = i < 3 && i == activeArm_;
        p.setPen(QPen(QColor("#050505"), 2));
        p.setBrush(active ? QColor("#040404") : QColor("#7c7c7c"));
        p.drawRoundedRect(box, 6, 6);
        p.setPen(active ? QColor("#00c7ee") : QColor("#ffffff"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 17, QFont::Bold));
        p.drawText(box, Qt::AlignCenter, names.at(i));
    }
}

void SitonDrillMainView::drawTopTabs(QPainter &p, const QRectF &panel) {
    const QStringList tabs{u("常用数据"), u("钻机参数"), u("钻孔模式")};
    for (int i = 0; i < tabs.size(); ++i) {
        drawSquareButton(p, leftTabRect(panel, i), tabs.at(i), i == leftTab_);
    }
}

QRectF SitonDrillMainView::dataTopBoxRect(const QRectF &panel) const {
    if (!panel.isValid()) {
        return QRectF();
    }
    const double topBoxH = leftTab_ == 0 ? qMin(288.0, panel.height() * 0.31) : qMin(300.0, panel.height() * 0.42);
    return QRectF(panel.left() + 8, panel.top() + 52, panel.width() - 16, topBoxH);
}

void SitonDrillMainView::drawDataPanel(QPainter &p, const QRectF &panel) {
    lastDataPanel_ = panel;
    drawHardPanel(p, panel, QColor("#555555"), 6);
    drawTopTabs(p, panel);

    const QRectF topBox = dataTopBoxRect(panel);
    if (leftTab_ == 1) {
        updateDrillModeInputs(QRectF());
        updateEditablePanelInputs(topBox);
        drawDrillParamPanel(p, topBox);
    } else if (leftTab_ == 2) {
        updateEditablePanelInputs(QRectF());
        updateDrillModeInputs(topBox);
        drawDrillModePanel(p, topBox);
    } else {
        updateDrillModeInputs(QRectF());
        updateEditablePanelInputs(QRectF());
        p.setPen(QPen(QColor("#050505"), 2));
        p.setBrush(QColor("#040404"));
        p.drawRoundedRect(topBox, 5, 5);
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 11, QFont::Bold));

        const QStringList rows{
            u("冲击压力"), u("推进压力"), u("回转压力"), u("钻进速度"), u("定位泵压力"),
            u("润滑压力"), u("泵后水压力"), u("水流量"), u("气压力"), u("缓冲压力")
        };
        const QStringList units{QStringLiteral("bar"), QStringLiteral("bar"), QStringLiteral("bar"), QStringLiteral("m/min"), QStringLiteral("bar"),
                                QStringLiteral("bar"), QStringLiteral("bar"), QStringLiteral("l/min"), QStringLiteral("bar"), QStringLiteral("bar")};
        p.setPen(QColor("#00c8ef"));
        p.drawText(QRectF(topBox.left() + 10, topBox.top() + 7, 110, 18), Qt::AlignLeft | Qt::AlignVCenter, u("状态量"));
        p.drawText(QRectF(topBox.left() + 158, topBox.top() + 7, 58, 18), Qt::AlignCenter, u("左"));
        p.drawText(QRectF(topBox.left() + 236, topBox.top() + 7, 58, 18), Qt::AlignCenter, u("中"));
        p.drawText(QRectF(topBox.left() + 314, topBox.top() + 7, 58, 18), Qt::AlignCenter, u("右"));
        p.drawText(QRectF(topBox.right() - 58, topBox.top() + 7, 54, 18), Qt::AlignLeft | Qt::AlignVCenter, u("单位"));
        const double rowH = (topBox.height() - 34) / rows.size();
        for (int i = 0; i < rows.size(); ++i) {
            const QRectF row(topBox.left() + 10, topBox.top() + 30 + i * rowH, topBox.width() - 20, rowH);
            p.setPen(QColor("#ffffff"));
            p.drawText(QRectF(row.left(), row.top(), 110, row.height()), Qt::AlignLeft | Qt::AlignVCenter, rows.at(i));
            for (int c = 0; c < 3; ++c) {
                p.drawText(QRectF(row.left() + 158 + c * 78, row.top(), 58, row.height()),
                           Qt::AlignCenter,
                           drillCommonValueText(realtimeState_.arms[c], i));
            }
            p.drawText(QRectF(row.right() - 58, row.top(), 54, row.height()), Qt::AlignLeft | Qt::AlignVCenter, units.at(i));
        }
    }

    const QRectF bars(panel.left() + 8, topBox.bottom() + 6, panel.width() - 16, 112);
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#555555"));
    p.drawRoundedRect(bars, 4, 4);
    const QStringList armNames{u("左臂"), u("中臂"), u("右臂")};
    for (int i = 0; i < armNames.size(); ++i) {
        const double y = bars.top() + 18 + i * 31;
        const bool active = i == activeArm_;
        const QColor accent = active ? QColor("#f6df4a") : QColor("#8fb4b0");
        const double currentDepthM = qMax(0.0, realtimeState_.arms[i].drillingDepthM);
        const double targetDepthM = qMax(0.0, targetDrillDepthMForArm(i));
        const double remainingDepthM = qMax(0.0, targetDepthM - currentDepthM);
        const QRectF leftText(bars.left() + 12, y - 11, 126, 24);
        const QRectF track(bars.left() + 146, y - 5, bars.width() - 250, 11);
        const QRectF rightText(track.right() + 10, y - 11, 92, 24);

        if (active) {
            p.setPen(Qt::NoPen);
            p.setBrush(QColor(0, 0, 0, 70));
            p.drawRoundedRect(QRectF(bars.left() + 6, y - 14, bars.width() - 12, 28), 4, 4);
        }

        p.setPen(active ? QColor("#f6df4a") : QColor("#ffffff"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::Bold));
        p.drawText(leftText, Qt::AlignLeft | Qt::AlignVCenter,
                   armNames.at(i) + u(" 已打 ") + QString::number(currentDepthM, 'f', 2) + QStringLiteral("m"));
        p.setPen(Qt::NoPen);
        p.setBrush(QColor("#060606"));
        p.drawRoundedRect(track, 4, 4);
        const double progress = targetDepthM > 0.001 ? qBound(0.0, currentDepthM / targetDepthM, 1.0) : 0.0;
        p.setBrush(accent);
        p.drawRoundedRect(QRectF(track.left(), track.top(), track.width() * progress, track.height()), 4, 4);
        p.setPen(QPen(QColor("#1f1f1f"), 1));
        p.setBrush(Qt::NoBrush);
        p.drawRoundedRect(track, 4, 4);
        p.setPen(active ? QColor("#f6df4a") : QColor("#ffffff"));
        p.drawText(rightText, Qt::AlignLeft | Qt::AlignVCenter,
                   u("剩 ") + QString::number(remainingDepthM, 'f', 2) + QStringLiteral("m"));
    }

    const QRectF arm(panel.left() + 8, bars.bottom() + 6, panel.width() - 16, panel.bottom() - bars.bottom() - 14);
    drawArmPanel(p, arm);
}

void SitonDrillMainView::updateDrillModeInputs(const QRectF &panel) {
    const bool show = panel.isValid() && leftTab_ == 2;
    if (!show) {
        for (const QPointer<QRadioButton> &button : holeTypeButtons_) {
            if (button) {
                button->hide();
            }
        }
        for (const QPointer<QRadioButton> &button : drillModeButtons_) {
            if (button) {
                button->hide();
            }
        }
        if (baseLevelEdit_) {
            baseLevelEdit_->hide();
        }
        if (equalLengthEdit_) {
            equalLengthEdit_->hide();
        }
        if (drillModeConfirm_) {
            drillModeConfirm_->hide();
        }
        return;
    }
    const double left = panel.left() + 10;
    const double labelW = 96;
    const double x0 = left + labelW + 24;
    const double typeSpacing = qBound(84.0, (panel.right() - 110 - x0) / 2.0, 114.0);
    const double inputW = qBound(112.0, panel.width() * 0.27, 140.0);
    const double inputX = panel.right() - inputW - 38;
    const double y0 = panel.top() + 38;
    const double y1 = y0 + 66;
    const double y2 = y1 + 52;
    const double y3 = y2 + 52;
    const QVector<QRectF> typeRects{
        QRectF(x0, y0 - 14, typeSpacing - 4, 30),
        QRectF(x0 + typeSpacing, y0 - 14, typeSpacing - 4, 30),
        QRectF(x0 + typeSpacing * 2.0, y0 - 14, 94, 30)
    };
    for (int i = 0; i < holeTypeButtons_.size() && i < typeRects.size(); ++i) {
        QRadioButton *button = holeTypeButtons_.at(i);
        if (!button) {
            continue;
        }
        button->setGeometry(typeRects.at(i).toAlignedRect());
        button->setChecked(i == holeType_);
        button->show();
        button->raise();
    }
    const QVector<QRectF> modeRects{
        QRectF(x0, y1 - 14, 122, 30),
        QRectF(x0, y2 - 14, 92, 30),
        QRectF(x0, y3 - 14, 142, 30)
    };
    for (int i = 0; i < drillModeButtons_.size() && i < modeRects.size(); ++i) {
        QRadioButton *button = drillModeButtons_.at(i);
        if (!button) {
            continue;
        }
        button->setGeometry(modeRects.at(i).toAlignedRect());
        button->setChecked(i == drillMode_);
        button->show();
        button->raise();
    }
    const QRectF baseRect(inputX, y1 - 17, inputW, 34);
    const QRectF equalRect(inputX, y2 - 17, inputW, 34);
    const QRectF confirmRect(panel.right() - 104, panel.bottom() - 44, 88, 32);
    if (baseLevelEdit_) {
        baseLevelEdit_->setGeometry(baseRect.toAlignedRect());
        baseLevelEdit_->show();
        baseLevelEdit_->raise();
    }
    if (equalLengthEdit_) {
        equalLengthEdit_->setGeometry(equalRect.toAlignedRect());
        equalLengthEdit_->show();
        equalLengthEdit_->raise();
    }
    if (drillModeConfirm_) {
        drillModeConfirm_->setGeometry(confirmRect.toAlignedRect());
        drillModeConfirm_->show();
        drillModeConfirm_->raise();
    }
}

void SitonDrillMainView::updateEditablePanelInputs(const QRectF &panel) {
    auto hideAll = [&]() {
        for (const QPointer<QLineEdit> &edit : drillParamEdits_) {
            if (edit) {
                edit->hide();
            }
        }
        if (drillParamConfirm_) {
            drillParamConfirm_->hide();
        }
    };

    if (!panel.isValid()) {
        hideAll();
        return;
    }

    for (const QPointer<QLineEdit> &edit : drillParamEdits_) {
        if (edit) {
            edit->hide();
        }
    }
    if (drillParamConfirm_) {
        drillParamConfirm_->hide();
    }

    if (leftTab_ == 1) {
        const double rowH = (panel.height() - 42) / 4.0;
        const double colW = panel.width() * 0.5;
        for (int i = 0; i < drillParamEdits_.size(); ++i) {
            QLineEdit *edit = drillParamEdits_.at(i);
            if (!edit) {
                continue;
            }
            const int row = i % 4;
            const int col = i / 4;
            const QRectF area(panel.left() + 12 + col * colW, panel.top() + 24 + row * rowH, colW - 22, rowH - 8);
            const QRectF value(area.left() + 92, area.top() + 2, area.width() - 132, qMin(32.0, area.height() - 4));
            edit->setGeometry(value.toAlignedRect());
            edit->show();
            edit->raise();
        }
        if (drillParamConfirm_) {
            const QRectF confirm(panel.right() - 112, panel.bottom() - 42, 96, 30);
            drillParamConfirm_->setGeometry(confirm.toAlignedRect());
            drillParamConfirm_->show();
            drillParamConfirm_->raise();
        }
        return;
    }

}

void SitonDrillMainView::drawDrillParamPanel(QPainter &p, const QRectF &panel) {
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#555555"));
    p.drawRoundedRect(panel, 5, 5);
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::Bold));
    const QStringList labels{
        u("推进压力"), u("冲击压力"), u("回转压力"), u("缓冲压力"),
        u("钻进速度"), u("推进速度"), u("回退速度"), u("水气控制")
    };
    const QStringList units{
        QStringLiteral("bar"), QStringLiteral("bar"), QStringLiteral("bar"), QStringLiteral("bar"),
        QStringLiteral("m/min"), QStringLiteral("%"), QStringLiteral("%"), QString()
    };
    const double rowH = (panel.height() - 42) / 4.0;
    const double colW = panel.width() * 0.5;
    for (int i = 0; i < labels.size(); ++i) {
        const int row = i % 4;
        const int col = i / 4;
        const QRectF area(panel.left() + 12 + col * colW, panel.top() + 24 + row * rowH, colW - 22, rowH - 8);
        p.setPen(QColor("#ffffff"));
        p.drawText(QRectF(area.left(), area.top(), 86, area.height()), Qt::AlignLeft | Qt::AlignVCenter, labels.at(i));
        const QRectF value(area.left() + 92, area.top() + 2, area.width() - 132, qMin(32.0, area.height() - 4));
        p.setPen(QPen(QColor("#050505"), 2));
        p.setBrush(QColor("#020202"));
        p.drawRoundedRect(value, 4, 4);
        p.setPen(QColor("#ffffff"));
        p.setFont(QFont(QStringLiteral("Consolas"), 10, QFont::Bold));
        p.drawText(value.adjusted(8, 0, -8, 0), Qt::AlignRight | Qt::AlignVCenter, QStringLiteral("0"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::Bold));
        p.drawText(QRectF(value.right() + 6, value.top(), 44, value.height()), Qt::AlignLeft | Qt::AlignVCenter, units.at(i));
    }
    const QRectF confirm(panel.right() - 112, panel.bottom() - 42, 96, 30);
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#8b8b8b"));
    p.drawRoundedRect(confirm, 4, 4);
    p.setPen(QColor("#ffffff"));
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 11, QFont::Bold));
    p.drawText(confirm, Qt::AlignCenter, u("确认"));
}

void SitonDrillMainView::drawDrillModePanel(QPainter &p, const QRectF &panel) {
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#555555"));
    p.drawRoundedRect(panel, 5, 5);
    const int uiFontSize = panel.width() < 470 ? 10 : 11;
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), uiFontSize, QFont::Bold));

    auto drawInput = [&](const QRectF &rect, const QString &value, const QString &unit) {
        p.setPen(QPen(QColor("#050505"), 2));
        p.setBrush(QColor("#020202"));
        p.drawRoundedRect(rect, 4, 4);
        p.setPen(QColor("#ffffff"));
        p.setFont(QFont(QStringLiteral("Consolas"), uiFontSize, QFont::Bold));
        p.drawText(rect.adjusted(8, 0, -8, 0), Qt::AlignLeft | Qt::AlignVCenter, value);
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), uiFontSize, QFont::Bold));
        p.drawText(QRectF(rect.right() + 6, rect.top(), 32, rect.height()), Qt::AlignLeft | Qt::AlignVCenter, unit);
    };

    const double left = panel.left() + 10;
    const double labelW = 96;
    const double inputW = qBound(112.0, panel.width() * 0.27, 140.0);
    const double inputX = panel.right() - inputW - 38;
    const double y0 = panel.top() + 38;
    p.setPen(QColor("#ffffff"));
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), uiFontSize, QFont::Bold));
    p.drawText(QRectF(left, y0 - 14, labelW, 28), Qt::AlignLeft | Qt::AlignVCenter, u("孔类型:"));

    const double y1 = y0 + 66;
    p.drawText(QRectF(left, y1 - 14, labelW, 28), Qt::AlignLeft | Qt::AlignVCenter, u("钻孔模式:"));
    drawInput(QRectF(inputX, y1 - 17, inputW, 34), baseLevelEdit_ ? baseLevelEdit_->text() : QStringLiteral("3"), QStringLiteral("m"));

    const double y2 = y1 + 52;
    drawInput(QRectF(inputX, y2 - 17, inputW, 34), equalLengthEdit_ ? equalLengthEdit_->text() : QStringLiteral("2.5"), QStringLiteral("m"));

    const QRectF confirm(panel.right() - 104, panel.bottom() - 44, 88, 32);
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#8b8b8b"));
    p.drawRoundedRect(confirm, 4, 4);
    p.setPen(QColor("#ffffff"));
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), uiFontSize, QFont::Bold));
    p.drawText(confirm, Qt::AlignCenter, u("确认"));
}

void SitonDrillMainView::drawArmPanel(QPainter &p, const QRectF &panel) {
    p.setPen(QPen(QColor("#050505"), 2));
    p.setBrush(QColor("#020202"));
    p.drawRoundedRect(panel, 4, 4);

    QVector<SitonProfileSegment> faceProfiles;
    std::copy_if(profiles_.cbegin(), profiles_.cend(), std::back_inserter(faceProfiles), [](const SitonProfileSegment &segment) {
        return segment.profileType == QStringLiteral("FaceProfile");
    });
    if (faceProfiles.isEmpty()) {
        faceProfiles = profiles_;
    }
    const QRectF zoomPlot = panel.adjusted(34, 58, -34, -28);
    const QRectF fullBounds = dataBounds(SitonDrillViewMode::Face, faceProfiles);
    const SitonPlanPoint hPoint = currentHPoint();
    const int hitIndex = hOverlapHoleIndex(hPoint);
    const bool matched = hitIndex >= 0;
    const int activeIndex = activeHoleIndex();
    const SitonPlanPoint targetPoint = activeIndex >= 0 && activeIndex < holes_.size() ? holes_.at(activeIndex).start : hPoint;
    const bool simulatedH = activeArm_ >= 0 && activeArm_ < 3 && simulatedHPointValid_[activeArm_];
    const int simulatedNearest = simulatedH ? simulatedNearestHole_[activeArm_] : -1;
    SitonPlanPoint centerPoint = hPoint;
    if (!centerPoint.valid) {
        centerPoint = targetPoint;
    }
    const QRectF bounds = centerPoint.valid
        ? zoomBoundsAround(fullBounds, zoomPlot, projectPoint(centerPoint, SitonDrillViewMode::Face))
        : fullBounds;

    p.save();
    p.setClipRect(zoomPlot);
    p.setPen(QPen(QColor("#222222"), 1));
    for (int i = 1; i < 5; ++i) {
        const double x = zoomPlot.left() + zoomPlot.width() * i / 5.0;
        const double y = zoomPlot.top() + zoomPlot.height() * i / 5.0;
        p.drawLine(QPointF(x, zoomPlot.top()), QPointF(x, zoomPlot.bottom()));
        p.drawLine(QPointF(zoomPlot.left(), y), QPointF(zoomPlot.right(), y));
    }
    p.setBrush(Qt::NoBrush);
    p.setPen(QPen(QColor("#9fb1ad"), 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
    for (const SitonProfileSegment &segment : faceProfiles) {
        const QVector<QPointF> points = profilePoints(segment);
        if (points.size() < 2) {
            continue;
        }
        QPainterPath path;
        path.moveTo(mapProjectedPoint(points.first(), zoomPlot, bounds));
        for (int i = 1; i < points.size(); ++i) {
            path.lineTo(mapProjectedPoint(points.at(i), zoomPlot, bounds));
        }
        p.drawPath(path);
    }
    p.setPen(QPen(QColor("#8fa39f"), 2, Qt::SolidLine, Qt::RoundCap));
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!holeVisible(i)) {
            continue;
        }
        if (hole.start.valid && hole.end.valid) {
            const QPointF startProjected = projectPoint(hole.start, SitonDrillViewMode::Face);
            if (!bounds.contains(startProjected)) {
                continue;
            }
            p.drawLine(mapDataPoint(hole.start, zoomPlot, bounds, SitonDrillViewMode::Face),
                       mapDataPoint(hole.end, zoomPlot, bounds, SitonDrillViewMode::Face));
        }
    }
    p.setPen(QPen(kConstructionTraceColor, 4, Qt::SolidLine, Qt::RoundCap));
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!holeVisible(i) || !hole.constructionTraceRecorded || !hole.constructionStart.valid) {
            continue;
        }
        const QPointF startProjected = projectPoint(hole.constructionStart, SitonDrillViewMode::Face);
        if (!bounds.contains(startProjected)) {
            continue;
        }
        if (hole.constructionEnd.valid) {
            p.drawLine(mapDataPoint(hole.constructionStart, zoomPlot, bounds, SitonDrillViewMode::Face),
                       mapDataPoint(hole.constructionEnd, zoomPlot, bounds, SitonDrillViewMode::Face));
        }
    }
    p.setPen(Qt::NoPen);
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const SitonPlanPoint displayStart = hole.constructionTraceRecorded && hole.constructionStart.valid
            ? hole.constructionStart
            : hole.start;
        const QPointF holeScreen = mapDataPoint(displayStart, zoomPlot, bounds, SitonDrillViewMode::Face);
        const bool hMatched = i == hitIndex;
        const bool simulatedNearestPoint = simulatedH && i == simulatedNearest;
        p.setBrush(hole.constructionTraceRecorded ? kConstructionTraceColor
                                                   : (hMatched ? QColor("#48e86e")
                                                               : (simulatedNearestPoint ? QColor("#f6df4a") : QColor("#b7c8c4"))));
        p.drawEllipse(holeScreen,
                      hole.constructionTraceRecorded ? 7.5 : (hMatched ? 8.0 : 5.5),
                      hole.constructionTraceRecorded ? 7.5 : (hMatched ? 8.0 : 5.5));
        if (simulatedNearestPoint) {
            p.setBrush(Qt::NoBrush);
            p.setPen(QPen(QColor("#f6df4a"), 2));
            p.drawEllipse(holeScreen, 13, 13);
            p.setPen(Qt::NoPen);
        }
    }
    if (centerPoint.valid) {
        const QPointF centerScreen = mapDataPoint(centerPoint, zoomPlot, bounds, SitonDrillViewMode::Face);
        p.setPen(QPen(QColor("#f6df4a"), 1, Qt::DashLine));
        p.drawLine(QPointF(centerScreen.x(), zoomPlot.top()), QPointF(centerScreen.x(), zoomPlot.bottom()));
        p.drawLine(QPointF(zoomPlot.left(), centerScreen.y()), QPointF(zoomPlot.right(), centerScreen.y()));
        p.setPen(QPen(QColor("#f6df4a"), 2));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(centerScreen, 10, 10);
    }
    if (hPoint.valid) {
        const QPointF hScreen = mapDataPoint(hPoint, zoomPlot, bounds, SitonDrillViewMode::Face);
        const QColor hColor = matched ? QColor("#48e86e") : QColor("#f6df4a");
        const SitonPlanPoint tailPoint = hTailPointForArm(activeArm_, hPoint);
        p.setBrush(Qt::NoBrush);
        p.setPen(QPen(hColor, 2));
        if (tailPoint.valid) {
            drawHDirectionTail(p, hScreen, mapDataPoint(tailPoint, zoomPlot, bounds, SitonDrillViewMode::Face),
                               hColor, matched ? 38.0 : 34.0, 3.0);
        }
        p.drawEllipse(hScreen, matched ? 12 : 10, matched ? 12 : 10);
        p.drawLine(QPointF(hScreen.x() - 6, hScreen.y() - 6), QPointF(hScreen.x() + 6, hScreen.y() + 6));
        p.drawLine(QPointF(hScreen.x() + 6, hScreen.y() - 6), QPointF(hScreen.x() - 6, hScreen.y() + 6));
    }
    p.restore();

    p.setPen(matched ? QColor("#48e86e") : QColor("#9fb1ad"));
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 12, QFont::Bold));
    const QString zoomTitle = simulatedH
        ? (simulatedNearest >= 0 ? u("H点局部 H") + holes_.at(simulatedNearest).id : u("H点局部"))
        : (matched ? u("H点重合") : u("H点局部"));
    p.drawText(QRectF(panel.left() + 10, panel.top() + 8, panel.width() - 20, 24), Qt::AlignLeft | Qt::AlignVCenter,
               zoomTitle);
    p.setFont(QFont(QStringLiteral("Consolas"), 10, QFont::Bold));
    p.setPen(simulatedH ? QColor("#f6df4a") : QColor("#48e86e"));
    p.drawText(QRectF(panel.left() + 10, panel.top() + 34, panel.width() - 20, 20), Qt::AlignLeft | Qt::AlignVCenter,
               coordText(centerPoint));
}

QVector<QPointF> SitonDrillMainView::profilePoints(const SitonProfileSegment &segment) const {
    if (!segment.start.valid || !segment.end.valid) {
        return {};
    }
    const QPointF start(segment.start.x, segment.start.z);
    const QPointF end(segment.end.x, segment.end.z);
    if (qFuzzyIsNull(segment.invertedRadius)) {
        return {start, end};
    }

    const double radius = 1.0 / qAbs(segment.invertedRadius);
    const double dx = end.x() - start.x();
    const double dz = end.y() - start.y();
    const double chord = qSqrt(dx * dx + dz * dz);
    if (chord < 1e-9 || chord / 2.0 > radius) {
        return {start, end};
    }

    const QPointF mid((start.x() + end.x()) / 2.0, (start.y() + end.y()) / 2.0);
    const double offset = qSqrt(qMax(0.0, radius * radius - qPow(chord / 2.0, 2)));
    const QPointF perpendicular(-dz / chord, dx / chord);
    const QPointF c1 = mid + perpendicular * offset;
    const QPointF c2 = mid - perpendicular * offset;
    const QPointF center = qAbs(c1.x()) < qAbs(c2.x()) ? c1 : c2;

    const double a0 = qAtan2(start.y() - center.y(), start.x() - center.x());
    const double a1 = qAtan2(end.y() - center.y(), end.x() - center.x());
    double delta = std::fmod(a1 - a0 + M_PI, 2.0 * M_PI);
    if (delta < 0) {
        delta += 2.0 * M_PI;
    }
    delta -= M_PI;

    const int steps = qMax(16, static_cast<int>(qAbs(delta) / (2.0 * M_PI) * 128.0));
    QVector<QPointF> points;
    points.reserve(steps + 1);
    for (int i = 0; i <= steps; ++i) {
        const double angle = a0 + delta * i / steps;
        points.append(QPointF(center.x() + qCos(angle) * radius, center.y() + qSin(angle) * radius));
    }
    return points;
}

QRectF SitonDrillMainView::planBounds(const QVector<SitonProfileSegment> &profiles) const {
    double minX = kInvalidLow;
    double maxX = kInvalidHigh;
    double minZ = kInvalidLow;
    double maxZ = kInvalidHigh;
    for (const SitonPlanHole &hole : holes_) {
        if (hole.start.valid) {
            expandRange(hole.start.x, minX, maxX);
            expandRange(hole.start.z, minZ, maxZ);
        }
        if (hole.end.valid) {
            expandRange(hole.end.x, minX, maxX);
            expandRange(hole.end.z, minZ, maxZ);
        }
        if (hole.constructionTraceRecorded && hole.constructionStart.valid) {
            expandRange(hole.constructionStart.x, minX, maxX);
            expandRange(hole.constructionStart.z, minZ, maxZ);
        }
        if (hole.constructionTraceRecorded && hole.constructionEnd.valid) {
            expandRange(hole.constructionEnd.x, minX, maxX);
            expandRange(hole.constructionEnd.z, minZ, maxZ);
        }
    }
    for (const SitonProfileSegment &segment : profiles) {
        for (const QPointF &point : profilePoints(segment)) {
            expandRange(point.x(), minX, maxX);
            expandRange(point.y(), minZ, maxZ);
        }
    }
    if (minX == kInvalidLow || minZ == kInvalidLow) {
        return QRectF(-1, -1, 2, 2);
    }
    const double padX = qMax(0.4, (maxX - minX) * 0.04);
    const double padZ = qMax(0.4, (maxZ - minZ) * 0.04);
    return QRectF(QPointF(minX - padX, minZ - padZ), QPointF(maxX + padX, maxZ + padZ)).normalized();
}

QPointF SitonDrillMainView::projectPoint(const SitonPlanPoint &point, SitonDrillViewMode mode) const {
    switch (mode) {
    case SitonDrillViewMode::Face:
        return QPointF(point.x, point.z);
    case SitonDrillViewMode::Top:
        return QPointF(point.x, point.y);
    case SitonDrillViewMode::Left:
        return QPointF(point.y, point.z);
    case SitonDrillViewMode::Space:
    {
        const double yaw = qDegreesToRadians(spaceYawDeg_);
        const double pitch = qDegreesToRadians(spacePitchDeg_);
        const double xYaw = point.x * qCos(yaw) + point.y * qSin(yaw);
        const double yYaw = -point.x * qSin(yaw) + point.y * qCos(yaw);
        const double zPitch = point.z * qCos(pitch) - yYaw * qSin(pitch);
        return QPointF(xYaw, zPitch);
    }
    }
    return QPointF(point.x, point.z);
}

QRectF SitonDrillMainView::dataBounds(SitonDrillViewMode mode, const QVector<SitonProfileSegment> &profiles) const {
    if (mode == SitonDrillViewMode::Face) {
        return planBounds(profiles);
    }

    double minX = kInvalidLow;
    double maxX = kInvalidHigh;
    double minY = kInvalidLow;
    double maxY = kInvalidHigh;
    auto add = [&](const SitonPlanPoint &point) {
        if (!point.valid) {
            return;
        }
        const QPointF projected = projectPoint(point, mode);
        expandRange(projected.x(), minX, maxX);
        expandRange(projected.y(), minY, maxY);
    };
    for (const SitonPlanHole &hole : holes_) {
        add(hole.start);
        add(hole.end);
        if (hole.constructionTraceRecorded) {
            add(hole.constructionStart);
            add(hole.constructionEnd);
        }
    }
    if (minX == kInvalidLow || minY == kInvalidLow) {
        return QRectF(-1, -1, 2, 2);
    }
    const double padX = qMax(0.25, (maxX - minX) * 0.08);
    const double padY = qMax(0.25, (maxY - minY) * 0.08);
    return QRectF(QPointF(minX - padX, minY - padY), QPointF(maxX + padX, maxY + padY)).normalized();
}

QPointF SitonDrillMainView::mapProjectedPoint(const QPointF &point, const QRectF &plot, const QRectF &bounds) const {
    const double scale = qMin(plot.width() / bounds.width(), plot.height() / bounds.height());
    const QPointF center = bounds.center();
    return QPointF(plot.center().x() + (point.x() - center.x()) * scale,
                   plot.center().y() - (point.y() - center.y()) * scale);
}

QPointF SitonDrillMainView::mapDataPoint(const SitonPlanPoint &point, const QRectF &plot, const QRectF &bounds, SitonDrillViewMode mode) const {
    return mapProjectedPoint(projectPoint(point, mode), plot, bounds);
}

QPointF SitonDrillMainView::unmapProjectedPoint(const QPointF &screenPoint, const QRectF &plot, const QRectF &bounds) const {
    if (bounds.width() <= 0.0 || bounds.height() <= 0.0) {
        return {};
    }
    const double scale = qMin(plot.width() / bounds.width(), plot.height() / bounds.height());
    const QPointF center = bounds.center();
    return QPointF(center.x() + (screenPoint.x() - plot.center().x()) / scale,
                    center.y() - (screenPoint.y() - plot.center().y()) / scale);
}

QRectF SitonDrillMainView::zoomBoundsAround(const QRectF &fullBounds, const QRectF &plot, const QPointF &center) const {
    if (fullBounds.isNull() || plot.width() <= 0.0 || plot.height() <= 0.0) {
        return fullBounds;
    }
    const double plotAspect = plot.width() / plot.height();
    double zoomW = qBound(3.8, fullBounds.width() * 0.58, 7.8);
    double zoomH = zoomW / plotAspect;
    if (zoomH < 2.2) {
        zoomH = 2.2;
        zoomW = zoomH * plotAspect;
    }
    return QRectF(center.x() - zoomW / 2.0, center.y() - zoomH / 2.0, zoomW, zoomH).normalized();
}

SitonPlanPoint SitonDrillMainView::mouseDataPoint(const QPointF &screenPoint) const {
    SitonPlanPoint point;
    if (!lastDrawPlot_.contains(screenPoint) || lastBounds_.isNull()) {
        return point;
    }
    const QPointF projected = unmapProjectedPoint(screenPoint, lastDrawPlot_, lastBounds_);
    const SitonPlanPoint hPoint = currentHPoint();
    switch (currentView_) {
    case SitonDrillViewMode::Face:
        point.x = projected.x();
        point.y = hPoint.y;
        point.z = projected.y();
        break;
    case SitonDrillViewMode::Top:
        point.x = projected.x();
        point.y = projected.y();
        point.z = hPoint.z;
        break;
    case SitonDrillViewMode::Left:
        point.x = hPoint.x;
        point.y = projected.x();
        point.z = projected.y();
        break;
    case SitonDrillViewMode::Space:
        point.x = projected.x();
        point.y = hPoint.y;
        point.z = projected.y();
        break;
    }
    point.valid = true;
    return point;
}

int SitonDrillMainView::nearestHoleToMouse(const QPointF &screenPoint) const {
    if (!lastDrawPlot_.contains(screenPoint)) {
        return -1;
    }
    int best = -1;
    double bestDistance = std::numeric_limits<double>::max();
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const QPointF holeScreen = mapDataPoint(hole.start, lastDrawPlot_, lastBounds_, currentView_);
        const double distance = QLineF(screenPoint, holeScreen).length();
        if (distance < bestDistance) {
            bestDistance = distance;
            best = i;
        }
    }
    return bestDistance <= (holeEditMode_ ? 42.0 : 24.0) ? best : -1;
}

int SitonDrillMainView::nearestEditableHoleToMouse(const QPointF &screenPoint, bool *endPoint) const {
    if (endPoint) {
        *endPoint = false;
    }
    if (!lastDrawPlot_.contains(screenPoint)) {
        return -1;
    }
    int best = -1;
    bool bestEnd = false;
    double bestDistance = std::numeric_limits<double>::max();
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const QPointF startScreen = mapDataPoint(hole.start, lastDrawPlot_, lastBounds_, currentView_);
        const double startDistance = QLineF(screenPoint, startScreen).length();
        if (startDistance < bestDistance) {
            bestDistance = startDistance;
            best = i;
            bestEnd = false;
        }
        if (hasEditableTail(hole)) {
            const QPointF endScreen = mapDataPoint(hole.end, lastDrawPlot_, lastBounds_, currentView_);
            const double endDistance = QLineF(screenPoint, endScreen).length();
            if (endDistance < bestDistance) {
                bestDistance = endDistance;
                best = i;
                bestEnd = true;
            }
        }
    }
    if (bestDistance > 42.0) {
        return -1;
    }
    if (endPoint) {
        *endPoint = bestEnd;
    }
    return best;
}

bool SitonDrillMainView::applySelectedHoleProjectedPoint(const QPointF &screenPoint) {
    if (editSelectedHole_ < 0 || editSelectedHole_ >= holes_.size()
        || !lastDrawPlot_.contains(screenPoint) || lastBounds_.isNull()) {
        return false;
    }
    const QPointF projected = unmapProjectedPoint(screenPoint, lastDrawPlot_, lastBounds_);
    SitonPlanHole &hole = holes_[editSelectedHole_];
    if (holeEditTargetEndPoint_) {
        if (!hasEditableTail(hole)) {
            emit editStatusChanged(u("该孔无尾巴，只能修改入口位置"));
            return false;
        }
        hole.end.x = projected.x();
        hole.end.z = projected.y();
        hole.end.valid = true;
    } else {
        const double dx = projected.x() - hole.start.x;
        const double dz = projected.y() - hole.start.z;
        hole.start.x = projected.x();
        hole.start.z = projected.y();
        hole.start.valid = true;
        if (hole.end.valid) {
            hole.end.x += dx;
            hole.end.z += dz;
        }
    }
    if (hole.start.valid && hole.end.valid) {
        hole.depthY = hole.end.y - hole.start.y;
    }
    emitEditSelectionChanged();
    update();
    return true;
}

void SitonDrillMainView::setEditSelectedHole(int index) {
    const int normalized = (index >= 0 && index < holes_.size()) ? index : -1;
    if (editSelectedHole_ == normalized) {
        return;
    }
    editSelectedHole_ = normalized;
    emitEditSelectionChanged();
    update();
}

void SitonDrillMainView::emitEditSelectionChanged() {
    emit editSelectionChanged();
}

QString SitonDrillMainView::holeEditSettingsGroup() const {
    QString fileKey = dpFileName_.trimmed();
    if (fileKey.isEmpty()) {
        fileKey = QStringLiteral("default");
    }
    fileKey.replace(QLatin1Char('/'), QLatin1Char('_'));
    fileKey.replace(QLatin1Char('\\'), QLatin1Char('_'));
    return QStringLiteral("holeMapEdits/%1").arg(fileKey);
}

QString SitonDrillMainView::holeEditKey(int index) const {
    QString id;
    if (index >= 0 && index < holes_.size()) {
        id = holes_.at(index).id.trimmed();
    }
    if (id.isEmpty()) {
        id = QStringLiteral("index_%1").arg(index);
    }
    id.replace(QLatin1Char('/'), QLatin1Char('_'));
    id.replace(QLatin1Char('\\'), QLatin1Char('_'));
    return id;
}

void SitonDrillMainView::applySavedHoleEdits() {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    for (int i = 0; i < holes_.size(); ++i) {
        const QString key = holeEditKey(i);
        settings.beginGroup(key);
        if (settings.contains(QStringLiteral("startX"))) {
            SitonPlanHole &hole = holes_[i];
            const bool endValid = settings.value(QStringLiteral("endValid"), hole.end.valid).toBool();
            hole.start.x = settings.value(QStringLiteral("startX"), hole.start.x).toDouble();
            hole.start.y = settings.value(QStringLiteral("startY"), hole.start.y).toDouble();
            hole.start.z = settings.value(QStringLiteral("startZ"), hole.start.z).toDouble();
            hole.end.x = settings.value(QStringLiteral("endX"), hole.end.x).toDouble();
            hole.end.y = settings.value(QStringLiteral("endY"), hole.end.y).toDouble();
            hole.end.z = settings.value(QStringLiteral("endZ"), hole.end.z).toDouble();
            hole.start.valid = true;
            hole.end.valid = endValid;
            hole.depthY = hole.end.valid ? (hole.end.y - hole.start.y) : 0.0;
        }
        settings.endGroup();
    }
    const QStringList deleted = settings.value(QStringLiteral("deletedIds")).toStringList();
    if (!deleted.isEmpty()) {
        for (int i = holes_.size() - 1; i >= 0; --i) {
            if (deleted.contains(holes_.at(i).id)) {
                holes_.removeAt(i);
            }
        }
    }
    settings.beginGroup(QStringLiteral("addedHoles"));
    const QStringList addedKeys = settings.childGroups();
    for (const QString &key : addedKeys) {
        settings.beginGroup(key);
        SitonPlanHole hole;
        hole.id = settings.value(QStringLiteral("id"), key).toString();
        hole.type = settings.value(QStringLiteral("type")).toString();
        hole.mwdOn = settings.value(QStringLiteral("mwdOn"), false).toBool();
        hole.completed = false;
        hole.userAdded = true;
        hole.start.x = settings.value(QStringLiteral("startX"), 0.0).toDouble();
        hole.start.y = settings.value(QStringLiteral("startY"), 0.0).toDouble();
        hole.start.z = settings.value(QStringLiteral("startZ"), 0.0).toDouble();
        hole.end.x = settings.value(QStringLiteral("endX"), hole.start.x).toDouble();
        hole.end.y = settings.value(QStringLiteral("endY"), hole.start.y + 4.0).toDouble();
        hole.end.z = settings.value(QStringLiteral("endZ"), hole.start.z).toDouble();
        hole.start.valid = true;
        hole.end.valid = settings.value(QStringLiteral("endValid"), true).toBool();
        hole.depthY = hole.end.valid ? (hole.end.y - hole.start.y) : 0.0;
        holes_.append(hole);
        settings.endGroup();
    }
    settings.endGroup();
    settings.endGroup();
}

QString SitonDrillMainView::constructionTraceSettingsGroup() const {
    QString fileKey = dpFileName_.trimmed();
    if (fileKey.isEmpty()) {
        fileKey = QStringLiteral("default");
    }
    fileKey.replace(QLatin1Char('/'), QLatin1Char('_'));
    fileKey.replace(QLatin1Char('\\'), QLatin1Char('_'));
    return QStringLiteral("constructionTraces/%1").arg(fileKey);
}

void SitonDrillMainView::applySavedConstructionTraces() {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(constructionTraceSettingsGroup());
    QVector<int> migratedTraceIndexes;
    for (int i = 0; i < holes_.size(); ++i) {
        SitonPlanHole &hole = holes_[i];
        hole.constructionTraceRecorded = false;
        hole.constructionArm = -1;
        hole.constructionDepthM = 0.0;
        hole.constructionTimestamp.clear();
        hole.constructionSource.clear();
        hole.constructionStart = {};
        hole.constructionEnd = {};
        hole.completed = false;

        settings.beginGroup(holeEditKey(i));
        if (settings.value(QStringLiteral("recorded"), false).toBool()) {
            hole.constructionStart.x = settings.value(QStringLiteral("startX"), hole.start.x).toDouble();
            hole.constructionStart.y = settings.value(QStringLiteral("startY"), hole.start.y).toDouble();
            hole.constructionStart.z = settings.value(QStringLiteral("startZ"), hole.start.z).toDouble();
            hole.constructionStart.valid = settings.value(QStringLiteral("startValid"), true).toBool();
            hole.constructionEnd.x = settings.value(QStringLiteral("endX"), hole.end.x).toDouble();
            hole.constructionEnd.y = settings.value(QStringLiteral("endY"), hole.end.y).toDouble();
            hole.constructionEnd.z = settings.value(QStringLiteral("endZ"), hole.end.z).toDouble();
            hole.constructionEnd.valid = settings.value(QStringLiteral("endValid"), false).toBool();
            hole.constructionArm = settings.value(QStringLiteral("arm"), -1).toInt();
            hole.constructionDepthM = settings.value(QStringLiteral("depthM"), 0.0).toDouble();
            hole.constructionTimestamp = settings.value(QStringLiteral("timestamp")).toString();
            hole.constructionSource = settings.value(QStringLiteral("source")).toString();
            hole.constructionTraceRecorded = hole.constructionStart.valid;
            const bool needsTraceMigration =
                hole.constructionTraceRecorded
                && (hole.constructionDepthM <= 0.05
                    || hole.constructionSource.isEmpty()
                    || hole.constructionSource == QStringLiteral("mouse-plan-tail")
                    || hole.constructionSource == QStringLiteral("mouse-sim-depth"));
            if (needsTraceMigration) {
                const int traceArm = qBound(0, hole.constructionArm, 2);
                hole.constructionDepthM = constructionTraceDepthMForArm(traceArm, i, hole.constructionStart);
                hole.constructionEnd = constructionTailPointForArm(traceArm, i, hole.constructionStart);
                if (hole.constructionSource.isEmpty()
                    || hole.constructionSource == QStringLiteral("mouse-plan-tail")) {
                    hole.constructionSource = QStringLiteral("mouse-sim-depth");
                }
                migratedTraceIndexes.append(i);
            }
            hole.completed = hole.constructionTraceRecorded;
        }
        settings.endGroup();
    }
    settings.endGroup();
    for (const int index : migratedTraceIndexes) {
        saveConstructionTrace(index);
    }
}

void SitonDrillMainView::saveConstructionTrace(int index) {
    if (index < 0 || index >= holes_.size()) {
        return;
    }
    const SitonPlanHole &hole = holes_.at(index);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(constructionTraceSettingsGroup());
    settings.beginGroup(holeEditKey(index));
    settings.setValue(QStringLiteral("id"), hole.id);
    settings.setValue(QStringLiteral("recorded"), hole.constructionTraceRecorded);
    settings.setValue(QStringLiteral("startX"), hole.constructionStart.x);
    settings.setValue(QStringLiteral("startY"), hole.constructionStart.y);
    settings.setValue(QStringLiteral("startZ"), hole.constructionStart.z);
    settings.setValue(QStringLiteral("startValid"), hole.constructionStart.valid);
    settings.setValue(QStringLiteral("endX"), hole.constructionEnd.x);
    settings.setValue(QStringLiteral("endY"), hole.constructionEnd.y);
    settings.setValue(QStringLiteral("endZ"), hole.constructionEnd.z);
    settings.setValue(QStringLiteral("endValid"), hole.constructionEnd.valid);
    settings.setValue(QStringLiteral("arm"), hole.constructionArm);
    settings.setValue(QStringLiteral("depthM"), hole.constructionDepthM);
    settings.setValue(QStringLiteral("timestamp"), hole.constructionTimestamp);
    settings.setValue(QStringLiteral("source"), hole.constructionSource);
    settings.endGroup();
    settings.endGroup();
    settings.sync();
}

void SitonDrillMainView::removeConstructionTrace(int index) {
    if (index < 0 || index >= holes_.size()) {
        return;
    }
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(constructionTraceSettingsGroup());
    settings.remove(holeEditKey(index));
    settings.endGroup();
    settings.sync();
}

double SitonDrillMainView::constructionTraceDepthMForArm(int armIndex, int holeIndex, const SitonPlanPoint &entry) const {
    armIndex = qBound(0, armIndex, 2);
    const ArmRealtimeState &arm = realtimeState_.arms[armIndex];
    if (arm.drillingDepthM > 0.05) {
        return arm.drillingDepthM;
    }
    if (drillMode_ == 0) {
        const SitonPlanPoint direction = constructionTraceDirectionForArm(armIndex, holeIndex);
        return baseLevelTargetDepthM(entry.x, direction.valid ? direction.x : 1.0);
    }
    return targetDrillDepthMForHole(holeIndex);
}

SitonPlanPoint SitonDrillMainView::constructionTraceDirectionForArm(int armIndex, int holeIndex) const {
    Q_UNUSED(holeIndex);
    armIndex = qBound(0, armIndex, 2);
    const ArmRealtimeState &arm = realtimeState_.arms[armIndex];
    if (arm.hValid && arm.h1Valid) {
        const SitonPlanPoint direction = normalizedDirection(arm.hX - arm.h1X,
                                                             arm.hY - arm.h1Y,
                                                             arm.hZ - arm.h1Z);
        if (direction.valid) {
            return direction;
        }
    }

    if (arm.angleValid && qAbs(arm.angleXzDeg) + qAbs(arm.angleYzDeg) > 0.05) {
        const SitonPlanPoint direction = normalizedDirection(qTan(qDegreesToRadians(arm.angleXzDeg)),
                                                             1.0,
                                                             qTan(qDegreesToRadians(arm.angleYzDeg)));
        if (direction.valid) {
            return direction;
        }
    }

    return normalizedDirection(0.0, 1.0, 0.0);
}

SitonPlanPoint SitonDrillMainView::constructionTailPointForArm(int armIndex, int holeIndex, const SitonPlanPoint &entry) const {
    SitonPlanPoint tail;
    if (!entry.valid || holeIndex < 0 || holeIndex >= holes_.size()) {
        return tail;
    }
    const SitonPlanPoint direction = constructionTraceDirectionForArm(armIndex, holeIndex);
    if (!direction.valid) {
        return tail;
    }
    const double depth = constructionTraceDepthMForArm(armIndex, holeIndex, entry);
    tail.x = entry.x + direction.x * depth;
    tail.y = entry.y + direction.y * depth;
    tail.z = entry.z + direction.z * depth;
    tail.valid = true;
    return tail;
}

bool SitonDrillMainView::recordConstructionTraceForArm(int armIndex, int holeIndex, bool forceCompletion) {
    armIndex = qBound(0, armIndex, 2);
    if (holeIndex < 0 || holeIndex >= holes_.size()) {
        return false;
    }

    SitonPlanPoint entry = hPointForArm(armIndex);
    if (!entry.valid || hOverlapHoleIndex(entry) != holeIndex) {
        return false;
    }

    const ArmRealtimeState &arm = realtimeState_.arms[armIndex];
    if (!forceCompletion) {
        if (!arm.hValid || holes_.at(holeIndex).constructionTraceRecorded) {
            return false;
        }
        const double targetDepth = targetDrillDepthMForArm(armIndex);
        if (targetDepth <= 0.05 || arm.drillingDepthM + 0.02 < targetDepth) {
            return false;
        }
    }

    SitonPlanHole &hole = holes_[holeIndex];
    hole.constructionTraceRecorded = true;
    hole.completed = true;
    hole.constructionArm = armIndex;
    hole.constructionTimestamp = QDateTime::currentDateTime().toString(Qt::ISODate);
    hole.constructionSource = forceCompletion ? QStringLiteral("mouse-sim-depth") : QStringLiteral("realtime-depth");
    hole.constructionStart = entry;
    hole.constructionDepthM = constructionTraceDepthMForArm(armIndex, holeIndex, entry);
    hole.constructionEnd = constructionTailPointForArm(armIndex, holeIndex, entry);
    saveConstructionTrace(holeIndex);
    return true;
}

void SitonDrillMainView::saveHoleEdit(int index) {
    if (index < 0 || index >= holes_.size()) {
        return;
    }
    const SitonPlanHole &hole = holes_.at(index);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    settings.beginGroup(holeEditKey(index));
    settings.setValue(QStringLiteral("id"), hole.id);
    settings.setValue(QStringLiteral("startX"), hole.start.x);
    settings.setValue(QStringLiteral("startY"), hole.start.y);
    settings.setValue(QStringLiteral("startZ"), hole.start.z);
    settings.setValue(QStringLiteral("endX"), hole.end.x);
    settings.setValue(QStringLiteral("endY"), hole.end.y);
    settings.setValue(QStringLiteral("endZ"), hole.end.z);
    settings.setValue(QStringLiteral("endValid"), hole.end.valid);
    settings.setValue(QStringLiteral("userAdded"), hole.userAdded);
    settings.endGroup();
    settings.endGroup();
    settings.sync();
}

void SitonDrillMainView::saveAddedHoles() {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    settings.remove(QStringLiteral("addedHoles"));
    settings.beginGroup(QStringLiteral("addedHoles"));
    for (const SitonPlanHole &hole : std::as_const(holes_)) {
        if (!hole.userAdded) {
            continue;
        }
        QString key = hole.id;
        key.replace(QLatin1Char('/'), QLatin1Char('_'));
        key.replace(QLatin1Char('\\'), QLatin1Char('_'));
        settings.beginGroup(key);
        settings.setValue(QStringLiteral("id"), hole.id);
        settings.setValue(QStringLiteral("type"), hole.type);
        settings.setValue(QStringLiteral("mwdOn"), hole.mwdOn);
        settings.setValue(QStringLiteral("startX"), hole.start.x);
        settings.setValue(QStringLiteral("startY"), hole.start.y);
        settings.setValue(QStringLiteral("startZ"), hole.start.z);
        settings.setValue(QStringLiteral("endX"), hole.end.x);
        settings.setValue(QStringLiteral("endY"), hole.end.y);
        settings.setValue(QStringLiteral("endZ"), hole.end.z);
        settings.setValue(QStringLiteral("endValid"), hole.end.valid);
        settings.endGroup();
    }
    settings.endGroup();
    settings.endGroup();
    settings.sync();
}

void SitonDrillMainView::saveDeletedHoleIds(const QStringList &ids) {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    settings.setValue(QStringLiteral("deletedIds"), ids);
    settings.endGroup();
    settings.sync();
}

QStringList SitonDrillMainView::deletedHoleIds() const {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(holeEditSettingsGroup());
    const QStringList ids = settings.value(QStringLiteral("deletedIds")).toStringList();
    settings.endGroup();
    return ids;
}

QString SitonDrillMainView::nextAddedHoleId() const {
    int maxId = 0;
    for (const SitonPlanHole &hole : holes_) {
        bool ok = false;
        const int id = hole.id.toInt(&ok);
        if (ok) {
            maxId = qMax(maxId, id);
        }
    }
    for (const SitonPlanHole &hole : originalHoles_) {
        bool ok = false;
        const int id = hole.id.toInt(&ok);
        if (ok) {
            maxId = qMax(maxId, id);
        }
    }
    int candidate = maxId + 1;
    QString candidateText;
    bool exists = true;
    while (exists) {
        candidateText = QString::number(candidate++);
        exists = false;
        for (const SitonPlanHole &hole : holes_) {
            if (hole.id == candidateText) {
                exists = true;
                break;
            }
        }
    }
    return candidateText;
}

bool SitonDrillMainView::restoreHoleFromOriginal(int index) {
    if (index < 0 || index >= holes_.size()) {
        return false;
    }
    const QString id = holes_.at(index).id;
    for (const SitonPlanHole &original : std::as_const(originalHoles_)) {
        if (original.id == id) {
            holes_[index] = original;
            return true;
        }
    }
    if (index < originalHoles_.size()) {
        holes_[index] = originalHoles_.at(index);
        return true;
    }
    return false;
}

QVector<int> SitonDrillMainView::armHoleIndices() const {
    QVector<int> result{-1, -1, -1};
    if (holes_.isEmpty()) {
        return result;
    }

    double leftScore = std::numeric_limits<double>::max();
    double middleScore = std::numeric_limits<double>::max();
    double rightScore = std::numeric_limits<double>::max();
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const double base = qAbs(hole.start.z + 1.0);
        const double scoreLeft = qAbs(hole.start.x + 4.0) + base * 0.5;
        const double scoreMiddle = qAbs(hole.start.x) + base * 0.8;
        const double scoreRight = qAbs(hole.start.x - 4.0) + base * 0.5;
        if (scoreLeft < leftScore) {
            leftScore = scoreLeft;
            result[0] = i;
        }
        if (scoreMiddle < middleScore) {
            middleScore = scoreMiddle;
            result[1] = i;
        }
        if (scoreRight < rightScore) {
            rightScore = scoreRight;
            result[2] = i;
        }
    }
    return result;
}

int SitonDrillMainView::defaultHoleIndexForArm(int armIndex) const {
    const QVector<int> indices = armHoleIndices();
    if (armIndex >= 0 && armIndex < indices.size() && indices.at(armIndex) >= 0) {
        return indices.at(armIndex);
    }
    for (int i = 0; i < holes_.size(); ++i) {
        if (holes_.at(i).start.valid && holeVisible(i)) {
            return i;
        }
    }
    return -1;
}

int SitonDrillMainView::activeHoleIndex() const {
    return defaultHoleIndexForArm(activeArm_);
}

double SitonDrillMainView::configuredBaseDepthM() const {
    bool ok = false;
    const double value = baseLevelEdit_ ? baseLevelEdit_->text().trimmed().toDouble(&ok) : 0.0;
    return ok && value > 0.05 ? value : 3.0;
}

double SitonDrillMainView::configuredEqualDepthM() const {
    bool ok = false;
    const double value = equalLengthEdit_ ? equalLengthEdit_->text().trimmed().toDouble(&ok) : 0.0;
    return ok && value > 0.05 ? value : 2.5;
}

double SitonDrillMainView::planDepthMForHole(int holeIndex) const {
    if (holeIndex < 0 || holeIndex >= holes_.size()) {
        return configuredEqualDepthM();
    }
    const SitonPlanHole &hole = holes_.at(holeIndex);
    if (!hole.start.valid || !hole.end.valid) {
        return configuredEqualDepthM();
    }
    const double dx = hole.end.x - hole.start.x;
    const double dy = hole.end.y - hole.start.y;
    const double dz = hole.end.z - hole.start.z;
    const double length = qSqrt(dx * dx + dy * dy + dz * dz);
    return length > 0.05 ? length : qMax(0.05, qAbs(hole.depthY));
}

double SitonDrillMainView::workBaseReferenceX() const {
    if (workBaseReferenceXValid_) {
        return workBaseReferenceX_;
    }
    const SitonPlanPoint hPoint = currentHPoint();
    if (hPoint.valid) {
        return hPoint.x;
    }
    const int activeIndex = activeHoleIndex();
    if (activeIndex >= 0 && activeIndex < holes_.size() && holes_.at(activeIndex).start.valid) {
        return holes_.at(activeIndex).start.x;
    }
    return 0.0;
}

double SitonDrillMainView::holeEntryReferenceXForArm(int armIndex, int holeIndex) const {
    armIndex = qBound(0, armIndex, 2);
    if (holeEntryReferenceXValid_[armIndex]) {
        return holeEntryReferenceX_[armIndex];
    }
    const SitonPlanPoint hPoint = hPointForArm(armIndex);
    if (hPoint.valid) {
        return hPoint.x;
    }
    if (holeIndex >= 0 && holeIndex < holes_.size() && holes_.at(holeIndex).start.valid) {
        return holes_.at(holeIndex).start.x;
    }
    return workBaseReferenceX();
}

SitonPlanPoint SitonDrillMainView::drillDirectionForHole(int holeIndex) const {
    if (holeIndex >= 0 && holeIndex < holes_.size()) {
        const SitonPlanHole &hole = holes_.at(holeIndex);
        if (hole.start.valid && hole.end.valid) {
            const SitonPlanPoint direction = normalizedDirection(hole.end.x - hole.start.x,
                                                                 hole.end.y - hole.start.y,
                                                                 hole.end.z - hole.start.z);
            if (direction.valid) {
                return direction;
            }
        }
    }
    return {};
}

SitonPlanPoint SitonDrillMainView::drillDirectionForArm(int armIndex, int holeIndex) const {
    armIndex = qBound(0, armIndex, 2);
    const ArmRealtimeState &arm = realtimeState_.arms[armIndex];
    if (arm.hValid && arm.h1Valid) {
        const SitonPlanPoint direction = normalizedDirection(arm.hX - arm.h1X,
                                                             arm.hY - arm.h1Y,
                                                             arm.hZ - arm.h1Z);
        if (direction.valid) {
            return direction;
        }
    }

    if (arm.angleValid && qAbs(arm.angleXzDeg) + qAbs(arm.angleYzDeg) > 0.05) {
        const SitonPlanPoint direction = normalizedDirection(qTan(qDegreesToRadians(arm.angleXzDeg)),
                                                             1.0,
                                                             qTan(qDegreesToRadians(arm.angleYzDeg)));
        if (direction.valid) {
            return direction;
        }
    }

    const SitonPlanPoint holeDirection = drillDirectionForHole(holeIndex);
    if (holeDirection.valid) {
        return holeDirection;
    }
    return normalizedDirection(0.0, 1.0, 0.0);
}

double SitonDrillMainView::baseLevelTargetDepthM(double entryX, double directionX) const {
    if (directionX <= kMinBaseLevelDirectionX) {
        directionX = kMinBaseLevelDirectionX;
    }
    const double bottomPlaneX = workBaseReferenceX() + configuredBaseDepthM();
    return qBound(0.10, (bottomPlaneX - entryX) / directionX, 20.0);
}

double SitonDrillMainView::targetDrillDepthMForHole(int holeIndex) const {
    if (drillMode_ == 1) {
        return configuredEqualDepthM();
    }
    if (drillMode_ == 2) {
        return planDepthMForHole(holeIndex);
    }
    if (holeIndex < 0 || holeIndex >= holes_.size() || !holes_.at(holeIndex).start.valid) {
        return configuredBaseDepthM();
    }
    const SitonPlanPoint direction = drillDirectionForHole(holeIndex);
    return baseLevelTargetDepthM(holes_.at(holeIndex).start.x, direction.valid ? direction.x : 1.0);
}

double SitonDrillMainView::targetDrillDepthMForArm(int armIndex) const {
    armIndex = qBound(0, armIndex, 2);
    const SitonPlanPoint hPoint = hPointForArm(armIndex);
    int holeIndex = hOverlapHoleIndex(hPoint);
    if (holeIndex < 0 && simulatedNearestHole_[armIndex] >= 0) {
        holeIndex = simulatedNearestHole_[armIndex];
    }
    if (holeIndex < 0) {
        holeIndex = defaultHoleIndexForArm(armIndex);
    }
    if (drillMode_ == 0) {
        if (!holeEntryReferenceXValid_[armIndex]) {
            return configuredBaseDepthM();
        }
        const double entryX = holeEntryReferenceXForArm(armIndex, holeIndex);
        const SitonPlanPoint direction = drillDirectionForArm(armIndex, holeIndex);
        return baseLevelTargetDepthM(entryX, direction.valid ? direction.x : 1.0);
    }
    return targetDrillDepthMForHole(holeIndex);
}

bool SitonDrillMainView::captureHoleEntryReferenceForArm(int armIndex) {
    armIndex = qBound(0, armIndex, 2);
    SitonPlanPoint entry = hPointForArm(armIndex);
    if (!entry.valid) {
        const int holeIndex = simulatedNearestHole_[armIndex] >= 0
            ? simulatedNearestHole_[armIndex]
            : defaultHoleIndexForArm(armIndex);
        if (holeIndex >= 0 && holeIndex < holes_.size()) {
            entry = holes_.at(holeIndex).start;
        }
    }
    if (!entry.valid) {
        return false;
    }
    holeEntryReferenceX_[armIndex] = entry.x;
    holeEntryReferenceXValid_[armIndex] = true;
    return true;
}

void SitonDrillMainView::updateDrillingEntryReferences(const MachineRealtimeState &previous,
                                                       const MachineRealtimeState &current) {
    constexpr double kStartThresholdM = 0.005;
    constexpr double kResetThresholdM = 0.002;
    for (int arm = 0; arm < 3; ++arm) {
        const ArmRealtimeState &oldArm = previous.arms[arm];
        const ArmRealtimeState &newArm = current.arms[arm];
        const double oldDepth = oldArm.drillingDepthM;
        const double newDepth = newArm.drillingDepthM;
        const bool stateKnown = oldArm.drillingStateValid || newArm.drillingStateValid
            || oldArm.drillingActive || newArm.drillingActive
            || oldArm.drillingStartPulse || newArm.drillingStartPulse;
        const bool stoppedAtZero = newDepth <= kResetThresholdM && (!stateKnown || !newArm.drillingActive);
        if (stoppedAtZero) {
            holeEntryReferenceXValid_[arm] = false;
            continue;
        }

        const bool startPulse = newArm.drillingStartPulse && !oldArm.drillingStartPulse;
        const bool activeRising = newArm.drillingActive && !oldArm.drillingActive;
        const bool depthRising = oldDepth <= kStartThresholdM && newDepth > kStartThresholdM;
        if (!holeEntryReferenceXValid_[arm] && (startPulse || activeRising || depthRising)) {
            captureHoleEntryReferenceForArm(arm);
        }
    }
}

SitonPlanPoint SitonDrillMainView::hPointForArm(int armIndex) const {
    armIndex = qBound(0, armIndex, 2);
    if (realtimeState_.arms[armIndex].hValid) {
        const ArmRealtimeState &arm = realtimeState_.arms[armIndex];
        SitonPlanPoint point;
        point.x = arm.hX;
        point.y = arm.hY;
        point.z = arm.hZ;
        point.valid = true;
        return point;
    }
    if (simulatedHPointValid_[armIndex] && simulatedHPoints_[armIndex].valid) {
        return simulatedHPoints_[armIndex];
    }
    SitonPlanPoint point;
    if (holes_.isEmpty()) {
        return point;
    }
    const int base = defaultHoleIndexForArm(armIndex);
    if (base < 0 || base >= holes_.size()) {
        return point;
    }
    const int phaseCount = 12;
    const int offsetStep = armIndex == activeArm_ ? 0 : (armIndex + 1) * 3;
    const int phase = (hStep_ + offsetStep) % phaseCount;
    int target = base;
    for (int offset = 1; offset <= holes_.size(); ++offset) {
        const int candidate = (base + hStep_ / phaseCount + offset + (armIndex == activeArm_ ? 0 : armIndex)) % holes_.size();
        if (holes_.at(candidate).start.valid && holeVisible(candidate)) {
            target = candidate;
            break;
        }
    }
    const SitonPlanPoint &a = holes_.at(base).start;
    const SitonPlanPoint &b = holes_.at(target).start;
    const double t = phase == 0 ? 0.0 : static_cast<double>(phase) / static_cast<double>(phaseCount - 1);
    point.x = a.x + (b.x - a.x) * t;
    point.y = a.y + (b.y - a.y) * t;
    point.z = a.z + (b.z - a.z) * t;
    point.valid = a.valid && b.valid;
    return point;
}

SitonPlanPoint SitonDrillMainView::hTailPointForArm(int armIndex, const SitonPlanPoint &hPoint) const {
    SitonPlanPoint tail;
    if (!hPoint.valid) {
        return tail;
    }

    armIndex = qBound(0, armIndex, 2);
    int holeIndex = hOverlapHoleIndex(hPoint);
    if (simulatedNearestHole_[armIndex] >= 0) {
        holeIndex = simulatedNearestHole_[armIndex];
    }
    if (holeIndex < 0) {
        holeIndex = defaultHoleIndexForArm(armIndex);
    }
    const SitonPlanPoint direction = drillDirectionForArm(armIndex, holeIndex);
    if (!direction.valid) {
        return tail;
    }
    tail.x = hPoint.x - direction.x;
    tail.y = hPoint.y - direction.y;
    tail.z = hPoint.z - direction.z;
    tail.valid = true;
    return tail;
}

SitonPlanPoint SitonDrillMainView::currentHPoint() const {
    return hPointForArm(activeArm_);
}

int SitonDrillMainView::hOverlapHoleIndex(const SitonPlanPoint &hPoint) const {
    if (!hPoint.valid) {
        return -1;
    }
    int best = -1;
    double bestDistance = std::numeric_limits<double>::max();
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const double dx = hole.start.x - hPoint.x;
        const double dy = hole.start.y - hPoint.y;
        const double dz = hole.start.z - hPoint.z;
        const double distance = qSqrt(dx * dx + dy * dy + dz * dz);
        if (distance < bestDistance) {
            bestDistance = distance;
            best = i;
        }
    }
    return bestDistance <= 0.06 ? best : -1;
}

QRectF SitonDrillMainView::leftTabRect(const QRectF &panel, int index) const {
    const QStringList tabs{u("常用数据"), u("钻机参数"), u("钻孔模式")};
    const double tabW = qMin(116.0, (panel.width() - 20) / tabs.size());
    return QRectF(panel.left() + 8 + index * tabW, panel.top() + 8, tabW - 2, 36);
}

QRectF SitonDrillMainView::viewTabRect(const QRectF &panel, int index) const {
    const double tabY = panel.top() + 8;
    const double tabW = 116.0;
    const double startX = panel.right() - tabW * 4 - 20;
    return QRectF(startX + tabW * index, tabY, tabW, 36);
}

void SitonDrillMainView::drawHPointOverlay(QPainter &p, const QRectF &plot, const QRectF &, const QRectF &) {
    const SitonPlanPoint hPoint = currentHPoint();
    const int hit = hOverlapHoleIndex(hPoint);
    const QRectF info(plot.left() + 10, plot.top() + 8, qMin(520.0, plot.width() - 210.0), 104);
    p.setPen(Qt::NoPen);
    p.setBrush(QColor(0, 0, 0, 150));
    p.drawRect(info);

    const ArmRealtimeState &arm = realtimeState_.arms[qBound(0, activeArm_, 2)];
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 12, QFont::Bold));
    p.setPen(QColor("#ffffff"));
    p.drawText(QRectF(info.left() + 10, info.top() + 4, 150, 22), Qt::AlignLeft | Qt::AlignVCenter, viewTitle(currentView_));
    p.setPen(QColor("#00c8ef"));
    p.drawText(QRectF(info.left() + 170, info.top() + 4, info.width() - 180, 22), Qt::AlignLeft | Qt::AlignVCenter,
               u("孔数 ") + QString::number(holes_.size()) + QStringLiteral("/") + QString::number(declaredHoleCount_));
    const double legendY = info.top() + 6;
    const double legendX = info.right() - 178;
    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::Bold));
    for (int arm = 0; arm < 3; ++arm) {
        const QPointF dot(legendX + arm * 58.0, legendY + 9.0);
        p.setPen(Qt::NoPen);
        p.setBrush(armHColor(arm, activeArm_));
        p.drawEllipse(dot, arm == activeArm_ ? 5.5 : 4.5, arm == activeArm_ ? 5.5 : 4.5);
        p.setPen(armHColor(arm, activeArm_));
        p.drawText(QRectF(dot.x() + 8, legendY, 46, 18), Qt::AlignLeft | Qt::AlignVCenter,
                   armShortName(arm).left(1) + QStringLiteral("H"));
    }

    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 13, QFont::Bold));
    p.setPen(QColor("#ffffff"));
    p.drawText(QRectF(info.left() + 10, info.top() + 28, 116, 22), Qt::AlignLeft | Qt::AlignVCenter,
               QStringLiteral("%1°/").arg(arm.angleXzDeg, 0, 'f', 1));
    p.setPen(QColor("#00d242"));
    p.drawText(QRectF(info.left() + 76, info.top() + 28, 86, 22), Qt::AlignLeft | Qt::AlignVCenter,
               QStringLiteral("%1°").arg(arm.angleYzDeg, 0, 'f', 1));

    p.setPen(QColor("#ffffff"));
    p.drawText(QRectF(info.left() + 10, info.top() + 50, 116, 22), Qt::AlignLeft | Qt::AlignVCenter,
               QStringLiteral("%1m/").arg(arm.drillingDepthM, 0, 'f', 1));
    p.setPen(hit >= 0 ? QColor("#48e86e") : armHColor(qBound(0, activeArm_, 2), activeArm_));
    p.drawText(QRectF(info.left() + 78, info.top() + 50, 96, 22), Qt::AlignLeft | Qt::AlignVCenter,
               hit >= 0 ? QStringLiteral("0.00 m") : QStringLiteral("0.00 m"));

    p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 12, QFont::Bold));
    p.setPen(hit >= 0 ? QColor("#48e86e") : QColor("#f6df4a"));
    const QString hitText = hit >= 0 ? (u("  重合孔 H") + holes_.at(hit).id) : u("  未重合");
    p.drawText(QRectF(info.left() + 10, info.top() + 74, info.width() - 20, 22), Qt::AlignLeft | Qt::AlignVCenter,
               u("H点 ") + coordText(hPoint) + hitText);

    if (mouseInPlot_ && mousePoint_.valid) {
        const SitonPlanPoint currentHole = activeHoleIndex() >= 0 && activeHoleIndex() < holes_.size()
            ? holes_.at(activeHoleIndex()).start
            : hPoint;
        const double dx = mousePoint_.x - currentHole.x;
        const double dy = mousePoint_.y - currentHole.y;
        const double dz = mousePoint_.z - currentHole.z;
        const double distance = qSqrt(dx * dx + dy * dy + dz * dz);
        const QString nearestText = mouseNearestHole_ >= 0 ? (u("  最近孔 H") + holes_.at(mouseNearestHole_).id) : u("  最近孔 -");
        p.setPen(QColor("#f6df4a"));
        const QString mouseText = coordText(mousePoint_) + nearestText
            + QStringLiteral("  Δ当前孔:%1").arg(distance, 0, 'f', 2);
        const QFontMetrics fm(p.font());
        p.drawText(QRectF(info.left() + 190, info.top() + 50, info.width() - 200, 22), Qt::AlignLeft | Qt::AlignVCenter,
                   fm.elidedText(mouseText, Qt::ElideRight, static_cast<int>(info.width() - 210)));
    }
}

void SitonDrillMainView::drawDrillView(QPainter &p, const QRectF &plot, const QRectF &drawPlot, const QVector<SitonProfileSegment> &faceProfiles) {
    const QRectF bounds = dataBounds(currentView_, faceProfiles);
    lastPlot_ = plot;
    lastDrawPlot_ = drawPlot;
    lastBounds_ = bounds;
    SitonPlanPoint hPoints[3];
    int hHits[3] = {-1, -1, -1};
    for (int arm = 0; arm < 3; ++arm) {
        hPoints[arm] = hPointForArm(arm);
        hHits[arm] = hOverlapHoleIndex(hPoints[arm]);
    }
    const int activeHit = hHits[qBound(0, activeArm_, 2)];

    if (currentView_ == SitonDrillViewMode::Face) {
        p.setBrush(Qt::NoBrush);
        p.setPen(QPen(QColor("#9fb1ad"), 4, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        for (const SitonProfileSegment &segment : faceProfiles) {
            const QVector<QPointF> points = profilePoints(segment);
            if (points.size() < 2) {
                continue;
            }
            QPainterPath path;
            path.moveTo(mapProjectedPoint(points.first(), drawPlot, bounds));
            for (int i = 1; i < points.size(); ++i) {
                path.lineTo(mapProjectedPoint(points.at(i), drawPlot, bounds));
            }
            p.drawPath(path);
        }
    }

    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !hole.end.valid || !holeVisible(i)) {
            continue;
        }
        const bool selected = holeEditMode_ && i == editSelectedHole_;
        p.setPen(QPen(selected ? QColor("#f6df4a") : QColor("#8fa39f"),
                      selected ? 4.0 : (currentView_ == SitonDrillViewMode::Face ? 2.0 : 3.0),
                      Qt::SolidLine, Qt::RoundCap));
        p.drawLine(mapDataPoint(hole.start, drawPlot, bounds, currentView_), mapDataPoint(hole.end, drawPlot, bounds, currentView_));
    }

    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!holeVisible(i) || !hole.constructionTraceRecorded || !hole.constructionStart.valid) {
            continue;
        }
        const bool selected = holeEditMode_ && i == editSelectedHole_;
        p.setPen(QPen(selected ? QColor("#f6df4a") : kConstructionTraceColor,
                      selected ? 4.0 : 4.2,
                      Qt::SolidLine, Qt::RoundCap));
        if (hole.constructionEnd.valid) {
            p.drawLine(mapDataPoint(hole.constructionStart, drawPlot, bounds, currentView_),
                       mapDataPoint(hole.constructionEnd, drawPlot, bounds, currentView_));
        }
    }

    p.setPen(Qt::NoPen);
    for (int i = 0; i < holes_.size(); ++i) {
        const SitonPlanHole &hole = holes_.at(i);
        if (!hole.start.valid || !holeVisible(i)) {
            continue;
        }
        const SitonPlanPoint displayStart = hole.constructionTraceRecorded && hole.constructionStart.valid
            ? hole.constructionStart
            : hole.start;
        const QPointF center = mapDataPoint(displayStart, drawPlot, bounds, currentView_);
        int matchedArm = -1;
        const bool activeMatched = i == activeHit;
        const bool selected = holeEditMode_ && i == editSelectedHole_;
        if (activeMatched) {
            matchedArm = qBound(0, activeArm_, 2);
        } else {
            for (int arm = 0; arm < 3; ++arm) {
                if (hHits[arm] == i) {
                    matchedArm = arm;
                    break;
                }
            }
        }
        p.setBrush(selected ? QColor("#f6df4a")
                            : (hole.constructionTraceRecorded ? kConstructionTraceColor
                                                               : (matchedArm >= 0 ? QColor("#48e86e") : QColor("#b7c8c4"))));
        p.drawEllipse(center,
                      selected ? 11.5 : (hole.constructionTraceRecorded ? 9.5 : (activeMatched ? 10.5 : (matchedArm >= 0 ? 9.0 : 7.5))),
                      selected ? 11.5 : (hole.constructionTraceRecorded ? 9.5 : (activeMatched ? 10.5 : (matchedArm >= 0 ? 9.0 : 7.5))));
    }

    if (holeEditMode_ && editSelectedHole_ >= 0 && editSelectedHole_ < holes_.size()) {
        const SitonPlanHole &hole = holes_.at(editSelectedHole_);
        auto drawEditHandle = [&](const SitonPlanPoint &point, bool active, const QString &label) {
            if (!point.valid) {
                return;
            }
            const QPointF targetScreen = mapDataPoint(point, drawPlot, bounds, currentView_);
            p.setBrush(Qt::NoBrush);
            p.setPen(QPen(active ? QColor("#00c8ef") : QColor("#f6df4a"),
                          active ? 3.0 : 2.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            p.drawEllipse(targetScreen, active ? 17.0 : 12.0, active ? 17.0 : 12.0);
            if (active) {
                p.drawLine(QPointF(targetScreen.x() - 11, targetScreen.y()), QPointF(targetScreen.x() + 11, targetScreen.y()));
                p.drawLine(QPointF(targetScreen.x(), targetScreen.y() - 11), QPointF(targetScreen.x(), targetScreen.y() + 11));
                p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 12, QFont::Bold));
                p.setPen(QColor("#00c8ef"));
                p.drawText(QRectF(targetScreen.x() + 16, targetScreen.y() + 8, 120, 24),
                           Qt::AlignLeft | Qt::AlignVCenter, label);
            }
        };
        drawEditHandle(hole.start, !holeEditTargetEndPoint_, u("入口点"));
        if (hasEditableTail(hole)) {
            drawEditHandle(hole.end, holeEditTargetEndPoint_, u("尾巴末端"));
        }
    }

    auto drawHMarker = [&](int arm) {
        arm = qBound(0, arm, 2);
        const SitonPlanPoint hPoint = hPoints[arm];
        if (!hPoint.valid) {
            return;
        }
        const QPointF hScreen = mapDataPoint(hPoint, drawPlot, bounds, currentView_);
        if (!drawPlot.adjusted(-28, -28, 28, 28).contains(hScreen)) {
            return;
        }
        const bool active = arm == activeArm_;
        const bool hit = hHits[arm] >= 0;
        const QColor color = hit ? QColor("#48e86e") : armHColor(arm, activeArm_);
        const double radius = active ? (hit ? 18.0 : 15.0) : (hit ? 13.0 : 11.0);
        const SitonPlanPoint tailPoint = hTailPointForArm(arm, hPoint);
        if (tailPoint.valid) {
            drawHDirectionTail(p, hScreen, mapDataPoint(tailPoint, drawPlot, bounds, currentView_),
                               color, active ? 42.0 : 30.0, active ? 4.0 : 2.8);
        }
        p.setBrush(Qt::NoBrush);
        p.setPen(QPen(color, active ? 3.2 : 2.4));
        p.drawEllipse(hScreen, radius, radius);
        const double cross = active ? 8.0 : 5.5;
        p.drawLine(QPointF(hScreen.x() - cross, hScreen.y() - cross), QPointF(hScreen.x() + cross, hScreen.y() + cross));
        p.drawLine(QPointF(hScreen.x() + cross, hScreen.y() - cross), QPointF(hScreen.x() - cross, hScreen.y() + cross));
        p.setFont(QFont(QStringLiteral("Consolas"), 11, QFont::Bold));
        p.setPen(color);
        p.drawText(QRectF(hScreen.x() + 12, hScreen.y() - 24, 92, 22), Qt::AlignLeft | Qt::AlignVCenter,
                   QStringLiteral("%1H").arg(armShortName(arm).left(1)));
    };
    for (int arm = 0; arm < 3; ++arm) {
        if (arm != activeArm_) {
            drawHMarker(arm);
        }
    }
    drawHMarker(qBound(0, activeArm_, 2));

    if (mouseInPlot_ && lastDrawPlot_.contains(mouseScreen_)) {
        p.setPen(QPen(QColor("#f6df4a"), 1, Qt::DashLine));
        p.drawLine(QPointF(mouseScreen_.x(), drawPlot.top()), QPointF(mouseScreen_.x(), drawPlot.bottom()));
        p.drawLine(QPointF(drawPlot.left(), mouseScreen_.y()), QPointF(drawPlot.right(), mouseScreen_.y()));
        p.setPen(QPen(QColor("#f6df4a"), 2));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(mouseScreen_, 7, 7);
        if (mouseNearestHole_ >= 0 && mouseNearestHole_ < holes_.size() && holeVisible(mouseNearestHole_)) {
            const QPointF nearest = mapDataPoint(holes_.at(mouseNearestHole_).start, drawPlot, bounds, currentView_);
            p.drawEllipse(nearest, 13, 13);
            p.drawLine(mouseScreen_, nearest);
        }
    }

    drawHPointOverlay(p, plot, drawPlot, bounds);
}

void SitonDrillMainView::drawFacePanel(QPainter &p, const QRectF &panel) {
    drawHardPanel(p, panel, QColor("#555555"), 6);
    const QStringList views{u("主视图"), u("俯视图"), u("左视图"), u("三维图")};
    for (int i = 0; i < views.size(); ++i) {
        drawSquareButton(p, viewTabRect(panel, i), views.at(i), static_cast<int>(currentView_) == i);
    }

    const QRectF plot(panel.left() + 22, panel.top() + 56, panel.width() - 44, panel.height() - 76);
    p.setPen(QPen(QColor("#151515"), 2));
    p.setBrush(QColor("#000000"));
    p.drawRect(plot);
    p.setPen(QPen(QColor("#242424"), 1));
    for (int i = 1; i < 21; ++i) {
        const double x = plot.left() + plot.width() * i / 21.0;
        p.drawLine(QPointF(x, plot.top()), QPointF(x, plot.bottom()));
    }
    for (int i = 1; i < 15; ++i) {
        const double y = plot.top() + plot.height() * i / 15.0;
        p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
    }

    if (!loadError_.isEmpty()) {
        p.setPen(QColor("#ff4040"));
        p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 18, QFont::Bold));
        p.drawText(plot, Qt::AlignCenter, loadError_);
        return;
    }

    QVector<SitonProfileSegment> faceProfiles;
    std::copy_if(profiles_.cbegin(), profiles_.cend(), std::back_inserter(faceProfiles), [](const SitonProfileSegment &segment) {
        return segment.profileType == QStringLiteral("FaceProfile");
    });
    if (faceProfiles.isEmpty()) {
        faceProfiles = profiles_;
    }

    const QRectF drawPlot = plot.adjusted(16, 136, -16, -12);

    updateHoleLegendChecks(plot);
    drawDrillView(p, plot, drawPlot, faceProfiles);
}

bool SitonDrillMainView::holeVisible(int index) const {
    if (index < 0 || index >= holes_.size()) {
        return false;
    }
    const bool completed = holes_.at(index).completed;
    return completed ? showCompletedHoles_ : showPendingHoles_;
}

void SitonDrillMainView::updateHoleLegendChecks(const QRectF &plot) {
    const bool valid = plot.isValid() && plot.width() > 160 && plot.height() > 80;
    const QPoint topLeft(qRound(plot.right() - 148), qRound(plot.top() + 12));
    const QSize size(136, 24);
    const QList<QPointer<QCheckBox>> checks{completedHoleCheck_, pendingHoleCheck_};
    for (int i = 0; i < checks.size(); ++i) {
        QCheckBox *check = checks.at(i);
        if (!check) {
            continue;
        }
        if (!valid) {
            check->hide();
            continue;
        }
        check->setGeometry(QRect(topLeft + QPoint(0, i * 28), size));
        check->show();
        check->raise();
    }
}
