#pragma once

#include "CanBusModel.h"

#include <QByteArray>
#include <QMap>
#include <QObject>
#include <QQueue>
#include <QTcpSocket>
#include <QTimer>
#include <QVector>

class CanToNetClient final : public QObject {
    Q_OBJECT

public:
    explicit CanToNetClient(QObject *parent = nullptr);

    void configure(const QString &host = QStringLiteral("192.168.0.105"),
                   quint16 port = 503,
                   quint8 channel = 0);
    void start();
    void stop();
    bool isConnected() const;

    void sendCanFrame(const CanFrame &frame);

    void setEndpoint(const QString &host, quint16 port);
    void setUnitId(quint8 unitId);
    void setAddressOffset(int offset);
    void setTimeoutMs(int timeoutMs);

    void connectToCanToNet();
    void disconnectFromCanToNet();

    void readHoldingRegisters(int canToNetStartAddress, int count);
    void writeHoldingRegisters(const QMap<int, quint16> &canToNetAddressValues);

    void readCanFrame(quint32 canId);
    void writeCanFrame(quint32 canId, const QByteArray &canData8);

    void startPolling(int canToNetStartAddress, int count, int intervalMs);
    void startPollingCanFrame(quint32 canId, int intervalMs);
    void stopPolling();

    static bool canIdToAddressRange(quint32 canId, int *startAddress, int *registerCount = nullptr);
    static QByteArray registersToCanData(const QVector<quint16> &registers);
    static QMap<int, quint16> canDataToRegisters(int startAddress, const QByteArray &canData8);

signals:
    void connected();
    void disconnected();
    void connectedChanged(bool connected);
    void registersRead(int canToNetStartAddress, QVector<quint16> values);
    void canFrameRead(quint32 canId, QByteArray canData8);
    void canFrameReceived(const CanFrame &frame);
    void writeFinished(int count);
    void canFrameWritten(quint32 canId);
    void packetDropped(const QString &reason, const QByteArray &raw);
    void errorOccurred(QString message);

private:
    enum class RequestType {
        Read,
        Write
    };

    enum class PollMode {
        None,
        DefaultCanFrames,
        Registers,
        SingleCanFrame
    };

    struct Request {
        RequestType type = RequestType::Read;
        quint16 transactionId = 0;
        quint8 functionCode = 0;
        int canToNetStartAddress = 0;
        int count = 0;
        quint32 canId = 0;
        bool isCanFrame = false;
        QByteArray pdu;
    };

    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError error);
    void onConnected();
    void onDisconnected();
    void onRequestTimeout();
    void onPollTimeout();
    void onReconnectTimeout();

    quint16 toProtocolAddress(int canToNetAddress);
    void enqueue(Request request);
    void sendNext();
    void handleResponse(const QByteArray &adu);
    void completeCurrentRequest();
    void reportError(const QString &message, const QByteArray &raw = QByteArray());
    QByteArray buildMbap(quint16 transactionId, quint16 pduLength) const;
    Request buildReadRequest(int canToNetStartAddress, int count, quint32 canId = 0);
    Request buildWriteRequest(int canToNetStartAddress, const QVector<quint16> &values, quint32 canId = 0);
    void startDefaultPolling();

    QTcpSocket socket_;
    QTimer timeoutTimer_;
    QTimer pollTimer_;
    QTimer reconnectTimer_;
    QByteArray rxBuffer_;
    QQueue<Request> queue_;
    Request current_;

    QString host_ = QStringLiteral("192.168.0.105");
    quint16 port_ = 503;
    quint8 unitId_ = 255;
    int addressOffset_ = 1;
    int timeoutMs_ = 100;
    int pollStartAddress_ = 50;
    int pollCount_ = 4;
    int pollIndex_ = 0;
    quint32 pollCanId_ = 0;
    PollMode pollMode_ = PollMode::None;
    quint16 nextTransactionId_ = 1;
    bool hasCurrentRequest_ = false;
    bool running_ = false;
    QVector<quint32> defaultPollCanIds_{0x150, 0x152, 0x153, 0x154, 0x15A, 0x170, 0x176};
};
