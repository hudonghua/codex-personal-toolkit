#include "MainWindow.h"
#include "SitonDrillMainView.h"

#include <algorithm>
#include <cstdio>
#include <functional>
#include <memory>
#include <QApplication>
#include <QAbstractItemView>
#include <QButtonGroup>
#include <QComboBox>
#include <QDateTime>
#include <QDateTimeEdit>
#include <QDialog>
#include <QDir>
#include <QElapsedTimer>
#include <QEvent>
#include <QFile>
#include <QFileDialog>
#include <QFrame>
#include <QFont>
#include <QGridLayout>
#include <QGroupBox>
#include <QHash>
#include <QHeaderView>
#include <QIcon>
#include <QItemSelectionModel>
#include <QLabel>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPixmap>
#include <QRegularExpression>
#include <QScrollArea>
#include <QScroller>
#include <QSettings>
#include <QStringConverter>
#include <QStringList>
#include <QSizePolicy>
#include <QSplitter>
#include <QStandardPaths>
#include <QStyle>
#include <QTableWidget>
#include <QTextStream>
#include <QToolButton>
#include <QVBoxLayout>
#include <QtMath>

namespace {
QString u(const char *text) {
    return QString::fromUtf8(text);
}

bool holeHasEditableTail(const SitonPlanHole &hole) {
    if (!hole.start.valid || !hole.end.valid) {
        return false;
    }
    const double dx = hole.end.x - hole.start.x;
    const double dz = hole.end.z - hole.start.z;
    return qSqrt(dx * dx + dz * dz) > 0.02;
}

QLabel *plainLabel(const QString &text, const QString &className = QString()) {
    auto *label = new QLabel(text);
    if (!className.isEmpty()) {
        label->setProperty("class", className);
    }
    label->setTextInteractionFlags(Qt::NoTextInteraction);
    return label;
}

QString sitonClockText(const QDateTime &dateTime) {
    const QStringList weekdays{u("一"), u("二"), u("三"), u("四"), u("五"), u("六"), u("日")};
    const int index = dateTime.date().dayOfWeek() - 1;
    return dateTime.toString(QStringLiteral("yyyy/MM/dd "))
        + weekdays.value(index)
        + dateTime.toString(QStringLiteral(" HH:mm:ss"));
}

void pulseButtonText(QPushButton *button, const QString &temporaryText, int delayMs = 800) {
    if (!button) {
        return;
    }
    const QString originalText = button->text();
    button->setText(temporaryText);
    QTimer::singleShot(delayMs, button, [button, originalText] {
        if (button) {
            button->setText(originalText);
        }
    });
}

void setDotColor(QLabel *label, const QColor &color) {
    if (!label) {
        return;
    }
    label->setStyleSheet(QStringLiteral("QLabel { background: transparent; color: %1; font-size: 20px; font-weight: 900; }").arg(color.name()));
}

void setLabelText(QLabel *label, const QString &text) {
    if (label) {
        label->setText(text);
    }
}

enum class CoverageHint {
    Covered,
    Gap
};

void refreshCoverageStyle(QWidget *widget) {
    if (!widget) {
        return;
    }
    widget->style()->unpolish(widget);
    widget->style()->polish(widget);
    widget->update();
}

void setCoverageHint(QWidget *widget, CoverageHint hint) {
    if (!widget) {
        return;
    }
    widget->setProperty("coverageHint", hint == CoverageHint::Covered ? "covered" : "gap");
    refreshCoverageStyle(widget);
}

void setCoverageHint(QWidget *first, QWidget *second, CoverageHint hint) {
    setCoverageHint(first, hint);
    setCoverageHint(second, hint);
}

bool coverageHintForObjectName(const QString &objectName, CoverageHint *hint) {
    if (objectName.isEmpty() || !hint) {
        return false;
    }
    if (objectName.startsWith(QStringLiteral("drillPreset."))
        || objectName.startsWith(QStringLiteral("calibration.qBody"))
        || objectName.startsWith(QStringLiteral("calibration.qWorld"))
        || objectName.startsWith(QStringLiteral("calibration.mechanical.input"))
        || objectName.startsWith(QStringLiteral("settings.canToNet."))
        || objectName.startsWith(QStringLiteral("settings.zero.arm"))) {
        *hint = CoverageHint::Covered;
        return true;
    }
    if (objectName.startsWith(QStringLiteral("settings.currentCalibration."))
        || objectName.startsWith(QStringLiteral("settings.storage."))
        || objectName.startsWith(QStringLiteral("settings.graphic."))
        || objectName.startsWith(QStringLiteral("settings.alarm."))
        || objectName.startsWith(QStringLiteral("settings.maintenance."))) {
        *hint = CoverageHint::Gap;
        return true;
    }
    return false;
}

QString monitorNumber(double value, int decimals = 0) {
    if (qAbs(value) < 0.0001) {
        return decimals > 0 ? QString::number(0.0, 'f', decimals) : QStringLiteral("0");
    }
    return QString::number(value, 'f', decimals);
}

QString persistentLineEditByNameKey(const QString &objectName) {
    return QStringLiteral("persistentInputs/lineEditByName/%1").arg(objectName);
}

QString savedLineEditText(const QString &objectName, const QString &fallback) {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    return settings.value(persistentLineEditByNameKey(objectName), fallback).toString();
}

quint16 savedCanToNetPort() {
    bool ok = false;
    const int port = savedLineEditText(QStringLiteral("settings.canToNet.modulePort"), QStringLiteral("503")).toInt(&ok);
    return ok && port > 0 && port <= 65535 ? static_cast<quint16>(port) : quint16(503);
}

QString sensorValueText(const ArmRealtimeState &arm, int row) {
    switch (row) {
    case 0:
        return monitorNumber(arm.thrustPressure);
    case 1:
        return monitorNumber(arm.impactPressure);
    case 2:
        return monitorNumber(arm.rotationPressure);
    case 3:
        return monitorNumber(arm.compensationThrustPressure);
    case 5:
        return monitorNumber(arm.angleXzDeg, 2);
    case 6:
        return monitorNumber(arm.angleYzDeg, 2);
    case 12:
        return monitorNumber(arm.drillingDepthM, 2);
    default:
        return QStringLiteral("0");
    }
}

QString truckDataValueText(const ArmRealtimeState &arm, int row) {
    switch (row) {
    case 1:
        return arm.rockDrillWorkTimeValid
            ? QString::number(arm.rockDrillWorkTimeRaw / 3600.0, 'f', 2)
            : QStringLiteral("0.00");
    case 3:
        return monitorNumber(arm.waterFlow, 2);
    case 4:
        return monitorNumber(arm.lubricationPressure, 2);
    case 7:
        return monitorNumber(arm.compensationThrustPressure, 2);
    default:
        return QStringLiteral("0.00");
    }
}

bool truckDataValid(const ArmRealtimeState &arm, int row) {
    switch (row) {
    case 1:
        return arm.rockDrillWorkTimeValid;
    case 3:
        return arm.waterFlowValid;
    case 4:
        return arm.lubricationPressureValid;
    case 7:
        return arm.compensationThrustPressureValid;
    case 8:
        return arm.lubricationPressureLowValid;
    case 9:
        return arm.waterFlowValid;
    default:
        return false;
    }
}

bool truckDataFault(const ArmRealtimeState &arm, int row) {
    return (row == 4 || row == 8) && arm.lubricationPressureLowValid && arm.lubricationPressureLow;
}

QString handleValueText(const OperatorHandleRealtimeState &handle, int row) {
    if (row >= 0 && row < 3) {
        return handle.axisValid[row] ? QString::number(handle.axis[row]) : QStringLiteral("--");
    }
    const int button = row - 3;
    if (button >= 0 && button < 4) {
        return handle.buttonValid[button] ? (handle.button[button] ? QStringLiteral("1") : QStringLiteral("0")) : QStringLiteral("--");
    }
    return QStringLiteral("--");
}

double inputDouble(const QLineEdit *edit) {
    if (!edit) {
        return 0.0;
    }
    bool ok = false;
    const double value = edit->text().trimmed().toDouble(&ok);
    return ok ? value : 0.0;
}

qint16 metersToSignedMillimeters(double meters, bool *ok = nullptr) {
    const qint64 mm = qRound64(meters * 1000.0);
    const bool inRange = mm >= -32768 && mm <= 32767;
    if (ok) {
        *ok = inRange;
    }
    return static_cast<qint16>(qBound<qint64>(qint64(-32768), mm, qint64(32767)));
}

using PointEditRows = QVector<std::array<QPointer<QLineEdit>, 3>>;

double pointEditMeters(const PointEditRows &edits, int row, int axis) {
    if (row < 0 || row >= edits.size() || axis < 0 || axis >= 3 || !edits.at(row).at(axis)) {
        return 0.0;
    }
    return inputDouble(edits.at(row).at(axis));
}

constexpr int kMechanicalSampleMaxRows = 20;
constexpr int kMechanicalSampleColumnCount = 8;

int safeMechanicalSampleArmIndex(int armIndex) {
    return qBound(0, armIndex, 2);
}

QString legacyMechanicalSampleSettingsGroup() {
    return QStringLiteral("calibration/mechanicalSamples");
}

QString mechanicalSampleSettingsGroup(int armIndex) {
    const QStringList armKeys{
        QStringLiteral("left"),
        QStringLiteral("middle"),
        QStringLiteral("right")
    };
    return QStringLiteral("calibration/mechanicalSamples/%1")
        .arg(armKeys.value(safeMechanicalSampleArmIndex(armIndex)));
}

void setCenteredTableText(QTableWidget *table, int row, int column, const QString &text) {
    if (!table || row < 0 || column < 0) {
        return;
    }
    auto *item = new QTableWidgetItem(text);
    item->setTextAlignment(Qt::AlignCenter);
    table->setItem(row, column, item);
}

double tableCellDouble(const QTableWidget *table, int row, int column) {
    if (!table) {
        return 0.0;
    }
    const QTableWidgetItem *item = table->item(row, column);
    if (!item) {
        return 0.0;
    }
    bool ok = false;
    const double value = item->text().trimmed().toDouble(&ok);
    return ok ? value : 0.0;
}

void refreshMechanicalSampleError(QTableWidget *table, int row) {
    if (!table || row < 0 || row >= table->rowCount()) {
        return;
    }
    const double errorMm = qSqrt(qPow(tableCellDouble(table, row, 4) - tableCellDouble(table, row, 1), 2)
                               + qPow(tableCellDouble(table, row, 5) - tableCellDouble(table, row, 2), 2)
                               + qPow(tableCellDouble(table, row, 6) - tableCellDouble(table, row, 3), 2)) * 1000.0;
    if (QTableWidgetItem *errorItem = table->item(row, 7)) {
        errorItem->setText(QString::number(errorMm, 'f', 1));
    } else {
        setCenteredTableText(table, row, 7, QString::number(errorMm, 'f', 1));
    }
}

void renumberMechanicalSamples(QTableWidget *table) {
    if (!table) {
        return;
    }
    for (int row = 0; row < table->rowCount(); ++row) {
        if (QTableWidgetItem *item = table->item(row, 0)) {
            item->setText(QString::number(row + 1));
            item->setTextAlignment(Qt::AlignCenter);
        } else {
            setCenteredTableText(table, row, 0, QString::number(row + 1));
        }
        refreshMechanicalSampleError(table, row);
    }
    table->setProperty("sampleCount", table->rowCount());
}

void updateMechanicalSampleStatus(QLabel *status, int count, const QString &extra = QString(), const QString &armName = QString()) {
    if (!status) {
        return;
    }
    const QString state = count >= kMechanicalSampleMaxRows
        ? u("允许拟合")
        : (count > 0 ? u("继续采集") : u("补偿拟合未开放"));
    const QString message = extra.isEmpty()
        ? u("有效样本 %1/20，%2").arg(count).arg(state)
        : u("有效样本 %1/20，%2，%3").arg(count).arg(state).arg(extra);
    status->setText(armName.isEmpty() ? message : u("%1：%2").arg(armName, message));
}

void saveMechanicalSamples(QTableWidget *table, int armIndex) {
    if (!table) {
        return;
    }
    const int safeArmIndex = safeMechanicalSampleArmIndex(armIndex);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    settings.beginGroup(mechanicalSampleSettingsGroup(safeArmIndex));
    settings.remove(QString());
    const int rowCount = qMin(table->rowCount(), kMechanicalSampleMaxRows);
    settings.setValue(QStringLiteral("rowCount"), rowCount);
    for (int row = 0; row < rowCount; ++row) {
        for (int column = 0; column < kMechanicalSampleColumnCount; ++column) {
            const QTableWidgetItem *item = table->item(row, column);
            settings.setValue(QStringLiteral("row%1/column%2").arg(row).arg(column),
                              item ? item->text() : QString());
        }
    }
    settings.endGroup();
    settings.sync();
    table->setProperty("sampleArmIndex", safeArmIndex);
}

int loadMechanicalSamples(QTableWidget *table, int armIndex) {
    if (!table) {
        return 0;
    }
    const int safeArmIndex = safeMechanicalSampleArmIndex(armIndex);
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    const QString armGroup = mechanicalSampleSettingsGroup(safeArmIndex);
    const QString legacyGroup = legacyMechanicalSampleSettingsGroup();
    const bool migrateLegacyLeftSamples = safeArmIndex == 0
        && !settings.contains(armGroup + QStringLiteral("/rowCount"))
        && settings.contains(legacyGroup + QStringLiteral("/rowCount"));
    settings.beginGroup(migrateLegacyLeftSamples ? legacyGroup : armGroup);
    const int rowCount = qBound(0, settings.value(QStringLiteral("rowCount"), 0).toInt(), kMechanicalSampleMaxRows);
    table->setRowCount(0);
    for (int row = 0; row < rowCount; ++row) {
        table->insertRow(row);
        for (int column = 0; column < kMechanicalSampleColumnCount; ++column) {
            QString text = settings.value(QStringLiteral("row%1/column%2").arg(row).arg(column)).toString();
            if (column == 0 && text.trimmed().isEmpty()) {
                text = QString::number(row + 1);
            }
            setCenteredTableText(table, row, column, text);
        }
        refreshMechanicalSampleError(table, row);
    }
    settings.endGroup();
    table->setProperty("sampleCount", rowCount);
    table->setProperty("sampleArmIndex", safeArmIndex);
    if (migrateLegacyLeftSamples) {
        saveMechanicalSamples(table, safeArmIndex);
    }
    return rowCount;
}

quint8 inputU8(const QLineEdit *edit) {
    return static_cast<quint8>(qBound(0, qRound(inputDouble(edit)), 255));
}

quint16 inputMetersToMm(const QLineEdit *edit) {
    return static_cast<quint16>(qBound(0, qRound(inputDouble(edit) * 1000.0), 65535));
}

bool looksTouchNumberText(const QString &text) {
    const QString value = text.trimmed();
    if (value.isEmpty()) {
        return true;
    }
    bool hasDigit = false;
    for (const QChar ch : value) {
        if (ch.isDigit()) {
            hasDigit = true;
            continue;
        }
        if (ch == QLatin1Char('.') || ch == QLatin1Char('-') || ch == QLatin1Char('+') || ch.isSpace()) {
            continue;
        }
        return false;
    }
    return hasDigit;
}

bool isTouchNumberEdit(const QLineEdit *edit) {
    if (!edit || edit->isReadOnly()) {
        return false;
    }
    if (edit->property("touchNumberPad").toBool()) {
        return true;
    }
    const QString className = edit->property("class").toString();
    if (className == QStringLiteral("drillModeInput") || className == QStringLiteral("panelValueInput")) {
        return true;
    }
    if (className != QStringLiteral("sitonValueInput")) {
        return false;
    }
    const QString text = edit->text();
    if (text.contains(QLatin1Char('\\')) || text.contains(QLatin1Char('/')) || text.contains(QLatin1Char(':'))) {
        return false;
    }
    return looksTouchNumberText(text);
}

struct LogEntry {
    QString date;
    QString content;
};

QString localLogDirectory() {
    QString base = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (base.isEmpty()) {
        base = QDir::homePath() + QStringLiteral("/.qdn-upper-computer-ui");
    }
    const QString dir = QDir(base).filePath(QStringLiteral("logs"));
    QDir().mkpath(dir);
    return dir;
}

QString localLogFilePath(const QString &kind) {
    const QString fileName = kind == QStringLiteral("sensor")
        ? QStringLiteral("sensor-monitor.log")
        : QStringLiteral("operation.log");
    return QDir(localLogDirectory()).filePath(fileName);
}

QString localAlarmHistoryFilePath() {
    return QDir(localLogDirectory()).filePath(QStringLiteral("alarm-history.log"));
}

QString sanitizedLogText(QString text) {
    text.replace(QLatin1Char('\t'), QLatin1Char(' '));
    text.replace(QLatin1Char('\r'), QLatin1Char(' '));
    text.replace(QLatin1Char('\n'), QLatin1Char(' '));
    return text.trimmed();
}

QString workerVisibleText(QString text) {
    text = sanitizedLogText(text);
    text.replace(QStringLiteral("CAN_TO_NET"), u("通讯模块"));
    text.replace(QStringLiteral("CAN-NET"), u("通讯模块"));
    text.replace(u("以太网转CAN模块"), u("通讯模块"));
    text.replace(u("CAN模块"), u("通讯模块"));
    text.replace(u("控制器数据"), u("设备数据"));
    text.replace(QRegularExpression(QStringLiteral("\\bRX\\s+0[xX][0-9A-Fa-f]+\\s*")), u("收到"));
    text.replace(QRegularExpression(QStringLiteral("\\bTX\\s+0[xX][0-9A-Fa-f]+\\s*")), u("下发"));
    text.replace(QRegularExpression(QStringLiteral("\\b0[xX][0-9A-Fa-f]+(?:/[A-Za-z0-9.\\-]+)?\\b")), u("设备信号"));
    text.replace(QRegularExpression(QStringLiteral("\\bDLC\\d+\\s+DATA\\s+[0-9A-Fa-f ]+")), QString());
    text.replace(QStringLiteral("CAN"), u("通讯"));
    text.replace(u("协议"), QString());
    text.replace(u("帧"), u("数据"));
    text.replace(QRegularExpression(QStringLiteral("\\s+")), QStringLiteral(" "));
    return text.trimmed();
}

QString calibrationObjectText(quint8 object, quint8 businessFlag) {
    switch (businessFlag) {
    case 0xa1:
        return u("机械位置");
    case 0xa2:
        return u("H点样本");
    case 0xa3:
        return u("现场位姿");
    default:
        break;
    }

    switch (object) {
    case 0:
        return u("整机");
    case 1:
        return u("左臂");
    case 2:
        return u("中臂");
    case 3:
        return u("右臂");
    default:
        return u("对象%1").arg(static_cast<int>(object));
    }
}

QString calibrationStatusText(quint8 status) {
    switch (status) {
    case 0:
        return u("等待");
    case 1:
        return u("处理中");
    case 2:
        return u("已接收");
    case 3:
        return u("已完成");
    case 4:
        return u("失败");
    default:
        return u("状态%1").arg(static_cast<int>(status));
    }
}

QString calibrationErrorText(quint8 errorCode) {
    switch (errorCode) {
    case 0:
        return u("无异常");
    case 1:
        return u("数据不足");
    case 2:
        return u("计算失败");
    case 3:
        return u("误差过大");
    case 4:
        return u("未准备");
    default:
        return u("异常%1").arg(static_cast<int>(errorCode));
    }
}

void trimLogFileIfNeeded(const QString &path) {
    QFile file(path);
    if (!file.exists() || file.size() <= 1024 * 1024) {
        return;
    }
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return;
    }
    QTextStream in(&file);
    in.setEncoding(QStringConverter::Utf8);
    QStringList lines;
    while (!in.atEnd()) {
        lines.append(in.readLine());
    }
    file.close();
    while (lines.size() > 4000) {
        lines.removeFirst();
    }
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        return;
    }
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    for (const QString &line : lines) {
        out << line << '\n';
    }
}

void appendLocalLog(const QString &kind, const QString &content) {
    const QString path = localLogFilePath(kind);
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return;
    }
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    const QDateTime now = QDateTime::currentDateTime();
    out << now.date().toString(QStringLiteral("yyyy-MM-dd"))
        << '\t'
        << now.time().toString(QStringLiteral("HH:mm:ss  "))
        << workerVisibleText(content)
        << '\n';
    file.close();
    trimLogFileIfNeeded(path);
}

QVector<LogEntry> readLocalLogs(const QString &kind, const QVector<LogEntry> &fallback) {
    QVector<LogEntry> rows;
    QFile file(localLogFilePath(kind));
    const bool exists = file.exists();
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        in.setEncoding(QStringConverter::Utf8);
        QStringList keptLines;
        while (!in.atEnd()) {
            const QString line = in.readLine();
            const int split = line.indexOf(QLatin1Char('\t'));
            if (split <= 0) {
                continue;
            }
            keptLines.append(line);
            while (keptLines.size() > 300) {
                keptLines.removeFirst();
            }
        }
        rows.reserve(keptLines.size());
        for (const QString &line : keptLines) {
            const int split = line.indexOf(QLatin1Char('\t'));
            rows.push_back({line.left(split), workerVisibleText(line.mid(split + 1))});
        }
    }
    if (!rows.isEmpty()) {
        return rows;
    }
    return exists ? rows : fallback;
}

QString csvCell(QString value) {
    value.replace(QLatin1Char('"'), QStringLiteral("\"\""));
    return QLatin1Char('"') + value + QLatin1Char('"');
}

QString exportLocalLogs(const QString &kind, const QVector<LogEntry> &entries) {
    const QString exportDir = QDir(localLogDirectory()).filePath(QStringLiteral("exports"));
    QDir().mkpath(exportDir);
    const QString stamp = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss"));
    const QString path = QDir(exportDir).filePath(QStringLiteral("%1-%2.csv").arg(kind, stamp));

    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        return QString();
    }
    file.write("\xEF\xBB\xBF");
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out << csvCell(u("日志日期")) << ',' << csvCell(u("日志内容")) << '\n';
    for (const LogEntry &entry : entries) {
        out << csvCell(entry.date) << ',' << csvCell(workerVisibleText(entry.content)) << '\n';
    }
    return path;
}

QString exportCsvRows(const QString &prefix, const QStringList &headers, const QVector<QStringList> &rows) {
    const QString exportDir = QDir(localLogDirectory()).filePath(QStringLiteral("exports"));
    QDir().mkpath(exportDir);
    const QString stamp = QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss"));
    const QString path = QDir(exportDir).filePath(QStringLiteral("%1-%2.csv").arg(prefix, stamp));

    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
        return QString();
    }
    file.write("\xEF\xBB\xBF");
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    for (int col = 0; col < headers.size(); ++col) {
        if (col > 0) {
            out << ',';
        }
        out << csvCell(headers.at(col));
    }
    out << '\n';
    for (const QStringList &row : rows) {
        for (int col = 0; col < headers.size(); ++col) {
            if (col > 0) {
                out << ',';
            }
            out << csvCell(row.value(col));
        }
        out << '\n';
    }
    return path;
}

bool clearLocalLog(const QString &kind) {
    QFile file(localLogFilePath(kind));
    return file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text);
}

QStringList alarmRowForActiveAlarm(const QString &alarm, const QString &raiseTime, const QString &clearTime = QString()) {
    if (alarm == u("CAN_TO_NET未连接")) {
        return {raiseTime, clearTime, u("通讯模块"), u("通讯模块未连接，无法接收设备数据")};
    }
    if (alarm == u("算法PCB掉线")) {
        return {raiseTime, clearTime, u("主控计算"), u("主控计算通讯中断")};
    }
    if (alarm == u("倾角仪掉线")) {
        return {raiseTime, clearTime, u("水平仪"), u("水平仪通讯中断")};
    }
    if (alarm.contains(u("润滑压力低"))) {
        return {raiseTime, clearTime, u("润滑压力"), workerVisibleText(alarm)};
    }
    if (alarm.contains(u("急停"))) {
        return {raiseTime, clearTime, u("急停"), workerVisibleText(alarm)};
    }
    if (alarm.contains(u("手柄掉线")) || alarm.contains(u("按键板掉线"))) {
        return {raiseTime, clearTime, u("操作手柄"), workerVisibleText(alarm)};
    }
    if (alarm.contains(u("编码器掉线"))) {
        return {raiseTime, clearTime, u("位置传感"), workerVisibleText(alarm)};
    }
    return {raiseTime, clearTime, u("设备通讯"), workerVisibleText(alarm)};
}

bool isTiltOrCollisionAlarmRow(const QStringList &row) {
    const QString text = row.join(QLatin1Char(' '));
    return text.contains(u("倾角")) || text.contains(u("倾斜")) || text.contains(u("碰撞")) || text.contains(u("姿态"));
}

void appendLocalAlarmHistoryRow(const QStringList &row) {
    if (row.size() < 4) {
        return;
    }
    QFile file(localAlarmHistoryFilePath());
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return;
    }
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out << sanitizedLogText(row.value(0)) << '\t'
        << sanitizedLogText(row.value(1)) << '\t'
        << workerVisibleText(row.value(2)) << '\t'
        << workerVisibleText(row.value(3)) << '\n';
    file.close();
    trimLogFileIfNeeded(localAlarmHistoryFilePath());
}

QVector<QStringList> readLocalAlarmHistoryRows() {
    QVector<QStringList> rows;
    QFile file(localAlarmHistoryFilePath());
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return rows;
    }

    QTextStream in(&file);
    in.setEncoding(QStringConverter::Utf8);
    while (!in.atEnd()) {
        const QStringList parts = in.readLine().split(QLatin1Char('\t'));
        if (parts.size() < 4) {
            continue;
        }
        rows.prepend({parts.value(0), parts.value(1), workerVisibleText(parts.value(2)), workerVisibleText(parts.value(3))});
    }
    while (rows.size() > 300) {
        rows.removeLast();
    }
    return rows;
}

QString canFrameText(const QString &prefix, const CanFrame &frame) {
    QStringList bytes;
    const int count = qBound(0, static_cast<int>(frame.dlc), 8);
    bytes.reserve(count);
    for (int i = 0; i < count; ++i) {
        bytes.append(QStringLiteral("%1").arg(frame.data.at(static_cast<size_t>(i)), 2, 16, QLatin1Char('0')).toUpper());
    }
    return QStringLiteral("%1 0x%2 DLC%3 DATA %4")
        .arg(prefix)
        .arg(frame.id, frame.id <= 0x7ff ? 3 : 8, 16, QLatin1Char('0'))
        .arg(count)
        .arg(bytes.join(QLatin1Char(' ')))
        .toUpper();
}

void showMaintenanceOverlay(QWidget *parent, const QString &message, std::function<void()> onAccepted = {}) {
    QWidget *window = parent ? parent->window() : QApplication::activeWindow();
    if (!window) {
        return;
    }
    auto *overlay = new QWidget(window);
    overlay->setAttribute(Qt::WA_StyledBackground, true);
    overlay->setStyleSheet(QStringLiteral("background: rgba(0, 0, 0, 165);"));
    overlay->setGeometry(window->rect());

    auto *panel = new QFrame(overlay);
    panel->setObjectName(QStringLiteral("maintenancePanel"));
    panel->setFixedSize(440, 168);
    panel->move((overlay->width() - panel->width()) / 2, (overlay->height() - panel->height()) / 2);
    panel->setStyleSheet(QStringLiteral(R"(
        QFrame#maintenancePanel {
            background: #5c5c5c;
            border: 1px solid #5c5c5c;
            border-radius: 4px;
        }
        QWidget {
            background: transparent;
            border: none;
        }
        QLabel[class="maintenanceTitle"] {
            color: #ffffff;
            background: transparent;
            border: none;
            font-family: "Microsoft YaHei UI";
            font-size: 15px;
            font-weight: 800;
        }
        QLabel[class="maintenanceText"] {
            color: #ffffff;
            background: transparent;
            border: none;
            font-family: "Microsoft YaHei UI";
            font-size: 14px;
            font-weight: 650;
        }
        QLabel[class="maintenanceWarn"] {
            color: #111111;
            background: #f2ad38;
            border: none;
            border-radius: 11px;
            font-family: "Microsoft YaHei UI";
            font-size: 17px;
            font-weight: 900;
        }
        QPushButton[class="maintenanceClose"] {
            color: #c8c8c8;
            background: transparent;
            border: none;
            font-family: "Microsoft YaHei UI";
            font-size: 22px;
        }
        QPushButton[class="maintenanceAction"] {
            color: #ffffff;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 4px;
            font-family: "Microsoft YaHei UI";
            font-size: 13px;
            font-weight: 700;
        }
        QPushButton[class="maintenanceAction"][primary="true"] {
            color: #00c8ef;
        }
    )"));

    auto *root = new QVBoxLayout(panel);
    root->setContentsMargins(26, 18, 18, 16);
    root->setSpacing(8);

    auto *top = new QWidget(panel);
    top->setProperty("class", "transparent");
    auto *topLayout = new QHBoxLayout(top);
    topLayout->setContentsMargins(0, 0, 0, 0);
    topLayout->addWidget(plainLabel(u("维保提示"), QStringLiteral("maintenanceTitle")));
    topLayout->addStretch();
    auto *close = new QPushButton(QStringLiteral("×"));
    close->setProperty("class", "maintenanceClose");
    close->setFixedSize(28, 28);
    topLayout->addWidget(close);
    root->addWidget(top);

    auto *body = new QWidget(panel);
    body->setProperty("class", "transparent");
    auto *bodyLayout = new QHBoxLayout(body);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(16);
    auto *warn = plainLabel(QStringLiteral("!"), QStringLiteral("maintenanceWarn"));
    warn->setAlignment(Qt::AlignCenter);
    warn->setFixedSize(22, 22);
    bodyLayout->addWidget(warn, 0, Qt::AlignTop);
    auto *text = plainLabel(message, QStringLiteral("maintenanceText"));
    text->setWordWrap(true);
    bodyLayout->addWidget(text, 1);
    root->addWidget(body, 1);

    auto *actions = new QWidget(panel);
    actions->setProperty("class", "transparent");
    auto *actionLayout = new QHBoxLayout(actions);
    actionLayout->setContentsMargins(0, 0, 4, 0);
    actionLayout->addStretch();
    auto *ok = new QPushButton(u("确定"));
    ok->setProperty("class", "maintenanceAction");
    ok->setProperty("primary", true);
    ok->setFixedSize(78, 34);
    auto *cancel = new QPushButton(u("取消"));
    cancel->setProperty("class", "maintenanceAction");
    cancel->setFixedSize(78, 34);
    actionLayout->addWidget(ok);
    actionLayout->addSpacing(10);
    actionLayout->addWidget(cancel);
    root->addWidget(actions);

    QObject::connect(close, &QPushButton::clicked, overlay, &QWidget::deleteLater);
    QObject::connect(cancel, &QPushButton::clicked, overlay, &QWidget::deleteLater);
    QObject::connect(ok, &QPushButton::clicked, overlay, [overlay, onAccepted] {
        overlay->deleteLater();
        if (onAccepted) {
            onAccepted();
        }
    });
    overlay->show();
    overlay->raise();
}

void showMaintenancePasswordOverlay(QWidget *parent, const QString &message, std::function<void()> onAccepted = {}) {
    QWidget *window = parent ? parent->window() : QApplication::activeWindow();
    if (!window) {
        return;
    }
    auto *overlay = new QWidget(window);
    overlay->setAttribute(Qt::WA_StyledBackground, true);
    overlay->setStyleSheet(QStringLiteral("background: rgba(0, 0, 0, 165);"));
    overlay->setGeometry(window->rect());

    auto *panel = new QFrame(overlay);
    panel->setObjectName(QStringLiteral("maintenancePanel"));
    panel->setFixedSize(408, 158);
    panel->move((overlay->width() - panel->width()) / 2, (overlay->height() - panel->height()) / 2);
    panel->setStyleSheet(QStringLiteral(R"(
        QFrame#maintenancePanel {
            background: #5c5c5c;
            border: 1px solid #5c5c5c;
            border-radius: 4px;
        }
        QWidget {
            background: transparent;
            border: none;
        }
        QLabel[class="maintenanceTitle"], QLabel[class="maintenanceText"] {
            color: #ffffff;
            background: transparent;
            border: none;
            font-family: "Microsoft YaHei UI";
            font-size: 15px;
            font-weight: 800;
        }
        QLabel[class="maintenanceWarn"] {
            color: #111111;
            background: #ffff2c;
            border: none;
            border-radius: 8px;
            font-family: "Microsoft YaHei UI";
            font-size: 12px;
            font-weight: 900;
        }
        QLineEdit[class="maintenancePassword"] {
            color: #ffffff;
            background: #050505;
            border: 2px solid #050505;
            border-radius: 4px;
            padding: 4px 10px;
            font-family: Consolas;
            font-size: 15px;
            font-weight: 800;
        }
        QPushButton[class="maintenanceAction"] {
            color: #ffffff;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 4px;
            font-family: "Microsoft YaHei UI";
            font-size: 13px;
            font-weight: 700;
        }
        QPushButton[class="maintenanceAction"][primary="true"] {
            color: #00c8ef;
        }
    )"));

    auto *root = new QVBoxLayout(panel);
    root->setContentsMargins(18, 18, 18, 12);
    root->setSpacing(8);
    root->addWidget(plainLabel(u("维保提示"), QStringLiteral("maintenanceTitle")));

    auto *messageRow = new QWidget(panel);
    messageRow->setProperty("class", "transparent");
    auto *messageLayout = new QHBoxLayout(messageRow);
    messageLayout->setContentsMargins(0, 0, 0, 0);
    messageLayout->setSpacing(8);
    auto *warn = plainLabel(QStringLiteral("!"), QStringLiteral("maintenanceWarn"));
    warn->setAlignment(Qt::AlignCenter);
    warn->setFixedSize(16, 16);
    messageLayout->addWidget(warn);
    messageLayout->addWidget(plainLabel(message, QStringLiteral("maintenanceText")), 1);
    root->addWidget(messageRow);

    auto *password = new QLineEdit(panel);
    password->setProperty("class", "maintenancePassword");
    password->setEchoMode(QLineEdit::Password);
    password->setFixedHeight(34);
    root->addWidget(password);

    auto *actions = new QWidget(panel);
    actions->setProperty("class", "transparent");
    auto *actionLayout = new QHBoxLayout(actions);
    actionLayout->setContentsMargins(0, 0, 0, 0);
    actionLayout->addStretch();
    auto *ok = new QPushButton(u("确定"));
    ok->setProperty("class", "maintenanceAction");
    ok->setProperty("primary", true);
    ok->setFixedSize(78, 34);
    auto *cancel = new QPushButton(u("取消"));
    cancel->setProperty("class", "maintenanceAction");
    cancel->setFixedSize(78, 34);
    actionLayout->addWidget(ok);
    actionLayout->addSpacing(10);
    actionLayout->addWidget(cancel);
    root->addWidget(actions);

    QObject::connect(cancel, &QPushButton::clicked, overlay, &QWidget::deleteLater);
    QObject::connect(ok, &QPushButton::clicked, overlay, [overlay, onAccepted] {
        overlay->deleteLater();
        if (onAccepted) {
            onAccepted();
        }
    });
    QObject::connect(password, &QLineEdit::returnPressed, ok, &QPushButton::click);
    overlay->show();
    overlay->raise();
    password->setFocus();
}

class LockCircleIcon final : public QWidget {
public:
    explicit LockCircleIcon(QWidget *parent = nullptr) : QWidget(parent) {
        setAttribute(Qt::WA_TranslucentBackground, true);
        setAutoFillBackground(false);
        setFixedSize(42, 42);
        setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.setPen(Qt::NoPen);
        p.setBrush(QColor("#050505"));
        p.drawEllipse(rect().adjusted(1, 1, -1, -1));

        QPen pen(QColor("#d8d8d8"), 2.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawRoundedRect(QRectF(15, 21, 12, 9), 1.5, 1.5);
        p.drawArc(QRectF(17, 13, 8, 12), 0, 180 * 16);
        p.drawLine(QPointF(17, 19), QPointF(17, 22));
        p.drawLine(QPointF(25, 19), QPointF(25, 22));
    }
};

class LevelGaugeWidget final : public QWidget {
public:
    explicit LevelGaugeWidget(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumSize(300, 220);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.fillRect(rect(), QColor("#050505"));

        const QRectF area = rect().adjusted(18, 18, -18, -18);
        const QPointF center = area.center();
        const double radius = qMin(area.width(), area.height()) * 0.38;
        const QColor axis("#adc0bd");
        const QColor dim("#2b3332");
        const QColor accent("#45e075");
        const QColor text("#f2f2f2");

        p.setPen(QPen(dim, 1.2));
        for (int i = -2; i <= 2; ++i) {
            const double dx = radius * i / 2.0;
            p.drawLine(QPointF(center.x() + dx, center.y() - radius),
                       QPointF(center.x() + dx, center.y() + radius));
            p.drawLine(QPointF(center.x() - radius, center.y() + dx),
                       QPointF(center.x() + radius, center.y() + dx));
        }

        p.setPen(QPen(axis, 2.0));
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(center, radius, radius);
        p.drawEllipse(center, radius * 0.55, radius * 0.55);
        p.drawLine(QPointF(center.x() - radius, center.y()), QPointF(center.x() + radius, center.y()));
        p.drawLine(QPointF(center.x(), center.y() - radius), QPointF(center.x(), center.y() + radius));

        p.setPen(QPen(QColor("#f0d92d"), 2.0, Qt::DashLine));
        p.drawLine(QPointF(center.x() - radius * 0.18, center.y()), QPointF(center.x() + radius * 0.18, center.y()));
        p.drawLine(QPointF(center.x(), center.y() - radius * 0.18), QPointF(center.x(), center.y() + radius * 0.18));

        p.setPen(Qt::NoPen);
        p.setBrush(accent);
        p.drawEllipse(center, 14, 14);
        p.setBrush(Qt::NoBrush);
        p.setPen(QPen(accent, 3.0));
        p.drawEllipse(center, 23, 23);

        QFont titleFont(QStringLiteral("Microsoft YaHei UI"), 16, QFont::Bold);
        p.setFont(titleFont);
        p.setPen(QColor("#20c8ee"));
        p.drawText(QRectF(area.left(), area.top(), area.width(), 30), Qt::AlignLeft | Qt::AlignVCenter, u("水平仪"));

    }
};

class SitonMainView final : public QWidget {
public:
    explicit SitonMainView(QWidget *parent = nullptr) : QWidget(parent) {
        setMinimumSize(1024, 560);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }

protected:
    void paintEvent(QPaintEvent *) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing, true);
        p.fillRect(rect(), QColor("#000000"));

        const QRectF canvas = rect().adjusted(8, 8, -8, -8);
        const double bodyW = qMin(canvas.width(), 1540.0);
        const double bodyH = qMin(canvas.height() - 8, 1000.0);
        const QRectF r(canvas.left() + (canvas.width() - bodyW) / 2.0, canvas.top(), bodyW, bodyH);
        const double bottomBarH = 38.0;
        const double bottomGap = 8.0;
        const QColor panel("#555555");
        const QColor panelDark("#020202");
        const QColor line("#0a0a0a");
        const QColor active("#17bde8");
        const QColor text("#e8e8ef");
        const QFont labelFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::Bold);
        const QFont smallFont(QStringLiteral("Microsoft YaHei UI"), 8, QFont::Bold);

        auto drawPanel = [&](const QRectF &box) {
            p.setPen(QPen(line, 1.4));
            p.setBrush(panel);
            p.drawRect(box);
        };
        auto drawTab = [&](const QRectF &box, const QString &label, bool selected) {
            p.setPen(QPen(QColor("#050505"), 1.4));
            p.setBrush(selected ? QColor("#050505") : QColor("#808080"));
            p.drawRoundedRect(box, 4, 4);
            p.setPen(selected ? QColor("#10d9ff") : QColor("#f2f2f2"));
            p.setFont(labelFont);
            p.drawText(box, Qt::AlignCenter, label);
        };
        auto drawVerticalButton = [&](const QRectF &box, const QString &label, bool selected) {
            p.setPen(QPen(QColor("#211b2f"), 1.0));
            p.setBrush(selected ? QColor("#10141d") : QColor("#746b86"));
            p.drawRoundedRect(box, 4, 4);
            p.setPen(selected ? active : QColor("#f1eef8"));
            p.setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 13, QFont::Bold));
            p.drawText(box, Qt::AlignCenter, label);
        };

        const double railW = qMax(58.0, r.width() * 0.045);
        const double mainH = r.height() - bottomBarH - bottomGap;
        const QRectF rail(r.left(), r.top(), railW, mainH);
        p.setPen(QPen(QColor("#171323"), 1.0));
        p.setBrush(QColor("#241f35"));
        p.drawRect(rail);
        const double armButtonGap = 10.0;
        const double armButtonH = (mainH - armButtonGap * 2.0) / 3.0;
        drawVerticalButton(QRectF(rail.left() + 7, rail.top(), rail.width() - 14, armButtonH), u("左\n臂"), true);
        drawVerticalButton(QRectF(rail.left() + 7, rail.top() + armButtonH + armButtonGap, rail.width() - 14, armButtonH), u("中\n臂"), false);
        drawVerticalButton(QRectF(rail.left() + 7, rail.top() + (armButtonH + armButtonGap) * 2.0, rail.width() - 14, armButtonH), u("右\n臂"), false);

        const QRectF content(r.left() + railW + 8, r.top(), r.width() - railW - 8, mainH);
        const double leftW = qBound(430.0, content.width() * 0.34, 500.0);
        const QRectF leftPanel(content.left(), content.top(), leftW, content.height());
        const QRectF rightPanel(leftPanel.right() + 8, content.top(), content.width() - leftW - 8, content.height());
        drawPanel(leftPanel);
        drawPanel(rightPanel);

        const double tabH = 34;
        drawTab(QRectF(leftPanel.left() + 10, leftPanel.top() + 8, 94, tabH), u("电脑监控"), true);
        drawTab(QRectF(leftPanel.left() + 104, leftPanel.top() + 8, 94, tabH), u("机械参数"), false);
        drawTab(QRectF(leftPanel.left() + 198, leftPanel.top() + 8, 94, tabH), u("钻机状态"), false);

        const QRectF table(leftPanel.left() + 14, leftPanel.top() + 52, leftPanel.width() - 28, leftPanel.height() * 0.34);
        p.setPen(QPen(QColor("#181224"), 1.0));
        p.setBrush(QColor("#191326"));
        p.drawRect(table);
        p.setFont(smallFont);
        p.setPen(text);
        const QStringList headers{u("项目"), u("左臂"), u("中臂"), u("右臂"), u("单位")};
        const int colCount = headers.size();
        for (int c = 0; c < colCount; ++c) {
            const QRectF cell(table.left() + table.width() * c / colCount, table.top() + 4,
                              table.width() / colCount, 18);
            p.drawText(cell, Qt::AlignCenter, headers.at(c));
        }
        const QList<QStringList> rows{
            {u("冲击压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("推进压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("回转压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("钻进速度"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("m/min")},
            {u("定位泵压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("润滑压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("泵后水压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("水流量"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("l/min")},
            {u("气压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")},
            {u("缓冲压力"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("0"), QStringLiteral("bar")}
        };
        const double rowH = (table.height() - 28) / rows.size();
        for (int i = 0; i < rows.size(); ++i) {
            const double y = table.top() + 26 + i * rowH;
            p.setPen(QPen(QColor("#2d2638"), 1.0));
            p.drawLine(QPointF(table.left(), y), QPointF(table.right(), y));
            p.setPen(text);
            for (int c = 0; c < colCount; ++c) {
                const QRectF cell(table.left() + table.width() * c / colCount, y,
                                  table.width() / colCount, rowH);
                p.drawText(cell.adjusted(2, 0, -2, 0), Qt::AlignCenter, rows.at(i).at(c));
            }
        }

        const QRectF bars(leftPanel.left() + 22, table.bottom() + 16, leftPanel.width() - 44, 74);
        const QList<QPair<QString, double>> barValues{
            {u("左臂  0.00"), 0.0},
            {u("中臂  0.00"), 0.0},
            {u("右臂  0.00"), 0.0}
        };
        p.setFont(smallFont);
        for (int i = 0; i < barValues.size(); ++i) {
            const double y = bars.top() + i * 24;
            p.setPen(text);
            p.drawText(QRectF(bars.left(), y, 66, 18), Qt::AlignLeft | Qt::AlignVCenter, barValues.at(i).first);
            const QRectF track(bars.left() + 82, y + 7, bars.width() - 124, 6);
            p.setPen(Qt::NoPen);
            p.setBrush(QColor("#51475e"));
            p.drawRoundedRect(track, 3, 3);
            p.setBrush(QColor("#19a7dd"));
            p.drawRoundedRect(QRectF(track.left(), track.top(), track.width() * barValues.at(i).second, track.height()), 3, 3);
            p.setPen(QColor("#cfc9db"));
            p.drawText(QRectF(track.right() + 8, y, 40, 18), Qt::AlignRight | Qt::AlignVCenter, QStringLiteral("2.50m"));
        }

        const QRectF arm(leftPanel.left() + 14, bars.bottom() + 12, leftPanel.width() - 28,
                         leftPanel.bottom() - bars.bottom() - 24);
        p.setPen(QPen(QColor("#050505"), 1.0));
        p.setBrush(QColor("#020202"));
        p.drawRect(arm);
        p.setPen(QPen(QColor("#a9b8b8"), 3.0));
        for (int i = 0; i < 4; ++i) {
            const double y = arm.top() + arm.height() * (0.22 + i * 0.18);
            p.drawLine(QPointF(arm.left(), y), QPointF(arm.left() + arm.width() * 0.34, y));
            p.drawLine(QPointF(arm.left() + arm.width() * 0.66, y), QPointF(arm.right(), y));
        }
        p.setBrush(QColor("#aebcbb"));
        p.setPen(Qt::NoPen);
        p.drawEllipse(QPointF(arm.left() + arm.width() * 0.44, arm.top() + arm.height() * 0.78), 26, 26);
        p.drawEllipse(QPointF(arm.left() + arm.width() * 0.94, arm.top() + arm.height() * 0.78), 18, 18);
        p.setPen(QPen(QColor("#4be872"), 4));
        p.setBrush(Qt::NoBrush);
        const QPointF cross(arm.left() + arm.width() * 0.50, arm.top() + arm.height() * 0.52);
        p.drawEllipse(cross, 18, 18);
        p.drawLine(QPointF(cross.x() - 9, cross.y() - 9), QPointF(cross.x() + 9, cross.y() + 9));
        p.drawLine(QPointF(cross.x() + 9, cross.y() - 9), QPointF(cross.x() - 9, cross.y() + 9));

        drawTab(QRectF(rightPanel.left() + rightPanel.width() - 420, rightPanel.top() + 8, 94, 30), u("主视图"), true);
        drawTab(QRectF(rightPanel.left() + rightPanel.width() - 326, rightPanel.top() + 8, 94, 30), u("俯视图"), false);
        drawTab(QRectF(rightPanel.left() + rightPanel.width() - 232, rightPanel.top() + 8, 94, 30), u("左视图"), false);
        drawTab(QRectF(rightPanel.left() + rightPanel.width() - 138, rightPanel.top() + 8, 94, 30), u("三维图"), false);

        const QRectF face(rightPanel.left() + 20, rightPanel.top() + 44, rightPanel.width() - 34, rightPanel.height() - 62);
        p.setPen(QPen(QColor("#2b2439"), 1.0));
        p.setBrush(panelDark);
        p.drawRect(face);
        p.setPen(QPen(QColor("#242424"), 1.0));
        for (int i = 1; i < 20; ++i) {
            const double x = face.left() + face.width() * i / 20.0;
            p.drawLine(QPointF(x, face.top()), QPointF(x, face.bottom()));
        }
        for (int i = 1; i < 14; ++i) {
            const double y = face.top() + face.height() * i / 14.0;
            p.drawLine(QPointF(face.left(), y), QPointF(face.right(), y));
        }
        p.setFont(smallFont);
        p.setPen(QColor("#f0edf5"));
        p.drawText(QRectF(face.left() + 12, face.top() + 8, 80, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.0°/"));
        p.setPen(QColor("#00dd55"));
        p.drawText(QRectF(face.left() + 55, face.top() + 8, 80, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.0°"));
        p.setPen(QColor("#f0edf5"));
        p.drawText(QRectF(face.left() + 12, face.top() + 28, 80, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.0°/"));
        p.setPen(QColor("#00dd55"));
        p.drawText(QRectF(face.left() + 55, face.top() + 28, 80, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.0°"));
        p.setPen(QColor("#f0edf5"));
        p.drawText(QRectF(face.left() + 12, face.top() + 48, 90, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.0m/"));
        p.setPen(QColor("#ff1c24"));
        p.drawText(QRectF(face.left() + 55, face.top() + 48, 80, 18), Qt::AlignLeft | Qt::AlignVCenter, QStringLiteral("0.00 m"));
        p.setPen(QColor("#e8e8e8"));
        p.drawText(QRectF(face.right() - 116, face.top() + 8, 100, 18), Qt::AlignLeft, u("☑ 已完成的孔"));
        p.drawText(QRectF(face.right() - 116, face.top() + 30, 100, 18), Qt::AlignLeft, u("☑ 未完成的孔"));

        const QPointF center(face.left() + face.width() * 0.56, face.bottom() - face.height() * 0.15);
        const double archW = face.width() * 0.72;
        const double archH = face.height() * 0.72;
        const double topY = center.y() - archH;
        p.setPen(QPen(QColor("#8b8799"), 2.0));
        p.setBrush(Qt::NoBrush);
        QPainterPath archPath;
        archPath.moveTo(center.x() - archW * 0.50, center.y());
        archPath.cubicTo(center.x() - archW * 0.48, center.y() - archH * 0.62,
                         center.x() - archW * 0.22, topY,
                         center.x(), topY);
        archPath.cubicTo(center.x() + archW * 0.22, topY,
                         center.x() + archW * 0.48, center.y() - archH * 0.62,
                         center.x() + archW * 0.50, center.y());
        p.drawPath(archPath);
        p.drawLine(QPointF(center.x() - archW * 0.50, center.y()), QPointF(center.x() + archW * 0.50, center.y()));

        p.setPen(Qt::NoPen);
        p.setBrush(QColor("#b5c4c2"));
        for (int i = 0; i <= 46; ++i) {
            const double theta = M_PI - M_PI * i / 46.0;
            const double x = center.x() + qCos(theta) * archW * 0.50;
            const double y = center.y() - qSin(theta) * archH;
            p.drawEllipse(QPointF(x, y), 3.8, 3.8);
        }
        for (int row = 0; row < 6; ++row) {
            const double y = topY + archH * (0.18 + row * 0.115);
            const double dy = (center.y() - y) / archH;
            const double half = archW * 0.50 * qSqrt(qMax(0.0, 1.0 - dy * dy));
            const int count = 6 + row;
            for (int i = 0; i < count; ++i) {
                const double x = center.x() - half * 0.82 + (half * 1.64) * i / qMax(1, count - 1);
                p.drawEllipse(QPointF(x, y), 4.1, 4.1);
            }
        }

        p.setPen(QPen(QColor("#aebcbb"), 2.3));
        for (int row = 0; row < 5; ++row) {
            const double y = face.top() + face.height() * (0.46 + row * 0.065);
            QPainterPath tunnelLine;
            tunnelLine.moveTo(center.x() - archW * 0.34, y + row * 2);
            tunnelLine.cubicTo(center.x() - archW * 0.12, y - 10, center.x() + archW * 0.08, y - 8,
                               center.x() + archW * 0.28, y - row * 1.5);
            p.drawPath(tunnelLine);
            p.setBrush(QColor("#b5c4c2"));
            p.setPen(Qt::NoPen);
            for (int i = 0; i < 6; ++i) {
                const double x = center.x() - archW * 0.30 + i * archW * 0.11;
                p.drawEllipse(QPointF(x, y - 2 + qSin(i) * 5), 3.6, 3.6);
            }
            p.setPen(QPen(QColor("#aebcbb"), 2.3));
        }
        for (int i = 0; i < 9; ++i) {
            const double x = center.x() - archW * 0.42 + i * archW * 0.105;
            const double y = center.y() + 18 + qSin(i * 0.8) * 8;
            p.drawLine(QPointF(x, y + 34), QPointF(x + 10, y));
            p.drawEllipse(QPointF(x + 10, y), 2.7, 2.7);
        }

        const QRectF leftBottom(content.left(), content.bottom() + bottomGap, content.width() * 0.50 - 4, bottomBarH);
        const QRectF rightBottom(leftBottom.right() + 8, content.bottom() + bottomGap, content.width() * 0.50 - 4, bottomBarH);
        p.setPen(QPen(QColor("#050505"), 1.4));
        p.setBrush(QColor("#555555"));
        p.drawRoundedRect(leftBottom, 6, 6);
        p.drawRoundedRect(rightBottom, 6, 6);
    }
};
}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), canClient_(this) {
    setWindowTitle(u("全电脑凿岩台车上位机"));
    setMinimumSize(1024, 600);
    resize(1180, 700);
    setCentralWidget(buildShell());
    setupPersistentInputs();
    QTimer::singleShot(0, this, [this] {
        ensurePageBuilt(6);
        ensurePageBuilt(1);
    });
    applyStyle();

    realtimeRefreshTimer_.setSingleShot(true);
    realtimeRefreshTimer_.setInterval(33);
    connect(&realtimeRefreshTimer_, &QTimer::timeout, this, &MainWindow::refreshRealtimeUi);

    connect(&timer_, &QTimer::timeout, this, &MainWindow::refreshClock);
    timer_.start(900);
    initCanToNet();
}

QWidget *MainWindow::buildShell() {
    auto *root = new QWidget;
    auto *mainLayout = new QVBoxLayout(root);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);
    mainLayout->addWidget(buildTopbar());

    pages_ = new QStackedWidget;
    for (int i = 0; i < static_cast<int>(pageSlots_.size()); ++i) {
        QWidget *page = nullptr;
        if (i == 0) {
            page = buildPageByIndex(i);
            pageBuilt_[static_cast<size_t>(i)] = true;
        } else {
            page = new QWidget;
            page->setProperty("class", "sitonPage");
            pageBuilt_[static_cast<size_t>(i)] = false;
        }
        pageSlots_[static_cast<size_t>(i)] = page;
        pages_->addWidget(page);
    }
    mainLayout->addWidget(pages_, 1);

    switchPage(0);
    return root;
}

QWidget *MainWindow::buildPageByIndex(int index) {
    switch (index) {
    case 0:
        return buildDashboardPage();
    case 1:
        return buildWorkfacePage();
    case 2:
        return buildSettingsHubPage();
    case 3:
        return buildAlarmsPage();
    case 4:
        return buildLogsPage();
    case 5:
        return buildSettingZeroPage();
    case 6:
        return buildSettingsPage();
    case 7:
        return buildDrillPresetPage();
    case 8:
        return buildRockProtectionPage();
    case 9:
        return buildCalibrationPage();
    case 10:
        return buildHoleMapEditPage();
    default:
        return new QWidget;
    }
}

void MainWindow::ensurePageBuilt(int index) {
    if (!pages_ || index < 0 || index >= static_cast<int>(pageBuilt_.size())) {
        return;
    }
    const size_t slot = static_cast<size_t>(index);
    if (pageBuilt_[slot]) {
        return;
    }

    QWidget *oldPage = pages_->widget(index);
    QElapsedTimer traceTimer;
    const bool traceBuild = qEnvironmentVariableIsSet("QDN_TRACE_PAGE_BUILD");
    if (traceBuild) {
        traceTimer.start();
    }
    QWidget *page = buildPageByIndex(index);
    if (page->objectName().isEmpty()) {
        page->setObjectName(QStringLiteral("main.page.%1").arg(index));
    }
    pages_->removeWidget(oldPage);
    if (oldPage) {
        oldPage->deleteLater();
    }
    pages_->insertWidget(index, page);
    pageSlots_[slot] = page;
    pageBuilt_[slot] = true;
    setupPersistentInputs();
    if (traceBuild) {
        std::fprintf(stdout, "TRACE page-build index=%d ms=%.3f\n",
                     index, double(traceTimer.nsecsElapsed()) / 1000000.0);
        std::fflush(stdout);
    }
}

QWidget *MainWindow::buildTopbar() {
    auto *bar = new QWidget;
    bar->setObjectName(QStringLiteral("topbar"));
    bar->setFixedHeight(48);
    topbar_ = bar;
    auto installDragHandle = [this](QWidget *widget) {
        if (!widget) {
            return;
        }
        widget->setProperty("windowDragHandle", true);
        widget->setCursor(Qt::OpenHandCursor);
        widget->installEventFilter(this);
    };
    installDragHandle(bar);
    auto *layout = new QHBoxLayout(bar);
    layout->setContentsMargins(6, 4, 18, 4);
    layout->setSpacing(4);

    auto makeTopIcon = [](const QString &kind) {
        QPixmap pixmap(24, 24);
        pixmap.fill(Qt::transparent);
        QPainter painter(&pixmap);
        painter.setRenderHint(QPainter::Antialiasing, true);
        const QColor color("#f2f2f2");
        painter.setPen(QPen(color, 2.2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.setBrush(Qt::NoBrush);
        const QRectF r(3, 3, 18, 18);
        if (kind == QStringLiteral("home")) {
            QPainterPath roof;
            roof.moveTo(4, 12);
            roof.lineTo(12, 5);
            roof.lineTo(20, 12);
            painter.drawPath(roof);
            painter.drawRect(QRectF(7, 12, 10, 8));
            painter.drawLine(QPointF(11, 20), QPointF(11, 15));
        } else if (kind == QStringLiteral("data")) {
            painter.setBrush(QColor("#10c8ef"));
            painter.setPen(Qt::NoPen);
            painter.drawRect(QRectF(5, 13, 3, 7));
            painter.drawRect(QRectF(11, 7, 3, 13));
            painter.drawRect(QRectF(17, 10, 3, 10));
        } else if (kind == QStringLiteral("alarm")) {
            painter.setBrush(color);
            painter.setPen(Qt::NoPen);
            painter.drawEllipse(r.adjusted(1, 1, -1, -1));
            painter.setPen(QPen(QColor("#545454"), 2.0, Qt::SolidLine, Qt::RoundCap));
            painter.drawLine(QPointF(12, 8), QPointF(12, 14));
            painter.drawPoint(QPointF(12, 17));
        } else if (kind == QStringLiteral("log")) {
            painter.drawRect(QRectF(6, 5, 13, 16));
            painter.drawLine(QPointF(9, 10), QPointF(17, 10));
            painter.drawLine(QPointF(9, 14), QPointF(17, 14));
            painter.drawLine(QPointF(9, 18), QPointF(15, 18));
            painter.drawLine(QPointF(9, 3), QPointF(16, 3));
        } else if (kind == QStringLiteral("settings")) {
            painter.drawEllipse(QPointF(12, 12), 5, 5);
            for (int i = 0; i < 8; ++i) {
                const double angle = i * M_PI / 4.0;
                const QPointF a(12 + qCos(angle) * 7, 12 + qSin(angle) * 7);
                const QPointF b(12 + qCos(angle) * 10, 12 + qSin(angle) * 10);
                painter.drawLine(a, b);
            }
        } else if (kind == QStringLiteral("exit")) {
            painter.drawLine(QPointF(6, 6), QPointF(18, 18));
            painter.drawLine(QPointF(18, 6), QPointF(6, 18));
        }
        return QIcon(pixmap);
    };

    auto *title = plainLabel(u("让施工更轻松"), QStringLiteral("machineTitle"));
    title->setFixedWidth(118);
    title->setAlignment(Qt::AlignCenter);
    installDragHandle(title);
    layout->addWidget(title);
    pageNumberLabel_ = plainLabel(QStringLiteral("P01"), QStringLiteral("pageNumberLabel"));
    pageNumberLabel_->setFixedWidth(88);
    pageNumberLabel_->setAlignment(Qt::AlignCenter);
    installDragHandle(pageNumberLabel_);
    layout->addWidget(pageNumberLabel_);
    layout->addStretch(1);

    struct TopTab {
        QString text;
        QString icon;
        int pageIndex;
    };
    const QList<TopTab> tabs {
        {u("主界面"), QStringLiteral("home"), 0},
        {u("数据监测"), QStringLiteral("data"), 1},
        {u("报警信息"), QStringLiteral("alarm"), 3},
        {u("操作日志"), QStringLiteral("log"), 4},
        {u("设置"), QStringLiteral("settings"), 2},
        {u("退出"), QStringLiteral("exit"), 0}
    };
    for (const auto &tab : tabs) {
        auto *button = touchButton(tab.text);
        button->setProperty("class", "topNavButton");
        button->setIcon(makeTopIcon(tab.icon));
        button->setIconSize(QSize(16, 16));
        button->setCheckable(tab.text != u("退出"));
        button->setFixedWidth(tab.text == u("数据监测") || tab.text == u("报警信息") || tab.text == u("操作日志") ? 88 : 72);
        button->setFixedHeight(34);
        if (tab.text != u("退出")) {
            button->setProperty("pageIndex", tab.pageIndex);
            navButtons_.append(button);
            connect(button, &QPushButton::clicked, this, [this, pageIndex = tab.pageIndex] { switchPage(pageIndex); });
        } else {
            connect(button, &QPushButton::clicked, this, &QWidget::close);
        }
        layout->addWidget(button);
    }
    layout->addSpacing(12);

    connectionLabel_ = plainLabel(sitonClockText(QDateTime::currentDateTime()), QStringLiteral("clockLabel"));
    connectionLabel_->setFixedWidth(264);
    connectionLabel_->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    installDragHandle(connectionLabel_);
    layout->addWidget(connectionLabel_);
    return bar;
}

QWidget *MainWindow::buildDashboardPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);
    auto *drillView = new SitonDrillMainView;
    dashboardView_ = drillView;
    layout->addWidget(drillView, 1);
    return page;
}

QWidget *MainWindow::buildWorkfacePage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *root = new QVBoxLayout(page);
    root->setContentsMargins(62, 10, 62, 16);
    root->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    content->setProperty("page", "p02");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 8);
    contentLayout->setSpacing(6);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);

    auto *stack = new QStackedWidget;
    stack->setProperty("class", "transparent");
    auto *tabGroup = new QButtonGroup(page);
    tabGroup->setExclusive(true);
    const QStringList tabNames{u("钻臂故障"), u("台车状态"), u("传感器数据"), u("钻机参数"), u("手柄监测")};
    for (int i = 0; i < tabNames.size(); ++i) {
        auto *button = touchButton(tabNames.at(i));
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 2);
        tabGroup->addButton(button, i);
        tabsLayout->addWidget(button);
    }
    tabsLayout->addStretch();

    auto makeValue = [](const QString &value = QStringLiteral("0")) {
        auto *label = plainLabel(value, QStringLiteral("sitonValueDisplay"));
        label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        label->setMinimumSize(82, 28);
        return label;
    };
    auto makeDot = [](const QColor &color) {
        auto *dot = plainLabel(QStringLiteral("●"));
        dot->setAlignment(Qt::AlignCenter);
        dot->setStyleSheet(QStringLiteral("QLabel { background: transparent; color: %1; font-size: 20px; font-weight: 900; }").arg(color.name()));
        dot->setFixedWidth(18);
        return dot;
    };
    auto makeGroup = [](const QString &title) {
        auto *group = new QGroupBox(title);
        group->setProperty("class", "sitonGroup");
        return group;
    };
    auto makeFaultPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *layout = new QVBoxLayout(host);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(10);

        auto *columns = new QWidget;
        columns->setProperty("class", "transparent");
        auto *columnsLayout = new QHBoxLayout(columns);
        columnsLayout->setContentsMargins(0, 0, 0, 0);
        columnsLayout->setSpacing(12);
        const QStringList arms{u("左臂"), u("中臂"), u("右臂")};
        const QStringList faultRows{
            u("推进压力传感器故障:"), u("冲击压力传感器故障:"), u("回转压力传感器故障:"),
            u("推进梁伸缩压力传感器故障:"), u("水压力传感器故障:"), u("润滑压力传感器故障:"),
            u("气压力传感器故障:"), u("缓冲压力传感器故障:"), u("水流量传感器故障:"),
            u("大臂摆动角度编码器故障:"), u("大臂俯仰角度编码器故障:"), u("大臂伸缩长度编码器故障:"),
            u("推进梁回转角度编码器故障:"), u("推进梁俯仰角度编码器故障:"), u("推进梁摆动角度编码器故障:"),
            u("推进梁伸缩长度编码器故障:"), u("凿岩机伸缩长度编码器故障:"), u("鹰式臂展开角度编码器故障:")
        };
        for (int armIndex = 0; armIndex < arms.size(); ++armIndex) {
            const QString &arm = arms.at(armIndex);
            auto *group = makeGroup(arm);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(12, 18, 10, 14);
            grid->setHorizontalSpacing(6);
            grid->setVerticalSpacing(0);
            for (int i = 0; i < faultRows.size(); ++i) {
                auto *label = plainLabel(arm + faultRows.at(i), QStringLiteral("sitonParamLabel"));
                label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
                setCoverageHint(label, i >= 9 ? CoverageHint::Covered : CoverageHint::Gap);
                grid->addWidget(label, i, 0);
                auto *dot = makeDot(QColor("#d8d8d8"));
                armFaultDots_[armIndex][i] = dot;
                grid->addWidget(dot, i, 1);
            }
            columnsLayout->addWidget(group, 1);
        }
        layout->addWidget(columns, 4);

        auto *system = makeGroup(u("整车与通信"));
        auto *systemGrid = new QGridLayout(system);
        systemGrid->setContentsMargins(44, 18, 34, 14);
        systemGrid->setHorizontalSpacing(40);
        systemGrid->setVerticalSpacing(4);
        const QStringList systemRows{
            u("控制器与车底盘通讯故障:"), u("控制器与控制器通讯故障:"), u("控制器与站位操作台通讯故障:"), u("控制器与坐位操作台通讯故障:"),
            u("主控制箱传感器电源故障:"), u("传感器电源故障:"), u("编码器电源故障:"), u("倾角仪故障:"),
            u("液压油温度传感器故障:"), u("泵后水压力传感器故障:"), u("定位泵压力传感器故障:"), u("通讯模块连接:")
        };
        for (int i = 0; i < systemRows.size(); ++i) {
            const int row = i / 4;
            const int col = (i % 4) * 2;
            auto *label = plainLabel(systemRows.at(i), QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label,
                            (i == 1 || i == 2 || i == 3 || i == 7 || i == 11)
                                ? CoverageHint::Covered
                                : CoverageHint::Gap);
            systemGrid->addWidget(label, row, col);
            auto *dot = makeDot(QColor("#d8d8d8"));
            systemFaultDots_[i] = dot;
            if (i == 11) {
                canToNetFaultDot_ = dot;
            }
            systemGrid->addWidget(dot, row, col + 1);
        }
        layout->addWidget(system, 1);
        return host;
    };
    auto makeHandlePage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *layout = new QVBoxLayout(host);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(10);

        struct HandlePairRow {
            QString label;
            QString leftValue;
            QString rightValue;
        };
        struct StatusItem {
            QString label;
            QColor color;
            QString value;
            CoverageHint coverage;
        };
        auto addHandleRow = [&](QGridLayout *grid, int row, const HandlePairRow &item) -> QPair<QLabel *, QLabel *> {
            auto *label = plainLabel(item.label, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label, CoverageHint::Covered);
            grid->addWidget(label, row, 0);
            auto *left = makeValue(item.leftValue);
            auto *right = makeValue(item.rightValue);
            setCoverageHint(left, right, CoverageHint::Covered);
            left->setMinimumWidth(76);
            right->setMinimumWidth(76);
            grid->addWidget(left, row, 1);
            grid->addWidget(right, row, 3);
            return {left, right};
        };
        auto addStatusItem = [&](QGridLayout *grid, int index, const StatusItem &item) {
            const int row = index / 3;
            const int col = (index % 3) * 3;
            auto *label = plainLabel(item.label, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label, item.coverage);
            grid->addWidget(label, row, col);
            auto *dot = makeDot(item.color);
            if (index >= 0 && index < static_cast<int>(handleStatusDots_.size())) {
                handleStatusDots_[static_cast<size_t>(index)] = dot;
            }
            if (item.label == u("通讯链路:")) {
                canToNetHandleDot_ = dot;
            }
            grid->addWidget(dot, row, col + 1);
            auto *value = makeValue(item.value);
            setCoverageHint(value, item.coverage);
            if (index >= 0 && index < static_cast<int>(handleStatusValues_.size())) {
                handleStatusValues_[static_cast<size_t>(index)] = value;
            }
            if (item.label == u("通讯链路:")) {
                canToNetHandleValue_ = value;
            }
            value->setMinimumWidth(82);
            grid->addWidget(value, row, col + 2);
        };

        auto *columns = new QWidget;
        columns->setProperty("class", "transparent");
        auto *columnsLayout = new QHBoxLayout(columns);
        columnsLayout->setContentsMargins(0, 0, 0, 0);
        columnsLayout->setSpacing(12);

        const QVector<QPair<QString, QVector<HandlePairRow>>> handleGroups{
            {u("站位操作台手柄"), {
                {u("X轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("Y轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("Z轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K0输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K1输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K2输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K3输入:"), QStringLiteral("0"), QStringLiteral("0")}
            }},
            {u("坐位操作台手柄"), {
                {u("X轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("Y轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("Z轴:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K0输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K1输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K2输入:"), QStringLiteral("0"), QStringLiteral("0")},
                {u("K3输入:"), QStringLiteral("0"), QStringLiteral("0")}
            }}
        };

        for (int consoleIndex = 0; consoleIndex < handleGroups.size(); ++consoleIndex) {
            const auto &handleGroup = handleGroups.at(consoleIndex);
            auto *group = makeGroup(handleGroup.first);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(34, 30, 30, 24);
            grid->setHorizontalSpacing(12);
            grid->setVerticalSpacing(8);
            auto *leftHeader = plainLabel(u("左手柄"), QStringLiteral("sitonParamLabel"));
            auto *rightHeader = plainLabel(u("右手柄"), QStringLiteral("sitonParamLabel"));
            leftHeader->setAlignment(Qt::AlignCenter);
            rightHeader->setAlignment(Qt::AlignCenter);
            grid->addWidget(leftHeader, 0, 1);
            grid->addWidget(rightHeader, 0, 3);
            for (int i = 0; i < handleGroup.second.size(); ++i) {
                const QPair<QLabel *, QLabel *> values = addHandleRow(grid, i + 1, handleGroup.second.at(i));
                if (consoleIndex >= 0 && consoleIndex < 2 && i >= 0 && i < 7) {
                    handleValueLabels_[static_cast<size_t>(consoleIndex)][0][static_cast<size_t>(i)] = values.first;
                    handleValueLabels_[static_cast<size_t>(consoleIndex)][1][static_cast<size_t>(i)] = values.second;
                }
            }
            columnsLayout->addWidget(group, 1);
        }
        layout->addWidget(columns, 5);

        auto *status = makeGroup(u("操作台与通讯状态"));
        auto *statusGrid = new QGridLayout(status);
        statusGrid->setContentsMargins(40, 22, 34, 18);
        statusGrid->setHorizontalSpacing(10);
        statusGrid->setVerticalSpacing(8);
        const QVector<StatusItem> statusItems{
            {u("站位操作台通讯:"), QColor("#d8d8d8"), u("未知"), CoverageHint::Covered},
            {u("坐位操作台通讯:"), QColor("#d8d8d8"), u("未知"), CoverageHint::Covered},
            {u("远程操作台通讯:"), QColor("#d8d8d8"), u("未接入"), CoverageHint::Gap},
            {u("1号遥控器通讯:"), QColor("#d8d8d8"), u("未接入"), CoverageHint::Gap},
            {u("2号遥控器通讯:"), QColor("#d8d8d8"), u("未接入"), CoverageHint::Gap},
            {u("通讯链路:"), QColor("#d8d8d8"), u("未连接"), CoverageHint::Covered},
            {u("操作台急停:"), QColor("#d8d8d8"), u("未知"), CoverageHint::Covered},
            {u("驾驶位急停:"), QColor("#d8d8d8"), u("未知"), CoverageHint::Gap},
            {u("吊篮臂急停:"), QColor("#d8d8d8"), u("未知"), CoverageHint::Gap}
        };
        for (int i = 0; i < statusItems.size(); ++i) {
            addStatusItem(statusGrid, i, statusItems.at(i));
        }
        layout->addWidget(status, 2);
        return host;
    };
    auto makeSensorPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *layout = new QVBoxLayout(host);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(8);

        auto *columns = new QWidget;
        columns->setProperty("class", "transparent");
        auto *columnsLayout = new QHBoxLayout(columns);
        columnsLayout->setContentsMargins(0, 0, 0, 0);
        columnsLayout->setSpacing(12);
        const QStringList arms{u("左臂"), u("中臂"), u("右臂")};
        const QStringList sensorRows{
            u("凿岩机推进压力(0~400bar):"), u("凿岩机冲击压力(0~400bar):"),
            u("凿岩机回转压力(0~400bar):"), u("推进梁伸缩压力(0~400bar):"),
            u("凿岩机伸缩原点(0~1):"), u("大臂摆动角度(-42° - 42°):"),
            u("大臂俯仰角度(-55° - 42°):"), u("大臂伸缩长度(0 - 2.5m):"),
            u("推进梁回转角度(-190° - 190°):"), u("推进梁俯仰角度(-135° - 135°):"),
            u("推进梁摆动角度(-55° - 8°):"), u("推进梁伸缩长度(0 - 1.8m):"),
            u("凿岩机伸缩长度(m):"), u("鹰式臂展开角度(0° - 130°):")
        };
        for (int armIndex = 0; armIndex < arms.size(); ++armIndex) {
            const QString &arm = arms.at(armIndex);
            auto *group = makeGroup(arm);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(14, 20, 8, 10);
            grid->setHorizontalSpacing(6);
            grid->setVerticalSpacing(1);
            for (int r = 0; r < sensorRows.size(); ++r) {
                auto *label = plainLabel(arm + sensorRows.at(r), QStringLiteral("sitonParamLabel"));
                label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
                const bool covered = r <= 3 || r == 5 || r == 6 || r == 12;
                setCoverageHint(label, covered ? CoverageHint::Covered : CoverageHint::Gap);
                grid->addWidget(label, r, 0);
                auto *valueLabel = makeValue();
                setCoverageHint(valueLabel, covered ? CoverageHint::Covered : CoverageHint::Gap);
                if (armIndex >= 0 && armIndex < 3 && r >= 0 && r < 14) {
                    sensorValueLabels_[armIndex][r] = valueLabel;
                }
                grid->addWidget(valueLabel, r, 1);
            }
            auto *bottomRow = new QWidget;
            bottomRow->setProperty("class", "transparent");
            auto *bottomLayout = new QHBoxLayout(bottomRow);
            bottomLayout->setContentsMargins(0, 0, 0, 0);
            bottomLayout->addStretch();
            auto *recordCount = plainLabel(u("(已记录0条)"), QStringLiteral("sitonParamLabel"));
            recordCount->setProperty("count", 0);
            bottomLayout->addWidget(recordCount);
            auto *record = touchButton(u("记录"));
            record->setProperty("class", "sitonSmallButton");
            record->setMinimumHeight(24);
            record->setMaximumHeight(26);
            auto *exportButton = touchButton(u("导出"));
            exportButton->setProperty("class", "sitonSmallButton");
            exportButton->setMinimumHeight(24);
            exportButton->setMaximumHeight(26);
            connect(record, &QPushButton::clicked, host, [recordCount, record] {
                const int count = recordCount->property("count").toInt() + 1;
                recordCount->setProperty("count", count);
                recordCount->setText(u("(已记录%1条)").arg(count));
                pulseButtonText(record, u("已记录"));
            });
            connect(exportButton, &QPushButton::clicked, host, [recordCount, exportButton] {
                const int count = recordCount->property("count").toInt();
                recordCount->setText(u("(已导出%1条)").arg(count));
                pulseButtonText(exportButton, u("已导出"));
            });
            bottomLayout->addWidget(record);
            bottomLayout->addWidget(exportButton);
            grid->addWidget(bottomRow, sensorRows.size(), 0, 1, 2);
            columnsLayout->addWidget(group, 1);
        }
        layout->addWidget(columns, 7);

        auto *other = makeGroup(u("其它"));
        auto *otherGrid = new QGridLayout(other);
        otherGrid->setContentsMargins(36, 18, 24, 12);
        otherGrid->setHorizontalSpacing(40);
        otherGrid->setVerticalSpacing(4);
        const QList<QPair<QString, QString>> otherRows{
            {u("倾角仪X轴角度:"), QStringLiteral("0")},
            {u("倾角仪Y轴角度:"), QStringLiteral("0")},
            {u("吊篮臂摆动角度(-45° - 45°):"), QStringLiteral("0")},
            {u("吊篮臂俯仰角度(-60° - 35°):"), QStringLiteral("0")}
        };
        for (int i = 0; i < otherRows.size(); ++i) {
            const int row = i / 3;
            const int col = (i % 3) * 2;
            auto *label = plainLabel(otherRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label, CoverageHint::Gap);
            otherGrid->addWidget(label, row, col);
            auto *valueLabel = makeValue(otherRows.at(i).second);
            setCoverageHint(valueLabel, CoverageHint::Gap);
            otherGrid->addWidget(valueLabel, row, col + 1);
        }
        layout->addWidget(other, 1);
        return host;
    };
    auto makeTruckPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *layout = new QVBoxLayout(host);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(14);

        auto addStatusGroup = [&](const QString &title,
                                  const QVector<QStringList> &columns,
                                  const QColor &color,
                                  const std::function<bool(int, int)> &isCovered) {
            auto *group = makeGroup(title);
            group->setMaximumHeight(title == u("工作状态") ? 166 : 90);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(70, 18, 70, 12);
            grid->setHorizontalSpacing(72);
            grid->setVerticalSpacing(4);
            for (int column = 0; column < columns.size(); ++column) {
                for (int row = 0; row < columns.at(column).size(); ++row) {
                    const int gridCol = column * 2;
                    auto *label = plainLabel(columns.at(column).at(row), QStringLiteral("sitonParamLabel"));
                    label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
                    setCoverageHint(label, isCovered && isCovered(column, row) ? CoverageHint::Covered : CoverageHint::Gap);
                    grid->addWidget(label, row, gridCol);
                    auto *dot = makeDot(color);
                    if (title == u("工作状态") && row == 3 && column >= 0 && column < 3) {
                        lubricationProtectDots_[column] = dot;
                    }
                    if (title == u("工作状态") && column >= 0 && column < 3 && row >= 0 && row < 6) {
                        truckWorkStatusDots_[static_cast<size_t>(column)][static_cast<size_t>(row)] = dot;
                    }
                    if (title == u("急停") && column >= 0 && column < 3 && row >= 0 && row < 2) {
                        truckEmergencyDots_[static_cast<size_t>(column)][static_cast<size_t>(row)] = dot;
                    }
                    grid->addWidget(dot, row, gridCol + 1);
                }
            }
            layout->addWidget(group);
        };
        addStatusGroup(u("工作状态"), {
            {u("左臂防卡钎:"), u("左臂防空打:"), u("左臂水洗压力保护:"), u("左臂润滑压力保护:"), u("左臂主泵电机运行:"), u("电源开关:")},
            {u("中臂防卡钎:"), u("中臂防空打:"), u("中臂水洗压力保护:"), u("中臂润滑压力保护:"), u("中臂主泵电机运行:")},
            {u("右臂防卡钎:"), u("右臂防空打:"), u("右臂水洗压力保护:"), u("右臂润滑压力保护:"), u("右臂主泵电机运行:")}
        }, QColor("#d8d8d8"), [](int, int row) {
            return row == 3;
        });
        addStatusGroup(u("急停"), {
            {u("操作台急停:"), u("左侧急停:")},
            {u("驾驶仪表盘急停:"), u("右侧急停:")},
            {u("吊篮臂急停:")}
        }, QColor("#d8d8d8"), [](int column, int row) {
            return (column == 0 && row <= 1) || (column == 1 && row == 1);
        });

        auto *data = makeGroup(u("数据与报警"));
        auto *dataLayout = new QVBoxLayout(data);
        dataLayout->setContentsMargins(30, 8, 30, 8);
        dataLayout->setSpacing(4);
        auto *legend = new QWidget;
        legend->setProperty("class", "transparent");
        legend->setMaximumHeight(24);
        auto *legendLayout = new QHBoxLayout(legend);
        legendLayout->setContentsMargins(0, 0, 0, 0);
        legendLayout->setSpacing(6);
        legendLayout->addStretch();
        const QList<QPair<QString, QColor>> legendItems{
            {u("传感器正常"), QColor("#86ef8f")},
            {u("传感器故障"), QColor("#ff0000")},
            {u("传感器未连接"), QColor("#d8d8d8")}
        };
        for (const auto &item : legendItems) {
            legendLayout->addWidget(makeDot(item.second));
            legendLayout->addWidget(plainLabel(item.first, QStringLiteral("sitonParamLabel")));
        }
        dataLayout->addWidget(legend);

        struct MonitorRow {
            QString label;
            QString value;
            QColor color;
        };
        auto makeCompactValue = [](const QString &value) {
            auto *label = plainLabel(value, QStringLiteral("sitonValueDisplay"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            label->setMinimumSize(68, 22);
            label->setMaximumHeight(24);
            return label;
        };
        const QVector<QList<MonitorRow>> dataColumns{
            {
                {u("左臂电机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂凿岩机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂钻头工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂水压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂润滑油压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂润滑气压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂润滑油压力2(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂推进极限位压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("左臂集中润滑压力:"), QString(), QColor("#d8d8d8")},
                {u("进水压力:"), QString(), QColor("#d8d8d8")},
                {u("左误入:"), QString(), QColor("#d8d8d8")}
            },
            {
                {u("中臂电机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂凿岩机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂钻头工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂水压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂润滑油压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂润滑气压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂润滑油压力2(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂推进极限位压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("中臂集中润滑压力:"), QString(), QColor("#d8d8d8")},
                {u("润滑油液位:"), QString(), QColor("#d8d8d8")},
                {u("右误入:"), QString(), QColor("#d8d8d8")}
            },
            {
                {u("右臂电机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂凿岩机工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂钻头工作时间(h):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂水压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂润滑油压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂润滑气压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂润滑油压力2(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂推进极限位压力(bar):"), QStringLiteral("0.00"), QColor("#d8d8d8")},
                {u("右臂集中润滑压力:"), QString(), QColor("#d8d8d8")}
            }
        };
        auto *dataColumnsHost = new QWidget;
        dataColumnsHost->setProperty("class", "transparent");
        auto *dataColumnsLayout = new QHBoxLayout(dataColumnsHost);
        dataColumnsLayout->setContentsMargins(0, 0, 0, 0);
        dataColumnsLayout->setSpacing(18);
        for (int block = 0; block < dataColumns.size(); ++block) {
            const QList<MonitorRow> &rows = dataColumns.at(block);
            auto *column = new QWidget;
            column->setProperty("class", "transparent");
            auto *grid = new QGridLayout(column);
            grid->setContentsMargins(0, 0, 0, 0);
            grid->setHorizontalSpacing(8);
            grid->setVerticalSpacing(2);
            for (int row = 0; row < rows.size(); ++row) {
                const MonitorRow &item = rows.at(row);
                auto *label = plainLabel(item.label, QStringLiteral("sitonParamLabel"));
                label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
                const bool covered = row == 1 || row == 3 || row == 4 || row == 7 || row == 8 || row == 9;
                setCoverageHint(label, covered ? CoverageHint::Covered : CoverageHint::Gap);
                label->setMinimumHeight(22);
                label->setMaximumHeight(24);
                label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
                grid->addWidget(label, row, 0);
                if (item.value.isEmpty()) {
                    auto *blank = new QWidget;
                    blank->setProperty("class", "transparent");
                    blank->setFixedSize(68, 22);
                    grid->addWidget(blank, row, 1);
                } else {
                    auto *valueLabel = makeCompactValue(item.value);
                    setCoverageHint(valueLabel, covered ? CoverageHint::Covered : CoverageHint::Gap);
                    if (block >= 0 && block < 3 && row >= 0 && row < 11) {
                        truckDataValueLabels_[static_cast<size_t>(block)][static_cast<size_t>(row)] = valueLabel;
                    }
                    grid->addWidget(valueLabel, row, 1);
                }
                auto *dot = makeDot(QColor("#d8d8d8"));
                dot->setFixedSize(18, 22);
                if (block >= 0 && block < 3 && row >= 0 && row < 11) {
                    truckDataStatusDots_[static_cast<size_t>(block)][static_cast<size_t>(row)] = dot;
                }
                grid->addWidget(dot, row, 2);
                grid->setRowMinimumHeight(row, 22);
            }
            grid->setColumnStretch(0, 1);
            dataColumnsLayout->addWidget(column, 1);
        }
        dataLayout->addWidget(dataColumnsHost, 1);
        layout->addWidget(data, 1);
        return host;
    };
    auto makeDrillParamPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *layout = new QVBoxLayout(host);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->setSpacing(8);
        auto *columns = new QWidget;
        columns->setProperty("class", "transparent");
        auto *columnsLayout = new QHBoxLayout(columns);
        columnsLayout->setContentsMargins(0, 0, 0, 0);
        columnsLayout->setSpacing(12);
        struct ArmMonitorParam {
            QString name;
            QString diameter;
            QStringList values;
        };
        const QStringList rows{
            u("二级卡钎压力(0-200)bar"),
            u("推进保护压力(0-100)bar"),
            u("领孔推进压力比率(0-100)%"),
            u("钻孔推进压力比率(0-100)%"),
            u("领孔冲击压力比率(0-100)%"),
            u("钻孔冲击压力比率(0-100)%"),
            u("领孔深度(0-0.5)m"),
            u("钻孔深度(0-6.0)m"),
            u("推进梁寻岩压力(20-60)bar"),
            u("钻机寻岩压力(20-50)bar"),
            u("梁回退(0-3.0)m"),
            u("大臂回退(0-3.0)m"),
            u("洗孔模式:"),
            u("气洗时间(0-30)s"),
            u("钻孔回转速度比率(0-100)%"),
            u("缓冲与推进压力差(0-100)bar"),
            u("钻孔推进速度比率(0-100)%"),
            u("一级卡钎压力(0-100)bar"),
            u("领孔推进速度比率(0-100)%"),
            u("领孔回转速度比率(0-100)%")
        };
        const QVector<ArmMonitorParam> arms{
            {u("左臂"), u("左臂Ø45"),
             {QStringLiteral("92"), QStringLiteral("35"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("40"),
              QStringLiteral("65"), QStringLiteral("0.3"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("30"),
              QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
              QStringLiteral("15"), QStringLiteral("100"), QStringLiteral("80"), QStringLiteral("75"), QStringLiteral("50")}},
            {u("中臂"), u("中臂Ø45"),
             {QStringLiteral("94"), QStringLiteral("35"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("43"),
              QStringLiteral("65"), QStringLiteral("0.3"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("20"),
              QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
              QStringLiteral("15"), QStringLiteral("90"), QStringLiteral("85"), QStringLiteral("75"), QStringLiteral("50")}},
            {u("右臂"), u("右臂Ø45"),
             {QStringLiteral("94"), QStringLiteral("40"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("41"),
              QStringLiteral("60"), QStringLiteral("0.4"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("30"),
              QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
              QStringLiteral("15"), QStringLiteral("100"), QStringLiteral("85"), QStringLiteral("75"), QStringLiteral("50")}}
        };
        auto makeCompactValue = [](const QString &value) {
            auto *label = plainLabel(value, QStringLiteral("sitonValueDisplay"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            label->setMinimumSize(74, 20);
            label->setMaximumHeight(22);
            label->setProperty("initialValue", value);
            return label;
        };
        QVector<QLabel *> drillParamValues;
        for (const ArmMonitorParam &arm : arms) {
            auto *group = makeGroup(arm.name);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(12, 16, 12, 10);
            grid->setHorizontalSpacing(8);
            grid->setVerticalSpacing(0);
            auto *diameterLabel = plainLabel(u("钻头直径(mm)"), QStringLiteral("sitonParamLabel"));
            diameterLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            setCoverageHint(diameterLabel, CoverageHint::Gap);
            grid->addWidget(diameterLabel, 0, 0);
            auto *diameterValue = makeCompactValue(arm.diameter);
            setCoverageHint(diameterValue, CoverageHint::Gap);
            drillParamValues.append(diameterValue);
            grid->addWidget(diameterValue, 0, 1);
            for (int i = 0; i < rows.size(); ++i) {
                auto *label = plainLabel(rows.at(i), QStringLiteral("sitonParamLabel"));
                label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
                setCoverageHint(label, CoverageHint::Gap);
                grid->addWidget(label, i + 1, 0);
                auto *value = makeCompactValue(arm.values.value(i));
                setCoverageHint(value, CoverageHint::Gap);
                drillParamValues.append(value);
                grid->addWidget(value, i + 1, 1);
            }
            columnsLayout->addWidget(group, 1);
        }
        layout->addWidget(columns, 1);

        auto *actions = makeGroup(u("参数监测"));
        auto *actionsLayout = new QHBoxLayout(actions);
        actionsLayout->setContentsMargins(44, 24, 44, 18);
        actionsLayout->setSpacing(16);
        auto *paramStatus = plainLabel(u("钻机参数监测待命"), QStringLiteral("sitonParamLabel"));
        paramStatus->setMinimumWidth(230);
        auto *recordCount = plainLabel(u("(已记录0条)"), QStringLiteral("sitonParamLabel"));
        recordCount->setProperty("count", 0);
        for (const QString &text : {u("刷新显示"), u("记录"), u("导出")}) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumHeight(32);
            connect(button, &QPushButton::clicked, host, [drillParamValues, paramStatus, recordCount, button, text] {
                if (text == u("刷新显示")) {
                    for (auto *value : drillParamValues) {
                        if (value) {
                            value->setText(value->property("initialValue").toString());
                        }
                    }
                    paramStatus->setText(u("钻机参数显示已刷新"));
                    pulseButtonText(button, u("已刷新"));
                } else if (text == u("记录")) {
                    const int count = recordCount->property("count").toInt() + 1;
                    recordCount->setProperty("count", count);
                    recordCount->setText(u("(已记录%1条)").arg(count));
                    paramStatus->setText(u("钻机参数监测值已记录"));
                    pulseButtonText(button, u("已记录"));
                } else if (text == u("导出")) {
                    const int count = recordCount->property("count").toInt();
                    recordCount->setText(u("(已导出%1条)").arg(count));
                    paramStatus->setText(u("钻机参数监测记录已准备导出"));
                    pulseButtonText(button, u("已导出"));
                }
            });
            actionsLayout->addWidget(button);
        }
        actionsLayout->addWidget(recordCount);
        actionsLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        actionsLayout->addWidget(paramStatus);
        actionsLayout->addStretch();
        layout->addWidget(actions);
        return host;
    };

    stack->addWidget(makeFaultPage());
    stack->addWidget(makeTruckPage());
    stack->addWidget(makeSensorPage());
    stack->addWidget(makeDrillParamPage());
    stack->addWidget(makeHandlePage());
    stack->setCurrentIndex(2);
    connect(tabGroup, &QButtonGroup::idClicked, this, [this, stack, tabNames](int id) {
        stack->setCurrentIndex(id);
        setPageMarker(QStringLiteral("P02-%1 %2")
                          .arg(id + 1, 2, 10, QLatin1Char('0'))
                          .arg(tabNames.value(id)));
    });

    contentLayout->addWidget(tabs);
    contentLayout->addWidget(stack, 1);
    root->addWidget(content, 1);

    auto *bottom = new QWidget;
    bottom->setProperty("class", "transparent");
    auto *bottomLayout = new QHBoxLayout(bottom);
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    bottomLayout->setSpacing(8);
    for (int i = 0; i < 2; ++i) {
        auto *bar = new QFrame;
        bar->setProperty("class", "sitonBottomBar");
        bar->setMinimumHeight(40);
        bottomLayout->addWidget(bar);
    }
    root->addWidget(bottom);
    return page;
}

QWidget *MainWindow::buildSettingsHubPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(190, 6, 190, 38);
    layout->setSpacing(0);

    auto makeIcon = [](int kind) {
        QPixmap pixmap(96, 96);
        pixmap.fill(Qt::transparent);
        QPainter painter(&pixmap);
        painter.setRenderHint(QPainter::Antialiasing, true);
        painter.setPen(QPen(QColor("#f5f5f5"), 5.0, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.setBrush(Qt::NoBrush);
        if (kind == 0) {
            painter.drawArc(QRectF(18, 20, 56, 56), 40 * 16, 260 * 16);
            QPainterPath a;
            a.moveTo(22, 32);
            a.lineTo(12, 28);
            a.lineTo(18, 44);
            painter.fillPath(a, QColor("#f5f5f5"));
            QPainterPath b;
            b.moveTo(74, 64);
            b.lineTo(84, 68);
            b.lineTo(78, 52);
            painter.fillPath(b, QColor("#f5f5f5"));
        } else if (kind == 1) {
            painter.drawRoundedRect(QRectF(20, 24, 56, 40), 4, 4);
            for (int i = 0; i < 4; ++i) {
                painter.drawLine(QPointF(30 + i * 12, 56), QPointF(30 + i * 12, 40 - i * 4));
            }
            painter.drawLine(QPointF(48, 64), QPointF(43, 76));
            painter.drawLine(QPointF(48, 64), QPointF(54, 76));
            painter.drawLine(QPointF(34, 76), QPointF(63, 76));
        } else if (kind == 2) {
            painter.drawLine(QPointF(24, 70), QPointF(76, 70));
            painter.drawLine(QPointF(24, 70), QPointF(24, 18));
            painter.drawLine(QPointF(24, 70), QPointF(68, 26));
            painter.drawEllipse(QPointF(48, 46), 7, 7);
            painter.drawEllipse(QPointF(66, 28), 5, 5);
            painter.drawLine(QPointF(48, 46), QPointF(66, 28));
        } else if (kind == 3) {
            painter.drawRoundedRect(QRectF(25, 17, 46, 62), 4, 4);
            painter.drawLine(QPointF(25, 36), QPointF(71, 36));
            painter.drawLine(QPointF(25, 58), QPointF(71, 58));
            painter.setBrush(QColor("#f5f5f5"));
            painter.drawEllipse(QPointF(37, 58), 6, 6);
            painter.drawEllipse(QPointF(62, 36), 6, 6);
            painter.setBrush(Qt::NoBrush);
        } else if (kind == 5) {
            painter.drawArc(QRectF(18, 18, 58, 62), 0, 180 * 16);
            painter.drawLine(QPointF(18, 50), QPointF(18, 78));
            painter.drawLine(QPointF(76, 50), QPointF(76, 78));
            painter.drawLine(QPointF(18, 78), QPointF(76, 78));
            painter.setBrush(QColor("#f5f5f5"));
            const QList<QPointF> dots{
                QPointF(34, 62), QPointF(48, 52), QPointF(62, 64),
                QPointF(36, 74), QPointF(52, 72)
            };
            for (const QPointF &dot : dots) {
                painter.drawEllipse(dot, 4, 4);
            }
            painter.setBrush(Qt::NoBrush);
            painter.setPen(QPen(QColor("#00c8ef"), 4, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            painter.drawEllipse(QPointF(62, 64), 9, 9);
        } else {
            painter.drawEllipse(QPointF(44, 58), 18, 18);
            painter.drawLine(QPointF(44, 40), QPointF(44, 14));
            painter.drawLine(QPointF(44, 14), QPointF(59, 14));
            painter.drawLine(QPointF(44, 26), QPointF(56, 26));
        }
        return QIcon(pixmap);
    };

    auto *content = new QFrame;
    content->setProperty("class", "sitonSettingsDimFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(10, 8, 10, 10);
    contentLayout->setSpacing(6);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);
    auto *settingsLogTabGroup = new QButtonGroup(page);
    settingsLogTabGroup->setExclusive(true);
    for (int i = 0; i < 2; ++i) {
        auto *button = touchButton(i == 0 ? u("操作日志") : u("传感器监控日志"));
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        settingsLogTabGroup->addButton(button, i);
        tabsLayout->addWidget(button);
    }
    tabsLayout->addStretch();
    contentLayout->addWidget(tabs);
    connect(settingsLogTabGroup, &QButtonGroup::idClicked, page, [this](int id) {
        const QString target = id == 0 ? u("操作日志") : u("传感器监控日志");
        switchPage(4);
        QTimer::singleShot(0, this, [this, target] {
            const QList<QPushButton *> buttons = findChildren<QPushButton *>();
            for (QPushButton *button : buttons) {
                if (button && button->isVisibleTo(this) && button->text() == target) {
                    button->click();
                    break;
                }
            }
        });
    });

    auto *canvas = new QFrame;
    canvas->setProperty("class", "sitonSettingsDimCanvas");
    auto *canvasLayout = new QVBoxLayout(canvas);
    canvasLayout->setContentsMargins(0, 0, 0, 0);
    canvasLayout->addStretch(1);

    auto *tiles = new QFrame;
    tiles->setProperty("class", "sitonSettingTileBar");
    auto *tileLayout = new QGridLayout(tiles);
    tileLayout->setContentsMargins(0, 0, 0, 0);
    tileLayout->setHorizontalSpacing(8);
    tileLayout->setVerticalSpacing(8);
    struct SettingEntry {
        QString text;
        int targetPage;
        int iconKind;
        CoverageHint coverage;
    };
    const QList<SettingEntry> entries{
        {u("清零"), 5, 0, CoverageHint::Covered},
        {u("维护"), 6, 1, CoverageHint::Gap},
        {u("坐标标定"), 9, 2, CoverageHint::Covered},
        {u("钻机参数预设"), 7, 3, CoverageHint::Covered},
        {u("凿岩保护解除"), 8, 4, CoverageHint::Gap},
        {u("炮孔图修改"), 10, 5, CoverageHint::Gap}
    };
    for (int i = 0; i < entries.size(); ++i) {
        auto *button = new QToolButton;
        button->setText(entries.at(i).text);
        button->setIcon(makeIcon(entries.at(i).iconKind));
        button->setIconSize(QSize(62, 62));
        button->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        button->setProperty("class", "sitonSettingTile");
        setCoverageHint(button, entries.at(i).coverage);
        button->setCursor(Qt::PointingHandCursor);
        button->setMinimumSize(176, 138);
        button->setMaximumSize(210, 150);
        button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        connect(button, &QToolButton::clicked, this, [this, target = entries.at(i).targetPage] {
            switchPage(target);
        });
        tileLayout->addWidget(button, i / 3, i % 3);
    }
    canvasLayout->addWidget(tiles, 0, Qt::AlignHCenter);
    canvasLayout->addStretch(2);
    contentLayout->addWidget(canvas, 1);
    layout->addWidget(content, 1);
    return page;
}

QWidget *MainWindow::buildHoleMapEditPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(38, 10, 38, 16);
    layout->setSpacing(8);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 8);
    contentLayout->setSpacing(8);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);
    auto *tab = touchButton(u("炮孔图修改"));
    tab->setProperty("class", "sitonMonitorTab");
    tab->setCheckable(true);
    tab->setChecked(true);
    tabsLayout->addWidget(tab);
    tabsLayout->addStretch(1);
    auto *backTop = touchButton(u("返回设置"));
    backTop->setProperty("class", "sitonSmallButton");
    connect(backTop, &QPushButton::clicked, this, [this] { switchPage(2); });
    tabsLayout->addWidget(backTop);
    contentLayout->addWidget(tabs);

    auto *body = new QWidget;
    body->setProperty("class", "transparent");
    auto *bodyLayout = new QHBoxLayout(body);
    bodyLayout->setContentsMargins(0, 0, 0, 0);
    bodyLayout->setSpacing(8);

    auto *editView = new SitonDrillMainView;
    editView->setHoleEditMode(true);
    editView->setMinimumSize(880, 560);
    holeEditView_ = editView;
    bodyLayout->addWidget(editView, 1);

    auto *side = new QFrame;
    side->setProperty("class", "sitonHoleEditPanel");
    side->setFixedWidth(330);
    auto *sideLayout = new QVBoxLayout(side);
    sideLayout->setContentsMargins(12, 12, 12, 12);
    sideLayout->setSpacing(10);

    auto *title = plainLabel(u("当前孔位"), QStringLiteral("sitonHoleEditTitle"));
    sideLayout->addWidget(title);
    auto *holeId = plainLabel(QStringLiteral("-"), QStringLiteral("sitonHoleEditValue"));
    holeId->setMinimumHeight(38);
    holeId->setAlignment(Qt::AlignCenter);
    sideLayout->addWidget(holeId);

    auto *targetTitle = plainLabel(u("修改点"), QStringLiteral("sitonFieldLabel"));
    sideLayout->addWidget(targetTitle);
    auto *targetRow = new QWidget;
    targetRow->setProperty("class", "transparent");
    auto *targetLayout = new QHBoxLayout(targetRow);
    targetLayout->setContentsMargins(0, 0, 0, 0);
    targetLayout->setSpacing(6);
    auto *targetGroup = new QButtonGroup(page);
    targetGroup->setExclusive(true);
    auto *entryButton = touchButton(u("入口点"));
    auto *endButton = touchButton(u("尾巴末端"));
    for (QPushButton *button : {entryButton, endButton}) {
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setMinimumHeight(42);
        targetLayout->addWidget(button);
    }
    entryButton->setChecked(true);
    targetGroup->addButton(entryButton, 0);
    targetGroup->addButton(endButton, 1);
    connect(targetGroup, &QButtonGroup::idClicked, page, [editView](int id) {
        editView->setHoleEditTargetEndPoint(id == 1);
    });
    sideLayout->addWidget(targetRow);

    auto makeEditor = [this](const QString &text) {
        auto *edit = new QLineEdit(text);
        edit->setProperty("class", "sitonEditor");
        edit->setProperty("touchNumberPad", true);
        edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        edit->setMinimumHeight(38);
        edit->setCursor(Qt::PointingHandCursor);
        installTouchKeyboard(edit);
        return edit;
    };

    auto *coordFrame = new QFrame;
    coordFrame->setProperty("class", "sitonHoleEditCoordBox");
    auto *coordLayout = new QGridLayout(coordFrame);
    coordLayout->setContentsMargins(8, 8, 8, 8);
    coordLayout->setHorizontalSpacing(8);
    coordLayout->setVerticalSpacing(8);

    const QStringList labels{u("入口X"), u("入口Y"), u("入口Z"), u("尾巴X"), u("尾巴Y"), u("尾巴Z")};
    std::array<QLineEdit *, 6> edits{};
    for (int row = 0; row < labels.size(); ++row) {
        auto *label = plainLabel(labels.at(row), QStringLiteral("sitonFieldLabel"));
        edits[static_cast<size_t>(row)] = makeEditor(QStringLiteral("0.00"));
        coordLayout->addWidget(label, row, 0);
        coordLayout->addWidget(edits[static_cast<size_t>(row)], row, 1);
    }
    sideLayout->addWidget(coordFrame);

    auto *status = plainLabel(u("点击孔位后可拖动或输入数值"), QStringLiteral("sitonHoleEditStatus"));
    status->setMinimumHeight(34);
    status->setWordWrap(true);
    sideLayout->addWidget(status);

    auto updateFields = [editView, holeId, entryButton, endButton, edits, status]() {
        const SitonPlanHole hole = editView->selectedHole();
        if (hole.id.isEmpty()) {
            holeId->setText(QStringLiteral("-"));
            for (QLineEdit *edit : edits) {
                if (edit) {
                    edit->setText(QStringLiteral("0.00"));
                    edit->setEnabled(false);
                }
            }
            entryButton->setEnabled(false);
            endButton->setEnabled(false);
            status->setText(u("未选中孔位"));
            return;
        }
        entryButton->setEnabled(true);
        const bool hasTail = holeHasEditableTail(hole);
        endButton->setEnabled(hasTail);
        if (!hasTail && editView->holeEditTargetEndPoint()) {
            editView->setHoleEditTargetEndPoint(false);
        }
        holeId->setText(u("H") + hole.id);
        entryButton->setChecked(!editView->holeEditTargetEndPoint());
        endButton->setChecked(editView->holeEditTargetEndPoint());
        const std::array<double, 6> values{
            hole.start.x, hole.start.y, hole.start.z,
            hole.end.x, hole.end.y, hole.end.z
        };
        for (int i = 0; i < static_cast<int>(edits.size()); ++i) {
            if (edits[static_cast<size_t>(i)]) {
                const bool tailField = i >= 3;
                edits[static_cast<size_t>(i)]->setEnabled(!tailField || hasTail);
                edits[static_cast<size_t>(i)]->setText(tailField && !hasTail
                                                       ? QStringLiteral("--")
                                                       : QString::number(values[static_cast<size_t>(i)], 'f', 3));
            }
        }
        status->setText(hasTail ? u("可修改入口位置和尾巴方向") : u("该孔无尾巴，只能修改入口位置"));
    };
    connect(editView, &SitonDrillMainView::editSelectionChanged, page, updateFields);
    connect(editView, &SitonDrillMainView::editStatusChanged, page, [this, status](const QString &message) {
        status->setText(message);
        if (dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
    });

    auto *buttonGrid = new QGridLayout;
    buttonGrid->setHorizontalSpacing(8);
    buttonGrid->setVerticalSpacing(8);
    auto *apply = touchButton(u("应用数值"));
    auto *addHole = touchButton(u("新增孔"));
    auto *deleteHole = touchButton(u("删除此孔"));
    auto *resetOne = touchButton(u("恢复此孔"));
    auto *resetAll = touchButton(u("恢复全部"));
    auto *back = touchButton(u("返回"));
    for (QPushButton *button : {apply, addHole, deleteHole, resetOne, resetAll, back}) {
        button->setProperty("class", "sitonBottomButton");
        button->setMinimumHeight(42);
    }
    buttonGrid->addWidget(apply, 0, 0, 1, 2);
    buttonGrid->addWidget(addHole, 1, 0);
    buttonGrid->addWidget(deleteHole, 1, 1);
    buttonGrid->addWidget(resetOne, 2, 0);
    buttonGrid->addWidget(resetAll, 2, 1);
    buttonGrid->addWidget(back, 3, 0, 1, 2);
    sideLayout->addLayout(buttonGrid);
    sideLayout->addStretch(1);

    auto readEdit = [](QLineEdit *edit, double fallback, bool &allOk) {
        bool ok = false;
        const double value = edit ? edit->text().trimmed().toDouble(&ok) : fallback;
        if (!ok) {
            allOk = false;
            return fallback;
        }
        return value;
    };
    connect(apply, &QPushButton::clicked, page, [this, editView, edits, status, readEdit] {
        SitonPlanHole hole = editView->selectedHole();
        if (hole.id.isEmpty()) {
            status->setText(u("未选中孔位"));
            return;
        }
        bool ok = true;
        hole.start.x = readEdit(edits[0], hole.start.x, ok);
        hole.start.y = readEdit(edits[1], hole.start.y, ok);
        hole.start.z = readEdit(edits[2], hole.start.z, ok);
        const bool hasTail = holeHasEditableTail(hole);
        if (hasTail) {
            hole.end.x = readEdit(edits[3], hole.end.x, ok);
            hole.end.y = readEdit(edits[4], hole.end.y, ok);
            hole.end.z = readEdit(edits[5], hole.end.z, ok);
        }
        hole.start.valid = true;
        if (!ok) {
            status->setText(u("数值格式不正确"));
            return;
        }
        if (editView->setSelectedHoleCoordinates(hole.start, hole.end) && dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
    });
    connect(addHole, &QPushButton::clicked, page, [this, editView, updateFields] {
        if (editView->addHoleNearSelection() && dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
        updateFields();
    });
    connect(deleteHole, &QPushButton::clicked, page, [this, editView, updateFields] {
        if (editView->deleteSelectedHole() && dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
        updateFields();
    });
    connect(resetOne, &QPushButton::clicked, page, [this, editView, updateFields] {
        if (editView->resetSelectedHoleEdit() && dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
        updateFields();
    });
    connect(resetAll, &QPushButton::clicked, page, [this, editView, updateFields] {
        if (editView->resetAllHoleEdits() && dashboardView_) {
            dashboardView_->reloadSavedHoleEdits();
        }
        updateFields();
    });
    connect(back, &QPushButton::clicked, this, [this] { switchPage(2); });

    updateFields();
    bodyLayout->addWidget(side);
    contentLayout->addWidget(body, 1);
    layout->addWidget(content, 1);
    return page;
}

QWidget *MainWindow::buildSettingZeroPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(62, 10, 62, 16);
    layout->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 8);
    contentLayout->setSpacing(8);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);
    auto *zeroTabGroup = new QButtonGroup(page);
    zeroTabGroup->setExclusive(true);
    for (int i = 0; i < 4; ++i) {
        const QString text = QStringList{u("左臂清零"), u("中臂清零"), u("右臂清零"), u("吊篮臂清零")}.at(i);
        auto *button = touchButton(text);
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        zeroTabGroup->addButton(button, i);
        tabsLayout->addWidget(button);
    }
    tabsLayout->addStretch();
    contentLayout->addWidget(tabs);

    auto makeGroup = [](const QString &title) {
        auto *group = new QGroupBox(title);
        group->setProperty("class", "sitonGroup");
        return group;
    };
    auto makeValue = [](const QString &text = QStringLiteral("0"),
                         const QString &objectName = QString()) {
        auto *edit = new QLineEdit(text);
        if (!objectName.isEmpty()) {
            edit->setObjectName(objectName);
        }
        edit->setProperty("class", "sitonValueInput");
        edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        edit->setMinimumHeight(28);
        return edit;
    };

    auto *modeGroup = makeGroup(u("清零方式"));
    auto *modeLayout = new QHBoxLayout(modeGroup);
    modeLayout->setContentsMargins(28, 20, 24, 14);
    modeLayout->setSpacing(14);
    auto *zeroModeGroup = new QButtonGroup(modeGroup);
    zeroModeGroup->setExclusive(true);
    const QList<QPair<QString, QString>> zeroModes{
        {u("选择清零"), u("说明：选择要清零的关节进行清零操作")},
        {u("出厂清零"), u("说明：一键将钻臂所有关节及凿岩机伸缩长度全部清零操作")},
        {u("坐标线清零"), u("说明：按当前炮孔图坐标线执行快速清零")}
    };
    auto *zeroModeStatus = plainLabel(u("清零方式：选择清零"), QStringLiteral("sitonParamLabel"));
    zeroModeStatus->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    for (int i = 0; i < zeroModes.size(); ++i) {
        const auto &mode = zeroModes.at(i);
        auto *button = touchButton(mode.first + QStringLiteral("\n") + mode.second);
        button->setProperty("class", "sitonZeroModeButton");
        button->setCheckable(true);
        button->setChecked(i == 0);
        button->setMinimumHeight(78);
        button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        zeroModeGroup->addButton(button, i);
        modeLayout->addWidget(button, 1);
    }
    contentLayout->addWidget(modeGroup);
    auto *modeStatusRow = new QWidget;
    modeStatusRow->setProperty("class", "transparent");
    auto *modeStatusLayout = new QHBoxLayout(modeStatusRow);
    modeStatusLayout->setContentsMargins(0, 0, 0, 0);
    modeStatusLayout->addStretch();
    modeStatusLayout->addWidget(zeroModeStatus);
    contentLayout->addWidget(modeStatusRow);
    connect(zeroModeGroup, &QButtonGroup::idClicked, page, [zeroModes, zeroModeStatus](int id) {
        if (id >= 0 && id < zeroModes.size()) {
            zeroModeStatus->setText(u("清零方式：") + zeroModes.at(id).first);
        }
    });

    auto *columns = new QWidget;
    columns->setProperty("class", "transparent");
    auto *columnsLayout = new QHBoxLayout(columns);
    columnsLayout->setContentsMargins(0, 0, 0, 0);
    columnsLayout->setSpacing(12);
    const QStringList rows{
        u("大臂摆动编码器零点设置:"), u("大臂俯仰编码器零点设置:"), u("大臂伸缩编码器零点设置:"),
        u("推进梁摆动编码器零点设置:"), u("推进梁俯仰编码器零点设置:"), u("推进梁回转编码器零点设置:"),
        u("推进梁伸缩编码器零点设置:"), u("凿岩机伸缩编码器零点设置:"), u("鹰式臂展开编码器零点设置:")
    };
    QVector<QLineEdit *> zeroEdits;
    auto *zeroStatus = plainLabel(u("左臂清零待命"), QStringLiteral("sitonParamLabel"));
    zeroStatus->setMinimumWidth(210);
    connect(zeroTabGroup, &QButtonGroup::idClicked, page, [this, zeroStatus](int id) {
        const QStringList names{u("左臂"), u("中臂"), u("右臂"), u("吊篮臂")};
        const QString name = names.value(id, u("左臂")) + u("清零");
        zeroStatus->setText(name + u("待命"));
        setPageMarker(QStringLiteral("P06-%1 %2")
                          .arg(id + 1, 2, 10, QLatin1Char('0'))
                          .arg(name));
    });
    const QStringList zeroArms{u("左臂"), u("中臂"), u("右臂")};
    for (int zeroArmIndex = 0; zeroArmIndex < zeroArms.size(); ++zeroArmIndex) {
        const QString arm = zeroArms.at(zeroArmIndex);
        auto *group = makeGroup(arm);
        auto *grid = new QGridLayout(group);
        grid->setContentsMargins(18, 20, 14, 12);
        grid->setHorizontalSpacing(8);
        grid->setVerticalSpacing(3);
        QVector<QLineEdit *> armZeroEdits;
        for (int i = 0; i < rows.size(); ++i) {
            auto *label = plainLabel(arm + rows.at(i), QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label, CoverageHint::Covered);
            grid->addWidget(label, i, 0);
            auto *edit = makeValue(QStringLiteral("0"),
                                   QStringLiteral("settings.zero.arm%1.field%2")
                                       .arg(zeroArmIndex)
                                       .arg(i));
            zeroEdits.append(edit);
            armZeroEdits.append(edit);
            grid->addWidget(edit, i, 1);
        }
        auto *zero = touchButton(arm + u("清零"));
        zero->setProperty("class", "sitonSmallButton");
        setCoverageHint(zero, CoverageHint::Covered);
        connect(zero, &QPushButton::clicked, group, [this, armZeroEdits,
                                                      zeroStatus = QPointer<QLabel>(zeroStatus),
                                                      zero = QPointer<QPushButton>(zero),
                                                      arm, zeroArmIndex] {
            showMaintenanceOverlay(
                this,
                u("此操作将立即清零%1编码器零点，请确认%1处于安全位置，是否继续？").arg(arm),
                [this, armZeroEdits, zeroStatus, zero, arm, zeroArmIndex] {
                    for (auto *edit : armZeroEdits) {
                        if (edit) {
                            edit->setText(QStringLiteral("0"));
                        }
                    }
                    const CanFrame frame = buildArmZeroCalibrationFrame(zeroArmIndex);
                    sendCommandFrame(arm + u("清零"), frame.id, frame.data, frame.dlc);
                    if (zeroStatus) {
                        zeroStatus->setText(arm + u("零点已清零"));
                    }
                    if (zero) {
                        pulseButtonText(zero, u("已清零"));
                    }
                });
        });
        grid->addWidget(zero, rows.size(), 0, 1, 2, Qt::AlignRight);
        columnsLayout->addWidget(group, 1);
    }
    contentLayout->addWidget(columns, 1);

    auto *actions = new QWidget;
    actions->setProperty("class", "transparent");
    auto *actionLayout = new QHBoxLayout(actions);
    actionLayout->setContentsMargins(0, 0, 0, 0);
    actionLayout->addStretch();
    for (const QString &text : {u("返回设置入口"), u("读取当前值"), u("保存零点"), u("导出")}) {
        auto *button = touchButton(text);
        button->setProperty("class", "sitonSmallButton");
        if (text == u("返回设置入口")) {
            connect(button, &QPushButton::clicked, this, [this] { switchPage(2); });
        } else if (text == u("读取当前值")) {
            connect(button, &QPushButton::clicked, page, [zeroEdits, zeroStatus, button] {
                for (auto *edit : zeroEdits) {
                    if (edit) {
                        edit->setText(QStringLiteral("0"));
                    }
                }
                zeroStatus->setText(u("已读取当前零点值"));
                pulseButtonText(button, u("已读取"));
            });
        } else if (text == u("保存零点")) {
            connect(button, &QPushButton::clicked, page, [zeroStatus, button] {
                zeroStatus->setText(u("清零位图已直接保存到控制器"));
                pulseButtonText(button, u("已保存"));
            });
        } else if (text == u("导出")) {
            connect(button, &QPushButton::clicked, page, [zeroStatus, button] {
                zeroStatus->setText(u("零点记录已准备导出"));
                pulseButtonText(button, u("已导出"));
            });
        }
        actionLayout->addWidget(button);
    }
    actionLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
    actionLayout->addWidget(zeroStatus);
    contentLayout->addWidget(actions);
    layout->addWidget(content, 1);
    return page;
}

QWidget *MainWindow::buildSettingsPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(62, 8, 62, 12);
    layout->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 10);
    contentLayout->setSpacing(6);

    auto value = [](const QString &text,
                    Qt::Alignment alignment = Qt::AlignRight | Qt::AlignVCenter,
                    const QString &objectName = QString()) {
        auto *edit = new QLineEdit(text);
        if (!objectName.isEmpty()) {
            edit->setObjectName(objectName);
        }
        edit->setProperty("class", "sitonValueInput");
        edit->setAlignment(alignment);
        edit->setMinimumHeight(26);
        edit->setMaximumHeight(28);
        return edit;
    };
    auto makeGroup = [](const QString &title) {
        auto *group = new QGroupBox(title);
        group->setProperty("class", "sitonGroup");
        return group;
    };
    auto addField = [](QGridLayout *grid, int row, const QString &labelText, QWidget *editor) {
        auto *label = plainLabel(labelText, QStringLiteral("sitonParamLabel"));
        label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        grid->addWidget(label, row, 0);
        grid->addWidget(editor, row, 1);
    };

    auto makeFolderButton = [this](QLineEdit *targetEdit) {
        auto *button = touchButton(QString());
        button->setProperty("class", "sitonSmallButton");
        button->setIcon(qApp->style()->standardIcon(QStyle::SP_DirIcon));
        button->setIconSize(QSize(18, 18));
        button->setFixedSize(46, 30);
        connect(button, &QPushButton::clicked, this, [this, targetEdit] {
            if (!targetEdit) {
                return;
            }
            const QString currentPath = targetEdit->text().trimmed();
            const QString selected = QFileDialog::getExistingDirectory(
                this,
                u("选择文件存放路径"),
                currentPath.isEmpty() ? QDir::homePath() : currentPath);
            if (!selected.isEmpty()) {
                targetEdit->setText(QDir::toNativeSeparators(selected));
            }
        });
        return button;
    };

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);
    auto *tabGroup = new QButtonGroup(page);
    tabGroup->setExclusive(true);
    const QStringList tabNames{
        u("文件存储设置"), u("报警阈值设置"), u("图形显示设置"), u("通信设置"), u("维护设置"), u("臂架电流标定")
    };
    for (int i = 0; i < tabNames.size(); ++i) {
        auto *button = touchButton(tabNames.at(i));
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        tabGroup->addButton(button, i);
        tabsLayout->addWidget(button);
    }
    tabsLayout->addStretch();
    contentLayout->addWidget(tabs);

    auto *stack = new QStackedWidget;
    stack->setProperty("class", "transparent");

    auto makeActionRow = [this](const QStringList &buttons, QLabel *status, const QString &doneText) {
        auto *row = new QWidget;
        row->setProperty("class", "transparent");
        auto *rowLayout = new QHBoxLayout(row);
        rowLayout->setContentsMargins(0, 0, 0, 0);
        rowLayout->addStretch();
        for (const QString &text : buttons) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(112);
            button->setMinimumHeight(30);
            connect(button, &QPushButton::clicked, row, [button, status, doneText, text] {
                if (status) {
                    status->setText(doneText.isEmpty() ? (text + u("已执行")) : doneText);
                }
                pulseButtonText(button, text.startsWith(u("保存")) ? u("已保存") : u("已执行"));
            });
            rowLayout->addWidget(button);
        }
        if (status) {
            rowLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
            rowLayout->addWidget(status);
        }
        return row;
    };

    auto makeStoragePage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        auto *top = new QWidget;
        top->setProperty("class", "transparent");
        auto *topLayout = new QHBoxLayout(top);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(12);

        auto *storage = makeGroup(u("文件存储设置"));
        auto *storageGrid = new QGridLayout(storage);
        storageGrid->setContentsMargins(34, 22, 34, 16);
        storageGrid->setHorizontalSpacing(12);
        storageGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> storageRows{
            {u("大地坐标3D点云文件路径设置:"), u("DocFile")},
            {u("隧道文件存储路径设置:"), u("DocFile")},
            {u("报警日志文件存储路径设置:"), u("Alarm")},
            {u("工作日志文件存储路径设置:"), u("Log")},
            {u("传感器日志文件存储路径设置:"), u("SensorLog")},
            {u("孔位文件目录:"), u("DocFile")}
        };
        for (int i = 0; i < storageRows.size(); ++i) {
            auto *edit = value(storageRows.at(i).second,
                               Qt::AlignRight | Qt::AlignVCenter,
                               QStringLiteral("settings.storage.path%1").arg(i));
            addField(storageGrid, i, storageRows.at(i).first, edit);
            storageGrid->addWidget(makeFolderButton(edit), i, 2);
        }
        storageGrid->setColumnStretch(1, 1);
        topLayout->addWidget(storage, 1);

        auto *import = makeGroup(u("导入文件设置"));
        auto *importGrid = new QGridLayout(import);
        importGrid->setContentsMargins(34, 22, 34, 16);
        importGrid->setHorizontalSpacing(12);
        importGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> importRows{
            {u("导入文件类型:"), QStringLiteral(".dp / .tl")},
            {u("自动加载最新:"), u("关闭")},
            {u("校验孔位文件:"), u("开启")},
            {u("导入后进主界面:"), u("开启")},
            {u("异常处理:"), u("提示")},
            {u("坐标系:"), u("H点同源")}
        };
        for (int i = 0; i < importRows.size(); ++i) {
            addField(importGrid,
                     i,
                     importRows.at(i).first,
                     value(importRows.at(i).second,
                           Qt::AlignRight | Qt::AlignVCenter,
                           QStringLiteral("settings.storage.import%1").arg(i)));
        }
        importGrid->setColumnStretch(1, 1);
        topLayout->addWidget(import, 1);
        hostLayout->addWidget(top, 3);

        auto *current = makeGroup(u("当前文件"));
        auto *currentGrid = new QGridLayout(current);
        currentGrid->setContentsMargins(34, 22, 34, 16);
        currentGrid->setHorizontalSpacing(40);
        currentGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> leftRows{
            {u("DP文件:"), u("千坑0531.dp")},
            {u("TL文件:"), QStringLiteral("20260430 (1).tl")},
            {u("孔数:"), QStringLiteral("207")},
            {u("隧道线点:"), QStringLiteral("2865")}
        };
        const QList<QPair<QString, QString>> rightRows{
            {u("断面线:"), QStringLiteral("5")},
            {u("完成记录:"), QStringLiteral("0")},
            {u("文件状态:"), u("已解析")},
            {u("默认视图:"), u("主视图")}
        };
        for (int i = 0; i < leftRows.size(); ++i) {
            auto *leftLabel = plainLabel(leftRows.at(i).first, QStringLiteral("sitonParamLabel"));
            leftLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            currentGrid->addWidget(leftLabel, i, 0);
            currentGrid->addWidget(value(leftRows.at(i).second,
                                         Qt::AlignRight | Qt::AlignVCenter,
                                         QStringLiteral("settings.storage.currentLeft%1").arg(i)), i, 1);
            auto *rightLabel = plainLabel(rightRows.at(i).first, QStringLiteral("sitonParamLabel"));
            rightLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            currentGrid->addWidget(rightLabel, i, 2);
            currentGrid->addWidget(value(rightRows.at(i).second,
                                         Qt::AlignRight | Qt::AlignVCenter,
                                         QStringLiteral("settings.storage.currentRight%1").arg(i)), i, 3);
        }
        currentGrid->setColumnStretch(1, 1);
        currentGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(current, 2);
        auto *status = plainLabel(u("文件设置待保存"), QStringLiteral("sitonParamLabel"));
        hostLayout->addWidget(makeActionRow({u("选择隧道文件"), u("选择孔位文件"), u("保存设置")}, status, u("文件设置已保存到本机")));
        return host;
    };

    auto makeAlarmSettingPage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        auto *top = new QWidget;
        top->setProperty("class", "transparent");
        auto *topLayout = new QHBoxLayout(top);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(12);
        const QList<QPair<QString, QString>> alarmRows{
            {u("车体前后倾翻阈值设置:"), QStringLiteral("8.0°")},
            {u("车体左右倾翻阈值设置:"), QStringLiteral("8.0°")},
            {u("推进压力报警阈值:"), QStringLiteral("400 bar")},
            {u("冲击压力报警阈值:"), QStringLiteral("400 bar")},
            {u("回转压力报警阈值:"), QStringLiteral("400 bar")},
            {u("缓冲压力报警阈值:"), QStringLiteral("80 bar")}
        };
        const QList<QPair<QString, QString>> protectRows{
            {u("水压力保护阈值:"), QStringLiteral("15 bar")},
            {u("润滑压力保护阈值:"), QStringLiteral("20 bar")},
            {u("泵后水压力阈值:"), QStringLiteral("15 bar")},
            {u("液压油温报警阈值:"), QStringLiteral("75°C")},
            {u("孔位偏差报警阈值:"), QStringLiteral("80 mm")},
            {u("角度偏差报警阈值:"), QStringLiteral("3.0°")}
        };
        for (const auto &spec : QList<QPair<QString, QList<QPair<QString, QString>>>>{
                 {u("报警阈值设置"), alarmRows},
                 {u("保护阈值设置"), protectRows}}) {
            auto *group = makeGroup(spec.first);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(38, 24, 34, 16);
            grid->setHorizontalSpacing(14);
            grid->setVerticalSpacing(10);
            for (int i = 0; i < spec.second.size(); ++i) {
                addField(grid, i, spec.second.at(i).first, value(spec.second.at(i).second));
            }
            grid->setColumnStretch(1, 1);
            topLayout->addWidget(group, 1);
        }
        hostLayout->addWidget(top, 3);

        auto *save = makeGroup(u("报警保存"));
        auto *saveGrid = new QGridLayout(save);
        saveGrid->setContentsMargins(52, 22, 50, 16);
        saveGrid->setHorizontalSpacing(40);
        saveGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> saveRows{
            {u("全部报警:"), u("记录")},
            {u("未恢复报警:"), u("保持")},
            {u("已恢复报警:"), u("保留")},
            {u("历史记录:"), u("开启")},
            {u("报警日志文件存储路径设置:"), u("Alarm")},
            {u("报警日志太多:"), u("提示")},
            {u("故障消失时间:"), u("记录")},
            {u("清除权限:"), u("维护员")}
        };
        for (int i = 0; i < saveRows.size(); ++i) {
            const int row = i % 4;
            const int col = (i / 4) * 2;
            auto *label = plainLabel(saveRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            saveGrid->addWidget(label, row, col);
            saveGrid->addWidget(value(saveRows.at(i).second), row, col + 1);
        }
        saveGrid->setColumnStretch(1, 1);
        saveGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(save, 2);
        auto *status = plainLabel(u("报警阈值待保存"), QStringLiteral("sitonParamLabel"));
        hostLayout->addWidget(makeActionRow({u("保存报警阈值"), u("恢复默认"), u("导出")}, status, u("报警阈值已保存到本机")));
        return host;
    };

    auto makeGraphicPage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        auto *top = new QWidget;
        top->setProperty("class", "transparent");
        auto *topLayout = new QHBoxLayout(top);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(12);
        const QList<QPair<QString, QString>> displayRows{
            {u("隧道数据颜色:"), u("灰白")},
            {u("隧道数据点大小/线宽度:"), QStringLiteral("2 / 2")},
            {u("隧道点/线颜色设置:"), u("灰白")},
            {u("H点轨迹点/线颜色设置:"), u("绿色")},
            {u("点线设置:"), u("显示")},
            {u("坐标轴设置:"), u("显示")}
        };
        const QList<QPair<QString, QString>> holeRows{
            {u("完成孔颜色:"), u("青色")},
            {u("未完成孔颜色:"), u("灰白")},
            {u("H点标记:"), u("小圆十字")},
            {u("局部放大:"), u("跟随当前臂H点")},
            {u("主视图:"), u("开放")},
            {u("三维图:"), u("开放")}
        };
        for (const auto &spec : QList<QPair<QString, QList<QPair<QString, QString>>>>{
                 {u("图形显示设置"), displayRows},
                 {u("炮孔图显示"), holeRows}}) {
            auto *group = makeGroup(spec.first);
            auto *grid = new QGridLayout(group);
            grid->setContentsMargins(38, 24, 34, 16);
            grid->setHorizontalSpacing(14);
            grid->setVerticalSpacing(10);
            for (int i = 0; i < spec.second.size(); ++i) {
                addField(grid, i, spec.second.at(i).first, value(spec.second.at(i).second));
            }
            grid->setColumnStretch(1, 1);
            topLayout->addWidget(group, 1);
        }
        hostLayout->addWidget(top, 3);

        auto *data = makeGroup(u("图形数据"));
        auto *dataGrid = new QGridLayout(data);
        dataGrid->setContentsMargins(50, 24, 48, 16);
        dataGrid->setHorizontalSpacing(40);
        dataGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> dataRows{
            {u("选择炮孔三维辅助数据文件:"), QStringLiteral("--")},
            {u("选择H点回放数据文件:"), QStringLiteral("--")},
            {u("导入模拟H点轨迹:"), u("关闭")},
            {u("图形显示设置:"), u("已保存")},
            {u("断面线显示:"), u("开启")},
            {u("隧道线显示:"), u("开启")},
            {u("俯视图:"), u("开放")},
            {u("左视图:"), u("开放")}
        };
        for (int i = 0; i < dataRows.size(); ++i) {
            const int row = i % 4;
            const int col = (i / 4) * 2;
            auto *label = plainLabel(dataRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            dataGrid->addWidget(label, row, col);
            dataGrid->addWidget(value(dataRows.at(i).second), row, col + 1);
        }
        dataGrid->setColumnStretch(1, 1);
        dataGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(data, 2);
        auto *status = plainLabel(u("图形设置待保存"), QStringLiteral("sitonParamLabel"));
        hostLayout->addWidget(makeActionRow({u("保存图形设置"), u("恢复默认"), u("导出")}, status, u("图形设置已保存到本机")));
        return host;
    };

    auto makeCommunicationPage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        auto *top = new QWidget;
        top->setProperty("class", "transparent");
        auto *topLayout = new QHBoxLayout(top);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(12);

        auto *canNet = makeGroup(u("设备通讯"));
        auto *canNetGrid = new QGridLayout(canNet);
        canNetGrid->setContentsMargins(38, 24, 34, 16);
        canNetGrid->setHorizontalSpacing(14);
        canNetGrid->setVerticalSpacing(10);
        auto *moduleIp = value(QStringLiteral("192.168.0.105"));
        auto *modulePort = value(QStringLiteral("503"));
        moduleIp->setObjectName(QStringLiteral("settings.canToNet.moduleIp"));
        modulePort->setObjectName(QStringLiteral("settings.canToNet.modulePort"));
        auto *netMode = value(u("网络通讯"));
        auto *modbusMode = value(u("系统自动"));
        auto *frameRule = value(u("系统自动处理"));
        auto *netStatus = value(u("未连接通讯模块"));
        netMode->setReadOnly(true);
        modbusMode->setReadOnly(true);
        frameRule->setReadOnly(true);
        netStatus->setReadOnly(true);
        canToNetStatusEdit_ = netStatus;
        const QList<QPair<QString, QLineEdit *>> canRows{
            {u("模块IP:"), moduleIp},
            {u("模块端口:"), modulePort},
            {u("当前模式:"), netMode},
            {u("通讯参数:"), modbusMode},
            {u("数据格式:"), frameRule},
            {u("连接状态:"), netStatus}
        };
        for (int i = 0; i < canRows.size(); ++i) {
            addField(canNetGrid, i, canRows.at(i).first, canRows.at(i).second);
        }
        canNetGrid->setColumnStretch(1, 1);
        topLayout->addWidget(canNet, 1);

        auto *permission = makeGroup(u("权限级别"));
        auto *permissionGrid = new QGridLayout(permission);
        permissionGrid->setContentsMargins(38, 24, 34, 16);
        permissionGrid->setHorizontalSpacing(14);
        permissionGrid->setVerticalSpacing(10);
        const QList<QPair<QString, QString>> permissionRows{
            {u("当前用户:"), u("操作员")},
            {u("权限等级:"), u("普通")},
            {u("参数修改:"), u("锁定")},
            {u("日志清除:"), u("锁定")},
            {u("报警确认:"), u("允许")},
            {u("退出系统:"), u("允许")}
        };
        for (int i = 0; i < permissionRows.size(); ++i) {
            addField(permissionGrid, i, permissionRows.at(i).first, value(permissionRows.at(i).second));
        }
        permissionGrid->setColumnStretch(1, 1);
        topLayout->addWidget(permission, 1);
        hostLayout->addWidget(top, 3);

        auto *switches = makeGroup(u("权限开关"));
        auto *switchGrid = new QGridLayout(switches);
        switchGrid->setContentsMargins(52, 24, 50, 16);
        switchGrid->setHorizontalSpacing(52);
        switchGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> switchRows{
            {u("允许手动打孔:"), u("开启")},
            {u("允许文件导入:"), u("开启")},
            {u("允许参数导出:"), u("开启")},
            {u("维护入口:"), u("关闭")},
            {u("厂家调试:"), u("关闭")},
            {u("远程协助:"), u("关闭")},
            {u("操作确认:"), u("开启")}
        };
        for (int i = 0; i < switchRows.size(); ++i) {
            const int row = i % 4;
            const int col = (i / 4) * 2;
            auto *label = plainLabel(switchRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            switchGrid->addWidget(label, row, col);
            switchGrid->addWidget(value(switchRows.at(i).second), row, col + 1);
        }
        switchGrid->setColumnStretch(1, 1);
        switchGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(switches, 2);
        auto *status = plainLabel(u("通信设置待保存"), QStringLiteral("sitonParamLabel"));
        status->setMinimumWidth(190);
        status->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        commandStatusLabel_ = status;
        auto *actions = new QWidget;
        actions->setProperty("class", "transparent");
        auto *actionLayout = new QHBoxLayout(actions);
        actionLayout->setContentsMargins(0, 0, 12, 0);
        actionLayout->addStretch();
        for (const QString &text : {u("登录"), u("修改密码"), u("应用通讯")}) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(112);
            button->setMinimumHeight(30);
            connect(button, &QPushButton::clicked, host, [this, button, text, status, moduleIp, modulePort] {
                if (text == u("应用通讯")) {
                    bool ok = false;
                    const int portValue = modulePort->text().trimmed().toInt(&ok);
                    const quint16 port = ok && portValue > 0 && portValue <= 65535
                        ? static_cast<quint16>(portValue)
                        : quint16(503);
                    applyCanToNetConfig(moduleIp->text(), port, true);
                    const QString endpoint = QStringLiteral("%1:%2").arg(canToNetHost_).arg(canToNetPort_);
                    if (status) {
                        status->setText(u("通讯设置已应用 ") + endpoint);
                    }
                    appendLocalLog(QStringLiteral("operation"), u("通讯设置已应用：") + endpoint);
                    pulseButtonText(button, u("已应用"));
                    return;
                }
                if (status) {
                    status->setText(text + u("已执行"));
                }
                pulseButtonText(button, u("已执行"));
            });
            actionLayout->addWidget(button);
        }
        actionLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        actionLayout->addWidget(status);
        hostLayout->addWidget(actions);
        return host;
    };

    auto makeMaintenancePage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        auto *top = new QWidget;
        top->setProperty("class", "transparent");
        auto *topLayout = new QHBoxLayout(top);
        topLayout->setContentsMargins(0, 0, 0, 0);
        topLayout->setSpacing(12);

        auto *count = makeGroup(u("维护计时"));
        auto *countGrid = new QGridLayout(count);
        countGrid->setContentsMargins(38, 24, 34, 16);
        countGrid->setHorizontalSpacing(14);
        countGrid->setVerticalSpacing(10);
        const QList<QPair<QString, QString>> countRows{
            {u("左臂电机(h):"), QStringLiteral("0.00")},
            {u("中臂电机(h):"), QStringLiteral("0.00")},
            {u("右臂电机(h):"), QStringLiteral("0.00")},
            {u("液压油(h):"), QStringLiteral("0.00")},
            {u("钻头累计(h):"), QStringLiteral("0.00")},
            {u("整机累计(h):"), QStringLiteral("0.00")}
        };
        for (int i = 0; i < countRows.size(); ++i) {
            addField(countGrid, i, countRows.at(i).first, value(countRows.at(i).second));
        }
        countGrid->setColumnStretch(1, 1);
        topLayout->addWidget(count, 1);

        auto *threshold = makeGroup(u("维护阈值"));
        auto *thresholdGrid = new QGridLayout(threshold);
        thresholdGrid->setContentsMargins(38, 24, 34, 16);
        thresholdGrid->setHorizontalSpacing(14);
        thresholdGrid->setVerticalSpacing(10);
        const QList<QPair<QString, QString>> thresholdRows{
            {u("电机保养(h):"), QStringLiteral("500")},
            {u("液压油更换(h):"), QStringLiteral("1000")},
            {u("钻头提醒(h):"), QStringLiteral("80")},
            {u("润滑检查(h):"), QStringLiteral("50")},
            {u("水路检查(h):"), QStringLiteral("50")},
            {u("系统备份:"), u("每周")}
        };
        for (int i = 0; i < thresholdRows.size(); ++i) {
            addField(thresholdGrid, i, thresholdRows.at(i).first, value(thresholdRows.at(i).second));
        }
        thresholdGrid->setColumnStretch(1, 1);
        topLayout->addWidget(threshold, 1);
        hostLayout->addWidget(top, 3);

        auto *state = makeGroup(u("维护状态"));
        auto *stateGrid = new QGridLayout(state);
        stateGrid->setContentsMargins(52, 22, 50, 14);
        stateGrid->setHorizontalSpacing(42);
        stateGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> stateRows{
            {u("左臂维护:"), u("正常")},
            {u("中臂维护:"), u("正常")},
            {u("右臂维护:"), u("正常")},
            {u("液压系统:"), u("正常")},
            {u("水路系统:"), u("正常")},
            {u("润滑系统:"), u("正常")},
            {u("电气系统:"), u("正常")},
            {u("最近维护:"), QStringLiteral("--")}
        };
        for (int i = 0; i < stateRows.size(); ++i) {
            const int row = i % 4;
            const int col = (i / 4) * 2;
            auto *label = plainLabel(stateRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            stateGrid->addWidget(label, row, col);
            stateGrid->addWidget(value(stateRows.at(i).second), row, col + 1);
        }
        stateGrid->setColumnStretch(1, 1);
        stateGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(state, 2);

        auto *maintenance = makeGroup(u("维护和保养"));
        auto *maintenanceGrid = new QGridLayout(maintenance);
        maintenanceGrid->setContentsMargins(42, 18, 34, 12);
        maintenanceGrid->setHorizontalSpacing(18);
        maintenanceGrid->setVerticalSpacing(8);
        const QStringList arms{u("左臂"), u("中臂"), u("右臂")};
        for (int row = 0; row < 2; ++row) {
            auto *label = plainLabel(row == 0 ? u("钻头更换") : u("凿岩机保养"), QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            maintenanceGrid->addWidget(label, row, 0);
            for (int col = 0; col < arms.size(); ++col) {
                const QString arm = arms.at(col);
                auto *button = touchButton(arm);
                button->setProperty("class", "sitonSmallButton");
                button->setMinimumWidth(94);
                button->setMinimumHeight(28);
                connect(button, &QPushButton::clicked, this, [this, row, arm] {
                    if (row == 0) {
                        showMaintenanceOverlay(
                            this,
                            u("此操作将立即重置%1钻头作业时间，请确认%1钻头已更换，是否继续？").arg(arm),
                            [this, arm] {
            showMaintenanceOverlay(this, u("%1钻头更换记录已保存。").arg(arm));
                            });
                        return;
                    }

                    showMaintenancePasswordOverlay(this, u("请输入凿岩机保养密码"), [this, arm] {
                        showMaintenanceOverlay(this, u("%1凿岩机是否已完成保养？").arg(arm), [this, arm] {
            showMaintenanceOverlay(this, u("%1凿岩机保养记录已保存。").arg(arm));
                        });
                    });
                });
                maintenanceGrid->addWidget(button, row, col + 1);
            }
        }
        hostLayout->addWidget(maintenance);
        auto *status = plainLabel(u("维护设置待记录"), QStringLiteral("sitonParamLabel"));
        hostLayout->addWidget(makeActionRow({u("记录维护"), u("清零计时"), u("导出维护记录")}, status, u("维护记录已保存到本机")));
        return host;
    };

    auto makeArmCurrentCalibrationPage = [=]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(6);

        struct CurrentFieldSpec {
            QString label;
            QString exportName;
            QString defaultLow;
            QString defaultHigh;
        };
        const QVector<CurrentFieldSpec> currentFields{
            {u("三角伸"), u("大三角伸缩电流"), QStringLiteral("150"), QStringLiteral("850")},
            {u("大臂伸"), u("大臂伸缩电流"), QStringLiteral("120"), QStringLiteral("800")},
            {u("梁旋"), u("推进梁旋转电流"), QStringLiteral("100"), QStringLiteral("700")},
            {u("梁俯"), u("推进梁俯仰电流"), QStringLiteral("100"), QStringLiteral("700")},
            {u("左右摆"), u("推进梁左右摆电流"), QStringLiteral("100"), QStringLiteral("650")},
            {u("补偿伸"), u("推进梁补偿伸缩电流"), QStringLiteral("100"), QStringLiteral("650")},
            {u("推进压"), u("推进压力电流"), QStringLiteral("35"), QStringLiteral("100")},
            {u("冲/推压"), u("冲击/推进压力电流"), QStringLiteral("100"), QStringLiteral("220")},
            {u("推进缩"), u("推进缩电流设定"), QStringLiteral("300"), QStringLiteral("300")}
        };
        const QStringList armNames{u("左臂"), u("中臂"), u("右臂")};
        QVector<QVector<QPair<QLineEdit *, QLineEdit *>>> currentEdits;
        currentEdits.resize(armNames.size());

        auto makeCurrentValue = [](const QString &text, const QString &objectName) {
            auto *edit = new QLineEdit(text);
            edit->setObjectName(objectName);
            edit->setProperty("class", "sitonValueInput");
            edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            edit->setMinimumSize(76, 30);
            edit->setMaximumSize(136, 32);
            return edit;
        };

        auto *note = plainLabel(u("设置各动作的最小/最大电流，保存后写入本机。"),
                                QStringLiteral("sitonParamLabel"));
        note->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        note->setMinimumHeight(30);
        setCoverageHint(note, CoverageHint::Gap);
        hostLayout->addWidget(note);

        auto *tableGroup = makeGroup(u("臂架电流参数"));
        tableGroup->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        tableGroup->setMinimumHeight(430);
        tableGroup->setMaximumHeight(456);
        auto *tableGrid = new QGridLayout(tableGroup);
        tableGrid->setContentsMargins(28, 26, 28, 18);
        tableGrid->setHorizontalSpacing(10);
        tableGrid->setVerticalSpacing(8);
        tableGrid->setAlignment(Qt::AlignTop);

        const QStringList headers{
            u("动作项"),
            u("左最小"), u("左最大"),
            u("中最小"), u("中最大"),
            u("右最小"), u("右最大")
        };
        for (int col = 0; col < headers.size(); ++col) {
            auto *header = plainLabel(headers.at(col), QStringLiteral("sitonParamLabel"));
            header->setAlignment(Qt::AlignCenter);
            header->setMinimumHeight(28);
            setCoverageHint(header, CoverageHint::Gap);
            tableGrid->addWidget(header, 0, col);
        }

        for (int row = 0; row < currentFields.size(); ++row) {
            const CurrentFieldSpec &field = currentFields.at(row);
            auto *name = plainLabel(field.label, QStringLiteral("sitonParamLabel"));
            name->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            setCoverageHint(name, CoverageHint::Gap);
            tableGrid->addWidget(name, row + 1, 0);

            for (int armIndex = 0; armIndex < armNames.size(); ++armIndex) {
                auto *low = makeCurrentValue(
                    field.defaultLow,
                    QStringLiteral("settings.currentCalibration.arm%1.field%2.low").arg(armIndex).arg(row));
                auto *high = makeCurrentValue(
                    field.defaultHigh,
                    QStringLiteral("settings.currentCalibration.arm%1.field%2.high").arg(armIndex).arg(row));
                low->setMinimumWidth(86);
                high->setMinimumWidth(86);
                tableGrid->addWidget(low, row + 1, 1 + armIndex * 2, Qt::AlignCenter);
                tableGrid->addWidget(high, row + 1, 2 + armIndex * 2, Qt::AlignCenter);
                currentEdits[armIndex].append(QPair<QLineEdit *, QLineEdit *>(low, high));
            }
        }
        tableGrid->setColumnMinimumWidth(0, 150);
        tableGrid->setColumnStretch(0, 1);
        for (int col = 1; col <= 6; ++col) {
            tableGrid->setColumnMinimumWidth(col, 112);
            tableGrid->setColumnStretch(col, 0);
        }
        hostLayout->addWidget(tableGroup, 0);
        hostLayout->addStretch(1);

        auto *status = plainLabel(u("电流标定参数待保存"), QStringLiteral("sitonParamLabel"));
        auto *actions = new QWidget;
        actions->setProperty("class", "transparent");
        auto *actionsLayout = new QHBoxLayout(actions);
        actionsLayout->setContentsMargins(0, 0, 0, 0);
        actionsLayout->setSpacing(8);
        actionsLayout->addStretch();
        for (const QString &text : {u("恢复默认"), u("保存本机"), u("导出参数")}) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(110);
            connect(button, &QPushButton::clicked, page, [button, text, status, currentFields, armNames, currentEdits] {
                if (text == u("恢复默认")) {
                    for (int arm = 0; arm < currentEdits.size(); ++arm) {
                        for (int row = 0; row < currentEdits.at(arm).size(); ++row) {
                            const CurrentFieldSpec &field = currentFields.at(row);
                            if (currentEdits.at(arm).at(row).first) {
                                currentEdits.at(arm).at(row).first->setText(field.defaultLow);
                            }
                            if (currentEdits.at(arm).at(row).second) {
                                currentEdits.at(arm).at(row).second->setText(field.defaultHigh);
                            }
                        }
                    }
                    status->setText(u("电流标定默认值已恢复并写入本机"));
                    pulseButtonText(button, u("已恢复"));
                    return;
                }
                if (text == u("保存本机")) {
                    status->setText(u("电流标定参数已保存到本机"));
                    pulseButtonText(button, u("已保存"));
                    return;
                }

                QVector<QStringList> rows;
                for (int arm = 0; arm < currentEdits.size(); ++arm) {
                    for (int row = 0; row < currentEdits.at(arm).size(); ++row) {
                        const CurrentFieldSpec &field = currentFields.at(row);
                        rows.append({
                            armNames.value(arm),
                            field.exportName,
                            currentEdits.at(arm).at(row).first ? currentEdits.at(arm).at(row).first->text() : QString(),
                            currentEdits.at(arm).at(row).second ? currentEdits.at(arm).at(row).second->text() : QString()
                        });
                    }
                }
                const QString path = exportCsvRows(
                    QStringLiteral("current-calibration"),
                    {u("钻臂"), u("动作项"), u("最小"), u("最大")},
                    rows);
                status->setText(path.isEmpty() ? u("电流标定参数导出失败") : (u("已导出 ") + QFileInfo(path).fileName()));
                pulseButtonText(button, path.isEmpty() ? u("失败") : u("已导出"));
            });
            actionsLayout->addWidget(button);
        }
        actionsLayout->addSpacing(10);
        actionsLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        actionsLayout->addWidget(status, 1);
        hostLayout->addWidget(actions);
        return host;
    };

    auto pageFactories = std::make_shared<QVector<std::function<QWidget *()>>>();
    pageFactories->reserve(6);
    pageFactories->append(makeStoragePage);
    pageFactories->append(makeAlarmSettingPage);
    pageFactories->append(makeGraphicPage);
    pageFactories->append(makeCommunicationPage);
    pageFactories->append(makeMaintenancePage);
    pageFactories->append(makeArmCurrentCalibrationPage);

    auto pageBuilt = std::make_shared<QVector<bool>>(pageFactories->size(), false);
    for (int i = 0; i < pageFactories->size(); ++i) {
        auto *placeholder = new QWidget;
        placeholder->setProperty("class", "transparent");
        stack->addWidget(placeholder);
    }

    auto ensureSettingsPage = [this, stack, pageFactories, pageBuilt](int id) {
        if (id < 0 || id >= pageFactories->size() || pageBuilt->value(id)) {
            return;
        }
        QWidget *oldPage = stack->widget(id);
        QWidget *newPage = pageFactories->at(id)();
        if (newPage->objectName().isEmpty()) {
            newPage->setObjectName(QStringLiteral("settings.page.%1").arg(id));
        }
        stack->removeWidget(oldPage);
        oldPage->deleteLater();
        stack->insertWidget(id, newPage);
        (*pageBuilt)[id] = true;
        setupPersistentInputs(newPage);
    };
    ensureSettingsPage(0);

    connect(tabGroup, &QButtonGroup::idClicked, this, [this, stack, tabNames, ensureSettingsPage](int id) {
        ensureSettingsPage(id);
        stack->setCurrentIndex(id);
        const QStringList markerNames{u("文件存储"), u("报警阈值"), u("图形显示"), u("通信设置"), u("维护设置"), u("电流标定")};
        setPageMarker(QStringLiteral("P07-%1 %2")
                          .arg(id + 1, 2, 10, QLatin1Char('0'))
                          .arg(markerNames.value(id, tabNames.value(id))));
    });
    contentLayout->addWidget(stack, 1);

    layout->addWidget(content, 1);

    auto *bottom = new QWidget;
    bottom->setProperty("class", "transparent");
    auto *bottomLayout = new QHBoxLayout(bottom);
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    bottomLayout->setSpacing(8);
    for (int i = 0; i < 2; ++i) {
        auto *bar = new QFrame;
        bar->setProperty("class", "sitonBottomBar");
        bar->setMinimumHeight(40);
        bottomLayout->addWidget(bar);
    }
    layout->addWidget(bottom);
    return page;
}

QWidget *MainWindow::buildCalibrationPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(62, 8, 62, 12);
    layout->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 10);
    contentLayout->setSpacing(6);

    auto makeGroup = [](const QString &title) {
        auto *group = new QGroupBox(title);
        group->setProperty("class", "sitonGroup");
        return group;
    };
    auto makeValue = [](const QString &text, const QString &objectName = QString(), bool readOnly = false) {
        auto *edit = new QLineEdit(text);
        if (!objectName.isEmpty()) {
            edit->setObjectName(objectName);
        }
        edit->setProperty("class", "sitonValueInput");
        edit->setProperty("calibrationInput", true);
        if (!readOnly) {
            edit->setProperty("touchNumberPad", true);
        }
        edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        edit->setMinimumWidth(150);
        edit->setMinimumHeight(38);
        edit->setMaximumHeight(44);
        edit->setReadOnly(readOnly);
        return edit;
    };
    auto addField = [](QGridLayout *grid, int row, int labelCol, const QString &labelText, QWidget *editor) {
        auto *label = plainLabel(labelText, QStringLiteral("sitonParamLabel"));
        label->setProperty("calibrationLabel", true);
        label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        setCoverageHint(label, CoverageHint::Covered);
        setCoverageHint(editor, CoverageHint::Covered);
        grid->addWidget(label, row, labelCol);
        grid->addWidget(editor, row, labelCol + 1);
    };
    auto makeActionRow = [this](const QStringList &buttons, QLabel *status, const QString &doneText) {
        auto *row = new QWidget;
        row->setProperty("class", "transparent");
        auto *rowLayout = new QHBoxLayout(row);
        rowLayout->setContentsMargins(0, 0, 0, 0);
        rowLayout->setSpacing(8);
        rowLayout->addStretch();
        for (const QString &text : buttons) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(132);
            button->setMinimumHeight(40);
            connect(button, &QPushButton::clicked, row, [button, status, doneText, text] {
                if (status) {
                    status->setText(doneText.isEmpty() ? (text + u("已执行")) : doneText);
                }
                pulseButtonText(button, text.startsWith(u("保存")) ? u("已保存") : u("已执行"));
            });
            rowLayout->addWidget(button);
        }
        if (status) {
            rowLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
            rowLayout->addWidget(status, 1);
        }
        return row;
    };
    auto makeTable = [](const QStringList &headers) {
        auto *table = new QTableWidget(0, headers.size());
        table->setHorizontalHeaderLabels(headers);
        table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        table->verticalHeader()->setVisible(false);
        table->setAlternatingRowColors(true);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionMode(QAbstractItemView::NoSelection);
        return table;
    };

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabsLayout = new QHBoxLayout(tabs);
    tabsLayout->setContentsMargins(0, 0, 0, 0);
    tabsLayout->setSpacing(0);
    auto *tabGroup = new QButtonGroup(page);
    tabGroup->setExclusive(true);
    const QStringList tabNames{
        u("机械位置"), u("现场位姿"), u("机械误差补偿"), u("标定检查")
    };
    for (int i = 0; i < tabNames.size(); ++i) {
        auto *button = touchButton(tabNames.at(i));
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        tabGroup->addButton(button, i);
        tabsLayout->addWidget(button);
    }
    tabsLayout->addStretch();
    contentLayout->addWidget(tabs);

    auto *stack = new QStackedWidget;
    stack->setProperty("class", "transparent");
    const QStringList qPointHeaders{u("点号"), QStringLiteral("X(m)"), QStringLiteral("Y(m)"), QStringLiteral("Z(m)")};

    auto makePointTablePage = [&](const QString &title,
                                  const QList<QStringList> &rows,
                                  const QString &keyPrefix,
                                  const QStringList &actions,
                                  const QString &initialStatus,
                                  const QString &doneStatus) {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(8);

        auto *group = makeGroup(title);
        group->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        group->setMinimumHeight(330);
        group->setMaximumHeight(360);
        auto *grid = new QGridLayout(group);
        grid->setContentsMargins(36, 24, 36, 18);
        grid->setHorizontalSpacing(14);
        grid->setVerticalSpacing(10);
        grid->setAlignment(Qt::AlignTop);
        PointEditRows pointEdits(rows.size());
        for (int col = 0; col < qPointHeaders.size(); ++col) {
            auto *header = plainLabel(qPointHeaders.at(col), QStringLiteral("sitonParamLabel"));
            header->setProperty("calibrationLabel", true);
            header->setAlignment(Qt::AlignCenter);
            setCoverageHint(header, CoverageHint::Covered);
            grid->addWidget(header, 0, col);
        }
        for (int row = 0; row < rows.size(); ++row) {
            auto *point = plainLabel(rows.at(row).at(0), QStringLiteral("sitonParamLabel"));
            point->setProperty("calibrationLabel", true);
            point->setAlignment(Qt::AlignCenter);
            setCoverageHint(point, CoverageHint::Covered);
            grid->addWidget(point, row + 1, 0);
            for (int axis = 0; axis < 3; ++axis) {
                auto *edit = makeValue(rows.at(row).at(axis + 1),
                                       QStringLiteral("calibration.%1.%2.%3").arg(keyPrefix).arg(row).arg(axis));
                pointEdits[row][axis] = edit;
                grid->addWidget(edit, row + 1, axis + 1);
            }
        }
        grid->setColumnStretch(1, 1);
        grid->setColumnStretch(2, 1);
        grid->setColumnStretch(3, 1);
        hostLayout->addWidget(group);
        hostLayout->addStretch(1);
        auto *status = plainLabel(initialStatus, QStringLiteral("sitonParamLabel"));
        auto *actionRow = new QWidget;
        actionRow->setProperty("class", "transparent");
        auto *actionLayout = new QHBoxLayout(actionRow);
        actionLayout->setContentsMargins(0, 0, 0, 0);
        actionLayout->setSpacing(8);
        actionLayout->addStretch();
        for (const QString &text : actions) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(132);
            button->setMinimumHeight(40);
            connect(button, &QPushButton::clicked, actionRow, [this, button, status, text, doneStatus, keyPrefix, pointEdits] {
                if (text.startsWith(u("保存"))) {
                    if (status) {
                        status->setText(doneStatus);
                    }
                    pulseButtonText(button, u("已保存"));
                    return;
                }

                if (keyPrefix != QStringLiteral("qBody")) {
                    if (status) {
                        status->setText(u("该页面未配置控制器下发"));
                    }
                    return;
                }

                bool rangeOk = true;
                for (int row = 0; row < pointEdits.size(); ++row) {
                    bool okX = false;
                    bool okY = false;
                    bool okZ = false;
                    const qint16 x = metersToSignedMillimeters(pointEditMeters(pointEdits, row, 0), &okX);
                    const qint16 y = metersToSignedMillimeters(pointEditMeters(pointEdits, row, 1), &okY);
                    const qint16 z = metersToSignedMillimeters(pointEditMeters(pointEdits, row, 2), &okZ);
                    if (!okX || !okY || !okZ) {
                        rangeOk = false;
                        break;
                    }
                    const CanFrame frame = buildFactoryQBodyFrame(static_cast<quint8>(row + 1), x, y, z);
                    sendCommandFrame(u("机械四Q点"), frame.id, frame.data, frame.dlc);
                }
                if (status) {
                    status->setText(rangeOk
                        ? (canClient_.isConnected() ? u("机械四Q点已下发控制器") : u("机械四Q点已保存，通讯未连接"))
                        : u("机械四Q点超出可下发范围，请检查坐标"));
                }
                pulseButtonText(button, rangeOk ? u("已下发") : u("检查数值"));
            });
            actionLayout->addWidget(button);
        }
        if (status) {
            actionLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
            actionLayout->addWidget(status, 1);
        }
        hostLayout->addWidget(actionRow);
        return host;
    };

    auto makeFieldPosePage = [&](const QList<QStringList> &rows) {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(8);

        auto *mainRow = new QWidget;
        mainRow->setProperty("class", "transparent");
        auto *mainRowLayout = new QHBoxLayout(mainRow);
        mainRowLayout->setContentsMargins(0, 0, 0, 0);
        mainRowLayout->setSpacing(8);

        auto *poseBox = makeGroup(u("现场四Q点"));
        poseBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        auto *poseGrid = new QGridLayout(poseBox);
        poseGrid->setContentsMargins(36, 24, 36, 16);
        poseGrid->setHorizontalSpacing(14);
        poseGrid->setVerticalSpacing(8);
        poseGrid->setAlignment(Qt::AlignTop);
        PointEditRows poseEdits(rows.size());
        for (int col = 0; col < qPointHeaders.size(); ++col) {
            auto *header = plainLabel(qPointHeaders.at(col), QStringLiteral("sitonParamLabel"));
            header->setProperty("calibrationLabel", true);
            header->setAlignment(Qt::AlignCenter);
            setCoverageHint(header, CoverageHint::Covered);
            poseGrid->addWidget(header, 0, col);
        }
        for (int row = 0; row < rows.size(); ++row) {
            auto *point = plainLabel(rows.at(row).at(0), QStringLiteral("sitonParamLabel"));
            point->setProperty("calibrationLabel", true);
            point->setAlignment(Qt::AlignCenter);
            setCoverageHint(point, CoverageHint::Covered);
            poseGrid->addWidget(point, row + 1, 0);
            for (int axis = 0; axis < 3; ++axis) {
                auto *edit = makeValue(rows.at(row).at(axis + 1),
                                       QStringLiteral("calibration.qWorld.%1.%2").arg(row).arg(axis));
                poseEdits[row][axis] = edit;
                poseGrid->addWidget(edit, row + 1, axis + 1);
            }
        }
        poseGrid->setColumnStretch(1, 1);
        poseGrid->setColumnStretch(2, 1);
        poseGrid->setColumnStretch(3, 1);
        mainRowLayout->addWidget(poseBox, 3);

        auto *gaugeBox = makeGroup(u("水平姿态"));
        auto *gaugeLayout = new QVBoxLayout(gaugeBox);
        gaugeLayout->setContentsMargins(18, 24, 18, 18);
        gaugeLayout->setSpacing(12);
        auto *gauge = new LevelGaugeWidget;
        gaugeLayout->addWidget(gauge, 1);
        auto *current = new QWidget;
        current->setProperty("class", "transparent");
        auto *currentGrid = new QGridLayout(current);
        currentGrid->setContentsMargins(0, 0, 0, 0);
        currentGrid->setHorizontalSpacing(8);
        currentGrid->setVerticalSpacing(8);
        const QList<QPair<QString, QString>> currentRows{
            {u("X轴角度:"), QStringLiteral("--")},
            {u("Y轴角度:"), QStringLiteral("--")},
                {u("通讯状态:"), u("等待数据")},
            {u("本机设置:"), u("无")}
        };
        for (int i = 0; i < currentRows.size(); ++i) {
            addField(currentGrid, i, 0, currentRows.at(i).first, makeValue(currentRows.at(i).second, QString(), true));
        }
        currentGrid->setColumnStretch(1, 1);
        gaugeLayout->addWidget(current);
        mainRowLayout->addWidget(gaugeBox, 2);
        hostLayout->addWidget(mainRow, 1);
        auto *status = plainLabel(u("现场位姿待保存"), QStringLiteral("sitonParamLabel"));
        auto *actions = new QWidget;
        actions->setProperty("class", "transparent");
        auto *actionsLayout = new QHBoxLayout(actions);
        actionsLayout->setContentsMargins(0, 0, 0, 0);
        actionsLayout->setSpacing(8);
        actionsLayout->addStretch();
        for (const QString &text : {u("保存本机"), u("下发控制器")}) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(132);
            button->setMinimumHeight(40);
            connect(button, &QPushButton::clicked, actions, [this, button, status, text, poseEdits] {
                if (text.startsWith(u("保存"))) {
                    const bool captured = dashboardView_ && dashboardView_->captureWorkBaseReferenceFromFarthestHPoint();
                    if (status) {
                        status->setText(captured
                            ? u("现场位姿已保存，工作基准面已记录")
                            : u("现场位姿已保存，等待H点记录工作基准面"));
                    }
                    pulseButtonText(button, u("已保存"));
                    return;
                }

                if (poseEdits.size() < 4) {
                    if (status) {
                        status->setText(u("现场四Q点不完整，未下发"));
                    }
                    return;
                }

                const double originX = pointEditMeters(poseEdits, 3, 0);
                const double originY = pointEditMeters(poseEdits, 3, 1);
                const double originZ = pointEditMeters(poseEdits, 3, 2);
                bool rangeOk = true;
                for (int row = 0; row < poseEdits.size(); ++row) {
                    bool okX = false;
                    bool okY = false;
                    bool okZ = false;
                    const qint16 x = metersToSignedMillimeters(pointEditMeters(poseEdits, row, 0) - originX, &okX);
                    const qint16 y = metersToSignedMillimeters(pointEditMeters(poseEdits, row, 1) - originY, &okY);
                    const qint16 z = metersToSignedMillimeters(pointEditMeters(poseEdits, row, 2) - originZ, &okZ);
                    if (!okX || !okY || !okZ) {
                        rangeOk = false;
                        break;
                    }
                    const CanFrame frame = buildVehiclePoseQWorldFrame(static_cast<quint8>(row + 1), x, y, z);
                    sendCommandFrame(u("现场四Q点"), frame.id, frame.data, frame.dlc);
                }
                if (status) {
                    status->setText(rangeOk
                        ? (canClient_.isConnected() ? u("现场四Q点已下发控制器") : u("现场四Q点已保存，通讯未连接"))
                        : u("现场四Q点超出可下发范围，请检查Q4基准"));
                }
                pulseButtonText(button, rangeOk ? u("已下发") : u("检查数值"));
            });
            actionsLayout->addWidget(button);
        }
        actionsLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        actionsLayout->addWidget(status, 1);
        hostLayout->addWidget(actions);
        return host;
    };

    auto makeMechanicalPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(8);

        auto *armSelect = new QWidget;
        armSelect->setProperty("class", "transparent");
        auto *armSelectLayout = new QHBoxLayout(armSelect);
        armSelectLayout->setContentsMargins(0, 0, 0, 0);
        armSelectLayout->setSpacing(8);
        armSelectLayout->addWidget(plainLabel(u("样本对象:"), QStringLiteral("sitonParamLabel")));
        auto *sampleArmGroup = new QButtonGroup(host);
        sampleArmGroup->setExclusive(true);
        const QStringList sampleArmNames{u("左臂"), u("中臂"), u("右臂")};
        for (int armIndex = 0; armIndex < sampleArmNames.size(); ++armIndex) {
            auto *button = touchButton(sampleArmNames.at(armIndex));
            button->setProperty("class", "sitonSmallButton");
            button->setCheckable(true);
            button->setChecked(armIndex == 0);
            button->setMinimumWidth(112);
            sampleArmGroup->addButton(button, armIndex);
            armSelectLayout->addWidget(button);
        }
        armSelectLayout->addStretch();
        hostLayout->addWidget(armSelect);

        auto *input = makeGroup(u("H点样本"));
        auto *inputGrid = new QGridLayout(input);
        inputGrid->setContentsMargins(36, 24, 36, 18);
        inputGrid->setHorizontalSpacing(28);
        inputGrid->setVerticalSpacing(12);
        constexpr int kSampleInputWidth = 320;
        const QList<QPair<QString, QString>> inputRows{
            {u("H点计算X(m)"), QStringLiteral("0.000")},
            {u("H点计算Y(m)"), QStringLiteral("0.000")},
            {u("H点计算Z(m)"), QStringLiteral("0.000")},
            {u("全站仪H点测量X(m)"), QStringLiteral("0.000")},
            {u("全站仪H点测量Y(m)"), QStringLiteral("0.000")},
            {u("全站仪H点测量Z(m)"), QStringLiteral("0.000")}
        };
        QVector<QPointer<QLineEdit>> sampleEdits;
        for (int i = 0; i < inputRows.size(); ++i) {
            auto *edit = makeValue(inputRows.at(i).second,
                                   QStringLiteral("calibration.mechanical.input.%1").arg(i));
            edit->setFixedWidth(kSampleInputWidth);
            edit->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
            sampleEdits.append(edit);

            auto *cell = new QWidget;
            cell->setProperty("class", "transparent");
            auto *cellLayout = new QVBoxLayout(cell);
            cellLayout->setContentsMargins(0, 0, 0, 0);
            cellLayout->setSpacing(6);
            auto *label = plainLabel(inputRows.at(i).first, QStringLiteral("sitonParamLabel"));
            label->setProperty("calibrationLabel", true);
            label->setAlignment(Qt::AlignCenter);
            label->setFixedWidth(kSampleInputWidth);
            setCoverageHint(label, CoverageHint::Covered);
            cellLayout->addWidget(label, 0, Qt::AlignHCenter);
            cellLayout->addWidget(edit, 0, Qt::AlignHCenter);
            inputGrid->addWidget(cell, i / 3, i % 3, Qt::AlignCenter);
        }
        for (int col = 0; col < 3; ++col) {
            inputGrid->setColumnStretch(col, 1);
        }
        hostLayout->addWidget(input);

        auto *table = makeTable({u("序号"),
                                 u("计算X(m)"), u("计算Y(m)"), u("计算Z(m)"),
                                 u("实测X(m)"), u("实测Y(m)"), u("实测Z(m)"),
                                 u("误差(mm)")});
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Fixed);
        table->horizontalHeader()->setSectionResizeMode(7, QHeaderView::Fixed);
        table->setColumnWidth(0, 90);
        table->setColumnWidth(7, 140);
        table->setProperty("sampleCount", 0);
        hostLayout->addWidget(table, 1);

        auto *status = plainLabel(u("左臂：有效样本 0/20，补偿拟合未开放"), QStringLiteral("sitonParamLabel"));
        auto selectedSampleArmIndex = [sampleArmGroup, table] {
            const int checkedId = sampleArmGroup ? sampleArmGroup->checkedId() : table->property("sampleArmIndex").toInt();
            return safeMechanicalSampleArmIndex(checkedId);
        };
        auto updateCurrentSampleStatus = [status, sampleArmNames](int armIndex, int count, const QString &extra) {
            updateMechanicalSampleStatus(status, count, extra, sampleArmNames.value(armIndex, u("左臂")));
        };
        const int initialArmIndex = selectedSampleArmIndex();
        const int loadedSamples = loadMechanicalSamples(table, initialArmIndex);
        updateCurrentSampleStatus(initialArmIndex, loadedSamples, loadedSamples > 0 ? u("已加载") : QString());
        auto *actions = new QWidget;
        actions->setProperty("class", "transparent");
        auto *actionsLayout = new QHBoxLayout(actions);
        actionsLayout->setContentsMargins(0, 0, 0, 0);
        actionsLayout->setSpacing(8);
        actionsLayout->addStretch();
        auto *record = touchButton(u("记录样本"));
        auto *save = touchButton(u("保存样本"));
        auto *clear = touchButton(u("清空选中"));
        auto *finish = touchButton(u("拟合完成"));
        for (QPushButton *button : {record, save, clear, finish}) {
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumWidth(112);
            actionsLayout->addWidget(button);
        }
        actionsLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        actionsLayout->addWidget(status, 1);
        connect(sampleArmGroup, &QButtonGroup::idClicked, table, [table, updateCurrentSampleStatus](int id) {
            const int previousArmIndex = safeMechanicalSampleArmIndex(table->property("sampleArmIndex").toInt());
            saveMechanicalSamples(table, previousArmIndex);
            const int armIndex = safeMechanicalSampleArmIndex(id);
            const int loaded = loadMechanicalSamples(table, armIndex);
            updateCurrentSampleStatus(armIndex, loaded, loaded > 0 ? u("已加载") : QString());
        });
        connect(record, &QPushButton::clicked, table, [this, table, sampleEdits, sampleArmNames, selectedSampleArmIndex, updateCurrentSampleStatus] {
            const int armIndex = selectedSampleArmIndex();
            const int count = table->rowCount();
            if (count >= kMechanicalSampleMaxRows) {
                updateCurrentSampleStatus(armIndex, count, u("已满，请先清空或编辑"));
                return;
            }
            const int row = table->rowCount();
            table->insertRow(row);
            auto valueText = [sampleEdits](int index) {
                if (index < 0 || index >= sampleEdits.size() || !sampleEdits.at(index)) {
                    return QStringLiteral("0.000");
                }
                return sampleEdits.at(index)->text().trimmed().isEmpty()
                    ? QStringLiteral("0.000")
                    : sampleEdits.at(index)->text().trimmed();
            };
            const double targetX = sampleEdits.value(0) ? inputDouble(sampleEdits.value(0)) : 0.0;
            const double targetY = sampleEdits.value(1) ? inputDouble(sampleEdits.value(1)) : 0.0;
            const double targetZ = sampleEdits.value(2) ? inputDouble(sampleEdits.value(2)) : 0.0;
            const double measuredX = sampleEdits.value(3) ? inputDouble(sampleEdits.value(3)) : 0.0;
            const double measuredY = sampleEdits.value(4) ? inputDouble(sampleEdits.value(4)) : 0.0;
            const double measuredZ = sampleEdits.value(5) ? inputDouble(sampleEdits.value(5)) : 0.0;
            const double errorMm = qSqrt(qPow(measuredX - targetX, 2)
                                       + qPow(measuredY - targetY, 2)
                                       + qPow(measuredZ - targetZ, 2)) * 1000.0;
            const QStringList cells{
                QString::number(count + 1),
                valueText(0), valueText(1), valueText(2),
                valueText(3), valueText(4), valueText(5),
                QString::number(errorMm, 'f', 1)
            };
            for (int col = 0; col < cells.size(); ++col) {
                setCenteredTableText(table, row, col, cells.at(col));
            }
            renumberMechanicalSamples(table);
            table->selectRow(row);
            saveMechanicalSamples(table, armIndex);
            bool originOkX = false;
            bool originOkY = false;
            bool originOkZ = false;
            const double originX = savedLineEditText(QStringLiteral("calibration.qWorld.3.0"), QStringLiteral("0")).toDouble(&originOkX);
            const double originY = savedLineEditText(QStringLiteral("calibration.qWorld.3.1"), QStringLiteral("0")).toDouble(&originOkY);
            const double originZ = savedLineEditText(QStringLiteral("calibration.qWorld.3.2"), QStringLiteral("0")).toDouble(&originOkZ);
            bool okX = false;
            bool okY = false;
            bool okZ = false;
            const qint16 hX = metersToSignedMillimeters(measuredX - (originOkX ? originX : 0.0), &okX);
            const qint16 hY = metersToSignedMillimeters(measuredY - (originOkY ? originY : 0.0), &okY);
            const qint16 hZ = metersToSignedMillimeters(measuredZ - (originOkZ ? originZ : 0.0), &okZ);
            if (originOkX && originOkY && originOkZ && okX && okY && okZ) {
                const CanFrame frame = buildMechanicalErrorSampleFrame(armIndex, static_cast<quint8>(row), hX, hY, hZ);
                sendCommandFrame(sampleArmNames.value(armIndex, u("左臂")) + u("H点样本"), frame.id, frame.data, frame.dlc);
                updateCurrentSampleStatus(armIndex, count + 1,
                                          canClient_.isConnected() ? u("已保存并下发") : u("已保存，通讯未连接"));
            } else {
                updateCurrentSampleStatus(armIndex, count + 1, u("现场Q4缺失或实测H点超出可下发范围"));
            }
        });
        connect(save, &QPushButton::clicked, table, [save, table, selectedSampleArmIndex, updateCurrentSampleStatus] {
            const int armIndex = selectedSampleArmIndex();
            saveMechanicalSamples(table, armIndex);
            updateCurrentSampleStatus(armIndex, table->rowCount(), u("已保存"));
            pulseButtonText(save, u("已保存"));
        });
        connect(table, &QTableWidget::cellClicked, table, [this, table](int row, int column) {
            if (row < 0) {
                return;
            }
            table->selectRow(row);
            if (column < 1 || column > 6) {
                return;
            }
            QTableWidgetItem *item = table->item(row, column);
            if (!item) {
                return;
            }
            QLineEdit editor(item->text());
            editor.setCursorPosition(editor.text().size());
            editor.setProperty("touchNumberPad", true);
            showTouchNumberPad(&editor);
            item->setText(editor.text().trimmed());
            refreshMechanicalSampleError(table, row);
            saveMechanicalSamples(table, safeMechanicalSampleArmIndex(table->property("sampleArmIndex").toInt()));
        });
        connect(clear, &QPushButton::clicked, table, [table, selectedSampleArmIndex, updateCurrentSampleStatus] {
            const int armIndex = selectedSampleArmIndex();
            int row = table->currentRow();
            if ((row < 0 || row >= table->rowCount()) && table->selectionModel()) {
                const QModelIndexList selectedRows = table->selectionModel()->selectedRows();
                if (!selectedRows.isEmpty()) {
                    row = selectedRows.first().row();
                }
            }
            if (row < 0 || row >= table->rowCount()) {
                updateCurrentSampleStatus(armIndex, table->rowCount(), u("请先选择一条样本"));
                return;
            }
            table->removeRow(row);
            renumberMechanicalSamples(table);
            saveMechanicalSamples(table, armIndex);
            if (table->rowCount() > 0) {
                table->selectRow(qMin(row, table->rowCount() - 1));
            }
            updateCurrentSampleStatus(armIndex, table->rowCount(), u("已清空选中样本"));
        });
        connect(finish, &QPushButton::clicked, table, [this, table, sampleArmNames, selectedSampleArmIndex, updateCurrentSampleStatus] {
            const int armIndex = selectedSampleArmIndex();
            const int count = table->rowCount();
            saveMechanicalSamples(table, armIndex);
            if (count < kMechanicalSampleMaxRows) {
                updateCurrentSampleStatus(armIndex, count, u("样本不足20组，暂不允许补偿拟合"));
                return;
            }
            const CanFrame frame = buildMechanicalErrorFitFrame(armIndex);
            sendCommandFrame(sampleArmNames.value(armIndex, u("左臂")) + u("机械误差拟合完成"), frame.id, frame.data, frame.dlc);
            updateCurrentSampleStatus(armIndex, count,
                                      canClient_.isConnected() ? u("机械误差补偿已下发控制器") : u("机械误差补偿已保存，通讯未连接"));
        });
        hostLayout->addWidget(actions);
        return host;
    };

    auto makeValidationPage = [&]() {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(8);

        auto *result = makeGroup(u("进入主界面检查"));
        auto *resultGrid = new QGridLayout(result);
        resultGrid->setContentsMargins(40, 26, 40, 20);
        resultGrid->setHorizontalSpacing(18);
        resultGrid->setVerticalSpacing(12);
        const QList<QPair<QString, QString>> rows{
            {u("机械四Q点:"), u("待保存")},
            {u("现场位姿:"), u("待保存")},
            {u("H点样本:"), u("0/20")},
            {u("炮孔图:"), u("未加载")},
            {u("设备反馈:"), u("等待")},
            {u("结果:"), u("不可进入")}
        };
        for (int i = 0; i < rows.size(); ++i) {
            addField(resultGrid, i / 2, (i % 2) * 2, rows.at(i).first, makeValue(rows.at(i).second, QString(), true));
        }
        resultGrid->setColumnStretch(1, 1);
        resultGrid->setColumnStretch(3, 1);
        hostLayout->addWidget(result, 1);
        auto *status = plainLabel(u("标定未完成，主界面炮孔图暂不放行"), QStringLiteral("sitonParamLabel"));
        auto *row = makeActionRow({u("检查状态"), u("保存结果")}, status, u("标定检查结果已保存到本机"));
        auto *back = touchButton(u("返回主界面"));
        back->setProperty("class", "sitonSmallButton");
        back->setMinimumWidth(112);
        connect(back, &QPushButton::clicked, this, [this] { switchPage(0); });
        row->layout()->addWidget(back);
        hostLayout->addWidget(row);
        return host;
    };

    const QList<QStringList> qBodyRows{
        {QStringLiteral("Q1"), QStringLiteral("-1.0113"), QStringLiteral("1.4386"), QStringLiteral("0.4341")},
        {QStringLiteral("Q2"), QStringLiteral("-2.6048"), QStringLiteral("1.3724"), QStringLiteral("-0.7573")},
        {QStringLiteral("Q3"), QStringLiteral("-1.0074"), QStringLiteral("-1.5646"), QStringLiteral("0.5359")},
        {QStringLiteral("Q4"), QStringLiteral("-2.6108"), QStringLiteral("-1.5013"), QStringLiteral("-0.7597")}
    };
    const QList<QStringList> qWorldRows{
        {QStringLiteral("Q1"), QStringLiteral("474708.1602"), QStringLiteral("3012843.6306"), QStringLiteral("239.5486")},
        {QStringLiteral("Q2"), QStringLiteral("474708.1304"), QStringLiteral("3012845.2330"), QStringLiteral("238.2545")},
        {QStringLiteral("Q3"), QStringLiteral("0.0000"), QStringLiteral("0.0000"), QStringLiteral("0.0000")},
        {QStringLiteral("Q4"), QStringLiteral("0.0000"), QStringLiteral("0.0000"), QStringLiteral("0.0000")}
    };

    stack->addWidget(makePointTablePage(u("机械四Q点"), qBodyRows, QStringLiteral("qBody"),
                                        {u("保存本机"), u("下发控制器")}, u("机械四Q点待保存"),
                                        u("机械四Q点已保存")));
    stack->addWidget(makeFieldPosePage(qWorldRows));
    stack->addWidget(makeMechanicalPage());
    stack->addWidget(makeValidationPage());
    connect(tabGroup, &QButtonGroup::idClicked, this, [this, stack, tabNames](int id) {
        stack->setCurrentIndex(id);
        setPageMarker(QStringLiteral("P10-%1 %2")
                          .arg(id + 1, 2, 10, QLatin1Char('0'))
                          .arg(tabNames.value(id)));
    });
    contentLayout->addWidget(stack, 1);
    layout->addWidget(content, 1);

    auto *bottom = new QWidget;
    bottom->setProperty("class", "transparent");
    auto *bottomLayout = new QHBoxLayout(bottom);
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    bottomLayout->setSpacing(8);
    for (int i = 0; i < 2; ++i) {
        auto *bar = new QFrame;
        bar->setProperty("class", "sitonBottomBar");
        bar->setMinimumHeight(40);
        bottomLayout->addWidget(bar);
    }
    layout->addWidget(bottom);
    return page;
}

QWidget *MainWindow::buildDrillPresetPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(58, 10, 58, 16);
    layout->setSpacing(8);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(14, 14, 14, 12);
    contentLayout->setSpacing(6);

    auto makeGroup = [](const QString &title) {
        auto *group = new QGroupBox(title);
        group->setProperty("class", "sitonGroup");
        return group;
    };
    auto makeValue = [](const QString &text, const QString &objectName = QString()) {
        auto *edit = new QLineEdit(text);
        if (!objectName.isEmpty()) {
            edit->setObjectName(objectName);
        }
        edit->setProperty("class", "sitonValueInput");
        edit->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
        edit->setMinimumSize(96, 24);
        edit->setMaximumHeight(24);
        return edit;
    };
    auto makeCombo = [](const QString &text, const QStringList &items, const QString &objectName = QString()) {
        auto *combo = new QComboBox;
        if (!objectName.isEmpty()) {
            combo->setObjectName(objectName);
        }
        combo->setProperty("class", "sitonValueInput");
        combo->addItems(items);
        const int index = combo->findText(text);
        if (index >= 0) {
            combo->setCurrentIndex(index);
        }
        combo->setMinimumSize(96, 24);
        combo->setMaximumHeight(24);
        return combo;
    };

    struct ArmPreset {
        QString name;
        QString diameter;
        QStringList values;
    };
    const QStringList labels{
        u("二级卡钎压力(0-200)bar"),
        u("推进保护压力(0-100)bar"),
        u("领孔推进压力比率(0-100)%"),
        u("钻孔推进压力比率(0-100)%"),
        u("领孔冲击压力比率(0-100)%"),
        u("钻孔冲击压力比率(0-100)%"),
        u("领孔深度(0-0.5)m"),
        u("钻孔深度(0-6.0)m"),
        u("推进梁寻岩压力(20-60)bar"),
        u("钻机寻岩压力(20-50)bar"),
        u("梁回退(0-3.0)m"),
        u("大臂回退(0-3.0)m"),
        u("洗孔模式:"),
        u("气洗时间(0-30)s"),
        u("钻孔回转速度比率(0-100)%"),
        u("缓冲与推进压力差(0-100)bar"),
        u("钻孔推进速度比率(0-100)%"),
        u("一级卡钎压力(0-100)bar"),
        u("领孔推进速度比率(0-100)%"),
        u("领孔回转速度比率(0-100)%")
    };
    const QVector<ArmPreset> arms{
        {u("左臂"), u("左臂Ø45"),
         {QStringLiteral("92"), QStringLiteral("35"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("40"),
          QStringLiteral("65"), QStringLiteral("0.3"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("30"),
          QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
          QStringLiteral("15"), QStringLiteral("100"), QStringLiteral("80"), QStringLiteral("75"), QStringLiteral("50")}},
        {u("中臂"), u("中臂Ø45"),
         {QStringLiteral("94"), QStringLiteral("35"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("43"),
          QStringLiteral("65"), QStringLiteral("0.3"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("20"),
          QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
          QStringLiteral("15"), QStringLiteral("90"), QStringLiteral("85"), QStringLiteral("75"), QStringLiteral("50")}},
        {u("右臂"), u("右臂Ø45"),
         {QStringLiteral("94"), QStringLiteral("40"), QStringLiteral("25"), QStringLiteral("43"), QStringLiteral("41"),
          QStringLiteral("60"), QStringLiteral("0.4"), QStringLiteral("5"), QStringLiteral("30"), QStringLiteral("30"),
          QStringLiteral("0.3"), QStringLiteral("0.3"), u("无洗孔"), QStringLiteral("5"), QStringLiteral("75"),
          QStringLiteral("15"), QStringLiteral("100"), QStringLiteral("85"), QStringLiteral("75"), QStringLiteral("50")}}
    };

    auto *columns = new QWidget;
    columns->setProperty("class", "transparent");
    auto *columnsLayout = new QHBoxLayout(columns);
    columnsLayout->setContentsMargins(0, 0, 0, 0);
    columnsLayout->setSpacing(10);
    QVector<QPair<QLineEdit *, QString>> presetEdits;
    QVector<QPair<QComboBox *, int>> presetCombos;
    std::array<std::array<QPointer<QLineEdit>, 20>, 3> armPresetEdits;
    for (int armIndex = 0; armIndex < arms.size(); ++armIndex) {
        const ArmPreset &arm = arms.at(armIndex);
        auto *group = makeGroup(arm.name);
        auto *grid = new QGridLayout(group);
        grid->setContentsMargins(8, 16, 8, 10);
        grid->setHorizontalSpacing(6);
        grid->setVerticalSpacing(4);
        auto *diameterLabel = plainLabel(u("钻头直径(mm)"), QStringLiteral("sitonParamLabel"));
        diameterLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
        setCoverageHint(diameterLabel, CoverageHint::Covered);
        auto *diameterCombo = makeCombo(
            arm.diameter,
            {u("左臂Ø45"), u("中臂Ø45"), u("右臂Ø45"), u("Ø51"), u("Ø64")},
            QStringLiteral("drillPreset.arm%1.diameter").arg(armIndex));
        presetCombos.append({diameterCombo, diameterCombo->currentIndex()});
        grid->addWidget(diameterLabel, 0, 0);
        grid->addWidget(diameterCombo, 0, 1);
        for (int i = 0; i < labels.size(); ++i) {
            auto *label = plainLabel(labels.at(i), QStringLiteral("sitonParamLabel"));
            label->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
            setCoverageHint(label, CoverageHint::Covered);
            grid->addWidget(label, i + 1, 0);
            QWidget *input = nullptr;
            if (labels.at(i) == u("洗孔模式:")) {
                auto *combo = makeCombo(
                    arm.values.at(i),
                    {u("无洗孔"), u("气洗"), u("水洗")},
                    QStringLiteral("drillPreset.arm%1.washMode").arg(armIndex));
                presetCombos.append({combo, combo->currentIndex()});
                input = combo;
            } else {
                auto *edit = makeValue(
                    arm.values.at(i),
                    QStringLiteral("drillPreset.arm%1.field%2").arg(armIndex).arg(i));
                presetEdits.append({edit, arm.values.at(i)});
                armPresetEdits[static_cast<size_t>(armIndex)][static_cast<size_t>(i)] = edit;
                input = edit;
            }
            grid->addWidget(input, i + 1, 1);
        }
        columnsLayout->addWidget(group, 1);
    }
    auto *scroll = new QScrollArea;
    scroll->setProperty("class", "sitonTouchScroll");
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    QScroller::grabGesture(scroll->viewport(), QScroller::TouchGesture);
    scroll->setWidget(columns);
    contentLayout->addWidget(scroll, 1);

    auto *actions = new QWidget;
    actions->setProperty("class", "transparent");
    auto *actionLayout = new QHBoxLayout(actions);
    actionLayout->setContentsMargins(0, 0, 0, 0);
    auto *backButton = touchButton(u("返回设置"));
    backButton->setProperty("class", "sitonSmallButton");
    backButton->setMinimumWidth(120);
    backButton->setMinimumHeight(28);
    connect(backButton, &QPushButton::clicked, this, [this] { switchPage(2); });
    actionLayout->addWidget(backButton);
    actionLayout->addStretch(2);
    QPointer<QPushButton> confirmButton;
    QPointer<QPushButton> refreshButton;
    for (const QString &text : {u("确认"), u("刷新")}) {
        auto *button = touchButton(text);
        button->setProperty("class", "sitonSmallButton");
        button->setMinimumWidth(148);
        button->setMinimumHeight(28);
        if (text == u("确认")) {
            confirmButton = button;
        } else if (text == u("刷新")) {
            refreshButton = button;
        }
        actionLayout->addWidget(button);
    }
    connect(refreshButton, &QPushButton::clicked, page, [presetEdits, presetCombos] {
        for (const auto &entry : presetEdits) {
            if (entry.first) {
                entry.first->setText(entry.second);
            }
        }
        for (const auto &entry : presetCombos) {
            if (entry.first) {
                entry.first->setCurrentIndex(entry.second);
            }
        }
    });
    connect(confirmButton, &QPushButton::clicked, page, [this, confirmButton, armPresetEdits] {
        if (!confirmButton) {
            return;
        }
        std::array<ArmDrillPreset, 3> presets;
        for (int arm = 0; arm < 3; ++arm) {
            const auto &edits = armPresetEdits[static_cast<size_t>(arm)];
            ArmDrillPreset &preset = presets[static_cast<size_t>(arm)];
            preset.drillingDepthMm = inputMetersToMm(edits[7]);
            preset.leadHoleDepthMm = inputMetersToMm(edits[6]);
            preset.antiJamPressure1 = inputU8(edits[17]);
            preset.antiJamPressure2 = inputU8(edits[0]);
            preset.antiEmptyHighPressure = inputU8(edits[1]);
            preset.roofPressure = inputU8(edits[8]);
            preset.leadThrustPressure = inputU8(edits[2]);
            preset.leadImpactPressure = inputU8(edits[4]);
            preset.leadThrustSpeed = inputU8(edits[18]);
            preset.leadRotationSpeed = inputU8(edits[19]);
            preset.drillingThrustPressure = inputU8(edits[3]);
            preset.drillingImpactPressure = inputU8(edits[5]);
            preset.drillingThrustSpeed = inputU8(edits[16]);
            preset.drillingRotationSpeed = inputU8(edits[14]);
        }
        const QVector<CanFrame> frames = buildDrillPresetFrames(presets);
        for (const CanFrame &frame : frames) {
            sendCommandFrame(u("钻机参数预设下发"), frame.id, frame.data, frame.dlc);
        }
        confirmButton->setText(u("已下发%1帧").arg(frames.size()));
        QTimer::singleShot(900, confirmButton, [confirmButton] {
            if (confirmButton) {
                confirmButton->setText(u("确认"));
            }
        });
    });
    actionLayout->addStretch();
    contentLayout->addWidget(actions);
    layout->addWidget(content, 1);
    return page;
}

QWidget *MainWindow::buildRockProtectionPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(170, 12, 170, 16);
    layout->setSpacing(8);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(70, 16, 70, 18);
    contentLayout->setSpacing(16);

    auto makeCard = [this](const QString &title, int protectionIndex) {
        auto *card = new QFrame;
        card->setProperty("class", "sitonProtectCard");
        auto *cardLayout = new QVBoxLayout(card);
        cardLayout->setContentsMargins(0, 0, 0, 12);
        cardLayout->setSpacing(4);
        cardLayout->setAlignment(Qt::AlignTop);

        auto *header = plainLabel(title, QStringLiteral("sitonProtectTitle"));
        header->setAlignment(Qt::AlignCenter);
        header->setFixedHeight(38);
        header->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        cardLayout->addWidget(header);

        auto *line = new QFrame;
        line->setProperty("class", "sitonProtectLine");
        line->setFixedHeight(2);
        cardLayout->addWidget(line);

        cardLayout->addSpacing(12);
        auto *icon = new LockCircleIcon;
        cardLayout->addWidget(icon, 0, Qt::AlignHCenter);
        cardLayout->addSpacing(4);

        auto *state = plainLabel(u("保护锁定"), QStringLiteral("sitonProtectState"));
        state->setAlignment(Qt::AlignCenter);
        state->setFixedHeight(22);
        state->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        cardLayout->addWidget(state);

        auto *desc = plainLabel(u("当前处于保护锁定状态，\n参数异常停止凿岩"), QStringLiteral("sitonProtectDesc"));
        desc->setWordWrap(true);
        desc->setAlignment(Qt::AlignCenter);
        desc->setFixedHeight(48);
        desc->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        cardLayout->addWidget(desc);
        cardLayout->addSpacing(8);

        auto *release = touchButton(u("解除锁定"));
        release->setProperty("class", "sitonSmallButton");
        release->setFixedSize(94, 28);
        release->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        connect(release, &QPushButton::clicked, card, [this, release = QPointer<QPushButton>(release),
                                                        state = QPointer<QLabel>(state),
                                                        desc = QPointer<QLabel>(desc),
                                                        title] {
            showMaintenancePasswordOverlay(this, u("请输入凿岩保护解除密码"), [release, state, desc, title] {
                if (state) {
                    state->setText(u("解除申请已记录"));
                }
                if (desc) {
            desc->setText(u("%1解除申请已记录。").arg(title));
                }
                if (release) {
                    pulseButtonText(release, u("已记录"));
                }
            });
        });
        cardLayout->addWidget(release, 0, Qt::AlignHCenter);
        return card;
    };

    auto *grid = new QWidget;
    grid->setProperty("class", "transparent");
    auto *gridLayout = new QGridLayout(grid);
    gridLayout->setContentsMargins(0, 0, 0, 0);
    gridLayout->setHorizontalSpacing(14);
    gridLayout->setVerticalSpacing(14);
    const QStringList titles{
        u("左臂水压力"), u("中臂水压力"), u("右臂水压力"),
        u("左臂润滑压力"), u("中臂润滑压力"), u("右臂润滑压力")
    };
    for (int i = 0; i < titles.size(); ++i) {
        auto *card = makeCard(titles.at(i), i);
        card->setMinimumSize(240, 320);
        gridLayout->addWidget(card, i / 3, i % 3);
    }
    contentLayout->addWidget(grid, 0, Qt::AlignHCenter | Qt::AlignTop);
    contentLayout->addStretch();
    auto *actions = new QWidget;
    actions->setProperty("class", "transparent");
    auto *actionLayout = new QHBoxLayout(actions);
    actionLayout->setContentsMargins(0, 0, 0, 0);
    actionLayout->addStretch();
    auto *backButton = touchButton(u("返回设置"));
    backButton->setProperty("class", "sitonSmallButton");
    backButton->setMinimumWidth(120);
    backButton->setMinimumHeight(28);
    connect(backButton, &QPushButton::clicked, this, [this] { switchPage(2); });
    actionLayout->addWidget(backButton);
    contentLayout->addWidget(actions);
    layout->addWidget(content, 1);

    auto *bottom = new QWidget;
    bottom->setProperty("class", "transparent");
    auto *bottomLayout = new QHBoxLayout(bottom);
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    bottomLayout->setSpacing(8);
    for (int i = 0; i < 2; ++i) {
        auto *bar = new QFrame;
        bar->setProperty("class", "sitonBottomBar");
        bar->setMinimumHeight(40);
        bottomLayout->addWidget(bar);
    }
    layout->addWidget(bottom);
    return page;
}

QWidget *MainWindow::buildAlarmsPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(54, 10, 54, 16);
    layout->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(10, 8, 10, 10);
    contentLayout->setSpacing(6);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabLayout = new QHBoxLayout(tabs);
    tabLayout->setContentsMargins(0, 0, 0, 0);
    tabLayout->setSpacing(0);
    auto *tabGroup = new QButtonGroup(page);
    tabGroup->setExclusive(true);
    const QStringList tabNames{u("全部报警"), u("未恢复报警"), u("已恢复报警"), u("倾斜和碰撞报警"), u("历史报警")};
    for (int i = 0; i < tabNames.size(); ++i) {
        auto *button = touchButton(tabNames.at(i));
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        tabGroup->addButton(button, i);
        tabLayout->addWidget(button);
    }
    tabLayout->addStretch();
    auto makePagerButton = [this](const QString &text, bool checked = false) {
        auto *button = touchButton(text);
        button->setProperty("class", "sitonPagerButton");
        button->setCheckable(true);
        button->setChecked(checked);
        button->setFixedSize(text.size() > 2 ? 46 : 34, 34);
        return button;
    };
    tabLayout->addWidget(makePagerButton(QStringLiteral("‹")));
    tabLayout->addWidget(makePagerButton(QStringLiteral("1"), true));
    auto *pageInfo = plainLabel(u("每页30条  当前0条/0条"), QStringLiteral("sitonPagerText"));
    alarmPageInfo_ = pageInfo;
    pageInfo->setAlignment(Qt::AlignCenter);
    pageInfo->setMinimumWidth(190);
    tabLayout->addWidget(pageInfo);
    tabLayout->addWidget(makePagerButton(QStringLiteral("›")));
    contentLayout->addWidget(tabs);

    auto *table = new QTableWidget;
    alarmTable_ = table;
    table->setObjectName(QStringLiteral("alarmFullTable"));
    table->setProperty("class", "sitonAlarmFullTable");
    table->setColumnCount(4);
    table->setHorizontalHeaderLabels({u("故障报警时间"), u("故障消失时间"), u("故障码"), u("故障内容")});
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    table->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    table->horizontalHeader()->setMinimumSectionSize(150);
    table->setColumnWidth(0, 260);
    table->setColumnWidth(1, 260);
    table->setColumnWidth(2, 170);
    table->verticalHeader()->setVisible(false);
    table->setFrameShape(QFrame::NoFrame);
    table->setShowGrid(true);
    table->setTextElideMode(Qt::ElideNone);
    table->setWordWrap(false);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
    table->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    table->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    table->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    table->setAlternatingRowColors(false);
    table->setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 10, QFont::DemiBold));
    table->horizontalHeader()->setFont(QFont(QStringLiteral("Microsoft YaHei UI"), 11, QFont::Bold));
    table->horizontalHeader()->setFixedHeight(34);
    table->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    table->verticalHeader()->setMinimumSectionSize(16);
    table->verticalHeader()->setDefaultSectionSize(18);
    table->setMinimumHeight(578);
    table->setStyleSheet(QStringLiteral(R"(
        QTableWidget#alarmFullTable {
            background: #020202;
            alternate-background-color: #020202;
            color: #f2f2f2;
            gridline-color: #303030;
            border: none;
            border-radius: 4px;
            selection-background-color: #33406d;
            selection-color: #ffffff;
            font-size: 13px;
        }
        QTableWidget#alarmFullTable::item {
            padding: 0 4px;
            border-bottom: 1px solid #202020;
        }
        QTableWidget#alarmFullTable QHeaderView::section {
            background: #020202;
            color: #f2f2f2;
            border: none;
            border-bottom: 1px solid #5d6870;
            padding: 2px 4px;
            font-size: 14px;
            font-weight: 600;
        }
        QTableWidget#alarmFullTable QTableCornerButton::section {
            background: #020202;
            border: none;
        }
    )"));
    contentLayout->addWidget(table, 1);

    alarmRowsByTab_.resize(5);
    connect(tabGroup, &QButtonGroup::idClicked, this, [this, tabNames](int pageIndex) {
        alarmTabIndex_ = qBound(0, pageIndex, 4);
        const QStringList markerNames{u("全部报警"), u("未恢复"), u("已恢复"), u("倾碰报警"), u("历史报警")};
        setPageMarker(QStringLiteral("P04-%1 %2")
                          .arg(alarmTabIndex_ + 1, 2, 10, QLatin1Char('0'))
                          .arg(markerNames.value(alarmTabIndex_, tabNames.value(alarmTabIndex_))));
        refreshAlarmTable();
    });
    refreshAlarmRowsFromState();
    refreshAlarmTable();

    layout->addWidget(content, 1);
    return page;
}

QWidget *MainWindow::buildLogsPage() {
    auto *page = new QWidget;
    page->setProperty("class", "sitonPage");
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(62, 10, 62, 16);
    layout->setSpacing(6);

    auto *content = new QFrame;
    content->setProperty("class", "sitonMonitorFrame");
    auto *contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(8, 8, 8, 8);
    contentLayout->setSpacing(8);

    auto *tabs = new QWidget;
    tabs->setProperty("class", "transparent");
    auto *tabLayout = new QHBoxLayout(tabs);
    tabLayout->setContentsMargins(0, 0, 0, 0);
    tabLayout->setSpacing(0);
    auto *tabGroup = new QButtonGroup(page);
    tabGroup->setExclusive(true);
    const QStringList tabNames{u("操作日志"), u("传感器监控日志")};
    for (int i = 0; i < tabNames.size(); ++i) {
        const QString text = tabNames.at(i);
        auto *button = touchButton(text);
        button->setProperty("class", "sitonMonitorTab");
        button->setCheckable(true);
        button->setChecked(i == 0);
        tabGroup->addButton(button, i);
        tabLayout->addWidget(button);
    }
    tabLayout->addStretch();
    contentLayout->addWidget(tabs);

    auto configureLogTable = [](QTableWidget *table) {
        table->setProperty("class", "sitonAlarmFullTable");
        table->verticalHeader()->setVisible(false);
        table->setFrameShape(QFrame::NoFrame);
        table->setShowGrid(true);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        table->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        table->verticalHeader()->setDefaultSectionSize(44);
        table->setStyleSheet(QStringLiteral(R"(
            QTableWidget {
                background: #020202;
                alternate-background-color: #020202;
                color: #f2f2f2;
                gridline-color: #303030;
                border: none;
                border-radius: 4px;
                selection-background-color: #33406d;
                selection-color: #ffffff;
                font-size: 18px;
            }
            QTableWidget::item {
                padding: 4px 12px;
                border-bottom: 1px solid #202020;
            }
            QHeaderView::section {
                background: #020202;
                color: #f2f2f2;
                border: none;
                border-bottom: 1px solid #5d6870;
                padding: 8px 12px;
                font-size: 18px;
                font-weight: 600;
            }
            QTableCornerButton::section {
                background: #020202;
                border: none;
            }
        )"));
    };

    auto makeLogPage = [&](const QString &kind, const QString &title, const QVector<LogEntry> &fallback) {
        auto *host = new QWidget;
        host->setProperty("class", "transparent");
        auto *hostLayout = new QVBoxLayout(host);
        hostLayout->setContentsMargins(0, 0, 0, 0);
        hostLayout->setSpacing(8);

        auto *body = new QFrame;
        body->setProperty("class", "sitonLogBody");
        body->setStyleSheet(QStringLiteral(R"(
            QFrame[class="sitonLogBody"] {
                background: #020202;
                border: 1px solid #2d2d2d;
                border-radius: 4px;
            }
        )"));
        auto *bodyLayout = new QHBoxLayout(body);
        bodyLayout->setContentsMargins(0, 0, 0, 0);
        bodyLayout->setSpacing(0);

        auto entries = std::make_shared<QVector<LogEntry>>();
        auto dates = std::make_shared<QStringList>();

        auto *dateTable = new QTableWidget;
        configureLogTable(dateTable);
        dateTable->setColumnCount(1);
        dateTable->setHorizontalHeaderLabels({u("日志日期")});
        dateTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
        dateTable->setFixedWidth(260);

        auto *contentTable = new QTableWidget;
        configureLogTable(contentTable);
        contentTable->setColumnCount(1);
        contentTable->setHorizontalHeaderLabels({title});
        contentTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);

        auto fillContent = [contentTable, entries](const QString &date) {
            QVector<QString> rows;
            for (const LogEntry &entry : *entries) {
                if (entry.date == date) {
                    rows.append(entry.content);
                }
            }
            if (rows.isEmpty()) {
                rows.append(u("暂无数据"));
            }
            contentTable->setRowCount(rows.size());
            for (int row = 0; row < rows.size(); ++row) {
                auto *item = new QTableWidgetItem(rows.at(row));
                item->setTextAlignment(Qt::AlignCenter);
                contentTable->setItem(row, 0, item);
            }
        };

        auto *pageInfo = plainLabel(QString(), QStringLiteral("sitonPagerText"));
        pageInfo->setAlignment(Qt::AlignCenter);
        pageInfo->setMinimumWidth(180);

        auto applyEntries = [entries, dates, dateTable, fillContent, pageInfo](const QVector<LogEntry> &rows) {
            *entries = rows;
            dates->clear();
            for (const LogEntry &entry : *entries) {
                if (!dates->contains(entry.date)) {
                    dates->append(entry.date);
                }
            }
            if (dates->isEmpty()) {
                dates->append(QDate::currentDate().toString(QStringLiteral("yyyy-MM-dd")));
            }

            dateTable->clearContents();
            dateTable->setRowCount(dates->size());
            for (int row = 0; row < dates->size(); ++row) {
                auto *item = new QTableWidgetItem(dates->at(row));
                item->setTextAlignment(Qt::AlignCenter);
                dateTable->setItem(row, 0, item);
            }
            dateTable->setCurrentCell(0, 0);
            fillContent(dates->first());
            pageInfo->setText(u("当前%1条/每页30条").arg(entries->size()));
        };
        auto reloadTables = [kind, fallback, applyEntries] {
            applyEntries(readLocalLogs(kind, fallback));
        };

        connect(dateTable, &QTableWidget::currentCellChanged, host, [dateTable, fillContent](int row) {
            if (auto *item = dateTable->item(row, 0)) {
                fillContent(item->text());
            }
        });
        applyEntries(fallback);
        QTimer::singleShot(250, host, reloadTables);

        bodyLayout->addWidget(dateTable);
        bodyLayout->addWidget(contentTable, 1);
        hostLayout->addWidget(body, 1);

        auto *status = plainLabel(u("日志待命"), QStringLiteral("sitonParamLabel"));
        status->setMinimumWidth(220);
        auto *pager = new QWidget;
        pager->setProperty("class", "transparent");
        auto *pagerLayout = new QHBoxLayout(pager);
        pagerLayout->setContentsMargins(0, 0, 0, 0);
        pagerLayout->setSpacing(12);
        for (const QString &text : {u("导出"), u("清空"), u("上一页"), u("下一页")}) {
            auto *button = touchButton(text);
            button->setProperty("class", "sitonSmallButton");
            button->setMinimumHeight(30);
            connect(button, &QPushButton::clicked, host, [button, status, text, kind, entries, reloadTables] {
                if (text == u("导出")) {
                    const QString path = exportLocalLogs(kind, *entries);
                    if (path.isEmpty()) {
                        status->setText(u("日志导出失败"));
                        pulseButtonText(button, u("失败"));
                    } else {
                        status->setText(u("已导出 ") + QDir::toNativeSeparators(path));
                        pulseButtonText(button, u("已导出"));
                    }
                } else if (text == u("清空")) {
                    if (clearLocalLog(kind)) {
                        reloadTables();
                        status->setText(u("当前日志已清空"));
                        pulseButtonText(button, u("已清空"));
                    } else {
                        status->setText(u("日志清空失败"));
                        pulseButtonText(button, u("失败"));
                    }
                } else {
                    status->setText(u("当前为第1页"));
                    pulseButtonText(button, u("第1页"));
                }
            });
            pagerLayout->addWidget(button);
        }
        pagerLayout->addWidget(plainLabel(u("状态:"), QStringLiteral("sitonParamLabel")));
        pagerLayout->addWidget(status);
        pagerLayout->addStretch();
        hostLayout->addWidget(pager);
        auto *infoRow = new QWidget;
        infoRow->setProperty("class", "transparent");
        auto *infoLayout = new QHBoxLayout(infoRow);
        infoLayout->setContentsMargins(0, 0, 0, 0);
        infoLayout->addStretch();
        infoLayout->addWidget(pageInfo);
        hostLayout->addWidget(infoRow);
        return host;
    };

    const QVector<LogEntry> operationFallback{
        {u("2026-06-20"), u("09:08:12  操作员进入主界面  结果: 成功")},
        {u("2026-06-20"), u("09:08:15  载入炮孔图与桩号线文件  结果: 成功")},
        {u("2026-06-20"), u("09:08:18  配置通讯模块  结果: 成功")},
        {u("2026-06-20"), u("09:08:24  打开数据监测  结果: 成功")},
        {u("2026-06-20"), u("09:08:30  切换主视图  结果: 成功")},
        {u("2026-06-20"), u("09:08:33  钻机参数预设已下发  结果: 成功")},
        {u("2026-06-20"), u("09:08:36  清零命令已下发  结果: 成功")},
        {u("2026-06-17"), u("17:20:05  系统启动自检完成  结果: 成功")}
    };
    const QVector<LogEntry> sensorFallback{
        {u("2026-06-20"), u("09:08:12  台车急停/保护状态  当前值: 正常")},
        {u("2026-06-20"), u("09:08:12  三臂压力保护状态  当前值: 88 bar  状态: 正常")},
        {u("2026-06-20"), u("09:08:12  H点坐标与钻孔偏差  当前值: X0.32 Y0.00 Z0.14")},
        {u("2026-06-20"), u("09:08:12  车辆姿态与角度反馈  当前值: 1.25 deg")},
        {u("2026-06-20"), u("09:08:12  三臂编码器和深度清零  状态: 已发送")},
        {u("2026-06-20"), u("09:08:12  三臂钻机参数  状态: 已发送")},
        {u("2026-06-20"), u("09:08:13  通讯模块心跳监控  当前值: 等待连接  状态: 提示")},
        {u("2026-06-17"), u("17:20:05  传感器链路自检  当前值: 待机  状态: 正常")}
    };

    auto *stack = new QStackedWidget;
    stack->setProperty("class", "transparent");
    stack->addWidget(makeLogPage(QStringLiteral("operation"), u("操作日志内容"), operationFallback));
    stack->addWidget(makeLogPage(QStringLiteral("sensor"), u("传感器监控日志内容"), sensorFallback));
    contentLayout->addWidget(stack, 1);
    connect(tabGroup, &QButtonGroup::idClicked, this, [this, stack, tabNames](int id) {
        stack->setCurrentIndex(id);
        const QStringList markerNames{u("操作日志"), u("传感器日志")};
        setPageMarker(QStringLiteral("P05-%1 %2")
                          .arg(id + 1, 2, 10, QLatin1Char('0'))
                          .arg(markerNames.value(id, tabNames.value(id))));
    });
    layout->addWidget(content, 1);

    auto *bottom = new QWidget;
    bottom->setProperty("class", "transparent");
    auto *bottomLayout = new QHBoxLayout(bottom);
    bottomLayout->setContentsMargins(0, 0, 0, 0);
    bottomLayout->setSpacing(8);
    for (int i = 0; i < 2; ++i) {
        auto *bar = new QFrame;
        bar->setProperty("class", "sitonBottomBar");
        bar->setMinimumHeight(40);
        bottomLayout->addWidget(bar);
    }
    layout->addWidget(bottom);
    return page;
}

void MainWindow::injectDemoCanFramesForScreenshot(double leftDepthM,
                                                  double middleDepthM,
                                                  double rightDepthM) {
    const bool traceDemoCan = qEnvironmentVariableIsSet("QDN_TRACE_DEMO_CAN");
    auto setU16 = [](CanFrame &frame, int offset, quint16 value) {
        frame.data[offset] = static_cast<quint8>(value & 0xff);
        frame.data[offset + 1] = static_cast<quint8>((value >> 8) & 0xff);
    };
    auto setS16 = [](CanFrame &frame, int offset, qint16 value) {
        const quint16 raw = static_cast<quint16>(value);
        frame.data[offset] = static_cast<quint8>(raw & 0xff);
        frame.data[offset + 1] = static_cast<quint8>((raw >> 8) & 0xff);
    };
    auto setS32 = [](CanFrame &frame, int offset, qint32 value) {
        const quint32 raw = static_cast<quint32>(value);
        frame.data[offset] = static_cast<quint8>(raw & 0xff);
        frame.data[offset + 1] = static_cast<quint8>((raw >> 8) & 0xff);
        frame.data[offset + 2] = static_cast<quint8>((raw >> 16) & 0xff);
        frame.data[offset + 3] = static_cast<quint8>((raw >> 24) & 0xff);
    };
    auto depthMm = [](double meters) {
        return static_cast<quint16>(qBound(0, int(qRound(meters * 1000.0)), 65535));
    };
    auto apply = [this, traceDemoCan](const CanFrame &frame) {
        if (traceDemoCan) {
            std::fprintf(stdout, "TRACE demo-can begin id=0x%03x b0=0x%02x\n",
                         unsigned(frame.id), unsigned(frame.data[0]));
            std::fflush(stdout);
        }
        handleCanFrame(frame);
        if (traceDemoCan) {
            std::fprintf(stdout, "TRACE demo-can end id=0x%03x b0=0x%02x\n",
                         unsigned(frame.id), unsigned(frame.data[0]));
            std::fflush(stdout);
        }
    };
    auto hFrame = [&](quint8 index, qint32 value) {
        CanFrame frame;
        frame.id = 0x150;
        frame.dlc = 8;
        frame.data[0] = index;
        setS32(frame, 1, value);
        apply(frame);
    };

    hFrame(0x10, -383);
    hFrame(0x11, 0);
    hFrame(0x12, -1);
    hFrame(0x20, 26);
    hFrame(0x21, 0);
    hFrame(0x22, 6);
    hFrame(0x30, 320);
    hFrame(0x31, 0);
    hFrame(0x32, 14);

    CanFrame depth;
    depth.id = 0x153;
    depth.dlc = 8;
    setU16(depth, 0, depthMm(leftDepthM));
    setU16(depth, 2, depthMm(middleDepthM));
    setU16(depth, 4, depthMm(rightDepthM));
    apply(depth);

    auto angleFrame = [&](quint8 index, qint16 xz, qint16 yz) {
        CanFrame frame;
        frame.id = 0x152;
        frame.dlc = 8;
        frame.data[0] = index;
        setS16(frame, 1, xz);
        setS16(frame, 3, yz);
        apply(frame);
    };
    angleFrame(0x10, 1250, -340);
    angleFrame(0x20, 820, 210);
    angleFrame(0x30, -650, 480);

    auto analogFrame = [&](quint8 index, quint16 a, quint16 b, quint16 c) {
        CanFrame frame;
        frame.id = 0x176;
        frame.dlc = 8;
        frame.data[0] = index;
        setU16(frame, 1, a);
        setU16(frame, 3, b);
        setU16(frame, 5, c);
        apply(frame);
    };
    analogFrame(0x07, 0, 0, 88);
    analogFrame(0x08, 122, 46, 31);
    analogFrame(0x09, 36, 18, 24);
    analogFrame(0x0a, 19, 0, 0);
    analogFrame(0x13, 0, 94, 118);
    analogFrame(0x14, 44, 29, 35);
    analogFrame(0x15, 17, 22, 18);
    analogFrame(0x1d, 0, 91, 116);
    analogFrame(0x1e, 42, 28, 37);
    analogFrame(0x1f, 16, 20, 17);

    CanFrame protection;
    protection.id = 0x170;
    protection.dlc = 8;
    protection.data[0] = 0x01;
    protection.data[1] = 0x08;
    apply(protection);

    CanFrame operatorStatus;
    operatorStatus.id = 0x170;
    operatorStatus.dlc = 8;
    operatorStatus.data[0] = 0x02;
    apply(operatorStatus);

    auto operatorAxisFrame = [&](quint8 index, qint16 x, qint16 y, qint16 z) {
        CanFrame frame;
        frame.id = 0x170;
        frame.dlc = 8;
        frame.data[0] = index;
        setS16(frame, 1, x);
        setS16(frame, 3, y);
        setS16(frame, 5, z);
        apply(frame);
    };
    operatorAxisFrame(0x03, 120, -18, 0);
    operatorAxisFrame(0x04, -42, 76, 12);
    operatorAxisFrame(0x05, 88, 0, -9);
    operatorAxisFrame(0x06, -10, 34, 6);

    CanFrame operatorButtons;
    operatorButtons.id = 0x170;
    operatorButtons.dlc = 8;
    operatorButtons.data[0] = 0x07;
    operatorButtons.data[1] = 0x11;
    operatorButtons.data[2] = 0x02;
    apply(operatorButtons);

    CanFrame dropout;
    dropout.id = 0x15a;
    dropout.dlc = 8;
    dropout.data[1] = 0x01;
    dropout.data[3] = 0x08;
    apply(dropout);

    canState_.setCanToNetOnline(true);
    realtimeRefreshTimer_.stop();
    refreshRealtimeUi();
}

void MainWindow::refreshAlarmRowsFromState() {
    if (alarmRowsByTab_.size() < 5) {
        alarmRowsByTab_.resize(5);
    }

    QVector<QStringList> activeRows;
    const QString now = QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"));

    const MachineRealtimeState &state = canState_.state();
    QStringList currentAlarms;
    for (const QString &alarm : state.activeAlarmCodes) {
        currentAlarms.append(alarm);
        if (!activeAlarmFirstSeen_.contains(alarm)) {
            activeAlarmFirstSeen_.insert(alarm, now);
        }
        activeRows.append(alarmRowForActiveAlarm(alarm, activeAlarmFirstSeen_.value(alarm, now)));
    }

    QStringList recoveredAlarms;
    for (auto it = activeAlarmFirstSeen_.cbegin(); it != activeAlarmFirstSeen_.cend(); ++it) {
        if (!currentAlarms.contains(it.key())) {
            recoveredAlarms.append(it.key());
        }
    }
    for (const QString &alarm : recoveredAlarms) {
        appendLocalAlarmHistoryRow(alarmRowForActiveAlarm(alarm, activeAlarmFirstSeen_.value(alarm), now));
        activeAlarmFirstSeen_.remove(alarm);
    }

    const QVector<QStringList> recoveredRows = readLocalAlarmHistoryRows();
    QVector<QStringList> tiltRows;
    for (const QStringList &row : activeRows) {
        if (isTiltOrCollisionAlarmRow(row)) {
            tiltRows.append(row);
        }
    }
    for (const QStringList &row : recoveredRows) {
        if (isTiltOrCollisionAlarmRow(row)) {
            tiltRows.append(row);
        }
    }

    QVector<QStringList> allRows = activeRows;
    allRows += recoveredRows;

    alarmRowsByTab_[0] = allRows;
    alarmRowsByTab_[1] = activeRows;
    alarmRowsByTab_[2] = recoveredRows;
    alarmRowsByTab_[3] = tiltRows;
    alarmRowsByTab_[4] = recoveredRows;
}

void MainWindow::refreshAlarmTable() {
    if (!alarmTable_ || !alarmPageInfo_) {
        return;
    }

    const QVector<QStringList> rows = alarmRowsByTab_.value(alarmTabIndex_);
    const int pageSize = 30;
    const int count = qMin(pageSize, rows.size());
    alarmTable_->clearContents();
    alarmTable_->setRowCount(count);
    for (int row = 0; row < count; ++row) {
        const QStringList cells = rows.at(row);
        for (int col = 0; col < 4; ++col) {
            auto *item = new QTableWidgetItem(col >= 2 ? workerVisibleText(cells.value(col)) : cells.value(col));
            item->setTextAlignment((col == 3 ? Qt::AlignLeft : Qt::AlignCenter) | Qt::AlignVCenter);
            alarmTable_->setItem(row, col, item);
        }
        alarmTable_->setRowHeight(row, 18);
    }
    alarmPageInfo_->setText(u("每页30条  当前%1条/%2条").arg(count).arg(rows.size()));
}

void MainWindow::sendCommandFrame(const QString &label, quint32 id, const std::array<quint8, 8> &data, quint8 dlc) {
    CanFrame frame;
    frame.id = id;
    frame.dlc = qMin<quint8>(dlc, 8);
    frame.data = data;

    const bool connected = canClient_.isConnected();
    if (connected) {
        canClient_.sendCanFrame(frame);
    }

    const QString status = connected
        ? (label + u(" 已下发"))
        : (label + u(" 未连接，未下发"));
    if (commandStatusLabel_) {
        commandStatusLabel_->setText(status);
    }
    if (canToNetStatusEdit_) {
        canToNetStatusEdit_->setText(status);
    }
    appendLocalLog(QStringLiteral("operation"), status);
    appendLocalLog(QStringLiteral("sensor"), u("参数下发：") + label);
}

void MainWindow::initCanToNet() {
    const QString host = savedLineEditText(QStringLiteral("settings.canToNet.moduleIp"), QStringLiteral("192.168.0.105"));
    applyCanToNetConfig(host, savedCanToNetPort(), false);

    connect(&canClient_, &CanToNetClient::connectedChanged, this, [this](bool connected) {
        canState_.setCanToNetOnline(connected);
        appendLocalLog(QStringLiteral("operation"), connected ? u("通讯模块已连接") : u("通讯模块已断开"));
        appendLocalLog(QStringLiteral("sensor"), connected ? u("通讯链路状态：已连接") : u("通讯链路状态：未连接"));
        refreshRealtimeUi();
    });
    connect(&canClient_, &CanToNetClient::canFrameReceived, this, [this](const CanFrame &frame) {
        handleCanFrame(frame);
    });
    connect(&canClient_, &CanToNetClient::packetDropped, this, [this](const QString &reason, const QByteArray &) {
        if (canToNetStatusEdit_) {
            canToNetStatusEdit_->setText(u("通讯错误，请检查连接"));
        }
        appendLocalLog(QStringLiteral("sensor"), u("通讯模块错误，请检查连接"));
    });

    refreshRealtimeUi();
    canClient_.start();
}

void MainWindow::applyCanToNetConfig(const QString &host, quint16 port, bool restartClient) {
    const QString cleanedHost = host.trimmed().isEmpty() ? QStringLiteral("192.168.0.105") : host.trimmed();
    canToNetHost_ = cleanedHost;
    canToNetPort_ = port == 0 ? quint16(503) : port;
    canState_.setCanToNetOnline(false);
    if (restartClient) {
        canClient_.stop();
    }
    canClient_.configure(canToNetHost_, canToNetPort_, 0);
    if (restartClient) {
        canClient_.start();
    }
    refreshRealtimeUi();
}

void MainWindow::handleCanFrame(const CanFrame &frame) {
    canState_.applyFrame(frame);
    static QDateTime lastRealtimeLog;
    const QDateTime now = QDateTime::currentDateTime();
    if (!lastRealtimeLog.isValid() || lastRealtimeLog.msecsTo(now) >= 5000) {
        appendLocalLog(QStringLiteral("sensor"), u("收到设备数据更新"));
        lastRealtimeLog = now;
    }
    scheduleRealtimeRefresh();
}

void MainWindow::scheduleRealtimeRefresh() {
    if (!realtimeRefreshTimer_.isActive()) {
        realtimeRefreshTimer_.start();
    }
}

void MainWindow::refreshRealtimeUi() {
    const bool traceRefresh = qEnvironmentVariableIsSet("QDN_TRACE_REFRESH_UI");
    auto trace = [traceRefresh](const char *stage) {
        if (traceRefresh) {
            std::fprintf(stdout, "TRACE refresh %s\n", stage);
            std::fflush(stdout);
        }
    };
    const MachineRealtimeState &state = canState_.state();
    const int currentPage = pages_ ? pages_->currentIndex() : -1;
    const bool refreshAll = currentPage < 0;
    const bool onDashboardPage = refreshAll || currentPage == 0;
    const bool onMonitorPage = refreshAll || currentPage == 1;
    const bool onAlarmPage = refreshAll || currentPage == 3;
    const bool onCalibrationPage = refreshAll || currentPage == 9;

    if (onAlarmPage) {
        trace("alarm-rows");
        refreshAlarmRowsFromState();
        refreshAlarmTable();
    }
    if (onDashboardPage && dashboardView_) {
        trace("dashboard");
        dashboardView_->setRealtimeState(state);
    }

    trace("status-dots");
    const bool connected = state.canToNetOnline;
    const QColor okColor("#86ef8f");
    const QColor faultColor("#ff0000");
    const QColor unknownColor("#d8d8d8");
    const QColor statusColor = connected ? okColor : faultColor;
    auto booleanColor = [&](bool valid, bool fault) {
        return valid ? (fault ? faultColor : okColor) : unknownColor;
    };
    auto booleanText = [](bool valid, bool fault) {
        if (!valid) {
            return QStringLiteral("--");
        }
        return fault ? u("故障") : u("正常");
    };
    auto emergencyText = [](bool valid, bool active) {
        if (!valid) {
            return QStringLiteral("--");
        }
        return active ? u("急停") : u("正常");
    };

    setDotColor(canToNetFaultDot_, statusColor);
    setDotColor(canToNetHandleDot_, statusColor);
    if (onMonitorPage) {
        setDotColor(systemFaultDots_[1], state.dropoutValid ? (state.algorithmPcbOffline ? faultColor : okColor) : unknownColor);
    }
    const bool leftConsoleFault = state.operatorConsoles[0].leftHandleOffline
        || state.operatorConsoles[0].rightHandleOffline
        || state.operatorConsoles[0].leftKeypadOffline
        || state.operatorConsoles[0].rightKeypadOffline;
    const bool rightConsoleFault = state.operatorConsoles[1].leftHandleOffline
        || state.operatorConsoles[1].rightHandleOffline
        || state.operatorConsoles[1].leftKeypadOffline
        || state.operatorConsoles[1].rightKeypadOffline;
    if (onMonitorPage) {
        setDotColor(systemFaultDots_[2], booleanColor(state.operatorConsoles[0].linkValid, leftConsoleFault));
        setDotColor(systemFaultDots_[3], booleanColor(state.operatorConsoles[1].linkValid, rightConsoleFault));
        setDotColor(systemFaultDots_[7], state.dropoutValid ? (state.inclinometerOffline ? faultColor : okColor) : unknownColor);
        setDotColor(systemFaultDots_[11], statusColor);

        for (int console = 0; console < 2; ++console) {
            const bool consoleFault = console == 0 ? leftConsoleFault : rightConsoleFault;
            setDotColor(handleStatusDots_[static_cast<size_t>(console)],
                        booleanColor(state.operatorConsoles[console].linkValid, consoleFault));
            setLabelText(handleStatusValues_[static_cast<size_t>(console)],
                         booleanText(state.operatorConsoles[console].linkValid, consoleFault));
            for (int handle = 0; handle < 2; ++handle) {
                for (int row = 0; row < 7; ++row) {
                    setLabelText(handleValueLabels_[static_cast<size_t>(console)][static_cast<size_t>(handle)][static_cast<size_t>(row)],
                                 handleValueText(state.operatorConsoles[console].handles[handle], row));
                }
            }
        }
        setDotColor(handleStatusDots_[6], booleanColor(state.vehicleStatusValid, state.leftConsoleEmergencyStop));
        setLabelText(handleStatusValues_[6], emergencyText(state.vehicleStatusValid, state.leftConsoleEmergencyStop));
    }

    if (canToNetHandleValue_) {
        canToNetHandleValue_->setText(connected ? u("已连接") : u("未连接"));
    }
    if (canToNetStatusEdit_) {
        const QString endpoint = QStringLiteral("%1:%2").arg(canToNetHost_).arg(canToNetPort_);
        canToNetStatusEdit_->setText(connected ? (u("已连接 ") + endpoint) : (u("未连接 ") + endpoint));
    }

    if (onMonitorPage) {
        trace("arm-values");
        for (int arm = 0; arm < 3; ++arm) {
            for (int row = 0; row < 14; ++row) {
                QLabel *label = sensorValueLabels_[arm][row];
                if (!label) {
                    continue;
                }
                label->setText(sensorValueText(state.arms[arm], row));
            }
            for (int row = 0; row < 11; ++row) {
                QLabel *valueLabel = truckDataValueLabels_[arm][row];
                if (valueLabel) {
                    valueLabel->setText(truckDataValueText(state.arms[arm], row));
                }
                const bool valid = truckDataValid(state.arms[arm], row);
                setDotColor(truckDataStatusDots_[arm][row],
                            valid ? (truckDataFault(state.arms[arm], row) ? faultColor : okColor) : unknownColor);
            }
            setDotColor(lubricationProtectDots_[arm],
                        state.arms[arm].lubricationPressureLowValid
                            ? (state.arms[arm].lubricationPressureLow ? faultColor : okColor)
                            : unknownColor);
            setDotColor(truckWorkStatusDots_[arm][3],
                        state.arms[arm].lubricationPressureLowValid
                            ? (state.arms[arm].lubricationPressureLow ? faultColor : okColor)
                            : unknownColor);
            for (int row = 0; row < 18; ++row) {
                QColor color = unknownColor;
                if (row >= 9 && row <= 17 && state.arms[arm].encoderOfflineValid) {
                    color = state.arms[arm].encoderOffline ? faultColor : okColor;
                }
                setDotColor(armFaultDots_[arm][row], color);
            }
        }
    }
    if (onCalibrationPage) {
        trace("calibration");
        const CalibrationFeedback &calibration = state.calibration;
        const QString objectText = calibration.statusValid || calibration.rmsValid
            ? calibrationObjectText(calibration.object, calibration.businessFlag)
            : QStringLiteral("--");
        const QString statusText = calibration.statusValid
            ? calibrationStatusText(calibration.status)
            : QStringLiteral("--");
        const QString errorText = calibration.statusValid
            ? calibrationErrorText(calibration.errorCode)
            : QStringLiteral("--");
        const QString countText = calibration.statusValid ? QString::number(calibration.receivedPointCount) : QStringLiteral("--");
        const QString maxErrorText = calibration.statusValid ? QString::number(calibration.maxErrorMm) : QStringLiteral("--");
        const QString rmsText = calibration.rmsValid ? QString::number(calibration.rmsMm) : QStringLiteral("--");
        const QStringList calibrationTexts{objectText, statusText, errorText, countText, maxErrorText, rmsText};
        for (int i = 0; i < calibrationTexts.size(); ++i) {
            setLabelText(calibrationFeedbackLabels_[static_cast<size_t>(i)], calibrationTexts.at(i));
        }
    }
    if (onMonitorPage) {
        setDotColor(truckEmergencyDots_[0][0], booleanColor(state.vehicleStatusValid, state.leftConsoleEmergencyStop));
        setDotColor(truckEmergencyDots_[0][1], booleanColor(state.vehicleStatusValid, state.cableBoxEmergencyStop));
        setDotColor(truckEmergencyDots_[1][1], booleanColor(state.vehicleStatusValid, state.hoseBoxEmergencyStop));
    }
}

QPushButton *MainWindow::touchButton(const QString &text, const QString &objectName) {
    auto *button = new QPushButton(text);
    button->setMinimumHeight(38);
    button->setCursor(Qt::PointingHandCursor);
    if (!objectName.isEmpty()) {
        button->setObjectName(objectName);
    }
    return button;
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event) {
    if (watched && watched->property("windowDragHandle").toBool()) {
        if (event->type() == QEvent::MouseButtonPress) {
            auto *mouseEvent = static_cast<QMouseEvent *>(event);
            if (mouseEvent->button() == Qt::LeftButton) {
                windowDragActive_ = true;
                windowDragOffset_ = mouseEvent->globalPosition().toPoint() - frameGeometry().topLeft();
                if (auto *widget = qobject_cast<QWidget *>(watched)) {
                    widget->setCursor(Qt::ClosedHandCursor);
                }
                return true;
            }
        } else if (event->type() == QEvent::MouseMove && windowDragActive_) {
            auto *mouseEvent = static_cast<QMouseEvent *>(event);
            if (!(mouseEvent->buttons() & Qt::LeftButton)) {
                windowDragActive_ = false;
                return false;
            }
            const QRect previousGeometry = frameGeometry();
            if (isFullScreen() || isMaximized()) {
                showNormal();
                setGeometry(previousGeometry);
            }
            move(mouseEvent->globalPosition().toPoint() - windowDragOffset_);
            return true;
        } else if (event->type() == QEvent::MouseButtonRelease && windowDragActive_) {
            windowDragActive_ = false;
            if (auto *widget = qobject_cast<QWidget *>(watched)) {
                widget->setCursor(Qt::OpenHandCursor);
            }
            return true;
        }
    }

    auto *edit = qobject_cast<QLineEdit *>(watched);
    if (edit && edit->property("touchNumberPadInstalled").toBool()) {
        if ((event->type() == QEvent::MouseButtonRelease || event->type() == QEvent::TouchEnd)
            && edit->isEnabled() && !edit->isReadOnly()) {
            const QPointer<QLineEdit> guardedEdit(edit);
            QTimer::singleShot(0, this, [this, guardedEdit] {
                if (guardedEdit) {
                    showTouchNumberPad(guardedEdit);
                }
            });
            return false;
        }
    }
    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::installTouchKeyboard(QLineEdit *edit) {
    if (!isTouchNumberEdit(edit) || edit->property("touchNumberPadInstalled").toBool()) {
        return;
    }
    edit->setProperty("touchNumberPadInstalled", true);
    edit->setCursor(Qt::PointingHandCursor);
    edit->installEventFilter(this);
}

void MainWindow::showTouchNumberPad(QLineEdit *edit) {
    if (!edit || edit->isReadOnly() || !edit->isEnabled()) {
        return;
    }

    QDialog dialog(this);
    dialog.setModal(true);
    dialog.setWindowTitle(u("数值输入"));
    dialog.setMinimumSize(470, 500);
    dialog.setStyleSheet(QStringLiteral(R"(
        QDialog {
            background: #565656;
            color: #ffffff;
        }
        QLabel {
            color: #ffffff;
            font-size: 22px;
            font-weight: 900;
        }
        QLineEdit {
            color: #ffffff;
            background: #020202;
            border: 2px solid #020202;
            border-radius: 5px;
            padding: 6px 12px;
            font-family: "Consolas";
            font-size: 28px;
            font-weight: 900;
        }
        QPushButton {
            color: #ffffff;
            background: #7f7f7f;
            border: 2px solid #050505;
            border-radius: 5px;
            font-size: 26px;
            font-weight: 900;
            min-height: 58px;
        }
        QPushButton:pressed {
            background: #00a9cb;
            color: #000000;
        }
        QPushButton[class="touchOk"] {
            color: #00c8ef;
        }
    )"));

    auto *layout = new QVBoxLayout(&dialog);
    layout->setContentsMargins(18, 18, 18, 18);
    layout->setSpacing(10);
    auto *title = plainLabel(u("数值输入"));
    layout->addWidget(title);

    const QString originalText = edit->text();
    const int originalCursorPosition = edit->cursorPosition();
    const int originalSelectionStart = edit->selectionStart();
    const int originalSelectionLength = edit->selectedText().size();

    auto *display = new QLineEdit(originalText, &dialog);
    display->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    display->setCursorPosition(originalCursorPosition);
    if (originalSelectionStart >= 0 && originalSelectionLength > 0) {
        display->setSelection(originalSelectionStart, originalSelectionLength);
    }
    layout->addWidget(display);
    QTimer::singleShot(0, display, [display] {
        display->setFocus(Qt::OtherFocusReason);
    });

    auto appendText = [display](const QString &text) {
        display->insert(text);
        display->setFocus(Qt::OtherFocusReason);
    };
    auto addButton = [&](QGridLayout *grid, int row, int col, const QString &text, const std::function<void()> &handler) {
        auto *button = touchButton(text);
        if (text == u("确定")) {
            button->setProperty("class", "touchOk");
        }
        connect(button, &QPushButton::clicked, &dialog, handler);
        grid->addWidget(button, row, col);
    };

    auto *keys = new QGridLayout;
    keys->setHorizontalSpacing(8);
    keys->setVerticalSpacing(8);
    const QStringList digits{QStringLiteral("7"), QStringLiteral("8"), QStringLiteral("9"),
                             QStringLiteral("4"), QStringLiteral("5"), QStringLiteral("6"),
                             QStringLiteral("1"), QStringLiteral("2"), QStringLiteral("3")};
    for (int i = 0; i < digits.size(); ++i) {
        addButton(keys, i / 3, i % 3, digits.at(i), [appendText, digit = digits.at(i)] { appendText(digit); });
    }
    addButton(keys, 3, 0, QStringLiteral("+/-"), [display] {
        QString value = display->text();
        int cursor = display->cursorPosition();
        const int selectionStart = display->selectionStart();
        const int selectionLength = display->selectedText().size();
        if (value.startsWith(QLatin1Char('-'))) {
            value.remove(0, 1);
            cursor = qMax(0, cursor - 1);
        } else {
            value.prepend(QLatin1Char('-'));
            ++cursor;
        }
        display->setText(value);
        if (selectionStart >= 0 && selectionLength > 0) {
            display->setSelection(value.startsWith(QLatin1Char('-')) ? selectionStart + 1 : qMax(0, selectionStart - 1),
                                  selectionLength);
        } else {
            display->setCursorPosition(qBound(0, cursor, value.size()));
        }
        display->setFocus(Qt::OtherFocusReason);
    });
    addButton(keys, 3, 1, QStringLiteral("0"), [appendText] { appendText(QStringLiteral("0")); });
    addButton(keys, 3, 2, QStringLiteral("."), [display, appendText] {
        QString value = display->text();
        const int selectionStart = display->selectionStart();
        const int selectionLength = display->selectedText().size();
        if (selectionStart >= 0 && selectionLength > 0) {
            value.remove(selectionStart, selectionLength);
        }
        if (!value.contains(QLatin1Char('.'))) {
            appendText(QStringLiteral("."));
        }
    });
    addButton(keys, 4, 0, u("清空"), [display] { display->clear(); });
    addButton(keys, 4, 1, u("退格"), [display] {
        display->backspace();
        display->setFocus(Qt::OtherFocusReason);
    });
    addButton(keys, 4, 2, u("取消"), [&dialog] { dialog.reject(); });
    addButton(keys, 5, 0, u("确定"), [&dialog] { dialog.accept(); });
    keys->addItem(new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Minimum), 5, 1);
    keys->addItem(new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::Minimum), 5, 2);
    layout->addLayout(keys);

    if (dialog.exec() == QDialog::Accepted) {
        edit->setText(display->text().trimmed());
        edit->setCursorPosition(qBound(0, display->cursorPosition(), edit->text().size()));
        edit->setFocus();
    } else {
        edit->setText(originalText);
        if (originalSelectionStart >= 0 && originalSelectionLength > 0) {
            edit->setSelection(originalSelectionStart, originalSelectionLength);
        } else {
            edit->setCursorPosition(qBound(0, originalCursorPosition, edit->text().size()));
        }
        edit->setFocus();
    }
}

void MainWindow::switchPage(int index) {
    if (!pages_ || index < 0 || index >= pages_->count()) {
        return;
    }
    ensurePageBuilt(index);
    pages_->setCurrentIndex(index);
    refreshPageNumberLabel(index);
    refreshRealtimeUi();
    int highlightedPage = index;
    if (index == 2 || index == 5 || index == 6 || index == 7 || index == 8 || index == 9 || index == 10) {
        highlightedPage = 2;
    }
    for (int i = 0; i < navButtons_.size(); ++i) {
        if (navButtons_.at(i)) {
            navButtons_.at(i)->setChecked(navButtons_.at(i)->property("pageIndex").toInt() == highlightedPage);
        }
    }
}

void MainWindow::setPageForScreenshot(int index) {
    switchPage(index);
}

void MainWindow::refreshClock() {
    if (connectionLabel_) {
        connectionLabel_->setText(sitonClockText(QDateTime::currentDateTime()));
    }
}

void MainWindow::setupPersistentInputs(QWidget *root) {
    QSettings settings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
    QWidget *scanRoot = root ? root : this;
    const QString scopePrefix = root && !root->objectName().isEmpty()
        ? (root->objectName() + QLatin1Char('/'))
        : QString();

    int lineEditIndex = 0;
    int namedFallbackIndex = 0;
    const QList<QLineEdit *> edits = scanRoot->findChildren<QLineEdit *>();
    for (QLineEdit *edit : edits) {
        if (!edit || edit->isReadOnly()) {
            continue;
        }
        const QString className = edit->property("class").toString();
        const bool isSitonValue = className == QStringLiteral("sitonValueInput");
        const bool isDashboardValue = className == QStringLiteral("drillModeInput")
            || className == QStringLiteral("panelValueInput");
        if (!isSitonValue && !isDashboardValue) {
            continue;
        }
        if (edit->property("persistentInputInstalled").toBool()) {
            continue;
        }
        QString key;
        if (isSitonValue && edit->objectName().isEmpty()) {
            key = QStringLiteral("persistentInputs/%1lineEdit/%2")
                      .arg(scopePrefix)
                      .arg(lineEditIndex++, 4, 10, QLatin1Char('0'));
        } else if (!edit->objectName().isEmpty()) {
            key = QStringLiteral("persistentInputs/lineEditByName/%1").arg(edit->objectName());
        } else {
            key = QStringLiteral("persistentInputs/lineEditByClass/%1/%2")
                      .arg(className)
                      .arg(namedFallbackIndex++, 4, 10, QLatin1Char('0'));
        }
        if (settings.contains(key)) {
            edit->setText(settings.value(key).toString());
        }
        CoverageHint hint = CoverageHint::Gap;
        if (coverageHintForObjectName(edit->objectName(), &hint)) {
            setCoverageHint(edit, hint);
        }
        const QPointer<QLineEdit> guardedEdit(edit);
        connect(edit, &QLineEdit::textChanged, this, [key, guardedEdit](const QString &text) {
            if (!guardedEdit) {
                return;
            }
            QSettings liveSettings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
            liveSettings.setValue(key, text);
            liveSettings.sync();
        });
        installTouchKeyboard(edit);
        edit->setProperty("persistentInputInstalled", true);
    }

    int comboIndex = 0;
    const QList<QComboBox *> combos = scanRoot->findChildren<QComboBox *>();
    for (QComboBox *combo : combos) {
        if (!combo || combo->property("class").toString() != QStringLiteral("sitonValueInput")) {
            continue;
        }
        if (combo->property("persistentInputInstalled").toBool()) {
            continue;
        }
        QString key;
        if (!combo->objectName().isEmpty()) {
            key = QStringLiteral("persistentInputs/comboBoxByName/%1").arg(combo->objectName());
        } else {
            key = QStringLiteral("persistentInputs/%1comboBox/%2")
                      .arg(scopePrefix)
                      .arg(comboIndex++, 4, 10, QLatin1Char('0'));
        }
        if (settings.contains(key)) {
            const QString saved = settings.value(key).toString();
            const int savedIndex = combo->findText(saved);
            if (savedIndex >= 0) {
                combo->setCurrentIndex(savedIndex);
            }
        }
        CoverageHint hint = CoverageHint::Gap;
        if (coverageHintForObjectName(combo->objectName(), &hint)) {
            setCoverageHint(combo, hint);
        }
        const QPointer<QComboBox> guardedCombo(combo);
        connect(combo, &QComboBox::currentTextChanged, this, [key, guardedCombo](const QString &text) {
            if (!guardedCombo) {
                return;
            }
            QSettings liveSettings(QStringLiteral("GengliMachine"), QStringLiteral("QdnUpperComputerUi"));
            liveSettings.setValue(key, text);
            liveSettings.sync();
        });
        combo->setProperty("persistentInputInstalled", true);
    }
}

void MainWindow::setPageMarker(const QString &marker) {
    if (pageNumberLabel_) {
        pageNumberLabel_->setText(marker.section(QLatin1Char(' '), 0, 0));
    }
}

void MainWindow::refreshPageNumberLabel(int index) {
    if (!pageNumberLabel_) {
        return;
    }
    static const QStringList pageNames{
        u("主界面"),
        u("P02-03 传感器"),
        u("设置入口"),
        u("P04-01 全部报警"),
        u("P05-01 操作日志"),
        u("P06-01 左臂清零"),
        u("P07-01 文件存储"),
        u("钻机参数预设"),
        u("凿岩保护解除"),
        u("P10-01 机械位置"),
        u("P03-01 炮孔图修改")
    };
    const QString name = pageNames.value(index, u("页面"));
    const QString label = name.startsWith(QLatin1Char('P'))
        ? name
        : QStringLiteral("P%1 %2").arg(index + 1, 2, 10, QLatin1Char('0')).arg(name);
    setPageMarker(label);
}

void MainWindow::applyStyle() {
    const QStringList qssParts{
        QStringLiteral(R"(
        QWidget {
            color: #f2f0e8;
            background: #171b1e;
            font-family: "Microsoft YaHei UI";
            font-size: 16px;
        }
        #sidebar {
            background: #0c0f11;
            border-right: 1px solid #252b30;
        }
        #brand {
            color: #101315;
            background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #30c29a, stop:1 #d8e86b);
            border-radius: 8px;
            font-weight: 900;
            font-size: 17px;
        }
        #topbar {
            background: #737373;
            border-bottom: 4px solid #000000;
        }
        QLabel[class="machineTitle"] {
            color: #f0c823;
            background: transparent;
            font-size: 15px;
            font-weight: 800;
        }
        QLabel[class="clockLabel"] {
            color: #e6e6e6;
            background: transparent;
            font-size: 16px;
            font-weight: 700;
        }
        QLabel[class="pageNumberLabel"] {
            color: #f0c823;
            background: #050505;
            border: 2px solid #050505;
            border-radius: 0;
            padding: 3px 8px;
            font-size: 16px;
            font-weight: 900;
        }
        QPushButton[class="topNavButton"] {
            color: #ececec;
            background: #595959;
            border: 2px solid #050505;
            border-radius: 0;
            padding: 2px 4px;
            font-size: 15px;
            font-weight: 800;
        }
        QPushButton[class="topNavButton"]:checked {
            color: #18c7f3;
            background: #060606;
            border-color: #060606;
        }
        QPushButton[class="topNavButton"]:hover {
            color: #ffffff;
            background: #464646;
            border-color: #050505;
        }
        QWidget[class="sitonPage"] {
            background: #000000;
        }
        QWidget[class="transparent"] {
            background: transparent;
        }
        QFrame[class="sitonRail"], QFrame[class="sitonCenter"] {
            background: #545454;
            border: 4px solid #050505;
            border-radius: 8px;
        }
        QFrame[class="sitonMainFrame"] {
            background: #545454;
            border: 4px solid #050505;
            border-radius: 7px;
        }
        QFrame[class="sitonMonitorFrame"] {
            background: #545454;
            border: 0;
            border-radius: 6px;
        }
        QFrame[class="sitonHoleEditPanel"] {
            background: #4f4f4f;
            border: 3px solid #050505;
            border-radius: 6px;
        }
        QFrame[class="sitonHoleEditCoordBox"] {
            background: #565656;
            border: 2px solid #050505;
            border-radius: 5px;
        }
        QLabel[class="sitonHoleEditTitle"] {
            color: #ffffff;
            background: transparent;
            font-size: 23px;
            font-weight: 900;
        }
        QLabel[class="sitonHoleEditValue"] {
            color: #00c8ef;
            background: #020202;
            border: 2px solid #020202;
            border-radius: 5px;
            font-family: "Consolas";
            font-size: 26px;
            font-weight: 900;
        }
        QLabel[class="sitonHoleEditStatus"] {
            color: #f6df4a;
            background: transparent;
            font-size: 14px;
            font-weight: 800;
        }
        QFrame[class="sitonSettingsDimFrame"] {
            background: #141414;
            border: 0;
            border-radius: 6px;
        }
        QFrame[class="sitonSettingsDimCanvas"] {
            background: #050505;
            border: 2px solid #3b3b3b;
            border-radius: 0;
        }
        QFrame[class="sitonSettingTileBar"] {
            background: #060606;
            border: 0;
            border-radius: 0;
        }
        QFrame[class="sitonBottomBar"] {
            background: #545454;
            border: 2px solid #050505;
            border-radius: 7px;
        }
        QLabel[class="sitonTitle"] {
            color: #ffffff;
            background: transparent;
            font-size: 26px;
            font-weight: 900;
        }
        QLabel[class="sitonFieldLabel"] {
            color: #e8e8e8;
            background: transparent;
            font-size: 15px;
            font-weight: 700;
        }
        QLabel[class="sitonParamLabel"] {
            color: #ffffff;
            background: transparent;
            font-size: 13px;
            font-weight: 650;
        }
        QLabel[class="sitonValueBox"] {
            color: #ffffff;
            background: #020202;
            border: 2px solid #020202;
            border-radius: 5px;
            padding: 2px 8px;
            font-family: "Consolas";
            font-size: 14px;
            font-weight: 700;
        }
        QLabel[class="sitonValueDisplay"] {
            color: #ffffff;
            background: #020202;
            border: 2px solid #020202;
            border-radius: 5px;
            padding: 1px 7px;
            font-family: "Consolas";
            font-size: 14px;
            font-weight: 700;
        }
        QFrame[class="sitonMonitorFrame"][page="p02"] QLabel[class="sitonParamLabel"] {
            font-size: 14px;
            font-weight: 800;
        }
        QFrame[class="sitonMonitorFrame"][page="p02"] QLabel[class="sitonValueDisplay"] {
            font-size: 16px;
            padding: 2px 8px;
            font-weight: 800;
        }
        QFrame[class="sitonMonitorFrame"][page="p02"] QPushButton[class="sitonMonitorTab"] {
            font-size: 18px;
            padding: 5px 10px;
            font-weight: 800;
        }
        QLineEdit[class="sitonValueInput"], QComboBox[class="sitonValueInput"] {
            color: #ffffff;
            background: #020202;
            border: 2px solid #020202;
            border-radius: 5px;
            padding: 1px 7px;
            font-family: "Consolas";
            font-size: 13px;
            font-weight: 700;
            selection-background-color: #00c8ef;
            selection-color: #000000;
        }
        QComboBox[class="sitonValueInput"] {
            padding-right: 16px;
        }
        QComboBox[class="sitonValueInput"]::drop-down {
            width: 16px;
            border: none;
            background: transparent;
        }
        QComboBox[class="sitonValueInput"]::down-arrow {
            image: none;
            width: 0;
            height: 0;
            border: none;
        }
        QLineEdit[class="sitonValueInput"]:focus, QComboBox[class="sitonValueInput"]:focus {
            border-color: #00c8ef;
        }
        QLabel[class="sitonParamLabel"][calibrationLabel="true"] {
            font-size: 18px;
            font-weight: 900;
        }
        QLineEdit[class="sitonValueInput"][calibrationInput="true"] {
            font-size: 18px;
            padding: 4px 10px;
        }
        QPushButton[class="sitonSwitch"] {
            color: #00c8ef;
            background: #050505;
            border: 2px solid #050505;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 900;
            padding-left: 18px;
        }
        QPushButton[class="sitonSwitch"]:checked {
            color: #00c8ef;
            background: #050505;
            border-color: #050505;
        }
    )"),
        QStringLiteral(R"(
        QFrame[class="sitonProtectCard"] {
            background: #555555;
            border: 2px solid #050505;
            border-radius: 5px;
        }
        QLabel[class="sitonProtectTitle"] {
            color: #ffffff;
            background: transparent;
            font-size: 20px;
            font-weight: 700;
        }
        QFrame[class="sitonProtectLine"] {
            background: #223c39;
            border: none;
        }
        QLabel[class="sitonProtectIcon"] {
            color: #d7d7d7;
            background: #050505;
            border: 2px solid #050505;
            border-radius: 21px;
            font-size: 14px;
            font-weight: 900;
        }
        QLabel[class="sitonProtectState"] {
            color: #ffffff;
            background: transparent;
            font-size: 14px;
            font-weight: 700;
        }
        QLabel[class="sitonProtectDesc"] {
            color: #ffffff;
            background: transparent;
            font-size: 13px;
            font-weight: 600;
        }
        QFrame[class="sitonLogFrame"] {
            background: #060606;
            border: 2px solid #3a3a3a;
            border-radius: 0;
        }
        QLabel[class="sitonLogDate"] {
            color: #7f8790;
            background: transparent;
            border-bottom: 1px solid #3a3a3a;
            padding-left: 14px;
            font-size: 12px;
            font-weight: 700;
        }
        QLabel[class="sitonLogHeader"] {
            color: #7f8790;
            background: transparent;
            border-left: 1px solid #333333;
            border-bottom: 1px solid #3a3a3a;
            font-size: 15px;
            font-weight: 700;
        }
        QLabel[class="sitonLogLine"] {
            color: #cfd3d5;
            background: transparent;
            font-size: 13px;
            font-weight: 600;
        }
        QFrame[class="sitonAlarmTable"] {
            background: #050505;
            border: 2px solid #3a3a3a;
            border-radius: 0;
        }
        QLabel[class="sitonAlarmHeader"] {
            color: #cfd3d5;
            background: #0a0a0a;
            border-right: 1px solid #333333;
            border-bottom: 1px solid #3a3a3a;
            padding-left: 14px;
            font-size: 13px;
            font-weight: 800;
        }
        QLabel[class="sitonAlarmCell"] {
            color: #ffffff;
            background: transparent;
            border-right: 1px solid #222222;
            border-bottom: 1px solid #222222;
            padding-left: 14px;
            font-size: 13px;
            font-weight: 600;
        }
        QFrame[class="sitonAlarmLogTable"] {
            background: #020202;
            border: none;
            border-radius: 5px;
        }
        QLabel[class="sitonAlarmLogHeader"] {
            color: #8b969c;
            background: #020202;
            padding-left: 16px;
            font-size: 13px;
            font-weight: 800;
        }
        QLabel[class="sitonAlarmEmpty"] {
            color: #2d4650;
            background: #020202;
            font-size: 13px;
            font-weight: 700;
        }
        QFrame[class="sitonAlarmLogLine"] {
            background: #d8dbe2;
            border: none;
        }
        QPushButton[class="sitonPagerButton"] {
            color: #dce9ff;
            background: transparent;
            border: none;
            border-radius: 3px;
            font-family: Consolas;
            font-size: 14px;
            font-weight: 800;
        }
        QPushButton[class="sitonPagerButton"]:checked {
            color: #dce9ff;
            background: #33406d;
        }
        QLabel[class="sitonPagerText"] {
            color: #dce9ff;
            background: transparent;
            font-family: Consolas;
            font-size: 14px;
            font-weight: 800;
        }
        QFrame[class="sitonZeroMode"] {
            background: #050505;
            border: 2px solid #050505;
            border-radius: 5px;
        }
        QLabel[class="sitonZeroTitle"] {
            color: #00c8ef;
            background: transparent;
            font-size: 14px;
            font-weight: 800;
        }
        QLabel[class="sitonZeroDesc"] {
            color: #ffffff;
            background: transparent;
            font-size: 10px;
            font-weight: 600;
        }
        QPushButton[class="sitonZeroModeButton"] {
            color: #ffffff;
            background: #050505;
            border: 2px solid #050505;
            border-radius: 5px;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: 800;
            text-align: center;
        }
        QPushButton[class="sitonZeroModeButton"]:checked {
            color: #00c8ef;
            border-color: #00c8ef;
        }
        QPushButton[class="sitonZeroModeButton"]:pressed {
            background: #101010;
        }
    )"),
        QStringLiteral(R"(
        QPushButton[class="railButton"] {
            color: #ffffff;
            background: #7e7e7e;
            border: 2px solid #090909;
            border-radius: 7px;
            font-size: 27px;
            font-weight: 600;
        }
        QPushButton[class="railButton"]:hover {
            background: #8c8c8c;
        }
        QPushButton[class="sitonToggle"] {
            color: #e8e8e8;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 7px;
            font-size: 16px;
            font-weight: 800;
        }
        QPushButton[class="sitonToggle"]:checked {
            color: #19c9f2;
            background: #060606;
            border-color: #060606;
        }
        QPushButton[class="sitonMonitorTab"] {
            color: #ffffff;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 4px;
            padding: 4px 7px;
            font-size: 16px;
            font-weight: 700;
        }
        QPushButton[class="sitonMonitorTab"]:checked {
            color: #00c8ef;
            background: #050505;
            border-color: #050505;
        }
        QPushButton[class="sitonSmallButton"] {
            color: #ffffff;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 4px;
            padding: 2px 14px;
            font-size: 13px;
            font-weight: 700;
        }
        QToolButton[class="sitonSettingTile"] {
            color: #ffffff;
            background: #858585;
            border: 2px solid #050505;
            border-radius: 5px;
            padding: 12px 8px 16px 8px;
            font-size: 18px;
            font-weight: 700;
        }
        QToolButton[class="sitonSettingTile"]:hover {
            color: #00c8ef;
            background: #777777;
        }
        QToolButton[class="sitonSettingTile"]:pressed {
            background: #626262;
            padding-top: 14px;
            padding-bottom: 14px;
        }
        QPushButton[class="sitonBottomButton"] {
            color: #ffffff;
            background: #8b8b8b;
            border: 2px solid #050505;
            border-radius: 3px;
            font-size: 17px;
            font-weight: 700;
        }
        QLineEdit[class="sitonEditor"], QComboBox[class="sitonEditor"],
        QDateTimeEdit[class="sitonEditor"] {
            color: #f7f7f7;
            background: #020202;
            border: 2px solid #080808;
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 15px;
        }
        QLineEdit[class="sitonEditor"]:focus, QComboBox[class="sitonEditor"]:focus,
        QDateTimeEdit[class="sitonEditor"]:focus {
            border-color: #22c8f0;
        }
        QLabel[class="eyebrow"], QLabel[class="panelSubtitle"], QLabel[class="armMode"],
        QLabel[class="stepDesc"], QLabel[class="stepState"], QLabel[class="fieldLabel"],
        QLabel[class="statLabel"], QLabel[class="sideState"] {
            color: #9ea8ad;
            background: transparent;
            font-size: 12px;
        }
        QLabel[class="pageTitle"] {
            color: #f2f0e8;
            background: transparent;
            font-size: 25px;
            font-weight: 800;
        }
        QFrame[class="panel"] {
            background: #20262a;
            border: 1px solid #353e45;
            border-radius: 8px;
        }
        QWidget[class="panelHeader"] {
            background: #20262a;
            border-bottom: 1px solid #343d44;
        }
        QLabel[class="panelTitle"], QLabel[class="sectionTitle"] {
            color: #f2f0e8;
            background: transparent;
            font-size: 16px;
            font-weight: 800;
        }
        QPushButton {
            color: #f2f0e8;
            background: #262d33;
            border: 1px solid #46525a;
            border-radius: 8px;
            padding: 7px 12px;
        }
        QPushButton:hover {
            border-color: #5d6a72;
            background: #2b343a;
        }
        QPushButton:checked {
            color: #07110f;
            background: #30c29a;
            border-color: #30c29a;
            font-weight: 800;
        }
        QPushButton[class="sitonZeroModeButton"]:checked {
            color: #00c8ef;
            background: #050505;
            border-color: #00c8ef;
        }
    )"),
        QStringLiteral(R"(
        QPushButton:disabled {
            color: #566268;
            background: #1d2327;
        }
        QPushButton#primaryButton {
            color: #08110f;
            background: #30c29a;
            border-color: #30c29a;
            font-weight: 800;
        }
        QPushButton[class="armCard"] {
            text-align: left;
            background: #252b30;
            border: 1px solid #3a444b;
            border-radius: 8px;
        }
        QPushButton[class="armCard"]:checked {
            background: #252b30;
            border: 2px solid #30c29a;
        }
        QLabel[class="armName"] {
            background: transparent;
            font-weight: 800;
            font-size: 15px;
        }
        QLabel[class="metric"] {
            background: transparent;
        }
        QLabel[class="tag"], QLabel[class="tag ok"], QLabel[class="tag warn"] {
            border-radius: 7px;
            padding: 4px 8px;
            background: #20272c;
            border: 1px solid #46525a;
        }
        QLabel[class="tag ok"] {
            color: #b9ecb4;
            border-color: rgba(116, 201, 109, 120);
        }
        QLabel[class="tag warn"] {
            color: #ffd98e;
            border-color: rgba(229, 170, 66, 120);
        }
        QLabel[class="stepIndex"] {
            color: #07110f;
            background: #30c29a;
            border-radius: 12px;
            font-weight: 900;
        }
        QLabel[class="stepName"] {
            background: transparent;
            font-weight: 800;
        }
        QFrame[class="calibCard"], QFrame[class="fieldBox"], QFrame[class="summaryRow"], QFrame[class="statTile"],
        QFrame[class="inputBox"] {
            background: #252b30;
            border: 1px solid #3a444b;
            border-radius: 8px;
        }
        QGroupBox[class="sitonGroup"] {
            color: #ffffff;
            background: #545454;
            border: 2px solid #050505;
            border-radius: 4px;
            margin-top: 15px;
            font-size: 15px;
            font-weight: 700;
        }
        QGroupBox[class="sitonGroup"]::title {
            subcontrol-origin: margin;
            subcontrol-position: top left;
            left: 18px;
            padding: 0 6px;
            background: #545454;
        }
        QLineEdit, QComboBox, QDateTimeEdit {
            color: #f2f0e8;
            background: #171d21;
            border: 1px solid #46525a;
            border-radius: 7px;
            padding: 6px 10px;
            selection-background-color: #2f675c;
        }
        QLineEdit:focus, QComboBox:focus, QDateTimeEdit:focus {
            border-color: #30c29a;
        }
        QComboBox::drop-down, QDateTimeEdit::drop-down {
            width: 34px;
            border: none;
        }
        QLabel[class="fieldValue"] {
            background: transparent;
            color: #f2f0e8;
            font-size: 18px;
            font-weight: 800;
        }
        QLabel[class="statValue"] {
            background: transparent;
            color: #f2f0e8;
            font-size: 25px;
            font-weight: 900;
        }
        QTableWidget {
            background: #20262a;
            alternate-background-color: #252b30;
            gridline-color: #343d44;
            border: none;
            selection-background-color: #2f675c;
            selection-color: #f2f0e8;
        }
        QHeaderView::section {
            color: #cbd3d6;
            background: #20262a;
            border: none;
            border-bottom: 1px solid #343d44;
            padding: 8px;
            font-weight: 800;
        }
        QTableWidget::item {
            padding: 7px;
        }
        QScrollBar:vertical {
            background: #151a1e;
            width: 12px;
            margin: 0;
        }
        QScrollBar::handle:vertical {
            background: #566268;
            border-radius: 6px;
            min-height: 36px;
        }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0;
        }
        QLabel[coverageHint="covered"], QLineEdit[coverageHint="covered"], QComboBox[coverageHint="covered"],
        QPushButton[coverageHint="covered"], QToolButton[coverageHint="covered"] {
            color: #86ef8f;
        }
        QLabel[coverageHint="gap"], QLineEdit[coverageHint="gap"], QComboBox[coverageHint="gap"],
        QPushButton[coverageHint="gap"], QToolButton[coverageHint="gap"] {
            color: #00c8ef;
        }
    )")};
    qApp->setStyleSheet(qssParts.join(QString()));
}
