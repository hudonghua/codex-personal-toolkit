#include "CanBusModel.h"
#include "MainWindow.h"
#include "SitonDrillMainView.h"

#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <QAbstractButton>
#include <QApplication>
#include <QCoreApplication>
#include <QComboBox>
#include <QDir>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QFileInfo>
#include <QIcon>
#include <QLabel>
#include <QLocale>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPushButton>
#include <QSignalBlocker>
#include <QStackedWidget>
#include <QStringConverter>
#include <QTableWidget>
#include <QTextStream>
#include <QTimer>
#include <QTranslator>
#include <QVector>
#include <QWidget>

namespace {

void appendVisibleText(QStringList &lines, const QString &source, const QString &text) {
    const QString cleaned = text.simplified();
    if (cleaned.isEmpty()) {
        return;
    }
    lines.append(source + QStringLiteral("\t") + cleaned);
}

QString visibleObjectName(const QObject *object) {
    if (!object || object->objectName().isEmpty()) {
        return QStringLiteral("-");
    }
    return object->objectName();
}

QStringList collectVisibleWidgetText(QWidget *window) {
    QStringList lines;
    if (!window) {
        return lines;
    }

    for (QLabel *label : window->findChildren<QLabel *>()) {
        if (label && label->isVisibleTo(window)) {
            appendVisibleText(lines, QStringLiteral("QLabel:") + visibleObjectName(label), label->text());
        }
    }
    for (QAbstractButton *button : window->findChildren<QAbstractButton *>()) {
        if (button && button->isVisibleTo(window)) {
            appendVisibleText(lines, QStringLiteral("QAbstractButton:") + visibleObjectName(button), button->text());
        }
    }
    for (QLineEdit *edit : window->findChildren<QLineEdit *>()) {
        if (edit && edit->isVisibleTo(window)) {
            appendVisibleText(lines, QStringLiteral("QLineEdit:") + visibleObjectName(edit), edit->text());
        }
    }
    for (QComboBox *combo : window->findChildren<QComboBox *>()) {
        if (combo && combo->isVisibleTo(window)) {
            appendVisibleText(lines, QStringLiteral("QComboBox:") + visibleObjectName(combo), combo->currentText());
        }
    }
    for (QTableWidget *table : window->findChildren<QTableWidget *>()) {
        if (!table || !table->isVisibleTo(window)) {
            continue;
        }
        const QString tableName = QStringLiteral("QTableWidget:") + visibleObjectName(table);
        for (int col = 0; col < table->columnCount(); ++col) {
            if (QTableWidgetItem *header = table->horizontalHeaderItem(col)) {
                appendVisibleText(lines, tableName + QStringLiteral(":header%1").arg(col), header->text());
            }
        }
        for (int row = 0; row < table->rowCount(); ++row) {
            for (int col = 0; col < table->columnCount(); ++col) {
                if (QTableWidgetItem *item = table->item(row, col)) {
                    appendVisibleText(lines,
                                      tableName + QStringLiteral(":r%1c%2").arg(row).arg(col),
                                      item->text());
                }
            }
        }
    }
    lines.removeDuplicates();
    lines.sort();
    return lines;
}

void writeVisibleWidgetText(QWidget *window, const QString &path) {
    if (path.isEmpty()) {
        return;
    }
    QFile file(path);
    const QFileInfo info(file);
    QDir().mkpath(info.absolutePath());
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return;
    }
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    for (const QString &line : collectVisibleWidgetText(window)) {
        out << line << '\n';
    }
}

void processEventsFor(QApplication &app, int minMs) {
    QElapsedTimer timer;
    timer.start();
    do {
        app.processEvents(QEventLoop::AllEvents, 8);
    } while (timer.elapsed() < minMs);
}

double averageMs(const QVector<double> &values) {
    if (values.isEmpty()) {
        return 0.0;
    }
    double total = 0.0;
    for (double value : values) {
        total += value;
    }
    return total / values.size();
}

double maxMs(const QVector<double> &values) {
    double maxValue = 0.0;
    for (double value : values) {
        maxValue = std::max(maxValue, value);
    }
    return maxValue;
}

void writeS32ForPerf(std::array<quint8, 8> &data, int offset, qint32 value) {
    const quint32 raw = static_cast<quint32>(value);
    data[offset] = static_cast<quint8>(raw & 0xff);
    data[offset + 1] = static_cast<quint8>((raw >> 8) & 0xff);
    data[offset + 2] = static_cast<quint8>((raw >> 16) & 0xff);
    data[offset + 3] = static_cast<quint8>((raw >> 24) & 0xff);
}

void writeU16ForPerf(std::array<quint8, 8> &data, int offset, quint16 value) {
    data[offset] = static_cast<quint8>(value & 0xff);
    data[offset + 1] = static_cast<quint8>((value >> 8) & 0xff);
}

QVector<CanFrame> makePerfFrames() {
    QVector<CanFrame> frames;
    auto appendS32 = [&frames](quint8 index, qint32 value) {
        CanFrame frame;
        frame.id = 0x150;
        frame.dlc = 8;
        frame.data[0] = index;
        writeS32ForPerf(frame.data, 1, value);
        if (index == 0x13 || index == 0x14 || index == 0x15
            || index == 0x23 || index == 0x24 || index == 0x25
            || index == 0x33 || index == 0x34 || index == 0x35) {
            frame.data[5] = 1;
        }
        frames.append(frame);
    };
    for (quint8 index : {quint8(0x10), quint8(0x11), quint8(0x12), quint8(0x13), quint8(0x14), quint8(0x15),
                         quint8(0x20), quint8(0x21), quint8(0x22), quint8(0x23), quint8(0x24), quint8(0x25),
                         quint8(0x30), quint8(0x31), quint8(0x32), quint8(0x33), quint8(0x34), quint8(0x35)}) {
        appendS32(index, 12000 + int(index) * 37);
    }
    CanFrame depth;
    depth.id = 0x153;
    depth.dlc = 8;
    writeU16ForPerf(depth.data, 0, 2500);
    writeU16ForPerf(depth.data, 2, 2500);
    writeU16ForPerf(depth.data, 4, 2500);
    frames.append(depth);

    CanFrame pressure;
    pressure.id = 0x176;
    pressure.dlc = 8;
    pressure.data[0] = 0x08;
    writeU16ForPerf(pressure.data, 1, 130);
    writeU16ForPerf(pressure.data, 3, 90);
    writeU16ForPerf(pressure.data, 5, 45);
    frames.append(pressure);

    CanFrame selected;
    selected.id = 0x176;
    selected.dlc = 8;
    selected.data[0] = 0x21;
    selected.data[1] = 1;
    selected.data[2] = 3;
    selected.data[3] = 0x07;
    frames.append(selected);

    CanFrame drilling;
    drilling.id = 0x176;
    drilling.dlc = 8;
    drilling.data[0] = 0x22;
    drilling.data[1] = 2;
    drilling.data[2] = 1;
    drilling.data[3] = 0;
    drilling.data[4] = 0x01;
    drilling.data[5] = 0x01;
    frames.append(drilling);

    CanFrame alarm;
    alarm.id = 0x170;
    alarm.dlc = 8;
    alarm.data[0] = 0x01;
    alarm.data[1] = 0x08;
    frames.append(alarm);

    CanFrame dropout;
    dropout.id = 0x15a;
    dropout.dlc = 8;
    dropout.data[3] = 0x00;
    frames.append(dropout);
    return frames;
}

bool printMetric(QTextStream &out, const QString &name, double avg, double max, const QString &unit,
                 double avgLimit, double maxLimit) {
    const bool pass = avg <= avgLimit && max <= maxLimit;
    out << (pass ? QStringLiteral("PASS ") : QStringLiteral("FAIL "))
        << name << QStringLiteral(": avg=") << QString::number(avg, 'f', 3) << unit
        << QStringLiteral(" max=") << QString::number(max, 'f', 3) << unit
        << QStringLiteral(" limit_avg<=") << QString::number(avgLimit, 'f', 3) << unit
        << QStringLiteral(" limit_max<=") << QString::number(maxLimit, 'f', 3) << unit << '\n';
    out.flush();
    return pass;
}

int runUiPerfSelfTest(QApplication &app) {
    QTextStream out(stdout);
    bool ok = true;

    out << "STEP perf-frames\n";
    out.flush();
    const QVector<CanFrame> frames = makePerfFrames();
    {
        out << "STEP business-frame-decode\n";
        out.flush();
        CanBusinessStateModel model;
        const int loops = 60000;
        QElapsedTimer timer;
        timer.start();
        for (int i = 0; i < loops; ++i) {
            model.applyFrame(frames.at(i % frames.size()));
        }
        const double avgUs = double(timer.nsecsElapsed()) / loops / 1000.0;
        ok = printMetric(out, QStringLiteral("business-frame-decode"), avgUs, avgUs,
                         QStringLiteral("us"), 40.0, 80.0) && ok;
    }
    {
        out << "STEP can-to-net-codec-roundtrip\n";
        out.flush();
        CanToNetPacket packet;
        const int loops = 30000;
        QElapsedTimer timer;
        timer.start();
        for (int i = 0; i < loops; ++i) {
            const QByteArray encoded = CanToNetCodec::encodeCanFrame(frames.at(i % frames.size()), quint8(i & 0xff));
            if (!CanToNetCodec::tryDecodePacket(encoded, &packet, nullptr)) {
                out << "FAIL can-to-net-codec: decode failed\n";
                ok = false;
                break;
            }
        }
        const double avgUs = double(timer.nsecsElapsed()) / loops / 1000.0;
        ok = printMetric(out, QStringLiteral("can-to-net-codec-roundtrip"), avgUs, avgUs,
                         QStringLiteral("us"), 60.0, 120.0) && ok;
    }

    out << "STEP startup-first-paint\n";
    out.flush();
    QElapsedTimer startupTimer;
    startupTimer.start();
    MainWindow window;
    window.resize(1280, 720);
    window.show();
    processEventsFor(app, 120);
    window.grab();
    const double firstPaintMs = double(startupTimer.nsecsElapsed()) / 1000000.0;
    ok = printMetric(out, QStringLiteral("startup-first-paint"), firstPaintMs, firstPaintMs,
                     QStringLiteral("ms"), 900.0, 1400.0) && ok;

    out << "STEP page-switch-and-paint\n";
    out.flush();
    for (int page = 0; page <= 9; ++page) {
        window.setPageForScreenshot(page);
        app.processEvents(QEventLoop::AllEvents, 10);
        window.grab();
    }
    QVector<double> pageSwitchMs;
    for (int round = 0; round < 3; ++round) {
        for (int page = 0; page <= 9; ++page) {
            QElapsedTimer timer;
            timer.start();
            window.setPageForScreenshot(page);
            app.processEvents(QEventLoop::AllEvents, 20);
            window.grab();
            pageSwitchMs.append(double(timer.nsecsElapsed()) / 1000000.0);
        }
    }
    ok = printMetric(out, QStringLiteral("page-switch-and-paint"), averageMs(pageSwitchMs), maxMs(pageSwitchMs),
                     QStringLiteral("ms"), 35.0, 120.0) && ok;

    QVector<double> dashboardRefreshMs;
    out << "STEP dashboard-demo-refresh\n";
    out.flush();
    window.setPageForScreenshot(0);
    processEventsFor(app, 40);
    for (int i = 0; i < 80; ++i) {
        QElapsedTimer timer;
        timer.start();
        window.injectDemoCanFramesForScreenshot();
        app.processEvents(QEventLoop::AllEvents, 10);
        if ((i % 10) == 0) {
            window.grab();
        }
        dashboardRefreshMs.append(double(timer.nsecsElapsed()) / 1000000.0);
    }
    ok = printMetric(out, QStringLiteral("dashboard-demo-refresh"), averageMs(dashboardRefreshMs), maxMs(dashboardRefreshMs),
                     QStringLiteral("ms"), 18.0, 90.0) && ok;

    out << "STEP drill-view-tab-and-paint\n";
    out.flush();
    SitonDrillMainView *drillView = nullptr;
    const QList<QWidget *> widgets = window.findChildren<QWidget *>();
    for (QWidget *widget : widgets) {
        if ((drillView = dynamic_cast<SitonDrillMainView *>(widget)) != nullptr) {
            break;
        }
    }
    if (drillView) {
        for (int tab = 0; tab < 4; ++tab) {
            drillView->setViewTabForScreenshot(tab);
            app.processEvents(QEventLoop::AllEvents, 10);
        }
        QVector<double> viewSwitchMs;
        for (int round = 0; round < 5; ++round) {
            for (int tab = 0; tab < 4; ++tab) {
                QElapsedTimer timer;
                timer.start();
                drillView->setViewTabForScreenshot(tab);
                app.processEvents(QEventLoop::AllEvents, 20);
                viewSwitchMs.append(double(timer.nsecsElapsed()) / 1000000.0);
            }
        }
        ok = printMetric(out, QStringLiteral("drill-view-tab-and-paint"), averageMs(viewSwitchMs), maxMs(viewSwitchMs),
                         QStringLiteral("ms"), 28.0, 100.0) && ok;
    } else {
        out << "FAIL drill-view-tab-and-paint: SitonDrillMainView not found\n";
        ok = false;
    }

    out << (ok ? "UI_PERF_SELF_TEST OK\n" : "UI_PERF_SELF_TEST FAIL\n");
    out.flush();
    return ok ? 0 : 4;
}

} // namespace

int main(int argc, char *argv[]) {
    for (int i = 1; i < argc; ++i) {
        if (QString::fromLocal8Bit(argv[i]) == QStringLiteral("--self-test-can")) {
            QString error;
            if (!runCanBusModelSelfTest(&error)) {
                const QByteArray text = error.toLocal8Bit();
                std::fprintf(stderr, "%s\n", text.constData());
                return 2;
            }
            std::fprintf(stdout, "CAN_TO_NET self-test OK\n");
            return 0;
        }
    }

    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("QdnUpperComputerUi"));
    QApplication::setOrganizationName(QStringLiteral("QDN"));
    const QStringList args = app.arguments();

    if (args.contains(QStringLiteral("--self-test-ui-perf"))) {
        return runUiPerfSelfTest(app);
    }

    const QIcon appIcon(QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("new_logo.png")));
    if (!appIcon.isNull()) {
        QApplication::setWindowIcon(appIcon);
    }

    MainWindow window;
    if (!appIcon.isNull()) {
        window.setWindowIcon(appIcon);
    }
    const int screenshotArg = args.indexOf(QStringLiteral("--screenshot"));
    if (screenshotArg >= 0 && screenshotArg + 1 < args.size()) {
        window.resize(1280, 720);
        window.show();
        int lastActionDelay = 0;
        bool useDemoCan = args.contains(QStringLiteral("--screenshot-demo-can"));
        double demoDepths[3] = {1.25, 2.10, 0.85};
        const int demoDepthArg = args.indexOf(QStringLiteral("--screenshot-demo-depth"));
        if (demoDepthArg >= 0 && demoDepthArg + 1 < args.size()) {
            bool ok = false;
            const double firstDepth = args.at(demoDepthArg + 1).toDouble(&ok);
            if (ok) {
                useDemoCan = true;
                demoDepths[0] = firstDepth;
                demoDepths[1] = firstDepth;
                demoDepths[2] = firstDepth;
                for (int arm = 1; arm < 3; ++arm) {
                    const int valueIndex = demoDepthArg + 1 + arm;
                    if (valueIndex >= args.size() || args.at(valueIndex).startsWith(QStringLiteral("--"))) {
                        break;
                    }
                    bool armOk = false;
                    const double armDepth = args.at(valueIndex).toDouble(&armOk);
                    if (armOk) {
                        demoDepths[arm] = armDepth;
                    }
                }
            }
        }
        if (useDemoCan) {
            QTimer::singleShot(140, &window, [&window, demoDepths] {
                window.injectDemoCanFramesForScreenshot(demoDepths[0], demoDepths[1], demoDepths[2]);
            });
            lastActionDelay = std::max(lastActionDelay, 140);
        }
        const int screenshotPageArg = args.indexOf(QStringLiteral("--screenshot-page"));
        if (screenshotPageArg >= 0 && screenshotPageArg + 1 < args.size()) {
            const QString pageName = args.at(screenshotPageArg + 1);
            QTimer::singleShot(100, &window, [&window, pageName] {
                const QList<QAbstractButton *> buttons = window.findChildren<QAbstractButton *>();
                for (QAbstractButton *button : buttons) {
                    if (button && button->isVisibleTo(&window) && button->text() == pageName) {
                        button->click();
                        break;
                    }
                }
            });
            lastActionDelay = std::max(lastActionDelay, 100);
        }
        const int screenshotIndexArg = args.indexOf(QStringLiteral("--screenshot-index"));
        if (screenshotIndexArg >= 0 && screenshotIndexArg + 1 < args.size()) {
            bool ok = false;
            const int pageIndex = args.at(screenshotIndexArg + 1).toInt(&ok);
            if (ok) {
                QTimer::singleShot(120, &window, [&window, pageIndex] {
                    window.setPageForScreenshot(pageIndex);
                });
                lastActionDelay = std::max(lastActionDelay, 120);
            }
        }
        const int screenshotLeftTabArg = args.indexOf(QStringLiteral("--screenshot-left-tab"));
        if (screenshotLeftTabArg >= 0 && screenshotLeftTabArg + 1 < args.size()) {
            bool ok = false;
            const int leftTabIndex = args.at(screenshotLeftTabArg + 1).toInt(&ok);
            if (ok) {
                QTimer::singleShot(160, &window, [&window, leftTabIndex] {
                    const QList<QWidget *> widgets = window.findChildren<QWidget *>();
                    for (QWidget *widget : widgets) {
                        if (auto *view = dynamic_cast<SitonDrillMainView *>(widget)) {
                            view->setLeftTabForScreenshot(leftTabIndex);
                            break;
                        }
                    }
                });
                lastActionDelay = std::max(lastActionDelay, 160);
            }
        }
        const int screenshotViewTabArg = args.indexOf(QStringLiteral("--screenshot-view-tab"));
        if (screenshotViewTabArg >= 0 && screenshotViewTabArg + 1 < args.size()) {
            bool ok = false;
            const int viewTabIndex = args.at(screenshotViewTabArg + 1).toInt(&ok);
            if (ok) {
                QTimer::singleShot(180, &window, [&window, viewTabIndex] {
                    const QList<QWidget *> widgets = window.findChildren<QWidget *>();
                    for (QWidget *widget : widgets) {
                        if (auto *view = dynamic_cast<SitonDrillMainView *>(widget)) {
                            view->setViewTabForScreenshot(viewTabIndex);
                            break;
                        }
                    }
                });
                lastActionDelay = std::max(lastActionDelay, 180);
            }
        }
        const int screenshotHoleArg = args.indexOf(QStringLiteral("--screenshot-select-hole"));
        if (screenshotHoleArg >= 0 && screenshotHoleArg + 1 < args.size()) {
            bool ok = false;
            const int holeIndex = args.at(screenshotHoleArg + 1).toInt(&ok);
            if (ok) {
                QTimer::singleShot(520, &window, [&window, holeIndex] {
                    const QList<QWidget *> widgets = window.findChildren<QWidget *>();
                    for (QWidget *widget : widgets) {
                        if (auto *view = dynamic_cast<SitonDrillMainView *>(widget)) {
                            if (!view->isHoleEditMode()) {
                                continue;
                            }
                            view->selectHoleForScreenshot(holeIndex);
                            break;
                        }
                    }
                });
                lastActionDelay = std::max(lastActionDelay, 520);
            }
        }
        const int screenshotClickArg = args.indexOf(QStringLiteral("--screenshot-click"));
        if (screenshotClickArg >= 0 && screenshotClickArg + 2 < args.size()) {
            bool okX = false;
            bool okY = false;
            const QPointF clickPoint(args.at(screenshotClickArg + 1).toDouble(&okX),
                                     args.at(screenshotClickArg + 2).toDouble(&okY));
            if (okX && okY) {
                QTimer::singleShot(250, &window, [&window, clickPoint] {
                    const QPoint global = window.mapToGlobal(clickPoint.toPoint());
                    QWidget *target = QApplication::widgetAt(global);
                    if (!target) {
                        target = &window;
                    }
                    const QPointF local = target->mapFromGlobal(global);
                    const QPointF globalF(global);
                    QMouseEvent press(QEvent::MouseButtonPress, local, local, globalF,
                                      Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
                    QApplication::sendEvent(target, &press);
                    QMouseEvent release(QEvent::MouseButtonRelease, local, local, globalF,
                                        Qt::LeftButton, Qt::NoButton, Qt::NoModifier);
                    QApplication::sendEvent(target, &release);
                });
                lastActionDelay = std::max(lastActionDelay, 250);
            }
        }
        int lineEditDelay = 260;
        for (int i = 1; i < args.size(); ++i) {
            if (args.at(i) != QStringLiteral("--screenshot-set-lineedit") || i + 2 >= args.size()) {
                continue;
            }
            const QString objectName = args.at(i + 1);
            const QString value = args.at(i + 2);
            QTimer::singleShot(lineEditDelay, &window, [&window, objectName, value] {
                if (auto *edit = window.findChild<QLineEdit *>(objectName)) {
                    const QSignalBlocker blocker(edit);
                    edit->setText(value);
                }
            });
            lastActionDelay = std::max(lastActionDelay, lineEditDelay);
            lineEditDelay += 80;
            i += 2;
        }
        int buttonDelay = std::max(300, lineEditDelay + 40);
        for (int i = 1; i < args.size(); ++i) {
            if (args.at(i) != QStringLiteral("--screenshot-button") || i + 1 >= args.size()) {
                continue;
            }
            const QString buttonText = args.at(i + 1);
            QTimer::singleShot(buttonDelay, &window, [&window, buttonText] {
                const QList<QAbstractButton *> buttons = window.findChildren<QAbstractButton *>();
                for (QAbstractButton *button : buttons) {
                    if (button && button->isVisibleTo(&window) && button->text() == buttonText) {
                        button->click();
                        break;
                    }
                }
            });
            lastActionDelay = std::max(lastActionDelay, buttonDelay);
            buttonDelay += 220;
            ++i;
        }
        QString textDumpPath;
        const int screenshotTextArg = args.indexOf(QStringLiteral("--screenshot-text"));
        if (screenshotTextArg >= 0 && screenshotTextArg + 1 < args.size()) {
            textDumpPath = args.at(screenshotTextArg + 1);
        }
        const int captureDelay = std::max(750, lastActionDelay + 520);
        QTimer::singleShot(captureDelay, &app, [&window, path = args.at(screenshotArg + 1), textDumpPath, &app] {
            writeVisibleWidgetText(&window, textDumpPath);
            const QPixmap pixmap = window.grab();
            pixmap.save(path);
            app.processEvents(QEventLoop::AllEvents, 20);
            std::exit(0);
        });
        return app.exec();
    }

    window.setWindowFlag(Qt::FramelessWindowHint, true);
    window.showFullScreen();

    return app.exec();
}
