using System.Globalization;

namespace McgsModbusTool;

internal sealed class MainForm : Form
{
    private readonly ModbusTcpClient _client = new();
    private readonly System.Windows.Forms.Timer _readTimer = new();
    private readonly System.Windows.Forms.Timer _writeTimer = new();
    private readonly System.Windows.Forms.Timer _monitorTimer = new();

    private TextBox _hostTextBox = null!;
    private NumericUpDown _portBox = null!;
    private NumericUpDown _unitIdBox = null!;
    private NumericUpDown _timeoutBox = null!;
    private NumericUpDown _addressOffsetBox = null!;
    private NumericUpDown _readAddressBox = null!;
    private NumericUpDown _readQuantityBox = null!;
    private NumericUpDown _readIntervalBox = null!;
    private NumericUpDown _writeIntervalBox = null!;
    private ComboBox _readFunctionBox = null!;
    private DataGridView _receiveGrid = null!;
    private DataGridView _sendGrid = null!;
    private DataGridView _rxMonitorGrid = null!;
    private DataGridView _txMonitorGrid = null!;
    private RichTextBox _logBox = null!;
    private Button _connectButton = null!;
    private Button _disconnectButton = null!;
    private Button _readButton = null!;
    private Button _readPollButton = null!;
    private Button _writeButton = null!;
    private Button _autoWriteButton = null!;
    private Button _addSendRowButton = null!;
    private Button _deleteSendRowButton = null!;
    private Button _monitorReadButton = null!;
    private Button _monitorPollButton = null!;
    private Label _statusLabel = null!;
    private Label _monitorStatusLabel = null!;
    private bool _isReadPolling;
    private bool _isAutoWriting;
    private bool _isMonitorPolling;
    private bool _readInFlight;
    private bool _writeInFlight;
    private bool _monitorReadInFlight;
    private readonly Dictionary<int, ushort> _lastTxRegisters = [];

    private static readonly CanRegisterMap[] ReceiveMaps =
    [
        new("0x150", 50, "三臂 H/H1 坐标、标定反馈"),
        new("0x152", 54, "端点 XZ/YZ 角度"),
        new("0x153", 58, "三臂当前钻进深度"),
        new("0x154", 62, "编码器角度组"),
        new("0x15A", 66, "算法PCB/倾角仪/编码器掉线"),
        new("0x170", 70, "急停、操作台、按键、报警位"),
        new("0x176", 74, "压力、水流量、润滑压力、选臂、开钻")
    ];

    private static readonly CanRegisterMap[] SendMaps =
    [
        new("0x50", 100, "清零、A1/A2/A3 标定下发"),
        new("0x71", 104, "钻机参数预设"),
        new("0x75", 108, "电流/动作标定扩展，未确认前慎写"),
        new("0x7A", 112, "压力/电流扩展标定，未确认前慎写")
    ];

    public MainForm()
    {
        Text = "CAN_TO_NET 503端口电脑端（协议待确认）";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1120, 720);
        Size = new Size(1240, 780);
        Font = new Font("Microsoft YaHei UI", 9F);

        BuildUi();

        _readTimer.Tick += async (_, _) => await ReadTimerTickAsync();
        _writeTimer.Tick += async (_, _) => await WriteTimerTickAsync();
        _monitorTimer.Tick += async (_, _) => await MonitorTimerTickAsync();
        FormClosing += (_, _) =>
        {
            _monitorTimer.Stop();
            _client.Dispose();
        };
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(10)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        root.Controls.Add(BuildConnectionPanel(), 0, 0);

        _logBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BackColor = Color.FromArgb(30, 30, 30),
            ForeColor = Color.Gainsboro,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 9F)
        };

        var mainLogSplit = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            SplitterDistance = 560,
            SplitterWidth = 8,
            Panel1MinSize = 260,
            Panel2MinSize = 80,
            BorderStyle = BorderStyle.FixedSingle
        };
        mainLogSplit.Panel1.Controls.Add(BuildMainPanel());
        mainLogSplit.Panel2.Controls.Add(_logBox);
        root.Controls.Add(mainLogSplit, 0, 1);
    }

    private Control BuildConnectionPanel()
    {
        var group = new GroupBox
        {
            Text = "网络连接",
            Dock = DockStyle.Fill
        };

        var panel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(10, 14, 10, 8),
            WrapContents = true
        };
        group.Controls.Add(panel);

        _hostTextBox = new TextBox { Width = 140, Text = "192.168.0.105" };
        _portBox = CreateNumberBox(1, 65535, 503, 76);
        _unitIdBox = CreateNumberBox(0, 255, 255, 66);
        _timeoutBox = CreateNumberBox(20, 10000, 100, 82);
        _addressOffsetBox = CreateNumberBox(0, 10, 1, 66);

        _connectButton = new Button { Text = "连接", Width = 76, Height = 30 };
        _disconnectButton = new Button { Text = "断开", Width = 76, Height = 30, Enabled = false };
        _statusLabel = new Label
        {
            AutoSize = false,
            Width = 390,
            Height = 30,
            TextAlign = ContentAlignment.MiddleLeft,
            Text = "状态：未连接"
        };

        _connectButton.Click += async (_, _) => await ConnectAsync();
        _disconnectButton.Click += (_, _) => Disconnect();
        AddLabeled(panel, "CAN_TO_NET IP", _hostTextBox);
        AddLabeled(panel, "端口", _portBox);
        AddLabeled(panel, "站号", _unitIdBox);
        AddLabeled(panel, "超时(ms)", _timeoutBox);
        AddLabeled(panel, "地址偏移", _addressOffsetBox);
        panel.Controls.Add(_connectButton);
        panel.Controls.Add(_disconnectButton);
        panel.Controls.Add(_statusLabel);

        return group;
    }

    private Control BuildMainPanel()
    {
        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Font = new Font("Microsoft YaHei UI", 9F)
        };

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Vertical,
            SplitterDistance = 535,
            SplitterWidth = 8,
            BorderStyle = BorderStyle.FixedSingle
        };
        split.Panel1.Controls.Add(BuildReceivePanel());
        split.Panel2.Controls.Add(BuildSendPanel());

        var editPage = new TabPage("寄存器读写 / 发送编辑");
        editPage.Controls.Add(split);
        tabs.TabPages.Add(editPage);

        var monitorPage = new TabPage("CAN收发监控");
        monitorPage.Controls.Add(BuildCanMonitorPanel());
        tabs.TabPages.Add(monitorPage);

        tabs.SelectedIndex = 1;
        return tabs;
    }

    private Control BuildReceivePanel()
    {
        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            SplitterDistance = 92,
            SplitterWidth = 8,
            Panel1MinSize = 62,
            Panel2MinSize = 120,
            BorderStyle = BorderStyle.FixedSingle
        };

        var group = new GroupBox
        {
            Text = "CAN_TO_NET -> 电脑：读取数据",
            Dock = DockStyle.Fill
        };
        split.Panel1.Controls.Add(group);

        var controls = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(10, 14, 10, 8),
            WrapContents = true
        };
        group.Controls.Add(controls);

        _readFunctionBox = new ComboBox { Width = 155, DropDownStyle = ComboBoxStyle.DropDownList };
        _readFunctionBox.Items.AddRange(["03 读保持寄存器", "04 读输入寄存器"]);
        _readFunctionBox.SelectedIndex = 0;

        _readAddressBox = CreateNumberBox(0, 65535, 50, 80);
        _readQuantityBox = CreateNumberBox(1, 125, 28, 70);
        _readIntervalBox = CreateNumberBox(20, 60000, 100, 84);

        _readButton = new Button { Text = "读一次", Width = 82, Height = 30 };
        _readPollButton = new Button { Text = "自动读", Width = 86, Height = 30 };
        _readButton.Click += async (_, _) => await ReadOnceAsync(showSuccessLog: true, showMessage: true, setBusy: true);
        _readPollButton.Click += (_, _) => ToggleReadPolling();

        AddLabeled(controls, "功能", _readFunctionBox);
        AddLabeled(controls, "CAN_TO_NET起始地址", _readAddressBox);
        AddLabeled(controls, "数量", _readQuantityBox);
        AddLabeled(controls, "周期(ms)", _readIntervalBox);
        controls.Controls.Add(_readButton);
        controls.Controls.Add(_readPollButton);

        _receiveGrid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            ReadOnly = true,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            BackgroundColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle
        };
        _receiveGrid.Columns.Add("ScreenAddress", "CAN_TO_NET地址");
        _receiveGrid.Columns.Add("CanId", "CAN ID");
        _receiveGrid.Columns.Add("Unsigned", "无符号值");
        _receiveGrid.Columns.Add("Signed", "有符号值");
        _receiveGrid.Columns.Add("Hex", "十六进制");
        _receiveGrid.Columns["ScreenAddress"]!.FillWeight = 115;
        _receiveGrid.Columns["CanId"]!.FillWeight = 85;
        split.Panel2.Controls.Add(_receiveGrid);

        return split;
    }

    private Control BuildSendPanel()
    {
        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2
        };
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var group = new GroupBox
        {
            Text = "电脑 -> CAN_TO_NET：发送编辑窗口",
            Dock = DockStyle.Fill
        };
        table.Controls.Add(group, 0, 0);

        var controls = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(10, 14, 10, 8),
            WrapContents = true
        };
        group.Controls.Add(controls);

        _writeIntervalBox = CreateNumberBox(20, 60000, 100, 84);
        _writeButton = new Button { Text = "发送一次", Width = 86, Height = 30 };
        _autoWriteButton = new Button { Text = "自动发送", Width = 90, Height = 30 };
        _addSendRowButton = new Button { Text = "加一行", Width = 76, Height = 30 };
        _deleteSendRowButton = new Button { Text = "删选中", Width = 76, Height = 30 };

        _writeButton.Click += async (_, _) => await WriteEnabledRowsAsync(showMessage: true, setBusy: true);
        _autoWriteButton.Click += (_, _) => ToggleAutoWriting();
        _addSendRowButton.Click += (_, _) => AddSendRow();
        _deleteSendRowButton.Click += (_, _) => DeleteSelectedSendRows();

        AddLabeled(controls, "周期(ms)", _writeIntervalBox);
        controls.Controls.Add(_writeButton);
        controls.Controls.Add(_autoWriteButton);
        controls.Controls.Add(_addSendRowButton);
        controls.Controls.Add(_deleteSendRowButton);

        _sendGrid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = true,
            AllowUserToDeleteRows = true,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            BackgroundColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle,
            EditMode = DataGridViewEditMode.EditOnEnter
        };
        _sendGrid.Columns.Add(new DataGridViewCheckBoxColumn
        {
            Name = "Enabled",
            HeaderText = "启用",
            Width = 48,
            FillWeight = 42
        });
        _sendGrid.Columns.Add("Name", "名称");
        _sendGrid.Columns.Add("Address", "CAN_TO_NET地址");
        _sendGrid.Columns.Add("CanId", "CAN ID");
        _sendGrid.Columns.Add("Value", "发送值");
        _sendGrid.Columns.Add("Hex", "十六进制");
        _sendGrid.Columns.Add("Status", "最近状态");
        _sendGrid.Columns["CanId"]!.ReadOnly = true;
        _sendGrid.Columns["Status"]!.ReadOnly = true;
        _sendGrid.Columns["Hex"]!.ReadOnly = true;
        _sendGrid.Columns["Enabled"]!.FillWeight = 42;
        _sendGrid.Columns["Name"]!.FillWeight = 92;
        _sendGrid.Columns["Address"]!.FillWeight = 110;
        _sendGrid.Columns["CanId"]!.FillWeight = 74;
        _sendGrid.Columns["Value"]!.FillWeight = 84;
        _sendGrid.Columns["Hex"]!.FillWeight = 84;
        _sendGrid.Columns["Status"]!.FillWeight = 115;
        _sendGrid.CellEndEdit += (_, args) =>
        {
            UpdateSendRowDisplay(args.RowIndex);
            RefreshSendMonitorFromSendGrid();
        };
        _sendGrid.CellValueChanged += (_, _) => RefreshSendMonitorFromSendGrid();
        _sendGrid.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (_sendGrid.IsCurrentCellDirty)
            {
                _sendGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        };
        _sendGrid.UserAddedRow += (_, _) => PrepareLastEditableRow();
        table.Controls.Add(_sendGrid, 0, 1);

        AddSendRow("0x50 字0(B0/B1)", 100, 0);
        AddSendRow("0x50 字1(B2/B3)", 101, 0);
        AddSendRow("0x50 字2(B4/B5)", 102, 0);
        AddSendRow("0x50 字3(B6/B7)", 103, 0);

        return table;
    }

    private Control BuildCanMonitorPanel()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(2)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var controls = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(10, 10, 10, 6),
            WrapContents = false
        };
        _monitorReadButton = new Button { Text = "监控读一次", Width = 100, Height = 30 };
        _monitorPollButton = new Button { Text = "停止监控", Width = 92, Height = 30 };
        _monitorStatusLabel = new Label
        {
            AutoSize = false,
            Width = 520,
            Height = 30,
            TextAlign = ContentAlignment.MiddleLeft,
            Text = "CAN监控：连接后自动读取 50-77 / 100-115"
        };
        _monitorReadButton.Click += async (_, _) => await ReadCanMonitorOnceAsync(showLog: true);
        _monitorPollButton.Click += (_, _) => ToggleMonitorPolling();
        controls.Controls.Add(_monitorReadButton);
        controls.Controls.Add(_monitorPollButton);
        controls.Controls.Add(_monitorStatusLabel);
        root.Controls.Add(controls, 0, 0);

        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(2)
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
        table.RowStyles.Add(new RowStyle(SizeType.Percent, 42));

        table.Controls.Add(BuildMonitorGroup("CAN_TO_NET -> 电脑：接收数据监控", ReceiveMaps, out _rxMonitorGrid), 0, 0);
        table.Controls.Add(BuildMonitorGroup("电脑 -> CAN_TO_NET：发送数据监控", SendMaps, out _txMonitorGrid), 0, 1);
        RefreshSendMonitorFromSendGrid();
        root.Controls.Add(table, 0, 1);
        return root;
    }

    private Control BuildMonitorGroup(string title, IReadOnlyList<CanRegisterMap> maps, out DataGridView grid)
    {
        var group = new GroupBox
        {
            Text = title,
            Dock = DockStyle.Fill
        };

        grid = CreateCanMonitorGrid();
        group.Controls.Add(grid);
        InitializeCanMonitorRows(grid, maps);
        return group;
    }

    private static DataGridView CreateCanMonitorGrid()
    {
        var grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            ReadOnly = true,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            BackgroundColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle
        };

        grid.Columns.Add("CanId", "CAN ID");
        grid.Columns.Add("AddressRange", "CAN_TO_NET地址");
        grid.Columns.Add("Purpose", "内容");
        for (var i = 0; i < 8; i++)
        {
            grid.Columns.Add($"B{i}", $"B{i}");
        }
        for (var i = 0; i < 4; i++)
        {
            grid.Columns.Add($"W{i}", $"寄存器{i + 1}");
        }
        grid.Columns.Add("Updated", "最后更新");

        grid.Columns["CanId"]!.Width = 64;
        grid.Columns["AddressRange"]!.Width = 112;
        grid.Columns["Purpose"]!.Width = 210;
        for (var i = 0; i < 8; i++)
        {
            grid.Columns[$"B{i}"]!.Width = 44;
        }
        for (var i = 0; i < 4; i++)
        {
            grid.Columns[$"W{i}"]!.Width = 72;
        }
        grid.Columns["Updated"]!.Width = 100;
        return grid;
    }

    private async Task ConnectAsync()
    {
        await ExecuteOperationAsync("连接", async token =>
        {
            await _client.ConnectAsync(_hostTextBox.Text.Trim(), (int)_portBox.Value, (int)_timeoutBox.Value, token);
            SetConnectedState(true);
            Log($"已连接 {_hostTextBox.Text.Trim()}:{_portBox.Value}，站号 {(byte)_unitIdBox.Value}");
        }, showMessage: true, setBusy: true);
    }

    private void Disconnect()
    {
        StopReadPolling();
        StopAutoWriting();
        StopMonitorPolling();
        _client.Disconnect();
        SetConnectedState(false);
        Log("已断开连接");
    }

    private async Task EnsureConnectedAsync(CancellationToken token)
    {
        if (_client.IsConnected)
        {
            return;
        }

        await _client.ConnectAsync(_hostTextBox.Text.Trim(), (int)_portBox.Value, (int)_timeoutBox.Value, token);
        SetConnectedState(true);
        Log("已自动重连");
    }

    private async Task ReadOnceAsync(bool showSuccessLog, bool showMessage, bool setBusy)
    {
        if (_readInFlight)
        {
            return;
        }

        _readInFlight = true;
        try
        {
            await ExecuteOperationAsync("读取", async token =>
            {
                await EnsureConnectedAsync(token);

                var unitId = (byte)_unitIdBox.Value;
                var screenAddress = (int)_readAddressBox.Value;
                var address = ScreenToProtocolAddress(screenAddress);
                var quantity = (ushort)_readQuantityBox.Value;
                var timeout = (int)_timeoutBox.Value;
                ushort[] values;

                if (_readFunctionBox.SelectedIndex == 0)
                {
                    values = await _client.ReadHoldingRegistersAsync(unitId, address, quantity, timeout, token);
                }
                else
                {
                    values = await _client.ReadInputRegistersAsync(unitId, address, quantity, timeout, token);
                }

                ShowReceivedRegisters(address, values);
                if (showSuccessLog)
                {
                    Log($"读取成功：CAN_TO_NET地址 {screenAddress}，数量 {quantity}");
                }
            }, showMessage, setBusy);
        }
        finally
        {
            _readInFlight = false;
        }
    }

    private async Task ReadCanMonitorOnceAsync(bool showLog)
    {
        if (_monitorReadInFlight)
        {
            return;
        }

        _monitorReadInFlight = true;
        try
        {
            var timeoutMs = (int)_timeoutBox.Value;
            using var cts = new CancellationTokenSource(timeoutMs * 2 + 120);
            await EnsureConnectedAsync(cts.Token);

            const int receiveStartAddress = 50;
            const ushort receiveQuantity = 28;
            var receiveProtocolAddress = ScreenToProtocolAddress(receiveStartAddress);
            var receiveValues = await _client.ReadHoldingRegistersAsync((byte)_unitIdBox.Value,
                receiveProtocolAddress,
                receiveQuantity,
                timeoutMs,
                cts.Token);

            ShowReceivedRegisters(receiveProtocolAddress, receiveValues);

            const int sendStartAddress = 100;
            const ushort sendQuantity = 16;
            var sendProtocolAddress = ScreenToProtocolAddress(sendStartAddress);
            var sendValues = await _client.ReadHoldingRegistersAsync((byte)_unitIdBox.Value,
                sendProtocolAddress,
                sendQuantity,
                timeoutMs,
                cts.Token);

            UpdateSendMonitor(sendProtocolAddress, sendValues);
            _monitorStatusLabel.Text = $"CAN监控：已刷新 50-77 / 100-115  {DateTime.Now:HH:mm:ss.fff}";
            if (showLog)
            {
                Log("CAN监控读取成功：CAN_TO_NET地址 50-77 / 100-115");
            }
        }
        catch (OperationCanceledException)
        {
            _monitorStatusLabel.Text = $"CAN监控：读取超时 {DateTime.Now:HH:mm:ss.fff}";
            if (showLog)
            {
                Log("CAN监控读取超时");
            }
        }
        catch (Exception ex)
        {
            _monitorStatusLabel.Text = $"CAN监控：读取失败 {DateTime.Now:HH:mm:ss.fff}";
            if (showLog)
            {
                Log($"CAN监控读取失败：{ex.Message}");
            }
        }
        finally
        {
            _monitorReadInFlight = false;
        }
    }

    private async Task WriteEnabledRowsAsync(bool showMessage, bool setBusy)
    {
        if (_writeInFlight)
        {
            return;
        }

        _writeInFlight = true;
        try
        {
            await ExecuteOperationAsync("写入", async token =>
            {
                await EnsureConnectedAsync(token);

                var items = CollectWriteItems();
                if (items.Count == 0)
                {
                    throw new InvalidOperationException("发送编辑窗口里没有启用的数据行。");
                }

                var unitId = (byte)_unitIdBox.Value;
                var timeout = (int)_timeoutBox.Value;
                var segments = BuildContiguousSegments(items);

                foreach (var segment in segments)
                {
                    if (segment.Values.Count == 1)
                    {
                        await _client.WriteSingleRegisterAsync(unitId, segment.StartAddress, segment.Values[0], timeout, token);
                    }
                    else
                    {
                        await _client.WriteMultipleRegistersAsync(unitId, segment.StartAddress, segment.Values, timeout, token);
                    }

                    MarkRows(segment.RowIndexes, $"OK {DateTime.Now:HH:mm:ss.fff}");
                }

                foreach (var item in items)
                {
                    _lastTxRegisters[item.ScreenAddress] = item.Value;
                }
                RefreshSendMonitorFromCache();
                Log($"发送成功：{items.Count} 个寄存器，{segments.Count} 包");
            }, showMessage, setBusy);
        }
        catch
        {
            MarkRows(CollectWriteItems().Select(item => item.RowIndex), $"失败 {DateTime.Now:HH:mm:ss.fff}");
            throw;
        }
        finally
        {
            _writeInFlight = false;
        }
    }

    private void ToggleReadPolling()
    {
        if (_isReadPolling)
        {
            StopReadPolling();
            return;
        }

        _readTimer.Interval = (int)_readIntervalBox.Value;
        _isReadPolling = true;
        _readPollButton.Text = "停止读";
        Log($"开始自动读：{_readTimer.Interval}ms");
        _readTimer.Start();
    }

    private void ToggleAutoWriting()
    {
        if (_isAutoWriting)
        {
            StopAutoWriting();
            return;
        }

        _writeTimer.Interval = (int)_writeIntervalBox.Value;
        _isAutoWriting = true;
        _autoWriteButton.Text = "停止发送";
        Log($"开始自动发送：{_writeTimer.Interval}ms");
        _writeTimer.Start();
    }

    private void ToggleMonitorPolling()
    {
        if (_isMonitorPolling)
        {
            StopMonitorPolling();
            return;
        }

        StartMonitorPolling();
    }

    private void StopReadPolling()
    {
        _readTimer.Stop();
        _isReadPolling = false;
        if (_readPollButton is not null)
        {
            _readPollButton.Text = "自动读";
        }
    }

    private void StopAutoWriting()
    {
        _writeTimer.Stop();
        _isAutoWriting = false;
        if (_autoWriteButton is not null)
        {
            _autoWriteButton.Text = "自动发送";
        }
    }

    private void StartMonitorPolling()
    {
        _monitorTimer.Interval = Math.Max(20, (int)_readIntervalBox.Value);
        _isMonitorPolling = true;
        if (_monitorPollButton is not null)
        {
            _monitorPollButton.Text = "停止监控";
        }
        if (_monitorStatusLabel is not null)
        {
            _monitorStatusLabel.Text = $"CAN监控：自动读取 50-77 / 100-115，周期 {_monitorTimer.Interval}ms";
        }
        _monitorTimer.Start();
        _ = ReadCanMonitorOnceAsync(showLog: false);
    }

    private void StopMonitorPolling()
    {
        _monitorTimer.Stop();
        _isMonitorPolling = false;
        if (_monitorPollButton is not null)
        {
            _monitorPollButton.Text = "开始监控";
        }
        if (_monitorStatusLabel is not null)
        {
            _monitorStatusLabel.Text = "CAN监控：已停止";
        }
    }

    private async Task ReadTimerTickAsync()
    {
        _readTimer.Stop();
        try
        {
            await ReadOnceAsync(showSuccessLog: false, showMessage: false, setBusy: false);
        }
        finally
        {
            if (_isReadPolling)
            {
                _readTimer.Interval = (int)_readIntervalBox.Value;
                _readTimer.Start();
            }
        }
    }

    private async Task WriteTimerTickAsync()
    {
        _writeTimer.Stop();
        try
        {
            await WriteEnabledRowsAsync(showMessage: false, setBusy: false);
        }
        finally
        {
            if (_isAutoWriting)
            {
                _writeTimer.Interval = (int)_writeIntervalBox.Value;
                _writeTimer.Start();
            }
        }
    }

    private void ShowReceivedRegisters(ushort startAddress, IReadOnlyList<ushort> values)
    {
        int? selectedScreenAddress = null;
        var selectedColumnIndex = _receiveGrid.CurrentCell?.ColumnIndex ?? 0;
        if (_receiveGrid.CurrentRow is not null && TryParseNumber(_receiveGrid.CurrentRow.Cells["ScreenAddress"].Value, out var selectedAddress))
        {
            selectedScreenAddress = selectedAddress;
        }

        while (_receiveGrid.Rows.Count < values.Count)
        {
            _receiveGrid.Rows.Add();
        }

        while (_receiveGrid.Rows.Count > values.Count)
        {
            _receiveGrid.Rows.RemoveAt(_receiveGrid.Rows.Count - 1);
        }

        for (var i = 0; i < values.Count; i++)
        {
            var address = startAddress + i;
            var screenAddress = ProtocolToScreenAddress(address);
            var value = values[i];
            var row = _receiveGrid.Rows[i];
            row.Cells["ScreenAddress"].Value = screenAddress.ToString(CultureInfo.InvariantCulture);
            row.Cells["CanId"].Value = GetCanIdText(screenAddress);
            row.Cells["Unsigned"].Value = value.ToString(CultureInfo.InvariantCulture);
            row.Cells["Signed"].Value = unchecked((short)value).ToString(CultureInfo.InvariantCulture);
            row.Cells["Hex"].Value = $"0x{value:X4}";
        }

        UpdateReceiveMonitor(startAddress, values);
        RestoreReceiveSelection(selectedScreenAddress, selectedColumnIndex);
    }

    private async Task MonitorTimerTickAsync()
    {
        _monitorTimer.Stop();
        try
        {
            await ReadCanMonitorOnceAsync(showLog: false);
        }
        finally
        {
            if (_isMonitorPolling)
            {
                _monitorTimer.Interval = Math.Max(20, (int)_readIntervalBox.Value);
                _monitorTimer.Start();
            }
        }
    }

    private void UpdateReceiveMonitor(ushort protocolStartAddress, IReadOnlyList<ushort> values)
    {
        var registersByScreenAddress = new Dictionary<int, ushort>();
        for (var i = 0; i < values.Count; i++)
        {
            registersByScreenAddress[ProtocolToScreenAddress(protocolStartAddress + i)] = values[i];
        }

        foreach (var map in ReceiveMaps)
        {
            UpdateMonitorRowFromRegisters(_rxMonitorGrid, map, registersByScreenAddress);
        }
    }

    private void UpdateSendMonitor(ushort protocolStartAddress, IReadOnlyList<ushort> values)
    {
        var registersByScreenAddress = new Dictionary<int, ushort>();
        for (var i = 0; i < values.Count; i++)
        {
            registersByScreenAddress[ProtocolToScreenAddress(protocolStartAddress + i)] = values[i];
        }

        foreach (var map in SendMaps)
        {
            UpdateMonitorRowFromRegisters(_txMonitorGrid, map, registersByScreenAddress);
        }
    }

    private void RefreshSendMonitorFromCache()
    {
        foreach (var map in SendMaps)
        {
            UpdateMonitorRowFromRegisters(_txMonitorGrid, map, _lastTxRegisters);
        }
    }

    private void RefreshSendMonitorFromSendGrid()
    {
        if (_sendGrid is null || _txMonitorGrid is null)
        {
            return;
        }

        var registers = new Dictionary<int, ushort>();
        foreach (DataGridViewRow row in _sendGrid.Rows)
        {
            if (row.IsNewRow)
            {
                continue;
            }

            if (!TryParseNumber(row.Cells["Address"].Value, out var screenAddress)
                || !TryParseNumber(row.Cells["Value"].Value, out var value))
            {
                continue;
            }

            registers[screenAddress] = ToRegisterValue(value);
        }

        foreach (var map in SendMaps)
        {
            UpdateMonitorRowFromRegisters(_txMonitorGrid, map, registers);
        }
    }

    private static void InitializeCanMonitorRows(DataGridView grid, IReadOnlyList<CanRegisterMap> maps)
    {
        grid.Rows.Clear();
        foreach (var map in maps)
        {
            var index = grid.Rows.Add();
            var row = grid.Rows[index];
            row.Tag = map.CanId;
            row.Cells["CanId"].Value = map.CanId;
            row.Cells["AddressRange"].Value = $"{map.StartAddress}-{map.EndAddress}";
            row.Cells["Purpose"].Value = map.Purpose;
            for (var i = 0; i < 4; i++)
            {
                row.Cells[$"W{i}"].Value = $"{map.StartAddress + i}=等待";
            }
            row.Cells["Updated"].Value = "等待数据";
        }
    }

    private static void UpdateMonitorRowFromRegisters(DataGridView grid, CanRegisterMap map, IReadOnlyDictionary<int, ushort> source)
    {
        DataGridViewRow? row = null;
        foreach (DataGridViewRow candidate in grid.Rows)
        {
            if (Equals(candidate.Tag, map.CanId))
            {
                row = candidate;
                break;
            }
        }

        if (row is null)
        {
            return;
        }

        var anyUpdated = false;
        for (var i = 0; i < 4; i++)
        {
            if (!source.TryGetValue(map.StartAddress + i, out var value))
            {
                continue;
            }

            anyUpdated = true;
            row.Cells[$"W{i}"].Value = $"{map.StartAddress + i}=0x{value:X4}";
            row.Cells[$"B{i * 2}"].Value = $"0x{value & 0xFF:X2}";
            row.Cells[$"B{i * 2 + 1}"].Value = $"0x{value >> 8:X2}";
        }
        if (anyUpdated)
        {
            row.Cells["Updated"].Value = DateTime.Now.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture);
        }
    }

    private void RestoreReceiveSelection(int? selectedScreenAddress, int selectedColumnIndex)
    {
        if (selectedScreenAddress is null)
        {
            _receiveGrid.ClearSelection();
            return;
        }

        foreach (DataGridViewRow row in _receiveGrid.Rows)
        {
            if (TryParseNumber(row.Cells["ScreenAddress"].Value, out var screenAddress) && screenAddress == selectedScreenAddress)
            {
                var columnIndex = Math.Clamp(selectedColumnIndex, 0, _receiveGrid.Columns.Count - 1);
                _receiveGrid.CurrentCell = row.Cells[columnIndex];
                row.Selected = true;
                return;
            }
        }
    }

    private void AddSendRow()
    {
        var nextAddress = ProtocolToScreenAddress(60);
        foreach (DataGridViewRow row in _sendGrid.Rows)
        {
            if (row.IsNewRow)
            {
                continue;
            }

            if (TryParseNumber(row.Cells["Address"].Value, out var address))
            {
                nextAddress = Math.Max(nextAddress, address + 1);
            }
        }

        AddSendRow($"发送{_sendGrid.Rows.Count}", nextAddress, 0);
    }

    private void AddSendRow(string name, int address, int value)
    {
        var index = _sendGrid.Rows.Add(true, name, address, GetCanIdText(address), value, ToRegisterHex(ToRegisterValue(value)), string.Empty);
        _sendGrid.Rows[index].Cells["Enabled"].Value = true;
        RefreshSendMonitorFromSendGrid();
    }

    private void DeleteSelectedSendRows()
    {
        foreach (DataGridViewRow row in _sendGrid.SelectedRows.Cast<DataGridViewRow>().Where(row => !row.IsNewRow).ToList())
        {
            _sendGrid.Rows.Remove(row);
        }
        RefreshSendMonitorFromSendGrid();
    }

    private void PrepareLastEditableRow()
    {
        foreach (DataGridViewRow row in _sendGrid.Rows)
        {
            if (row.IsNewRow)
            {
                continue;
            }

            row.Cells["Enabled"].Value ??= true;
            UpdateSendRowDisplay(row.Index);
        }
    }

    private void UpdateSendRowDisplay(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= _sendGrid.Rows.Count)
        {
            return;
        }

        var row = _sendGrid.Rows[rowIndex];
        if (row.IsNewRow)
        {
            return;
        }

        if (TryParseNumber(row.Cells["Address"].Value, out var address))
        {
            row.Cells["CanId"].Value = GetCanIdText(address);
        }
        else
        {
            row.Cells["CanId"].Value = string.Empty;
        }

        if (TryParseNumber(row.Cells["Value"].Value, out var value))
        {
            row.Cells["Hex"].Value = ToRegisterHex(ToRegisterValue(value));
        }

    }

    private List<WriteItem> CollectWriteItems()
    {
        var result = new List<WriteItem>();
        foreach (DataGridViewRow row in _sendGrid.Rows)
        {
            if (row.IsNewRow)
            {
                continue;
            }

            var enabled = row.Cells["Enabled"].Value is true || row.Cells["Enabled"].Value?.ToString() == "True";
            if (!enabled)
            {
                continue;
            }

            var screenAddress = ParseNumber(row.Cells["Address"].Value, "CAN_TO_NET地址");
            var address = ScreenToProtocolAddress(screenAddress);
            var value = ParseNumber(row.Cells["Value"].Value, "发送值");

            var registerValue = ToRegisterValue(value);
            row.Cells["CanId"].Value = GetCanIdText(screenAddress);
            row.Cells["Hex"].Value = ToRegisterHex(registerValue);
            result.Add(new WriteItem(row.Index, screenAddress, address, registerValue));
        }

        var duplicate = result.GroupBy(item => item.Address).FirstOrDefault(group => group.Count() > 1);
        if (duplicate is not null)
        {
            throw new InvalidOperationException($"发送表里地址重复：{duplicate.Key}");
        }

        return result.OrderBy(item => item.Address).ToList();
    }

    private static List<WriteSegment> BuildContiguousSegments(IReadOnlyList<WriteItem> items)
    {
        var segments = new List<WriteSegment>();
        WriteSegment? current = null;

        foreach (var item in items)
        {
            if (current is null || item.Address != current.StartAddress + current.Values.Count)
            {
                current = new WriteSegment(item.Address);
                segments.Add(current);
            }

            current.Values.Add(item.Value);
            current.RowIndexes.Add(item.RowIndex);
        }

        return segments;
    }

    private void MarkRows(IEnumerable<int> rowIndexes, string status)
    {
        foreach (var rowIndex in rowIndexes)
        {
            if (rowIndex >= 0 && rowIndex < _sendGrid.Rows.Count)
            {
                _sendGrid.Rows[rowIndex].Cells["Status"].Value = status;
            }
        }
    }

    private async Task ExecuteOperationAsync(string operationName, Func<CancellationToken, Task> operation, bool showMessage, bool setBusy)
    {
        if (setBusy)
        {
            SetBusy(true);
        }

        using var cts = new CancellationTokenSource((int)_timeoutBox.Value + 20);

        try
        {
            await operation(cts.Token);
            _statusLabel.Text = _client.IsConnected ? "状态：已连接" : "状态：未连接";
        }
        catch (OperationCanceledException)
        {
            SetConnectedState(false);
            Log($"{operationName}超时");
            if (showMessage)
            {
                MessageBox.Show($"{operationName}超时，请检查网线/IP/端口/CAN_TO_NET服务。", "503端口", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        catch (Exception ex)
        {
            SetConnectedState(false);
            Log($"{operationName}失败：{ex.Message}");
            if (showMessage)
            {
                MessageBox.Show(ex.Message, $"{operationName}失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        finally
        {
            if (setBusy)
            {
                SetBusy(false);
            }
        }
    }

    private void SetConnectedState(bool connected)
    {
        _connectButton.Enabled = !connected;
        _disconnectButton.Enabled = connected;
        _statusLabel.Text = connected ? "状态：已连接" : "状态：未连接";
        if (connected)
        {
            StartMonitorPolling();
        }
        else if (!_client.IsConnected)
        {
            StopMonitorPolling();
        }
    }

    private void SetBusy(bool busy)
    {
        _connectButton.Enabled = !busy && !_client.IsConnected;
        _disconnectButton.Enabled = !busy && _client.IsConnected;
        _readButton.Enabled = !busy;
        _writeButton.Enabled = !busy;
        _readPollButton.Enabled = !busy || _isReadPolling;
        _autoWriteButton.Enabled = !busy || _isAutoWriting;
        _addSendRowButton.Enabled = !busy;
        _deleteSendRowButton.Enabled = !busy;
        if (_monitorReadButton is not null)
        {
            _monitorReadButton.Enabled = !busy;
        }
        if (_monitorPollButton is not null)
        {
            _monitorPollButton.Enabled = !busy || _isMonitorPolling;
        }
        UseWaitCursor = busy;
    }

    private void Log(string message)
    {
        _logBox.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {message}{Environment.NewLine}");
        _logBox.ScrollToCaret();
    }

    private static NumericUpDown CreateNumberBox(decimal minimum, decimal maximum, decimal value, int width)
    {
        return new NumericUpDown
        {
            Minimum = minimum,
            Maximum = maximum,
            Value = value,
            Width = width
        };
    }

    private static void AddLabeled(FlowLayoutPanel parent, string labelText, Control control)
    {
        var wrapper = new FlowLayoutPanel
        {
            AutoSize = true,
            WrapContents = false,
            Margin = new Padding(0, 0, 12, 8)
        };
        wrapper.Controls.Add(new Label
        {
            Text = labelText,
            AutoSize = false,
            Width = Math.Max(52, labelText.Length * 16),
            Height = 28,
            TextAlign = ContentAlignment.MiddleLeft
        });
        control.Height = 28;
        wrapper.Controls.Add(control);
        parent.Controls.Add(wrapper);
    }

    private static int ParseNumber(object? value, string fieldName)
    {
        if (!TryParseNumber(value, out var number))
        {
            throw new FormatException($"{fieldName}格式不正确：{value}");
        }

        return number;
    }

    private static bool TryParseNumber(object? value, out int number)
    {
        number = 0;
        var text = Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim();
        if (string.IsNullOrWhiteSpace(text))
        {
            return false;
        }

        if (text.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
        {
            return int.TryParse(text[2..], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out number);
        }

        return int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out number);
    }

    private ushort ScreenToProtocolAddress(int screenAddress)
    {
        var protocolAddress = screenAddress - (int)_addressOffsetBox.Value;
        if (protocolAddress is < 0 or > 65535)
        {
            throw new FormatException($"CAN_TO_NET地址 {screenAddress} 超出范围。当前地址偏移：{_addressOffsetBox.Value}");
        }

        return (ushort)protocolAddress;
    }

    private bool TryScreenToProtocolAddress(int screenAddress, out ushort protocolAddress)
    {
        protocolAddress = 0;
        var converted = screenAddress - (int)_addressOffsetBox.Value;
        if (converted is < 0 or > 65535)
        {
            return false;
        }

        protocolAddress = (ushort)converted;
        return true;
    }

    private int ProtocolToScreenAddress(int protocolAddress)
    {
        return protocolAddress + (int)_addressOffsetBox.Value;
    }

    private static ushort ToRegisterValue(int value)
    {
        if (value is < short.MinValue or > ushort.MaxValue)
        {
            throw new FormatException($"发送值超出 16 位寄存器范围：{value}");
        }

        return value < 0 ? unchecked((ushort)(short)value) : (ushort)value;
    }

    private static string ToRegisterHex(ushort value)
    {
        return $"0x{value:X4}";
    }

    private static string GetCanIdText(int canToNetAddress)
    {
        return canToNetAddress switch
        {
            >= 50 and <= 53 => "0x150",
            >= 54 and <= 57 => "0x152",
            >= 58 and <= 61 => "0x153",
            >= 62 and <= 65 => "0x154",
            >= 66 and <= 69 => "0x15A",
            >= 70 and <= 73 => "0x170",
            >= 74 and <= 77 => "0x176",
            >= 100 and <= 103 => "0x50",
            >= 104 and <= 107 => "0x71",
            >= 108 and <= 111 => "0x75",
            >= 112 and <= 115 => "0x7A",
            _ => "未映射"
        };
    }

    private sealed record CanRegisterMap(string CanId, int StartAddress, string Purpose)
    {
        public int EndAddress => StartAddress + 3;
    }

    private sealed record WriteItem(int RowIndex, int ScreenAddress, ushort Address, ushort Value);

    private sealed class WriteSegment(ushort startAddress)
    {
        public ushort StartAddress { get; } = startAddress;
        public List<ushort> Values { get; } = [];
        public List<int> RowIndexes { get; } = [];
    }
}
