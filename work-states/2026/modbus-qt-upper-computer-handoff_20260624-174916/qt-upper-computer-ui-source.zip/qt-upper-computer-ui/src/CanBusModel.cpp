#include "CanBusModel.h"

#include <cmath>

namespace {

quint8 byteAt(const QByteArray &bytes, qsizetype index) {
    return static_cast<quint8>(bytes.at(index));
}

quint16 readU16LE(const std::array<quint8, 8> &data, int offset) {
    return static_cast<quint16>(data[offset] | (data[offset + 1] << 8));
}

qint16 readS16LE(const std::array<quint8, 8> &data, int offset) {
    return static_cast<qint16>(readU16LE(data, offset));
}

quint32 readU32LE(const std::array<quint8, 8> &data, int offset) {
    return static_cast<quint32>(data[offset])
        | (static_cast<quint32>(data[offset + 1]) << 8)
        | (static_cast<quint32>(data[offset + 2]) << 16)
        | (static_cast<quint32>(data[offset + 3]) << 24);
}

qint32 readS32LE(const std::array<quint8, 8> &data, int offset) {
    return static_cast<qint32>(readU32LE(data, offset));
}

void writeU16LE(std::array<quint8, 8> &data, int offset, quint16 value) {
    data[offset] = static_cast<quint8>(value & 0xff);
    data[offset + 1] = static_cast<quint8>((value >> 8) & 0xff);
}

void writeS16LE(std::array<quint8, 8> &data, int offset, qint16 value) {
    writeU16LE(data, offset, static_cast<quint16>(value));
}

void writeS32LE(std::array<quint8, 8> &data, int offset, qint32 value) {
    const quint32 raw = static_cast<quint32>(value);
    data[offset] = static_cast<quint8>(raw & 0xff);
    data[offset + 1] = static_cast<quint8>((raw >> 8) & 0xff);
    data[offset + 2] = static_cast<quint8>((raw >> 16) & 0xff);
    data[offset + 3] = static_cast<quint8>((raw >> 24) & 0xff);
}

bool bit(const std::array<quint8, 8> &data, int byteIndex, int bitIndex) {
    return (data[byteIndex] & (1u << bitIndex)) != 0;
}

int coordinateArmFromIndex(quint8 index) {
    const int low = index & 0x0f;
    if (low < 0 || low > 5) {
        return -1;
    }
    if ((index & 0xf0) == 0x10) {
        return 0;
    }
    if ((index & 0xf0) == 0x20) {
        return 1;
    }
    if ((index & 0xf0) == 0x30) {
        return 2;
    }
    return -1;
}

int coordinateAxisFromIndex(quint8 index) {
    const int low = index & 0x0f;
    if (low >= 0 && low <= 2) {
        return low;
    }
    if (low >= 3 && low <= 5) {
        return low - 3;
    }
    return -1;
}

bool isH1CoordinateIndex(quint8 index) {
    const int low = index & 0x0f;
    return coordinateArmFromIndex(index) >= 0 && low >= 3 && low <= 5;
}

int armFromBaseIndex(quint8 index) {
    if ((index & 0xf0) == 0x10) {
        return 0;
    }
    if ((index & 0xf0) == 0x20) {
        return 1;
    }
    if ((index & 0xf0) == 0x30) {
        return 2;
    }
    return -1;
}

bool near(double a, double b) {
    return std::abs(a - b) < 0.0001;
}

CanFrame buildCalibrationPointFrame(quint8 businessFlag, quint8 pointIndex, qint16 xMm, qint16 yMm, qint16 zMm) {
    CanFrame frame;
    frame.id = 0x50;
    frame.dlc = 8;
    frame.data[0] = pointIndex;
    writeS16LE(frame.data, 1, xMm);
    writeS16LE(frame.data, 3, yMm);
    writeS16LE(frame.data, 5, zMm);
    frame.data[7] = businessFlag;
    return frame;
}

void fail(QString *error, const QString &message) {
    if (error) {
        *error = message;
    }
}

} // namespace

QByteArray CanToNetCodec::encodeCanFrame(const CanFrame &frame,
                                         quint8 sequence,
                                         CanToNetFrameType type,
                                         quint8 channel) {
    QByteArray packet(PacketSize, char(0));
    packet[0] = char(0xaa);
    packet[1] = char(0x55);
    packet[2] = char(0x01);
    packet[3] = char(static_cast<quint8>(type));
    packet[4] = char(sequence);
    packet[5] = char(channel);

    quint8 attributes = 0;
    if (frame.extended) {
        attributes |= 0x01;
    }
    if (frame.remote) {
        attributes |= 0x02;
    }
    packet[6] = char(attributes);
    packet[7] = char(frame.dlc <= 8 ? frame.dlc : 8);
    packet[8] = char(frame.id & 0xff);
    packet[9] = char((frame.id >> 8) & 0xff);
    packet[10] = char((frame.id >> 16) & 0xff);
    packet[11] = char((frame.id >> 24) & 0xff);
    for (int i = 0; i < 8; ++i) {
        packet[12 + i] = char(frame.data[i]);
    }
    packet[20] = char(checksum(packet, 20));
    return packet;
}

QByteArray CanToNetCodec::encodeHeartbeat(quint8 sequence) {
    CanFrame emptyFrame;
    return encodeCanFrame(emptyFrame, sequence, CanToNetFrameType::Heartbeat, 0);
}

bool CanToNetCodec::tryDecodePacket(const QByteArray &packet, CanToNetPacket *out, QString *error) {
    if (packet.size() != PacketSize) {
        fail(error, QStringLiteral("CAN_TO_NET packet length is not 21 bytes"));
        return false;
    }
    if (byteAt(packet, 0) != 0xaa || byteAt(packet, 1) != 0x55) {
        fail(error, QStringLiteral("CAN_TO_NET packet header is invalid"));
        return false;
    }
    if (byteAt(packet, 2) != 0x01) {
        fail(error, QStringLiteral("CAN_TO_NET protocol version is unsupported"));
        return false;
    }
    if (checksum(packet, 20) != byteAt(packet, 20)) {
        fail(error, QStringLiteral("CAN_TO_NET packet checksum mismatch"));
        return false;
    }

    const quint8 rawType = byteAt(packet, 3);
    if (rawType != 0x01 && rawType != 0x02 && rawType != 0x03) {
        fail(error, QStringLiteral("CAN_TO_NET frame type is unsupported"));
        return false;
    }

    if (out) {
        out->type = static_cast<CanToNetFrameType>(rawType);
        out->sequence = byteAt(packet, 4);
        out->channel = byteAt(packet, 5);
        out->frame.extended = (byteAt(packet, 6) & 0x01) != 0;
        out->frame.remote = (byteAt(packet, 6) & 0x02) != 0;
        out->frame.dlc = byteAt(packet, 7) <= 8 ? byteAt(packet, 7) : 8;
        out->frame.id = static_cast<quint32>(byteAt(packet, 8))
            | (static_cast<quint32>(byteAt(packet, 9)) << 8)
            | (static_cast<quint32>(byteAt(packet, 10)) << 16)
            | (static_cast<quint32>(byteAt(packet, 11)) << 24);
        for (int i = 0; i < 8; ++i) {
            out->frame.data[i] = byteAt(packet, 12 + i);
        }
    }
    return true;
}

quint8 CanToNetCodec::checksum(const QByteArray &bytes, qsizetype count) {
    quint32 sum = 0;
    const qsizetype capped = std::min(count, bytes.size());
    for (qsizetype i = 0; i < capped; ++i) {
        sum += byteAt(bytes, i);
    }
    return static_cast<quint8>(sum & 0xff);
}

void CanBusinessStateModel::reset() {
    state_ = MachineRealtimeState();
}

void CanBusinessStateModel::setCanToNetOnline(bool online) {
    state_.canToNetOnline = online;
    rebuildActiveAlarms();
}

void CanBusinessStateModel::applyFrame(const CanFrame &frame) {
    switch (frame.id) {
    case 0x150:
        applyAlgorithmFrame(frame);
        break;
    case 0x152:
        applyEndpointAngleFrame(frame);
        break;
    case 0x153:
        applyDrillingDepthFrame(frame);
        break;
    case 0x154:
        applyEncoderAngleFrame(frame);
        break;
    case 0x170:
        applyMachineAlarmFrame(frame);
        break;
    case 0x176:
        applyAnalogFrame(frame);
        break;
    case 0x15a:
        applyDropoutFrame(frame);
        break;
    default:
        break;
    }
}

const MachineRealtimeState &CanBusinessStateModel::state() const {
    return state_;
}

void CanBusinessStateModel::applyAlgorithmFrame(const CanFrame &frame) {
    const quint8 index = frame.data[0];
    if (index == 0xe0) {
        state_.calibration.statusValid = true;
        state_.calibration.object = frame.data[1];
        state_.calibration.status = frame.data[2];
        state_.calibration.errorCode = frame.data[3];
        state_.calibration.receivedPointCount = frame.data[4];
        state_.calibration.maxErrorMm = readS16LE(frame.data, 5);
        state_.calibration.businessFlag = frame.data[7];
        return;
    }
    if (index == 0xe1) {
        state_.calibration.rmsValid = true;
        state_.calibration.object = frame.data[1];
        state_.calibration.rmsMm = readU16LE(frame.data, 3);
        return;
    }
    applyEndpointCoordinateFrame(frame);
}

void CanBusinessStateModel::applyEndpointCoordinateFrame(const CanFrame &frame) {
    const int arm = coordinateArmFromIndex(frame.data[0]);
    const int axis = coordinateAxisFromIndex(frame.data[0]);
    if (arm < 0 || axis < 0) {
        return;
    }

    ArmRealtimeState &target = state_.arms[arm];
    const double value = readS32LE(frame.data, 1) / 100.0;
    if (isH1CoordinateIndex(frame.data[0])) {
        const bool valid = frame.data[5] != 0;
        target.h1AxisValid[axis] = valid;
        if (valid) {
            if (axis == 0) {
                target.h1X = value;
            } else if (axis == 1) {
                target.h1Y = value;
            } else {
                target.h1Z = value;
            }
        }
        target.h1Valid = target.h1AxisValid[0] && target.h1AxisValid[1] && target.h1AxisValid[2];
    } else {
        if (axis == 0) {
            target.hX = value;
        } else if (axis == 1) {
            target.hY = value;
        } else {
            target.hZ = value;
        }
        target.hValid = true;
    }
}

void CanBusinessStateModel::applyEndpointAngleFrame(const CanFrame &frame) {
    const int arm = armFromBaseIndex(frame.data[0]);
    if (arm < 0) {
        return;
    }
    ArmRealtimeState &target = state_.arms[arm];
    target.angleXzDeg = readS16LE(frame.data, 1) / 100.0;
    target.angleYzDeg = readS16LE(frame.data, 3) / 100.0;
    target.angleValid = true;
}

void CanBusinessStateModel::applyDrillingDepthFrame(const CanFrame &frame) {
    for (int arm = 0; arm < 3; ++arm) {
        ArmRealtimeState &target = state_.arms[arm];
        target.drillingDepthRaw = readU16LE(frame.data, arm * 2);
        target.drillingDepthM = target.drillingDepthRaw / 1000.0;
    }
}

void CanBusinessStateModel::applyEncoderAngleFrame(const CanFrame &frame) {
    const int arm = armFromBaseIndex(frame.data[0]);
    if (arm < 0) {
        return;
    }
    const int group = frame.data[0] & 0x0f;
    if (group > 2) {
        return;
    }

    ArmRealtimeState &target = state_.arms[arm];
    for (int i = 0; i < 3; ++i) {
        const int slot = group * 3 + i;
        target.encoderAnglesDeg[slot] = readS16LE(frame.data, 1 + i * 2) / 100.0;
        target.encoderAnglesValid[slot] = true;
    }
}

void CanBusinessStateModel::applyAnalogFrame(const CanFrame &frame) {
    const quint8 index = frame.data[0];
    switch (index) {
    case 0x07:
        state_.arms[0].thrustPressure = readU16LE(frame.data, 5);
        state_.arms[0].thrustPressureValid = true;
        break;
    case 0x08:
        state_.arms[0].impactPressure = readU16LE(frame.data, 1);
        state_.arms[0].rotationPressure = readU16LE(frame.data, 3);
        state_.arms[0].boomPressure = readU16LE(frame.data, 5);
        state_.arms[0].impactPressureValid = true;
        state_.arms[0].rotationPressureValid = true;
        state_.arms[0].boomPressureValid = true;
        break;
    case 0x09:
        state_.arms[0].compensationThrustPressure = readU16LE(frame.data, 1);
        state_.arms[0].waterFlow = readU16LE(frame.data, 3);
        state_.arms[0].lubricationPressure = readU16LE(frame.data, 5);
        state_.arms[0].compensationThrustPressureValid = true;
        state_.arms[0].waterFlowValid = true;
        state_.arms[0].lubricationPressureValid = true;
        break;
    case 0x0a:
        state_.arms[0].bufferPressure = readU16LE(frame.data, 1);
        state_.arms[0].rockDrillWorkTimeRaw = readU32LE(frame.data, 3);
        state_.arms[0].bufferPressureValid = true;
        state_.arms[0].rockDrillWorkTimeValid = true;
        break;
    case 0x13:
        state_.arms[1].thrustPressure = readU16LE(frame.data, 3);
        state_.arms[1].impactPressure = readU16LE(frame.data, 5);
        state_.arms[1].thrustPressureValid = true;
        state_.arms[1].impactPressureValid = true;
        break;
    case 0x14:
        state_.arms[1].rotationPressure = readU16LE(frame.data, 1);
        state_.arms[1].boomPressure = readU16LE(frame.data, 3);
        state_.arms[1].compensationThrustPressure = readU16LE(frame.data, 5);
        state_.arms[1].rotationPressureValid = true;
        state_.arms[1].boomPressureValid = true;
        state_.arms[1].compensationThrustPressureValid = true;
        break;
    case 0x15:
        state_.arms[1].waterFlow = readU16LE(frame.data, 1);
        state_.arms[1].lubricationPressure = readU16LE(frame.data, 3);
        state_.arms[1].bufferPressure = readU16LE(frame.data, 5);
        state_.arms[1].waterFlowValid = true;
        state_.arms[1].lubricationPressureValid = true;
        state_.arms[1].bufferPressureValid = true;
        break;
    case 0x16:
        state_.arms[1].rockDrillWorkTimeRaw = readU32LE(frame.data, 1);
        state_.arms[1].rockDrillWorkTimeValid = true;
        break;
    case 0x1d:
        state_.arms[2].thrustPressure = readU16LE(frame.data, 3);
        state_.arms[2].impactPressure = readU16LE(frame.data, 5);
        state_.arms[2].thrustPressureValid = true;
        state_.arms[2].impactPressureValid = true;
        break;
    case 0x1e:
        state_.arms[2].rotationPressure = readU16LE(frame.data, 1);
        state_.arms[2].boomPressure = readU16LE(frame.data, 3);
        state_.arms[2].compensationThrustPressure = readU16LE(frame.data, 5);
        state_.arms[2].rotationPressureValid = true;
        state_.arms[2].boomPressureValid = true;
        state_.arms[2].compensationThrustPressureValid = true;
        break;
    case 0x1f:
        state_.arms[2].waterFlow = readU16LE(frame.data, 1);
        state_.arms[2].lubricationPressure = readU16LE(frame.data, 3);
        state_.arms[2].bufferPressure = readU16LE(frame.data, 5);
        state_.arms[2].waterFlowValid = true;
        state_.arms[2].lubricationPressureValid = true;
        state_.arms[2].bufferPressureValid = true;
        break;
    case 0x20:
        state_.arms[2].rockDrillWorkTimeRaw = readU32LE(frame.data, 1);
        state_.arms[2].rockDrillWorkTimeValid = true;
        break;
    case 0x21:
        state_.operatorConsoles[0].selectedArm = frame.data[1] <= 3 ? frame.data[1] : 0;
        state_.operatorConsoles[1].selectedArm = frame.data[2] <= 3 ? frame.data[2] : 0;
        state_.operatorConsoles[0].selectedArmValid = true;
        state_.operatorConsoles[1].selectedArmValid = true;
        state_.selectedArmSourceFlags = frame.data[3];
        state_.selectedArmStatusValid = true;
        break;
    case 0x22:
        for (int arm = 0; arm < 3; ++arm) {
            state_.arms[arm].drillingState = frame.data[1 + arm];
            state_.arms[arm].drillingStateValid = true;
            state_.arms[arm].drillingActive = bit(frame.data, 4, arm);
            state_.arms[arm].drillingStartPulse = bit(frame.data, 5, arm);
        }
        break;
    default:
        break;
    }
}

void CanBusinessStateModel::applyMachineAlarmFrame(const CanFrame &frame) {
    auto setAxisPacket = [&](int console, int handle) {
        if (console < 0 || console >= 2 || handle < 0 || handle >= 2) {
            return;
        }
        OperatorHandleRealtimeState &target = state_.operatorConsoles[console].handles[handle];
        target.axis[0] = readS16LE(frame.data, 1);
        target.axis[1] = readS16LE(frame.data, 3);
        target.axis[2] = readS16LE(frame.data, 5);
        target.axisValid[0] = true;
        target.axisValid[1] = true;
        target.axisValid[2] = true;
    };

    switch (frame.data[0]) {
    case 0x01:
        state_.arms[0].lubricationPressureLow = bit(frame.data, 1, 3);
        state_.arms[0].lubricationPressureLowValid = true;
        state_.cableBoxEmergencyStop = bit(frame.data, 3, 5);
        state_.hoseBoxEmergencyStop = bit(frame.data, 3, 6);
        state_.leftConsoleEmergencyStop = bit(frame.data, 3, 7);
        state_.vehicleStatusValid = true;
        break;
    case 0x02:
        state_.arms[1].lubricationPressureLow = bit(frame.data, 4, 7);
        state_.arms[2].lubricationPressureLow = bit(frame.data, 6, 5);
        state_.arms[1].lubricationPressureLowValid = true;
        state_.arms[2].lubricationPressureLowValid = true;

        state_.operatorConsoles[0].linkValid = true;
        state_.operatorConsoles[0].leftHandleOffline = bit(frame.data, 3, 3);
        state_.operatorConsoles[0].rightHandleOffline = bit(frame.data, 3, 4);
        state_.operatorConsoles[0].leftKeypadOffline = bit(frame.data, 3, 5);
        state_.operatorConsoles[0].rightKeypadOffline = bit(frame.data, 3, 6);

        state_.operatorConsoles[1].linkValid = true;
        state_.operatorConsoles[1].leftHandleOffline = bit(frame.data, 3, 7);
        state_.operatorConsoles[1].rightHandleOffline = bit(frame.data, 4, 0);
        state_.operatorConsoles[1].leftKeypadOffline = bit(frame.data, 4, 1);
        state_.operatorConsoles[1].rightKeypadOffline = bit(frame.data, 4, 2);
        break;
    case 0x03:
        setAxisPacket(0, 0);
        break;
    case 0x04:
        setAxisPacket(0, 1);
        break;
    case 0x05:
        setAxisPacket(1, 0);
        break;
    case 0x06:
        setAxisPacket(1, 1);
        break;
    case 0x07:
        for (int button = 0; button < 4; ++button) {
            state_.operatorConsoles[0].handles[0].button[button] = bit(frame.data, 1, button);
            state_.operatorConsoles[0].handles[0].buttonValid[button] = true;
            state_.operatorConsoles[0].handles[1].button[button] = bit(frame.data, 1, button + 4);
            state_.operatorConsoles[0].handles[1].buttonValid[button] = true;
            state_.operatorConsoles[1].handles[0].button[button] = bit(frame.data, 2, button);
            state_.operatorConsoles[1].handles[0].buttonValid[button] = true;
            state_.operatorConsoles[1].handles[1].button[button] = bit(frame.data, 2, button + 4);
            state_.operatorConsoles[1].handles[1].buttonValid[button] = true;
        }
        break;
    default:
        break;
    }
    rebuildActiveAlarms();
}

void CanBusinessStateModel::applyDropoutFrame(const CanFrame &frame) {
    state_.dropoutValid = true;
    state_.algorithmPcbOffline = bit(frame.data, 3, 2);
    state_.inclinometerOffline = bit(frame.data, 3, 3);

    state_.arms[0].encoderOffline = frame.data[0] != 0;
    state_.arms[1].encoderOffline = frame.data[1] != 0;
    state_.arms[2].encoderOffline = frame.data[2] != 0;
    state_.arms[0].encoderOfflineValid = true;
    state_.arms[1].encoderOfflineValid = true;
    state_.arms[2].encoderOfflineValid = true;
    rebuildActiveAlarms();
}

void CanBusinessStateModel::rebuildActiveAlarms() {
    state_.activeAlarmCodes.clear();
    if (!state_.canToNetOnline) {
        state_.activeAlarmCodes.push_back(QStringLiteral("CAN_TO_NET未连接"));
    }
    if (state_.algorithmPcbOffline) {
        state_.activeAlarmCodes.push_back(QStringLiteral("算法PCB掉线"));
    }
    if (state_.inclinometerOffline) {
        state_.activeAlarmCodes.push_back(QStringLiteral("倾角仪掉线"));
    }
    if (state_.vehicleStatusValid) {
        if (state_.cableBoxEmergencyStop) {
            state_.activeAlarmCodes.push_back(QStringLiteral("电缆盒急停"));
        }
        if (state_.hoseBoxEmergencyStop) {
            state_.activeAlarmCodes.push_back(QStringLiteral("水缆盒急停"));
        }
        if (state_.leftConsoleEmergencyStop) {
            state_.activeAlarmCodes.push_back(QStringLiteral("左操作台急停"));
        }
    }

    static constexpr const char *armNames[3] = {"左臂", "中臂", "右臂"};
    for (int arm = 0; arm < 3; ++arm) {
        if (state_.arms[arm].lubricationPressureLow) {
            state_.activeAlarmCodes.push_back(QString::fromUtf8(armNames[arm]) + QStringLiteral("润滑压力低"));
        }
        if (state_.arms[arm].encoderOffline) {
            state_.activeAlarmCodes.push_back(QString::fromUtf8(armNames[arm]) + QStringLiteral("编码器掉线"));
        }
    }

    static constexpr const char *consoleNames[2] = {"左操作台", "右操作台"};
    for (int console = 0; console < 2; ++console) {
        const OperatorConsoleRealtimeState &operatorConsole = state_.operatorConsoles[console];
        if (!operatorConsole.linkValid) {
            continue;
        }
        const QString consoleName = QString::fromUtf8(consoleNames[console]);
        if (operatorConsole.leftHandleOffline) {
            state_.activeAlarmCodes.push_back(consoleName + QStringLiteral("左手柄掉线"));
        }
        if (operatorConsole.rightHandleOffline) {
            state_.activeAlarmCodes.push_back(consoleName + QStringLiteral("右手柄掉线"));
        }
        if (operatorConsole.leftKeypadOffline) {
            state_.activeAlarmCodes.push_back(consoleName + QStringLiteral("左按键板掉线"));
        }
        if (operatorConsole.rightKeypadOffline) {
            state_.activeAlarmCodes.push_back(consoleName + QStringLiteral("右按键板掉线"));
        }
    }
}

QVector<CanFrame> buildDrillPresetFrames(const std::array<ArmDrillPreset, 3> &presets) {
    QVector<CanFrame> frames;
    frames.reserve(15);

    auto makeFrame = [](quint8 b0) {
        CanFrame frame;
        frame.id = 0x71;
        frame.dlc = 8;
        frame.data[0] = b0;
        return frame;
    };

    for (int arm = 0; arm < 3; ++arm) {
        const ArmDrillPreset &preset = presets.at(static_cast<size_t>(arm));
        const quint8 offset = static_cast<quint8>(arm * 0x10);

        CanFrame depth = makeFrame(static_cast<quint8>(0x10 + offset));
        writeU16LE(depth.data, 1, preset.drillingDepthMm);
        writeU16LE(depth.data, 3, preset.leadHoleDepthMm);
        depth.data[5] = preset.antiJamPressure1;
        depth.data[6] = preset.antiJamPressure2;
        depth.data[7] = preset.antiEmptyHighPressure;
        frames.push_back(depth);

        CanFrame protection = makeFrame(static_cast<quint8>(0x40 + offset));
        protection.data[3] = preset.roofPressure;
        frames.push_back(protection);

        CanFrame leadAndDrill = makeFrame(static_cast<quint8>(0x70 + offset));
        leadAndDrill.data[1] = preset.leadRotationPressure;
        leadAndDrill.data[2] = preset.leadThrustPressure;
        leadAndDrill.data[3] = preset.leadImpactPressure;
        leadAndDrill.data[4] = preset.leadThrustSpeed;
        leadAndDrill.data[5] = preset.leadRotationSpeed;
        leadAndDrill.data[6] = preset.drillingRotationPressure;
        leadAndDrill.data[7] = preset.drillingThrustPressure;
        frames.push_back(leadAndDrill);

        CanFrame drillImpact = makeFrame(static_cast<quint8>(0x71 + offset));
        drillImpact.data[1] = preset.drillingImpactPressure;
        frames.push_back(drillImpact);

        CanFrame drillingSpeed = makeFrame(static_cast<quint8>(0xa0 + offset));
        drillingSpeed.data[1] = preset.drillingThrustSpeed;
        drillingSpeed.data[2] = preset.drillingRotationSpeed;
        frames.push_back(drillingSpeed);
    }

    return frames;
}

CanFrame buildArmZeroCalibrationFrame(int armIndex) {
    CanFrame frame;
    frame.id = 0x50;
    frame.dlc = 8;
    frame.data[7] = 0x00;

    if (armIndex == 0) {
        frame.data[0] = 0xff;
        frame.data[1] = 0x01;
    } else if (armIndex == 1) {
        frame.data[1] = 0xfe;
        frame.data[2] = 0x01;
    } else if (armIndex == 2) {
        frame.data[2] = 0xfe;
        frame.data[3] = 0x01;
    }

    return frame;
}

CanFrame buildFactoryQBodyFrame(quint8 pointIndex, qint16 xMm, qint16 yMm, qint16 zMm) {
    return buildCalibrationPointFrame(0xa1, pointIndex, xMm, yMm, zMm);
}

CanFrame buildVehiclePoseQWorldFrame(quint8 pointIndex, qint16 xMm, qint16 yMm, qint16 zMm) {
    return buildCalibrationPointFrame(0xa3, pointIndex, xMm, yMm, zMm);
}

CanFrame buildMechanicalErrorSampleFrame(int armIndex, quint8 sampleIndex, qint16 hXmm, qint16 hYmm, qint16 hZmm) {
    CanFrame frame;
    frame.id = 0x50;
    frame.dlc = 8;
    frame.data[7] = 0xa2;

    if (armIndex < 0 || armIndex > 2 || sampleIndex > 0x3e) {
        return frame;
    }

    frame.data[0] = static_cast<quint8>(armIndex * 0x40 + sampleIndex);
    writeS16LE(frame.data, 1, hXmm);
    writeS16LE(frame.data, 3, hYmm);
    writeS16LE(frame.data, 5, hZmm);
    return frame;
}

CanFrame buildMechanicalErrorFitFrame(int armIndex) {
    CanFrame frame;
    frame.id = 0x50;
    frame.dlc = 8;
    frame.data[7] = 0xa2;

    if (armIndex < 0 || armIndex > 2) {
        return frame;
    }

    frame.data[0] = static_cast<quint8>(armIndex * 0x40 + 0x3f);
    return frame;
}

bool runCanBusModelSelfTest(QString *error) {
    CanFrame tx;
    tx.id = 0x50;
    tx.dlc = 8;
    tx.data = {1, 2, 3, 4, 5, 6, 7, 0xa3};

    const QByteArray encoded = CanToNetCodec::encodeCanFrame(tx, 0x34);
    if (encoded.size() != CanToNetCodec::PacketSize || byteAt(encoded, 0) != 0xaa || byteAt(encoded, 1) != 0x55) {
        fail(error, QStringLiteral("encodeCanFrame did not produce a valid 21-byte header"));
        return false;
    }
    if (byteAt(encoded, 3) != 0x01 || byteAt(encoded, 4) != 0x34 || byteAt(encoded, 7) != 8) {
        fail(error, QStringLiteral("encodeCanFrame metadata mismatch"));
        return false;
    }
    if (byteAt(encoded, 8) != 0x50 || byteAt(encoded, 20) != CanToNetCodec::checksum(encoded, 20)) {
        fail(error, QStringLiteral("encodeCanFrame id or checksum mismatch"));
        return false;
    }

    CanToNetPacket decoded;
    if (!CanToNetCodec::tryDecodePacket(encoded, &decoded, error)) {
        return false;
    }
    if (decoded.frame.id != 0x50 || decoded.frame.data[7] != 0xa3 || decoded.sequence != 0x34) {
        fail(error, QStringLiteral("tryDecodePacket did not round-trip the CAN frame"));
        return false;
    }

    const QByteArray heartbeat = CanToNetCodec::encodeHeartbeat(0x5a);
    if (!CanToNetCodec::tryDecodePacket(heartbeat, &decoded, error)
        || decoded.type != CanToNetFrameType::Heartbeat
        || decoded.sequence != 0x5a) {
        fail(error, QStringLiteral("heartbeat encode/decode failed"));
        return false;
    }

    QByteArray bad = encoded;
    bad[20] = char(byteAt(bad, 20) ^ 0x01);
    if (CanToNetCodec::tryDecodePacket(bad, &decoded, nullptr)) {
        fail(error, QStringLiteral("bad checksum packet was accepted"));
        return false;
    }

    CanBusinessStateModel model;
    CanFrame frame;
    frame.id = 0x150;
    frame.dlc = 8;
    frame.data[0] = 0x10;
    writeS32LE(frame.data, 1, 12345);
    model.applyFrame(frame);
    frame.data = {};
    frame.data[0] = 0x11;
    writeS32LE(frame.data, 1, -5678);
    model.applyFrame(frame);
    frame.data = {};
    frame.data[0] = 0x12;
    writeS32LE(frame.data, 1, 900);
    model.applyFrame(frame);
    if (!model.state().arms[0].hValid
        || !near(model.state().arms[0].hX, 123.45)
        || !near(model.state().arms[0].hY, -56.78)
        || !near(model.state().arms[0].hZ, 9.0)) {
        fail(error, QStringLiteral("0x150 H point decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x13;
    frame.data[5] = 0x01;
    writeS32LE(frame.data, 1, 1111);
    model.applyFrame(frame);
    frame.data = {};
    frame.data[0] = 0x14;
    frame.data[5] = 0x01;
    writeS32LE(frame.data, 1, 2222);
    model.applyFrame(frame);
    frame.data = {};
    frame.data[0] = 0x15;
    frame.data[5] = 0x01;
    writeS32LE(frame.data, 1, 3333);
    model.applyFrame(frame);
    if (!model.state().arms[0].h1Valid
        || !near(model.state().arms[0].h1X, 11.11)
        || !near(model.state().arms[0].h1Y, 22.22)
        || !near(model.state().arms[0].h1Z, 33.33)) {
        fail(error, QStringLiteral("0x150 H1 point decode failed"));
        return false;
    }

    frame.id = 0x153;
    frame.data = {};
    writeU16LE(frame.data, 0, 1500);
    writeU16LE(frame.data, 2, 2500);
    writeU16LE(frame.data, 4, 3500);
    model.applyFrame(frame);
    if (!near(model.state().arms[1].drillingDepthM, 2.5)) {
        fail(error, QStringLiteral("0x153 drilling depth decode failed"));
        return false;
    }

    frame.id = 0x176;
    frame.data = {};
    frame.data[0] = 0x08;
    writeU16LE(frame.data, 1, 100);
    writeU16LE(frame.data, 3, 200);
    writeU16LE(frame.data, 5, 300);
    model.applyFrame(frame);
    if (!near(model.state().arms[0].impactPressure, 100.0)
        || !near(model.state().arms[0].rotationPressure, 200.0)
        || !near(model.state().arms[0].boomPressure, 300.0)) {
        fail(error, QStringLiteral("0x176 pressure decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x21;
    frame.data[1] = 0x01;
    frame.data[2] = 0x03;
    frame.data[3] = 0x07;
    model.applyFrame(frame);
    if (!model.state().selectedArmStatusValid
        || model.state().operatorConsoles[0].selectedArm != 1
        || model.state().operatorConsoles[1].selectedArm != 3
        || model.state().selectedArmSourceFlags != 0x07) {
        fail(error, QStringLiteral("0x176 selected arm decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x22;
    frame.data[1] = 0x02;
    frame.data[2] = 0x00;
    frame.data[3] = 0x04;
    frame.data[4] = 0x05;
    frame.data[5] = 0x01;
    model.applyFrame(frame);
    if (!model.state().arms[0].drillingStateValid
        || model.state().arms[0].drillingState != 2
        || !model.state().arms[0].drillingActive
        || !model.state().arms[0].drillingStartPulse
        || !model.state().arms[2].drillingActive
        || model.state().arms[2].drillingStartPulse) {
        fail(error, QStringLiteral("0x176 drilling state decode failed"));
        return false;
    }

    frame.id = 0x170;
    frame.data = {};
    frame.data[0] = 0x01;
    frame.data[1] = 0x08;
    model.applyFrame(frame);
    if (!model.state().arms[0].lubricationPressureLow
        || !model.state().activeAlarmCodes.contains(QStringLiteral("左臂润滑压力低"))) {
        fail(error, QStringLiteral("0x170 lubrication alarm decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x01;
    frame.data[3] = 0xe0;
    model.applyFrame(frame);
    if (!model.state().cableBoxEmergencyStop
        || !model.state().hoseBoxEmergencyStop
        || !model.state().leftConsoleEmergencyStop
        || !model.state().activeAlarmCodes.contains(QStringLiteral("左操作台急停"))) {
        fail(error, QStringLiteral("0x170 emergency stop decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x02;
    frame.data[3] = 0x18;
    frame.data[4] = 0x01;
    model.applyFrame(frame);
    if (!model.state().operatorConsoles[0].linkValid
        || !model.state().operatorConsoles[0].leftHandleOffline
        || !model.state().operatorConsoles[0].rightHandleOffline
        || !model.state().operatorConsoles[1].rightHandleOffline
        || !model.state().activeAlarmCodes.contains(QStringLiteral("左操作台左手柄掉线"))) {
        fail(error, QStringLiteral("0x170 operator dropout decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x03;
    writeU16LE(frame.data, 1, 1000);
    writeU16LE(frame.data, 3, 2000);
    writeU16LE(frame.data, 5, 3000);
    model.applyFrame(frame);
    if (!model.state().operatorConsoles[0].handles[0].axisValid[2]
        || model.state().operatorConsoles[0].handles[0].axis[0] != 1000
        || model.state().operatorConsoles[0].handles[0].axis[1] != 2000
        || model.state().operatorConsoles[0].handles[0].axis[2] != 3000) {
        fail(error, QStringLiteral("0x170 operator axis decode failed"));
        return false;
    }

    frame.data = {};
    frame.data[0] = 0x07;
    frame.data[1] = 0x91;
    frame.data[2] = 0x42;
    model.applyFrame(frame);
    if (!model.state().operatorConsoles[0].handles[0].button[0]
        || !model.state().operatorConsoles[0].handles[1].button[3]
        || !model.state().operatorConsoles[1].handles[0].button[1]
        || !model.state().operatorConsoles[1].handles[1].button[2]) {
        fail(error, QStringLiteral("0x170 operator button decode failed"));
        return false;
    }

    frame.id = 0x15a;
    frame.data = {};
    frame.data[3] = 0x0c;
    model.applyFrame(frame);
    if (!model.state().algorithmPcbOffline
        || !model.state().inclinometerOffline
        || !model.state().activeAlarmCodes.contains(QStringLiteral("算法PCB掉线"))) {
        fail(error, QStringLiteral("0x15A dropout decode failed"));
        return false;
    }

    std::array<ArmDrillPreset, 3> presets;
    presets[0].drillingDepthMm = 5000;
    presets[0].leadHoleDepthMm = 300;
    presets[0].antiJamPressure1 = 80;
    presets[0].antiJamPressure2 = 92;
    presets[0].antiEmptyHighPressure = 35;
    presets[0].roofPressure = 30;
    presets[0].leadThrustPressure = 25;
    presets[0].leadImpactPressure = 40;
    presets[0].leadThrustSpeed = 75;
    presets[0].leadRotationSpeed = 50;
    presets[0].drillingThrustPressure = 43;
    presets[0].drillingImpactPressure = 65;
    presets[0].drillingThrustSpeed = 100;
    presets[0].drillingRotationSpeed = 75;
    const QVector<CanFrame> presetFrames = buildDrillPresetFrames(presets);
    if (presetFrames.size() != 15
        || presetFrames.at(0).id != 0x71
        || presetFrames.at(0).data[0] != 0x10
        || readU16LE(presetFrames.at(0).data, 1) != 5000
        || readU16LE(presetFrames.at(0).data, 3) != 300
        || presetFrames.at(0).data[5] != 80
        || presetFrames.at(0).data[6] != 92
        || presetFrames.at(0).data[7] != 35
        || presetFrames.at(2).data[0] != 0x70
        || presetFrames.at(2).data[2] != 25
        || presetFrames.at(2).data[7] != 43
        || presetFrames.at(3).data[0] != 0x71
        || presetFrames.at(3).data[1] != 65
        || presetFrames.at(5).data[0] != 0x20
        || presetFrames.at(10).data[0] != 0x30) {
        fail(error, QStringLiteral("0x71 drill preset packing failed"));
        return false;
    }

    const CanFrame leftZero = buildArmZeroCalibrationFrame(0);
    const CanFrame midZero = buildArmZeroCalibrationFrame(1);
    const CanFrame rightZero = buildArmZeroCalibrationFrame(2);
    if (leftZero.id != 0x50 || leftZero.data[0] != 0xff || leftZero.data[1] != 0x01 || leftZero.data[7] != 0x00
        || midZero.data[1] != 0xfe || midZero.data[2] != 0x01
        || rightZero.data[2] != 0xfe || rightZero.data[3] != 0x01) {
        fail(error, QStringLiteral("0x50 zero calibration packing failed"));
        return false;
    }

    const CanFrame qBody = buildFactoryQBodyFrame(4, -120, 345, 678);
    if (qBody.id != 0x50
        || qBody.data[0] != 4
        || readS16LE(qBody.data, 1) != -120
        || readS16LE(qBody.data, 3) != 345
        || readS16LE(qBody.data, 5) != 678
        || qBody.data[7] != 0xa1) {
        fail(error, QStringLiteral("0x50/A1 factory Q-body packing failed"));
        return false;
    }

    const CanFrame qWorld = buildVehiclePoseQWorldFrame(2, 1000, -2000, 30);
    if (qWorld.id != 0x50
        || qWorld.data[0] != 2
        || readS16LE(qWorld.data, 1) != 1000
        || readS16LE(qWorld.data, 3) != -2000
        || readS16LE(qWorld.data, 5) != 30
        || qWorld.data[7] != 0xa3) {
        fail(error, QStringLiteral("0x50/A3 vehicle pose Q-world packing failed"));
        return false;
    }

    const CanFrame leftSample = buildMechanicalErrorSampleFrame(0, 0x3e, -1, 2, -3);
    const CanFrame midSample = buildMechanicalErrorSampleFrame(1, 0x00, 10, 20, 30);
    const CanFrame rightSample = buildMechanicalErrorSampleFrame(2, 0x02, 40, 50, 60);
    const CanFrame leftFit = buildMechanicalErrorFitFrame(0);
    const CanFrame midFit = buildMechanicalErrorFitFrame(1);
    const CanFrame rightFit = buildMechanicalErrorFitFrame(2);
    if (leftSample.data[0] != 0x3e
        || readS16LE(leftSample.data, 1) != -1
        || readS16LE(leftSample.data, 3) != 2
        || readS16LE(leftSample.data, 5) != -3
        || leftSample.data[7] != 0xa2
        || midSample.data[0] != 0x40
        || rightSample.data[0] != 0x82
        || leftFit.data[0] != 0x3f
        || midFit.data[0] != 0x7f
        || rightFit.data[0] != 0xbf
        || rightFit.data[7] != 0xa2) {
        fail(error, QStringLiteral("0x50/A2 mechanical error packing failed"));
        return false;
    }

    return true;
}
