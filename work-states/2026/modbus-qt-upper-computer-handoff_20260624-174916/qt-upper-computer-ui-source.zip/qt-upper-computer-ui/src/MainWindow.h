#pragma once

#include "CanBusModel.h"
#include "CanToNetClient.h"

#include <array>
#include <QMainWindow>
#include <QHash>
#include <QLabel>
#include <QLineEdit>
#include <QPoint>
#include <QPointer>
#include <QPushButton>
#include <QStringList>
#include <QStackedWidget>
#include <QTimer>
#include <QVector>

class SitonDrillMainView;
class QEvent;
class QTableWidget;

class MainWindow final : public QMainWindow {
public:
    explicit MainWindow(QWidget *parent = nullptr);
    void injectDemoCanFramesForScreenshot(double leftDepthM = 1.25,
                                          double middleDepthM = 2.10,
                                          double rightDepthM = 0.85);
    void setPageForScreenshot(int index);

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    QWidget *buildShell();
    QWidget *buildTopbar();
    QWidget *buildDashboardPage();
    QWidget *buildWorkfacePage();
    QWidget *buildSettingsHubPage();
    QWidget *buildSettingZeroPage();
    QWidget *buildSettingsPage();
    QWidget *buildDrillPresetPage();
    QWidget *buildRockProtectionPage();
    QWidget *buildCalibrationPage();
    QWidget *buildHoleMapEditPage();
    QWidget *buildAlarmsPage();
    QWidget *buildLogsPage();
    QWidget *buildPageByIndex(int index);
    void ensurePageBuilt(int index);

    QPushButton *touchButton(const QString &text, const QString &objectName = QString());

    void switchPage(int index);
    void refreshClock();
    void initCanToNet();
    void applyCanToNetConfig(const QString &host, quint16 port, bool restartClient);
    void handleCanFrame(const CanFrame &frame);
    void scheduleRealtimeRefresh();
    void refreshRealtimeUi();
    void refreshAlarmRowsFromState();
    void refreshAlarmTable();
    void setupPersistentInputs(QWidget *root = nullptr);
    void installTouchKeyboard(QLineEdit *edit);
    void showTouchNumberPad(QLineEdit *edit);
    void setPageMarker(const QString &marker);
    void refreshPageNumberLabel(int index);
    void sendCommandFrame(const QString &label, quint32 id, const std::array<quint8, 8> &data, quint8 dlc = 8);
    void scheduleCanToNetCommandClear(quint32 id, const std::array<quint8, 8> &data);
    void clearCanToNetCommandAfterWrite(quint32 id);
    void applyStyle();

    CanToNetClient canClient_;
    CanBusinessStateModel canState_;
    QPointer<QStackedWidget> pages_;
    QPointer<QWidget> topbar_;
    QPointer<SitonDrillMainView> dashboardView_;
    QPointer<SitonDrillMainView> holeEditView_;
    std::array<QPointer<QWidget>, 11> pageSlots_;
    std::array<bool, 11> pageBuilt_{};
    QVector<QPointer<QPushButton>> navButtons_;
    QPointer<QLabel> connectionLabel_;
    QPointer<QLineEdit> canToNetStatusEdit_;
    QPointer<QLabel> canToNetFaultDot_;
    QPointer<QLabel> canToNetHandleDot_;
    QPointer<QLabel> canToNetHandleValue_;
    QPointer<QLabel> pageNumberLabel_;
    QPointer<QTableWidget> alarmTable_;
    QPointer<QLabel> alarmPageInfo_;
    QPointer<QLabel> commandStatusLabel_;
    bool windowDragActive_ = false;
    QPoint windowDragOffset_;
    QString canToNetHost_ = QStringLiteral("192.168.0.105");
    quint16 canToNetPort_ = 503;
    QVector<QVector<QStringList>> alarmRowsByTab_;
    QHash<QString, QString> activeAlarmFirstSeen_;
    int alarmTabIndex_ = 0;
    int pendingCanToNetCommandClears_ = 0;
    std::array<std::array<QPointer<QLabel>, 18>, 3> armFaultDots_;
    std::array<QPointer<QLabel>, 12> systemFaultDots_;
    std::array<std::array<std::array<QPointer<QLabel>, 7>, 2>, 2> handleValueLabels_;
    std::array<QPointer<QLabel>, 9> handleStatusDots_;
    std::array<QPointer<QLabel>, 9> handleStatusValues_;
    std::array<std::array<QPointer<QLabel>, 6>, 3> truckWorkStatusDots_;
    std::array<std::array<QPointer<QLabel>, 2>, 3> truckEmergencyDots_;
    std::array<QPointer<QLabel>, 3> lubricationProtectDots_;
    std::array<std::array<QPointer<QLabel>, 11>, 3> truckDataValueLabels_;
    std::array<std::array<QPointer<QLabel>, 11>, 3> truckDataStatusDots_;
    std::array<std::array<QPointer<QLabel>, 14>, 3> sensorValueLabels_;
    std::array<QPointer<QLabel>, 6> calibrationFeedbackLabels_;
    QTimer realtimeRefreshTimer_;
    QTimer timer_;
};
