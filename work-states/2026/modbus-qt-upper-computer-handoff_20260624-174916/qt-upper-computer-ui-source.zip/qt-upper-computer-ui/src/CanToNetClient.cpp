#include "CanToNetClient.h"

#include <QDataStream>
#include <QIODevice>
#include <QNetworkProxy>
#include <QtGlobal>

namespace {
constexpr int DefaultPollIntervalMs = 100;
constexpr int ReconnectIntervalMs = 1000;
}

CanToNetClient::CanToNetClient(QObject *parent)
    : QObject(parent) {
    socket_.setProxy(QNetworkProxy::NoProxy);
    timeoutTimer_.setSingleShot(true);
    reconnectTimer_.setInterval(ReconnectIntervalMs);

    connect(&socket_, &QTcpSocket::connected, this, &CanToNetClient::onConnected);
    connect(&socket_, &QTcpSocket::disconnected, this, &CanToNetClient::onDisconnected);
    connect(&socket_, &QTcpSocket::readyRead, this, &CanToNetClient::onReadyRead);
    connect(&socket_, &QTcpSocket::errorOccurred, this, &CanToNetClient::onSocketError);
    connect(&timeoutTimer_, &QTimer::timeout, this, &CanToNetClient::onRequestTimeout);
    connect(&pollTimer_, &QTimer::timeout, this, &CanToNetClient::onPollTimeout);
    connect(&reconnectTimer_, &QTimer::timeout, this, &CanToNetClient::onReconnectTimeout);
}

void CanToNetClient::configure(const QString &host, quint16 port, quint8 channel) {
    Q_UNUSED(channel);
    setEndpoint(host, port == 0 ? quint16(503) : port);
}

void CanToNetClient::start() {
    running_ = true;
    startDefaultPolling();
    connectToCanToNet();
    reconnectTimer_.start();
}

void CanToNetClient::stop() {
    running_ = false;
    reconnectTimer_.stop();
    disconnectFromCanToNet();
}

bool CanToNetClient::isConnected() const {
    return socket_.state() == QAbstractSocket::ConnectedState;
}

void CanToNetClient::sendCanFrame(const CanFrame &frame) {
    QByteArray data(8, 0);
    const int bytes = qMin<int>(frame.dlc, 8);
    for (int i = 0; i < bytes; ++i) {
        data[i] = char(frame.data.at(i));
    }
    writeCanFrame(frame.id, data);
}

void CanToNetClient::setEndpoint(const QString &host, quint16 port) {
    host_ = host.trimmed().isEmpty() ? QStringLiteral("192.168.0.105") : host.trimmed();
    port_ = port == 0 ? quint16(503) : port;
}

void CanToNetClient::setUnitId(quint8 unitId) {
    unitId_ = unitId;
}

void CanToNetClient::setAddressOffset(int offset) {
    addressOffset_ = offset;
}

void CanToNetClient::setTimeoutMs(int timeoutMs) {
    timeoutMs_ = qMax(20, timeoutMs);
}

void CanToNetClient::connectToCanToNet() {
    if (socket_.state() != QAbstractSocket::UnconnectedState) {
        socket_.abort();
    }
    socket_.connectToHost(host_, port_);
}

void CanToNetClient::disconnectFromCanToNet() {
    stopPolling();
    queue_.clear();
    hasCurrentRequest_ = false;
    timeoutTimer_.stop();
    rxBuffer_.clear();
    if (socket_.state() != QAbstractSocket::UnconnectedState) {
        socket_.disconnectFromHost();
    }
}

void CanToNetClient::readHoldingRegisters(int canToNetStartAddress, int count) {
    if (count <= 0 || count > 125) {
        reportError(QStringLiteral("Read register count must be 1..125."));
        return;
    }
    enqueue(buildReadRequest(canToNetStartAddress, count));
}

void CanToNetClient::writeHoldingRegisters(const QMap<int, quint16> &canToNetAddressValues) {
    if (canToNetAddressValues.isEmpty()) {
        return;
    }

    auto it = canToNetAddressValues.cbegin();
    while (it != canToNetAddressValues.cend()) {
        const int startAddress = it.key();
        QVector<quint16> values;
        values.append(it.value());
        ++it;

        int nextAddress = startAddress + 1;
        while (it != canToNetAddressValues.cend() && it.key() == nextAddress && values.size() < 123) {
            values.append(it.value());
            ++it;
            ++nextAddress;
        }

        enqueue(buildWriteRequest(startAddress, values));
    }
}

void CanToNetClient::readCanFrame(quint32 canId) {
    int startAddress = 0;
    int registerCount = 0;
    if (!canIdToAddressRange(canId, &startAddress, &registerCount)) {
        reportError(QStringLiteral("Unknown CAN ID: 0x%1").arg(canId, 0, 16).toUpper());
        return;
    }
    enqueue(buildReadRequest(startAddress, registerCount, canId));
}

void CanToNetClient::writeCanFrame(quint32 canId, const QByteArray &canData8) {
    int startAddress = 0;
    int registerCount = 0;
    if (!canIdToAddressRange(canId, &startAddress, &registerCount)) {
        reportError(QStringLiteral("Unknown CAN ID: 0x%1").arg(canId, 0, 16).toUpper());
        return;
    }

    if (canData8.size() != 8) {
        reportError(QStringLiteral("CAN DATA must be exactly 8 bytes."));
        return;
    }

    const auto registers = canDataToRegisters(startAddress, canData8);
    QVector<quint16> values;
    for (auto it = registers.cbegin(); it != registers.cend(); ++it) {
        values.append(it.value());
    }

    if (values.size() != registerCount) {
        reportError(QStringLiteral("CAN DATA register packing failed."));
        return;
    }

    enqueue(buildWriteRequest(startAddress, values, canId));
}

void CanToNetClient::startPolling(int canToNetStartAddress, int count, int intervalMs) {
    pollMode_ = PollMode::Registers;
    pollStartAddress_ = canToNetStartAddress;
    pollCount_ = count;
    pollTimer_.start(qMax(20, intervalMs));
}

void CanToNetClient::startPollingCanFrame(quint32 canId, int intervalMs) {
    int startAddress = 0;
    int registerCount = 0;
    if (!canIdToAddressRange(canId, &startAddress, &registerCount)) {
        reportError(QStringLiteral("Unknown CAN ID: 0x%1").arg(canId, 0, 16).toUpper());
        return;
    }

    pollMode_ = PollMode::SingleCanFrame;
    pollCanId_ = canId;
    pollStartAddress_ = startAddress;
    pollCount_ = registerCount;
    pollTimer_.start(qMax(20, intervalMs));
}

void CanToNetClient::stopPolling() {
    pollTimer_.stop();
    pollMode_ = PollMode::None;
}

bool CanToNetClient::canIdToAddressRange(quint32 canId, int *startAddress, int *registerCount) {
    int address = 0;
    switch (canId) {
    case 0x50:  address = 100; break;
    case 0x71:  address = 104; break;
    case 0x75:  address = 108; break;
    case 0x7A:  address = 112; break;
    case 0x150: address = 50; break;
    case 0x152: address = 54; break;
    case 0x153: address = 58; break;
    case 0x154: address = 62; break;
    case 0x15A: address = 66; break;
    case 0x170: address = 70; break;
    case 0x176: address = 74; break;
    default:
        return false;
    }

    if (startAddress != nullptr) {
        *startAddress = address;
    }
    if (registerCount != nullptr) {
        *registerCount = 4;
    }
    return true;
}

QByteArray CanToNetClient::registersToCanData(const QVector<quint16> &registers) {
    QByteArray data;
    data.reserve(registers.size() * 2);
    for (const auto value : registers) {
        data.append(char(value & 0xFF));
        data.append(char((value >> 8) & 0xFF));
    }
    return data.left(8);
}

QMap<int, quint16> CanToNetClient::canDataToRegisters(int startAddress, const QByteArray &canData8) {
    QMap<int, quint16> registers;
    for (int i = 0; i < 8; i += 2) {
        const quint8 low = i < canData8.size() ? quint8(canData8[i]) : 0;
        const quint8 high = (i + 1) < canData8.size() ? quint8(canData8[i + 1]) : 0;
        registers[startAddress + i / 2] = quint16(low) | (quint16(high) << 8);
    }
    return registers;
}

void CanToNetClient::onReadyRead() {
    rxBuffer_.append(socket_.readAll());

    while (rxBuffer_.size() >= 7) {
        const quint16 length = (quint8(rxBuffer_[4]) << 8) | quint8(rxBuffer_[5]);
        const int frameSize = 6 + length;
        if (rxBuffer_.size() < frameSize) {
            return;
        }

        const QByteArray adu = rxBuffer_.left(frameSize);
        rxBuffer_.remove(0, frameSize);
        handleResponse(adu);
    }
}

void CanToNetClient::onSocketError(QAbstractSocket::SocketError) {
    reportError(socket_.errorString());
}

void CanToNetClient::onConnected() {
    reconnectTimer_.stop();
    emit connected();
    emit connectedChanged(true);
}

void CanToNetClient::onDisconnected() {
    emit disconnected();
    emit connectedChanged(false);
    timeoutTimer_.stop();
    hasCurrentRequest_ = false;
    queue_.clear();
    if (running_) {
        reconnectTimer_.start();
    }
}

void CanToNetClient::onRequestTimeout() {
    reportError(QStringLiteral("CAN_TO_NET Modbus communication timeout."));
    socket_.abort();
    hasCurrentRequest_ = false;
    queue_.clear();
}

void CanToNetClient::onPollTimeout() {
    if (!running_ || !isConnected() || hasCurrentRequest_ || !queue_.isEmpty()) {
        return;
    }

    switch (pollMode_) {
    case PollMode::DefaultCanFrames:
        if (!defaultPollCanIds_.isEmpty()) {
            readCanFrame(defaultPollCanIds_.at(pollIndex_ % defaultPollCanIds_.size()));
            ++pollIndex_;
        }
        break;
    case PollMode::Registers:
        readHoldingRegisters(pollStartAddress_, pollCount_);
        break;
    case PollMode::SingleCanFrame:
        readCanFrame(pollCanId_);
        break;
    case PollMode::None:
        break;
    }
}

void CanToNetClient::onReconnectTimeout() {
    if (running_ && socket_.state() == QAbstractSocket::UnconnectedState) {
        socket_.connectToHost(host_, port_);
    }
}

quint16 CanToNetClient::toProtocolAddress(int canToNetAddress) {
    const int protocolAddress = canToNetAddress - addressOffset_;
    if (protocolAddress < 0 || protocolAddress > 65535) {
        reportError(QStringLiteral("CAN_TO_NET address out of range."));
        return 0;
    }
    return quint16(protocolAddress);
}

void CanToNetClient::enqueue(Request request) {
    if (!isConnected()) {
        reportError(QStringLiteral("CAN_TO_NET is not connected."));
        return;
    }

    queue_.enqueue(request);
    sendNext();
}

void CanToNetClient::sendNext() {
    if (hasCurrentRequest_ || queue_.isEmpty()) {
        return;
    }

    if (!isConnected()) {
        reportError(QStringLiteral("CAN_TO_NET is not connected."));
        queue_.clear();
        return;
    }

    current_ = queue_.dequeue();
    current_.transactionId = nextTransactionId_++;

    QByteArray adu = buildMbap(current_.transactionId, current_.pdu.size());
    adu.append(current_.pdu);
    socket_.write(adu);
    socket_.flush();

    hasCurrentRequest_ = true;
    timeoutTimer_.start(timeoutMs_);
}

void CanToNetClient::handleResponse(const QByteArray &adu) {
    if (!hasCurrentRequest_ || adu.size() < 9) {
        return;
    }

    const quint16 transactionId = (quint8(adu[0]) << 8) | quint8(adu[1]);
    const quint8 unitId = quint8(adu[6]);
    const QByteArray pdu = adu.mid(7);

    if (transactionId != current_.transactionId || unitId != unitId_) {
        reportError(QStringLiteral("CAN_TO_NET response does not match request."), adu);
        return;
    }

    if ((quint8(pdu[0]) & 0x80) != 0) {
        const quint8 code = pdu.size() > 1 ? quint8(pdu[1]) : 0;
        reportError(QStringLiteral("CAN_TO_NET Modbus exception: %1").arg(code), adu);
        completeCurrentRequest();
        return;
    }

    if (current_.type == RequestType::Read) {
        const int byteCount = pdu.size() > 1 ? quint8(pdu[1]) : 0;
        QVector<quint16> values;
        for (int i = 0; i + 1 < byteCount; i += 2) {
            values.append((quint8(pdu[2 + i]) << 8) | quint8(pdu[3 + i]));
        }

        if (current_.isCanFrame) {
            const QByteArray canData = registersToCanData(values);
            emit canFrameRead(current_.canId, canData);

            CanFrame frame;
            frame.id = current_.canId;
            frame.dlc = qMin<quint8>(8, static_cast<quint8>(canData.size()));
            frame.data.fill(0);
            for (int i = 0; i < frame.dlc; ++i) {
                frame.data[i] = quint8(canData.at(i));
            }
            emit canFrameReceived(frame);
        } else {
            emit registersRead(current_.canToNetStartAddress, values);
        }
    } else {
        if (current_.isCanFrame) {
            emit canFrameWritten(current_.canId);
        } else {
            emit writeFinished(current_.count);
        }
    }

    completeCurrentRequest();
}

void CanToNetClient::completeCurrentRequest() {
    timeoutTimer_.stop();
    hasCurrentRequest_ = false;
    sendNext();
}

void CanToNetClient::reportError(const QString &message, const QByteArray &raw) {
    emit errorOccurred(message);
    emit packetDropped(message, raw);
}

QByteArray CanToNetClient::buildMbap(quint16 transactionId, quint16 pduLength) const {
    QByteArray mbap;
    QDataStream stream(&mbap, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::BigEndian);
    stream << transactionId << quint16(0) << quint16(1 + pduLength) << unitId_;
    return mbap;
}

CanToNetClient::Request CanToNetClient::buildReadRequest(int canToNetStartAddress, int count, quint32 canId) {
    const auto protocolAddress = toProtocolAddress(canToNetStartAddress);

    QByteArray pdu;
    QDataStream stream(&pdu, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::BigEndian);
    stream << quint8(0x03) << protocolAddress << quint16(count);

    Request request;
    request.type = RequestType::Read;
    request.functionCode = 0x03;
    request.canToNetStartAddress = canToNetStartAddress;
    request.count = count;
    request.canId = canId;
    request.isCanFrame = canId != 0;
    request.pdu = pdu;
    return request;
}

CanToNetClient::Request CanToNetClient::buildWriteRequest(int canToNetStartAddress, const QVector<quint16> &values, quint32 canId) {
    const auto protocolAddress = toProtocolAddress(canToNetStartAddress);

    QByteArray pdu;
    QDataStream stream(&pdu, QIODevice::WriteOnly);
    stream.setByteOrder(QDataStream::BigEndian);

    if (values.size() == 1) {
        stream << quint8(0x06) << protocolAddress << values.first();
    } else {
        stream << quint8(0x10) << protocolAddress << quint16(values.size()) << quint8(values.size() * 2);
        for (const auto value : values) {
            stream << value;
        }
    }

    Request request;
    request.type = RequestType::Write;
    request.functionCode = values.size() == 1 ? 0x06 : 0x10;
    request.canToNetStartAddress = canToNetStartAddress;
    request.count = values.size();
    request.canId = canId;
    request.isCanFrame = canId != 0;
    request.pdu = pdu;
    return request;
}

void CanToNetClient::startDefaultPolling() {
    pollMode_ = PollMode::DefaultCanFrames;
    pollIndex_ = 0;
    pollTimer_.start(DefaultPollIntervalMs);
}
