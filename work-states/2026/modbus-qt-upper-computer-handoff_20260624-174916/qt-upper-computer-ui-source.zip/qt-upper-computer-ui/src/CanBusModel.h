#pragma once

#include <array>

#include <QByteArray>
#include <QString>
#include <QVector>
#include <QtGlobal>

struct CanFrame {
    quint32 id = 0;
    quint8 dlc = 0;
    std::array<quint8, 8> data = {};
    bool extended = false;
    bool remote = false;
};

enum class CanToNetFrameType : quint8 {
    SendCan = 0x01,
    ReceiveCan = 0x02,
    Heartbeat = 0x03
};

struct CanToNetPacket {
    CanToNetFrameType type = CanToNetFrameType::ReceiveCan;
    quint8 sequence = 0;
    quint8 channel = 0;
    CanFrame frame;
};

class CanToNetCodec {
public:
    static constexpr int PacketSize = 21;

    static QByteArray encodeCanFrame(const CanFrame &frame,
                                     quint8 sequence,
                                     CanToNetFrameType type = CanToNetFrameType::SendCan,
                                     quint8 channel = 0);
    static QByteArray encodeHeartbeat(quint8 sequence);
    static bool tryDecodePacket(const QByteArray &packet, CanToNetPacket *out, QString *error = nullptr);
    static quint8 checksum(const QByteArray &bytes, qsizetype count = 20);
};

struct ArmRealtimeState {
    double hX = 0.0;
    double hY = 0.0;
    double hZ = 0.0;
    bool hValid = false;

    double h1X = 0.0;
    double h1Y = 0.0;
    double h1Z = 0.0;
    bool h1Valid = false;
    bool h1AxisValid[3] = {};

    quint16 drillingDepthRaw = 0;
    double drillingDepthM = 0.0;
    quint8 drillingState = 0;
    bool drillingStateValid = false;
    bool drillingActive = false;
    bool drillingStartPulse = false;

    double angleXzDeg = 0.0;
    double angleYzDeg = 0.0;
    bool angleValid = false;

    double encoderAnglesDeg[9] = {};
    bool encoderAnglesValid[9] = {};

    double thrustPressure = 0.0;
    double impactPressure = 0.0;
    double rotationPressure = 0.0;
    double boomPressure = 0.0;
    double compensationThrustPressure = 0.0;
    double waterFlow = 0.0;
    double lubricationPressure = 0.0;
    double bufferPressure = 0.0;
    quint32 rockDrillWorkTimeRaw = 0;
    bool thrustPressureValid = false;
    bool impactPressureValid = false;
    bool rotationPressureValid = false;
    bool boomPressureValid = false;
    bool compensationThrustPressureValid = false;
    bool waterFlowValid = false;
    bool lubricationPressureValid = false;
    bool bufferPressureValid = false;
    bool rockDrillWorkTimeValid = false;

    bool lubricationPressureLow = false;
    bool lubricationPressureLowValid = false;
    bool encoderOffline = false;
    bool encoderOfflineValid = false;
};

struct CalibrationFeedback {
    bool statusValid = false;
    bool rmsValid = false;
    quint8 object = 0;
    quint8 status = 0;
    quint8 errorCode = 0;
    quint8 receivedPointCount = 0;
    qint16 maxErrorMm = 0;
    quint8 businessFlag = 0;
    quint16 rmsMm = 0;
};

struct OperatorHandleRealtimeState {
    qint16 axis[3] = {};
    bool axisValid[3] = {};
    bool button[4] = {};
    bool buttonValid[4] = {};
};

struct OperatorConsoleRealtimeState {
    OperatorHandleRealtimeState handles[2];
    quint8 selectedArm = 0;
    bool selectedArmValid = false;
    bool linkValid = false;
    bool leftHandleOffline = false;
    bool rightHandleOffline = false;
    bool leftKeypadOffline = false;
    bool rightKeypadOffline = false;
};

struct MachineRealtimeState {
    ArmRealtimeState arms[3];
    OperatorConsoleRealtimeState operatorConsoles[2];
    CalibrationFeedback calibration;
    quint8 selectedArmSourceFlags = 0;
    bool selectedArmStatusValid = false;
    bool canToNetOnline = false;
    bool algorithmPcbOffline = false;
    bool inclinometerOffline = false;
    bool dropoutValid = false;
    bool vehicleStatusValid = false;
    bool cableBoxEmergencyStop = false;
    bool hoseBoxEmergencyStop = false;
    bool leftConsoleEmergencyStop = false;
    QVector<QString> activeAlarmCodes;
};

struct ArmDrillPreset {
    quint16 drillingDepthMm = 0;
    quint16 leadHoleDepthMm = 0;
    quint8 antiJamPressure1 = 0;
    quint8 antiJamPressure2 = 0;
    quint8 antiEmptyHighPressure = 0;
    quint8 roofPressure = 0;
    quint8 leadRotationPressure = 0;
    quint8 leadThrustPressure = 0;
    quint8 leadImpactPressure = 0;
    quint8 leadThrustSpeed = 0;
    quint8 leadRotationSpeed = 0;
    quint8 drillingRotationPressure = 0;
    quint8 drillingThrustPressure = 0;
    quint8 drillingImpactPressure = 0;
    quint8 drillingThrustSpeed = 0;
    quint8 drillingRotationSpeed = 0;
};

QVector<CanFrame> buildDrillPresetFrames(const std::array<ArmDrillPreset, 3> &presets);
CanFrame buildArmZeroCalibrationFrame(int armIndex);
CanFrame buildFactoryQBodyFrame(quint8 pointIndex, qint16 xMm, qint16 yMm, qint16 zMm);
CanFrame buildVehiclePoseQWorldFrame(quint8 pointIndex, qint16 xMm, qint16 yMm, qint16 zMm);
CanFrame buildMechanicalErrorSampleFrame(int armIndex, quint8 sampleIndex, qint16 hXmm, qint16 hYmm, qint16 hZmm);
CanFrame buildMechanicalErrorFitFrame(int armIndex);

class CanBusinessStateModel {
public:
    void reset();
    void setCanToNetOnline(bool online);
    void applyFrame(const CanFrame &frame);

    const MachineRealtimeState &state() const;

private:
    void applyAlgorithmFrame(const CanFrame &frame);
    void applyEndpointCoordinateFrame(const CanFrame &frame);
    void applyEndpointAngleFrame(const CanFrame &frame);
    void applyDrillingDepthFrame(const CanFrame &frame);
    void applyEncoderAngleFrame(const CanFrame &frame);
    void applyAnalogFrame(const CanFrame &frame);
    void applyMachineAlarmFrame(const CanFrame &frame);
    void applyDropoutFrame(const CanFrame &frame);
    void rebuildActiveAlarms();

    MachineRealtimeState state_;
};

bool runCanBusModelSelfTest(QString *error = nullptr);
