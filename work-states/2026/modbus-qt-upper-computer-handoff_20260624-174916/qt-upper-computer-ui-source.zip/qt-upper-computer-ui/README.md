# 全电脑凿岩台车 Qt/C++ 上位机 UI

文档版本：V2026.06.22-A13-推进梁深度演示与基准深度显示修正版

这是 Qt/C++ 触摸屏上位机工程。当前阶段以 siton 风格界面、炮孔图/H 点交互、CAN_TO_NET Modbus TCP 封装和已确认的业务映射为主；已确认的下发项执行闭环，未映射设置页只保存本机状态。

技术栈：

- Qt 6 Widgets
- C++17
- CMake + Ninja
- 触摸屏优先布局：左侧大导航、顶部状态栏、中央施工面图、右侧三臂状态、底部 CAN_TO_NET/标定摘要

参考边界：

- 参考 `E:\AI_划时代\全电脑_算法PCB\上位机（siton）\Z16EA-1.2.5` 的界面组织方式：左侧导航、主施工面图、三臂状态、流程和日志。
- 不复用 siton 的运动学、CANopen、Redis、Electron 方案。
- 本项目后续按我们自己的 `Qt 上位机 + CAN_TO_NET + 算法PCB + 整车PCB` 架构接入。电脑端通过 Modbus TCP 503 读写 CAN_TO_NET 保持寄存器，CAN_TO_NET 再转 CAN；业务语义仍按 CAN ID、DLC、DATA 解析。

当前版本边界：

- 施工/维护页当前主动下发包括 `0x71` 钻机参数预设、`0x50 B7=0x00` 清零/标零位图，以及 P10 标定流程的 `0x50/B7=0xA1`、`0xA2`、`0xA3`。
- 协议资料里的强制操作已作废，不列入页面、缺口或待办，不做入口、不显示页面、不下发。
- 全自动、循环状态/循环控制、主机/从机角色当前不开放。
- 未完成映射的设置页只做 UI、记录和状态提示，不发送占位 CAN 帧。
- P10-3 机械误差补偿样本按左臂、中臂、右臂分别保存，每个臂 20 组，共 60 组；旧版共享样本首次读取时只迁移到左臂，避免继续三臂共用一张表。
- P01 左侧常用数据和局部放大图之间显示左臂、中臂、右臂的已进孔深度、剩余深度和推进梁实时长度条；数据来自实时钻进深度，目标深度沿用当前钻孔模式计算。
- 基准底平齐模式下，设置值只作为基准深度；若当前孔入口/H 点有效，界面显示按超欠挖和推进方向修正后的最终目标孔深，例如基准 4m 可能显示为 5.6m。
- `tools\MakeFeedDepthDemo.ps1` 只用于本地演示推进梁动作动画，不进入正式触摸屏界面；正式版仍从协议实时数据采集推进梁位移/钻进深度。

构建命令：

```powershell
& cmd.exe /d /s /c '"C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul && "E:\Qt\Tools\CMake_64\bin\cmake.exe" --build "C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\build" --config Release'
```

上线前自检命令：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\tools\Run-ReleaseAudit.ps1
```

无现场 CAN_TO_NET 模块时，先跑本机模拟数据验证：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\tools\Test-CanToNetMock.ps1
```

这条命令会在本机启动 `127.0.0.1:1503` 模拟 CAN_TO_NET，验证上位机工具链能读取 `0x150/0x152/0x176` 模拟缓存，并能写入、回读 `0x71` 下发缓存。完整审计可使用：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\tools\Run-ReleaseAudit.ps1 -SimulatedHardwareCheck
```

模拟验证只证明 Modbus TCP 打包、地址偏移、读写链路和业务缓存解析能闭环，不等同于真实现场 CAN_TO_NET 模块已经实连通过。

现场外设就绪核验命令：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\tools\Test-CanToNetFieldReady.ps1
```

这条命令只读检查本机网段、`192.168.0.105` 连通性、常见服务端口和 CAN_TO_NET 缓存寄存器，不写任何参数。现场网线、IP、端口、Unit ID 都确认后，再运行：

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\t250c\Documents\全电脑台车-CAN协议\qt-upper-computer-ui\tools\Run-ReleaseAudit.ps1 -HardwareCheck
```
## V2026.06.22 协议定版补充

- `0x150` 新增 H1 坐标索引：左臂 `0x13/0x14/0x15`，中臂 `0x23/0x24/0x25`，右臂 `0x33/0x34/0x35`。`B1-B4` 为 signed32 小端、坐标乘 100，`B5=1` 表示有效。
- 上位机画推进梁尾巴/进孔方向时，以 `dir = normalize(H - H1)` 为准；`0x152` 只保留为 XZ/YZ 线面角显示，不能单独反推完整三维方向。
- `0x176/B0=0x21` 为双屏/双操作台当前选臂状态：`B1` 左屏/左操作台，`B2` 右屏/右操作台，0 无、1 左、2 中、3 右，`B3` 为有效与控制权来源标志。
- `0x176/B0=0x22` 为三臂凿岩状态和开钻上升沿：`B1/B2/B3` 为左/中/右状态，`B4` bit0-bit2 表示正在钻进，`B5` bit0-bit2 表示开钻上升沿。
- P01 的基准底平齐逻辑在上位机完成：四个 Q 点现场标定成功时取三臂有效 H.x 中最大值作为共享工作基准面 X；每孔开钻上升沿抓当前孔入口 H.x 和推进梁方向，按 `目标深度 = (工作基准面X + 基准深度 - 当前孔入口X) / 推进方向X分量` 计算后通过现有 `0x71` 下发。推进方向优先取 `normalize(H-H1)`，其次取布孔图 start/end，再用角度兜底；算法 PCB 不做钻孔模式逻辑，只提供 H/H1/角度/深度反馈。
- `0x50/B7=0x51` 旧版屏幕应急/强制操作在本版取消，Qt 上位机不再暴露和主动下发。`0x50/B7=0xA1/A2/A3` 分别作为机械四Q点、机械误差样本/拟合完成、现场四Q点的定版标定出口。

