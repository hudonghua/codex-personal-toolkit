param(
    [string]$ListenHost = '127.0.0.1',
    [int]$Port = 1503,
    [byte]$UnitId = 255,
    [int]$AddressOffset = 1,
    [int]$MaxRequests = 100,
    [int]$IdleTimeoutMs = 30000
)

$ErrorActionPreference = 'Stop'

function To-U16Bytes {
    param([int]$Value)
    return ,([byte[]]@([byte](($Value -shr 8) -band 0xff), [byte]($Value -band 0xff)))
}

function Read-Exact {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$Count,
        [int]$TimeoutMs
    )
    $buffer = New-Object byte[] $Count
    $offset = 0
    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
    while ($offset -lt $Count) {
        if ([DateTime]::UtcNow -gt $deadline) {
            throw "Timed out while reading $Count bytes."
        }
        if (!$Stream.DataAvailable) {
            Start-Sleep -Milliseconds 10
            continue
        }
        $read = $Stream.Read($buffer, $offset, $Count - $offset)
        if ($read -le 0) {
            throw 'Socket closed while reading.'
        }
        $offset += $read
    }
    return $buffer
}

function Set-S32Le {
    param(
        [byte[]]$Bytes,
        [int]$Offset,
        [int]$Value
    )
    $raw = [uint32]$Value
    $Bytes[$Offset] = [byte]($raw -band 0xff)
    $Bytes[$Offset + 1] = [byte](($raw -shr 8) -band 0xff)
    $Bytes[$Offset + 2] = [byte](($raw -shr 16) -band 0xff)
    $Bytes[$Offset + 3] = [byte](($raw -shr 24) -band 0xff)
}

function Set-S16Le {
    param(
        [byte[]]$Bytes,
        [int]$Offset,
        [int]$Value
    )
    $raw = [uint16]($Value -band 0xffff)
    $Bytes[$Offset] = [byte]($raw -band 0xff)
    $Bytes[$Offset + 1] = [byte](($raw -shr 8) -band 0xff)
}

function Set-CanData {
    param(
        [hashtable]$Registers,
        [int]$StartAddress,
        [byte[]]$Data
    )
    for ($i = 0; $i -lt 4; ++$i) {
        $low = if (($i * 2) -lt $Data.Length) { $Data[$i * 2] } else { 0 }
        $high = if (($i * 2 + 1) -lt $Data.Length) { $Data[$i * 2 + 1] } else { 0 }
        $Registers[$StartAddress + $i] = [int](([int]$low) -bor (([int]$high) -shl 8))
    }
}

function Initialize-Registers {
    $registers = @{}

    $h1LeftX = New-Object byte[] 8
    $h1LeftX[0] = 0x13
    Set-S32Le -Bytes $h1LeftX -Offset 1 -Value 123456
    $h1LeftX[5] = 0x01
    Set-CanData -Registers $registers -StartAddress 50 -Data $h1LeftX

    $plane = New-Object byte[] 8
    $plane[0] = 0x10
    Set-S16Le -Bytes $plane -Offset 1 -Value 1234
    Set-S16Le -Bytes $plane -Offset 3 -Value -567
    Set-S16Le -Bytes $plane -Offset 5 -Value 2500
    $plane[7] = 0x01
    Set-CanData -Registers $registers -StartAddress 54 -Data $plane

    $selectedArm = New-Object byte[] 8
    $selectedArm[0] = 0x21
    $selectedArm[1] = 0x01
    $selectedArm[2] = 0x03
    $selectedArm[3] = 0x07
    Set-CanData -Registers $registers -StartAddress 74 -Data $selectedArm

    foreach ($address in 100..115) {
        if (!$registers.ContainsKey($address)) {
            $registers[$address] = 0
        }
    }

    return $registers
}

function Build-Adu {
    param(
        [byte[]]$Header,
        [byte[]]$Pdu
    )
    $transactionId = (([int]$Header[0] -shl 8) -bor [int]$Header[1])
    $response = New-Object System.Collections.Generic.List[byte]
    $response.AddRange((To-U16Bytes $transactionId))
    $response.AddRange((To-U16Bytes 0))
    $response.AddRange((To-U16Bytes (1 + $Pdu.Length)))
    $response.Add($Header[6])
    $response.AddRange($Pdu)
    return $response.ToArray()
}

$ip = [System.Net.IPAddress]::Parse($ListenHost)
$listener = [System.Net.Sockets.TcpListener]::new($ip, $Port)
$registers = Initialize-Registers
$requests = 0
$listener.Start()
Write-Host ("MOCK_SERVER=LISTENING {0}:{1}" -f $ListenHost, $Port)

try {
    $idleDeadline = [DateTime]::UtcNow.AddMilliseconds($IdleTimeoutMs)
    while ($requests -lt $MaxRequests) {
        if (!$listener.Pending()) {
            if ($IdleTimeoutMs -gt 0 -and [DateTime]::UtcNow -gt $idleDeadline) {
                break
            }
            Start-Sleep -Milliseconds 25
            continue
        }

        $client = $listener.AcceptTcpClient()
        ++$requests
        $client.ReceiveTimeout = 1000
        $client.SendTimeout = 1000
        try {
            $stream = $client.GetStream()
            $header = Read-Exact -Stream $stream -Count 7 -TimeoutMs 1000
            $length = (([int]$header[4] -shl 8) -bor [int]$header[5])
            if ($length -lt 2) {
                throw "Invalid MBAP length: $length"
            }
            $pdu = Read-Exact -Stream $stream -Count ($length - 1) -TimeoutMs 1000
            $function = $pdu[0]
            $responsePdu = New-Object System.Collections.Generic.List[byte]

            if ($header[6] -ne $UnitId) {
                $responsePdu.Add($function -bor 0x80)
                $responsePdu.Add(0x0b)
            } elseif ($function -eq 0x03) {
                $protocolAddress = (([int]$pdu[1] -shl 8) -bor [int]$pdu[2])
                $count = (([int]$pdu[3] -shl 8) -bor [int]$pdu[4])
                $startAddress = $protocolAddress + $AddressOffset
                $responsePdu.Add(0x03)
                $responsePdu.Add([byte]($count * 2))
                for ($i = 0; $i -lt $count; ++$i) {
                    $value = if ($registers.ContainsKey($startAddress + $i)) { $registers[$startAddress + $i] } else { 0 }
                    $responsePdu.AddRange((To-U16Bytes $value))
                }
            } elseif ($function -eq 0x06) {
                $protocolAddress = (([int]$pdu[1] -shl 8) -bor [int]$pdu[2])
                $startAddress = $protocolAddress + $AddressOffset
                $value = (([int]$pdu[3] -shl 8) -bor [int]$pdu[4])
                $registers[$startAddress] = $value
                $responsePdu.AddRange($pdu)
            } elseif ($function -eq 0x10) {
                $protocolAddress = (([int]$pdu[1] -shl 8) -bor [int]$pdu[2])
                $count = (([int]$pdu[3] -shl 8) -bor [int]$pdu[4])
                $startAddress = $protocolAddress + $AddressOffset
                for ($i = 0; $i -lt $count; ++$i) {
                    $offset = 6 + $i * 2
                    $registers[$startAddress + $i] = (([int]$pdu[$offset] -shl 8) -bor [int]$pdu[$offset + 1])
                }
                $responsePdu.Add(0x10)
                $responsePdu.AddRange((To-U16Bytes $protocolAddress))
                $responsePdu.AddRange((To-U16Bytes $count))
            } else {
                $responsePdu.Add($function -bor 0x80)
                $responsePdu.Add(0x01)
            }

            $adu = Build-Adu -Header $header -Pdu $responsePdu.ToArray()
            $stream.Write($adu, 0, $adu.Length)
            $stream.Flush()
            $idleDeadline = [DateTime]::UtcNow.AddMilliseconds($IdleTimeoutMs)
        } catch {
            Write-Host ("MOCK_REQUEST_IGNORED={0}" -f $_.Exception.Message)
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
    Write-Host ("MOCK_SERVER=STOPPED REQUESTS={0}" -f $requests)
}
