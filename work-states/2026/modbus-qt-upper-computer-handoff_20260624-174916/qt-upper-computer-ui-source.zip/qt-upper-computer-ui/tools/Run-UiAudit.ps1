param(
    [string]$ExePath,
    [string]$OutDir,
    [switch]$DemoData
)

$ErrorActionPreference = 'Stop'

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $repoRoot 'build\QdnUpperComputerUi.exe'
}
if ([string]::IsNullOrWhiteSpace($OutDir)) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $OutDir = Join-Path $repoRoot "build\ui-audit-$stamp"
}

$exe = (Resolve-Path $ExePath).Path
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function New-Case {
    param(
        [string]$Name,
        [object[]]$CaseArgs = @()
    )
    [pscustomobject]@{
        Name = $Name
        CaseArgs = @($CaseArgs)
    }
}

function U {
    param([string]$Text)
    [regex]::Replace($Text, '\\u([0-9a-fA-F]{4})', {
        param($Match)
        [string][char][Convert]::ToInt32($Match.Groups[1].Value, 16)
    })
}

$cases = @(
    New-Case 'P01-01-main' @('--screenshot-demo-can')
    New-Case 'P01-02-main-hpoint-click' @('--screenshot-demo-can', '--screenshot-click', '760', '548')
    New-Case 'P01-03-main-left-common' @('--screenshot-demo-can', '--screenshot-left-tab', '0')
    New-Case 'P01-04-main-left-drill-param' @('--screenshot-demo-can', '--screenshot-left-tab', '1')
    New-Case 'P01-05-main-left-drill-mode' @('--screenshot-demo-can', '--screenshot-left-tab', '2')
    New-Case 'P01-06-main-view-top' @('--screenshot-demo-can', '--screenshot-view-tab', '1')
    New-Case 'P01-07-main-view-left' @('--screenshot-demo-can', '--screenshot-view-tab', '2')
    New-Case 'P01-08-main-view-3d' @('--screenshot-demo-can', '--screenshot-view-tab', '3')

    New-Case 'P02-01-data-fault' @('--screenshot-index', '1', '--screenshot-button', (U '\u94bb\u81c2\u6545\u969c'))
    New-Case 'P02-02-data-truck' @('--screenshot-index', '1', '--screenshot-button', (U '\u53f0\u8f66\u72b6\u6001'))
    New-Case 'P02-03-data-sensor' @('--screenshot-index', '1', '--screenshot-button', (U '\u4f20\u611f\u5668\u6570\u636e'))
    New-Case 'P02-04-data-drill-param' @('--screenshot-index', '1', '--screenshot-button', (U '\u94bb\u673a\u53c2\u6570'))
    New-Case 'P02-05-data-handle' @('--screenshot-index', '1', '--screenshot-button', (U '\u624b\u67c4\u76d1\u6d4b'))

    New-Case 'P03-01-settings-entry' @('--screenshot-index', '2')

    New-Case 'P04-01-alarm-all' @('--screenshot-index', '3', '--screenshot-button', (U '\u5168\u90e8\u62a5\u8b66'))
    New-Case 'P04-02-alarm-active' @('--screenshot-index', '3', '--screenshot-button', (U '\u672a\u6062\u590d\u62a5\u8b66'))
    New-Case 'P04-03-alarm-recovered' @('--screenshot-index', '3', '--screenshot-button', (U '\u5df2\u6062\u590d\u62a5\u8b66'))
    New-Case 'P04-04-alarm-tilt-collision' @('--screenshot-index', '3', '--screenshot-button', (U '\u503e\u659c\u548c\u78b0\u649e\u62a5\u8b66'))
    New-Case 'P04-05-alarm-history' @('--screenshot-index', '3', '--screenshot-button', (U '\u5386\u53f2\u62a5\u8b66'))

    New-Case 'P05-01-log-operation' @('--screenshot-index', '4', '--screenshot-button', (U '\u64cd\u4f5c\u65e5\u5fd7'))
    New-Case 'P05-02-log-sensor' @('--screenshot-index', '4', '--screenshot-button', (U '\u4f20\u611f\u5668\u76d1\u63a7\u65e5\u5fd7'))

    New-Case 'P06-01-zero-left' @('--screenshot-index', '5', '--screenshot-button', (U '\u5de6\u81c2\u6e05\u96f6'))
    New-Case 'P06-02-zero-middle' @('--screenshot-index', '5', '--screenshot-button', (U '\u4e2d\u81c2\u6e05\u96f6'))
    New-Case 'P06-03-zero-right' @('--screenshot-index', '5', '--screenshot-button', (U '\u53f3\u81c2\u6e05\u96f6'))
    New-Case 'P06-04-zero-basket' @('--screenshot-index', '5', '--screenshot-button', (U '\u540a\u7bee\u81c2\u6e05\u96f6'))

    New-Case 'P07-01-settings-file' @('--screenshot-index', '6', '--screenshot-button', (U '\u6587\u4ef6\u5b58\u50a8\u8bbe\u7f6e'))
    New-Case 'P07-02-settings-alarm-threshold' @('--screenshot-index', '6', '--screenshot-button', (U '\u62a5\u8b66\u9608\u503c\u8bbe\u7f6e'))
    New-Case 'P07-03-settings-graphic' @('--screenshot-index', '6', '--screenshot-button', (U '\u56fe\u5f62\u663e\u793a\u8bbe\u7f6e'))
    New-Case 'P07-04-settings-communication' @('--screenshot-index', '6', '--screenshot-button', (U '\u901a\u4fe1\u8bbe\u7f6e'))
    New-Case 'P07-05-settings-maintenance' @('--screenshot-index', '6', '--screenshot-button', (U '\u7ef4\u62a4\u8bbe\u7f6e'))
    New-Case 'P07-06-settings-current' @('--screenshot-index', '6', '--screenshot-button', (U '\u81c2\u67b6\u7535\u6d41\u6807\u5b9a'))

    New-Case 'P08-01-drill-preset' @('--screenshot-index', '7')
    New-Case 'P09-01-rock-protection' @('--screenshot-index', '8')

    New-Case 'P10-01-calibration-machine' @('--screenshot-index', '9', '--screenshot-button', (U '\u673a\u68b0\u4f4d\u7f6e'))
    New-Case 'P10-02-calibration-pose' @('--screenshot-index', '9', '--screenshot-button', (U '\u73b0\u573a\u4f4d\u59ff'))
    New-Case 'P10-03-calibration-error' @('--screenshot-index', '9', '--screenshot-button', (U '\u673a\u68b0\u8bef\u5dee\u8865\u507f'))
    New-Case 'P10-04-calibration-check' @('--screenshot-index', '9', '--screenshot-button', (U '\u6807\u5b9a\u68c0\u67e5'))
)

if ($DemoData) {
    $cases = $cases | ForEach-Object {
        if ($_.CaseArgs -notcontains '--screenshot-demo-can') {
            [pscustomobject]@{ Name = $_.Name; CaseArgs = @('--screenshot-demo-can') + $_.CaseArgs }
        } else {
            $_
        }
    }
}

$results = New-Object System.Collections.Generic.List[object]

foreach ($case in $cases) {
    $png = Join-Path $OutDir ($case.Name + '.png')
    $txt = Join-Path $OutDir ($case.Name + '.txt')
    $args = @('--screenshot', $png, '--screenshot-text', $txt) + @($case.CaseArgs)
    Write-Host ("[UI] {0}" -f $case.Name)
    & $exe @args
    if ($LASTEXITCODE -ne 0) {
        throw "Screenshot failed: $($case.Name)"
    }
    $results.Add([pscustomobject]@{
        Name = $case.Name
        Image = Split-Path $png -Leaf
        Text = Split-Path $txt -Leaf
        Args = ($case.CaseArgs -join ' ')
    })
}

$forbiddenPatterns = @(
    [pscustomobject]@{ Name = 'CAN_TO_NET'; Pattern = 'CAN_TO_NET' },
    [pscustomobject]@{ Name = 'CAN-NET'; Pattern = 'CAN-NET' },
    [pscustomobject]@{ Name = 'CAN'; Pattern = '\bCAN\b' },
    [pscustomobject]@{ Name = 'protocol word'; Pattern = (U '\u534f\u8bae') },
    [pscustomobject]@{ Name = 'hex code'; Pattern = '0[xX][0-9A-Fa-f]+' }
)

$hits = New-Object System.Collections.Generic.List[object]
foreach ($txt in Get-ChildItem -Path $OutDir -Filter '*.txt') {
    $lines = Get-Content -Path $txt.FullName -Encoding UTF8
    for ($i = 0; $i -lt $lines.Count; ++$i) {
        foreach ($rule in $forbiddenPatterns) {
            if ($lines[$i] -match $rule.Pattern) {
                $hits.Add([pscustomobject]@{
                    File = $txt.Name
                    Line = $i + 1
                    Rule = $rule.Name
                    Text = $lines[$i]
                })
            }
        }
    }
}

function HtmlEncode([string]$text) {
    [System.Net.WebUtility]::HtmlEncode($text)
}

$reportPath = Join-Path $OutDir 'audit-report.md'
$indexPath = Join-Path $OutDir 'index.html'
$hitStatus = if ($hits.Count -eq 0) { 'PASS' } else { 'FAIL' }

$report = New-Object System.Collections.Generic.List[string]
$report.Add('# UI Audit Report')
$report.Add('')
$report.Add(("Generated: {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
$report.Add(("Executable: {0}" -f $exe))
$report.Add(("Output: {0}" -f (Resolve-Path $OutDir).Path))
$report.Add(("Cases: {0}" -f $results.Count))
$report.Add(("Worker-visible forbidden text scan: **{0}**" -f $hitStatus))
$report.Add('')
$report.Add('## Cases')
foreach ($item in $results) {
    $report.Add(("- {0}: [{1}]({1}), [{2}]({2})" -f $item.Name, $item.Image, $item.Text))
}
$report.Add('')
$report.Add('## Forbidden Text Hits')
if ($hits.Count -eq 0) {
    $report.Add('None.')
} else {
    foreach ($hit in $hits) {
        $report.Add(("- {0}:{1} {2} {3}" -f $hit.File, $hit.Line, $hit.Rule, $hit.Text))
    }
}
Set-Content -Path $reportPath -Encoding UTF8 -Value $report

$html = New-Object System.Collections.Generic.List[string]
$html.Add('<!doctype html><html><head><meta charset="utf-8">')
$html.Add('<title>UI Audit</title>')
$html.Add('<style>body{font-family:Microsoft YaHei UI,Arial,sans-serif;background:#1b1b1b;color:#eee;margin:20px} .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:16px}.card{background:#2d2d2d;border:1px solid #555;padding:10px}.card img{width:100%;border:1px solid #777}.meta{font-size:13px;color:#bbb;word-break:break-all}.pass{color:#49e07b}.fail{color:#ff6666}</style>')
$html.Add('</head><body>')
$html.Add(('<h1>UI Audit <span class="{0}">{1}</span></h1>' -f ($(if ($hitStatus -eq 'PASS') { 'pass' } else { 'fail' }), $hitStatus)))
$html.Add(('<p>Generated: {0}</p>' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
if ($hits.Count -gt 0) {
    $html.Add('<h2>Forbidden Text Hits</h2><ul>')
    foreach ($hit in $hits) {
        $html.Add(('<li><b>{0}:{1}</b> {2}: {3}</li>' -f (HtmlEncode $hit.File), $hit.Line, (HtmlEncode $hit.Rule), (HtmlEncode $hit.Text)))
    }
    $html.Add('</ul>')
}
$html.Add('<div class="grid">')
foreach ($item in $results) {
    $html.Add('<div class="card">')
    $html.Add(('<h2>{0}</h2>' -f (HtmlEncode $item.Name)))
    $html.Add(('<a href="{0}"><img src="{0}" alt="{1}"></a>' -f (HtmlEncode $item.Image), (HtmlEncode $item.Name)))
    $html.Add(('<p class="meta"><a href="{0}">visible text</a><br>{1}</p>' -f (HtmlEncode $item.Text), (HtmlEncode $item.Args)))
    $html.Add('</div>')
}
$html.Add('</div></body></html>')
Set-Content -Path $indexPath -Encoding UTF8 -Value $html

Write-Host ("Output: {0}" -f (Resolve-Path $OutDir).Path)
Write-Host ("Report: {0}" -f $reportPath)
Write-Host ("Index:  {0}" -f $indexPath)
Write-Host ("Forbidden text scan: {0}" -f $hitStatus)
if ($hits.Count -gt 0) {
    $hits | Format-Table File,Line,Rule,Text -AutoSize
    exit 3
}
