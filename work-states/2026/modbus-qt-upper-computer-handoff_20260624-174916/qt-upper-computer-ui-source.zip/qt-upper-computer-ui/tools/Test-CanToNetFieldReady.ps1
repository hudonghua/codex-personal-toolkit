param(
    [string]$TargetHost = '192.168.0.105',
    [int]$Port = 503,
    [byte]$UnitId = 255,
    [int]$AddressOffset = 1,
    [int]$TimeoutMs = 1000,
    [int]$CanToNetAddress = 50,
    [int]$RegisterCount = 4
)

$ErrorActionPreference = 'Stop'

function Test-TcpPort {
    param(
        [string]$HostName,
        [int]$PortNumber,
        [int]$ConnectTimeoutMs
    )
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $task = $client.ConnectAsync($HostName, $PortNumber)
        if (!$task.Wait($ConnectTimeoutMs)) {
            return $false
        }
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Get-LocalIpv4Info {
    $items = @()
    try {
        $items = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object {
                $_.IPAddress -ne '127.0.0.1' -and
                $_.IPAddress -notlike '169.254.*' -and
                $_.PrefixOrigin -ne 'WellKnown'
            } |
            Select-Object IPAddress, PrefixLength, InterfaceAlias
    } catch {
        $items = @()
    }
    return @($items)
}

function Get-Ipv4Prefix24 {
    param([string]$Ip)
    $parts = $Ip.Split('.')
    if ($parts.Count -lt 4) {
        return ''
    }
    return ($parts[0..2] -join '.')
}

$localIps = @(Get-LocalIpv4Info)
$targetPrefix = Get-Ipv4Prefix24 -Ip $TargetHost
$sameSubnet = $false
foreach ($ip in $localIps) {
    if ((Get-Ipv4Prefix24 -Ip $ip.IPAddress) -eq $targetPrefix) {
        $sameSubnet = $true
    }
}

$localText = if ($localIps.Count -gt 0) {
    (($localIps | ForEach-Object {
        '{0}/{1}({2})' -f $_.IPAddress, $_.PrefixLength, $_.InterfaceAlias
    }) -join ';')
} else {
    'NONE'
}

Write-Host ("TARGET={0}" -f $TargetHost)
Write-Host ("UNIT_ID={0}" -f $UnitId)
Write-Host ("LOCAL_IPV4={0}" -f $localText)
Write-Host ("SAME_24_SUBNET={0}" -f $sameSubnet)

$pingOk = Test-Connection -ComputerName $TargetHost -Count 1 -Quiet -ErrorAction SilentlyContinue
Write-Host ("PING={0}" -f $pingOk)

$tcp500 = Test-TcpPort -HostName $TargetHost -PortNumber 500 -ConnectTimeoutMs $TimeoutMs
$tcp502 = Test-TcpPort -HostName $TargetHost -PortNumber 502 -ConnectTimeoutMs $TimeoutMs
$tcp503 = Test-TcpPort -HostName $TargetHost -PortNumber 503 -ConnectTimeoutMs $TimeoutMs
$tcpTarget = if ($Port -eq 500) { $tcp500 } elseif ($Port -eq 502) { $tcp502 } elseif ($Port -eq 503) { $tcp503 } else {
    Test-TcpPort -HostName $TargetHost -PortNumber $Port -ConnectTimeoutMs $TimeoutMs
}

Write-Host ("TCP_500={0}" -f $tcp500)
Write-Host ("TCP_502={0}" -f $tcp502)
Write-Host ("TCP_503={0}" -f $tcp503)
if ($Port -notin @(500, 502, 503)) {
    Write-Host ("TCP_TARGET_{0}={1}" -f $Port, $tcpTarget)
}

$modbusScript = Join-Path $PSScriptRoot 'Test-CanToNetModbus.ps1'
$modbusOutput = & powershell -NoProfile -ExecutionPolicy Bypass -File $modbusScript `
    -TargetHost $TargetHost `
    -Port $Port `
    -UnitId $UnitId `
    -AddressOffset $AddressOffset `
    -TimeoutMs $TimeoutMs `
    -CanToNetAddress $CanToNetAddress `
    -RegisterCount $RegisterCount 2>&1
$modbusExit = $LASTEXITCODE
$modbusOutput | ForEach-Object { Write-Host $_ }

if ($modbusExit -eq 0) {
    Write-Host 'READY=PASS'
    Write-Host 'SUGGESTION=Field link is ready for read-only CAN_TO_NET polling.'
    exit 0
}

Write-Host 'READY=FAIL'
if (!$sameSubnet) {
    Write-Host ("SUGGESTION=Put the PC wired adapter in {0}.x subnet or confirm the module IP." -f $targetPrefix)
} elseif (!$pingOk) {
    Write-Host 'SUGGESTION=Check power, cable, target IP, and PC adapter route.'
} elseif (!$tcpTarget) {
    Write-Host ("SUGGESTION=Target pings but TCP port {0} is closed or blocked; check CAN_TO_NET service port." -f $Port)
} else {
    Write-Host 'SUGGESTION=TCP is open but Modbus read failed; check Unit ID, address offset, and register map.'
}
exit 3
