﻿param(
    [string]$TargetHost = '192.168.0.105',
    [int]$Port = 503,
    [byte]$UnitId = 255,
    [int]$AddressOffset = 1,
    [int]$TimeoutMs = 1000,
    [int]$CanToNetAddress = 50,
    [int]$RegisterCount = 4
)

$ErrorActionPreference = 'Stop'

function To-BigEndianU16 {
    param([int]$Value)
    return ,([byte[]]@([byte](($Value -shr 8) -band 0xff), [byte]($Value -band 0xff)))
}

function Read-Exact {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$Count,
        [int]$TimeoutMs
    )
    $buffer = New-Object byte[] $Count
    $offset = 0
    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
    while ($offset -lt $Count) {
        if ([DateTime]::UtcNow -gt $deadline) {
            throw "Timed out while reading $Count bytes."
        }
        if (!$Stream.DataAvailable) {
            Start-Sleep -Milliseconds 10
            continue
        }
        $read = $Stream.Read($buffer, $offset, $Count - $offset)
        if ($read -le 0) {
            throw 'Socket closed while reading.'
        }
        $offset += $read
    }
    return $buffer
}

function Invoke-ModbusReadHoldingRegisters {
    param(
        [string]$TargetHost,
        [int]$Port,
        [byte]$UnitId,
        [int]$ProtocolAddress,
        [int]$RegisterCount,
        [int]$TimeoutMs
    )

    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $connectTask = $client.ConnectAsync($TargetHost, $Port)
        if (!$connectTask.Wait($TimeoutMs)) {
            throw "TCP connect timeout: $TargetHost`:$Port"
        }
        if (!$client.Connected) {
            throw "TCP connect failed: $TargetHost`:$Port"
        }
        $client.ReceiveTimeout = $TimeoutMs
        $client.SendTimeout = $TimeoutMs
        $stream = $client.GetStream()

        $transactionId = 1
        $pdu = New-Object System.Collections.Generic.List[byte]
        $pdu.Add(0x03)
        $pdu.AddRange((To-BigEndianU16 $ProtocolAddress))
        $pdu.AddRange((To-BigEndianU16 $RegisterCount))

        $adu = New-Object System.Collections.Generic.List[byte]
        $adu.AddRange((To-BigEndianU16 $transactionId))
        $adu.AddRange((To-BigEndianU16 0))
        $adu.AddRange((To-BigEndianU16 (1 + $pdu.Count)))
        $adu.Add($UnitId)
        $adu.AddRange($pdu)

        $bytes = $adu.ToArray()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()

        $header = Read-Exact -Stream $stream -Count 7 -TimeoutMs $TimeoutMs
        $rxTransactionId = ([int]$header[0] -shl 8) -bor [int]$header[1]
        $protocolId = ([int]$header[2] -shl 8) -bor [int]$header[3]
        $length = ([int]$header[4] -shl 8) -bor [int]$header[5]
        $rxUnitId = $header[6]
        if ($rxTransactionId -ne $transactionId -or $protocolId -ne 0 -or $rxUnitId -ne $UnitId) {
            throw "Modbus MBAP mismatch. transaction=$rxTransactionId protocol=$protocolId unit=$rxUnitId"
        }
        if ($length -lt 2) {
            throw "Invalid Modbus length: $length"
        }

        $pduResponse = Read-Exact -Stream $stream -Count ($length - 1) -TimeoutMs $TimeoutMs
        $functionCode = $pduResponse[0]
        if (($functionCode -band 0x80) -ne 0) {
            $exceptionCode = if ($pduResponse.Length -gt 1) { $pduResponse[1] } else { 0 }
            throw ("Modbus exception. function=0x{0:X2} exception=0x{1:X2}" -f $functionCode, $exceptionCode)
        }
        if ($functionCode -ne 0x03) {
            throw ("Unexpected Modbus function: 0x{0:X2}" -f $functionCode)
        }
        $byteCount = $pduResponse[1]
        if ($byteCount -ne ($RegisterCount * 2)) {
            throw "Unexpected Modbus byte count: $byteCount"
        }

        $registers = New-Object System.Collections.Generic.List[int]
        for ($i = 0; $i -lt $RegisterCount; ++$i) {
            $offset = 2 + $i * 2
            $registers.Add((([int]$pduResponse[$offset] -shl 8) -bor [int]$pduResponse[$offset + 1]))
        }
        return $registers
    } finally {
        $client.Close()
    }
}

$protocolAddress = $CanToNetAddress - $AddressOffset
Write-Host ("TARGET={0}:{1}" -f $TargetHost, $Port)
Write-Host ("UNIT_ID={0}" -f $UnitId)
Write-Host ("CAN_TO_NET_ADDRESS={0}" -f $CanToNetAddress)
Write-Host ("PROTOCOL_ADDRESS={0}" -f $protocolAddress)
Write-Host ("REGISTER_COUNT={0}" -f $RegisterCount)

$pingOk = Test-Connection -ComputerName $TargetHost -Count 1 -Quiet -ErrorAction SilentlyContinue
Write-Host ("PING={0}" -f $pingOk)

try {
    $registers = Invoke-ModbusReadHoldingRegisters `
        -TargetHost $TargetHost `
        -Port $Port `
        -UnitId $UnitId `
        -ProtocolAddress $protocolAddress `
        -RegisterCount $RegisterCount `
        -TimeoutMs $TimeoutMs
    Write-Host 'MODBUS_READ=PASS'
    Write-Host ("REGISTERS={0}" -f (($registers | ForEach-Object { '0x{0:X4}' -f $_ }) -join ' '))
    exit 0
} catch {
    Write-Host 'MODBUS_READ=FAIL'
    Write-Host ("ERROR={0}" -f $_.Exception.Message)
    exit 3
}

