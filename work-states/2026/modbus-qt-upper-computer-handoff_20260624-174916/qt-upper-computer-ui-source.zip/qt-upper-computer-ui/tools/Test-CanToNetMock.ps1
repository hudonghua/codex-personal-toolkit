param(
    [string]$TargetHost = '127.0.0.1',
    [int]$Port = 1503,
    [byte]$UnitId = 255,
    [int]$AddressOffset = 1,
    [int]$TimeoutMs = 1000
)

$ErrorActionPreference = 'Stop'

function To-U16Bytes {
    param([int]$Value)
    return ,([byte[]]@([byte](($Value -shr 8) -band 0xff), [byte]($Value -band 0xff)))
}

function Read-Exact {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$Count,
        [int]$TimeoutMs
    )
    $buffer = New-Object byte[] $Count
    $offset = 0
    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
    while ($offset -lt $Count) {
        if ([DateTime]::UtcNow -gt $deadline) {
            throw "Timed out while reading $Count bytes."
        }
        if (!$Stream.DataAvailable) {
            Start-Sleep -Milliseconds 10
            continue
        }
        $read = $Stream.Read($buffer, $offset, $Count - $offset)
        if ($read -le 0) {
            throw 'Socket closed while reading.'
        }
        $offset += $read
    }
    return $buffer
}

function Invoke-Modbus {
    param(
        [string]$HostName,
        [int]$PortNumber,
        [byte]$Unit,
        [byte[]]$Pdu,
        [int]$ConnectTimeoutMs
    )
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $connectTask = $client.ConnectAsync($HostName, $PortNumber)
        if (!$connectTask.Wait($ConnectTimeoutMs)) {
            throw "TCP connect timeout: $HostName`:$PortNumber"
        }
        $stream = $client.GetStream()
        $transactionId = 1
        $adu = New-Object System.Collections.Generic.List[byte]
        $adu.AddRange((To-U16Bytes $transactionId))
        $adu.AddRange((To-U16Bytes 0))
        $adu.AddRange((To-U16Bytes (1 + $Pdu.Length)))
        $adu.Add($Unit)
        $adu.AddRange($Pdu)
        $bytes = $adu.ToArray()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()

        $header = Read-Exact -Stream $stream -Count 7 -TimeoutMs $ConnectTimeoutMs
        $length = (([int]$header[4] -shl 8) -bor [int]$header[5])
        return Read-Exact -Stream $stream -Count ($length - 1) -TimeoutMs $ConnectTimeoutMs
    } finally {
        $client.Close()
    }
}

function Read-Registers {
    param([int]$CanToNetAddress, [int]$Count)
    $protocolAddress = $CanToNetAddress - $AddressOffset
    $pdu = New-Object System.Collections.Generic.List[byte]
    $pdu.Add(0x03)
    $pdu.AddRange((To-U16Bytes $protocolAddress))
    $pdu.AddRange((To-U16Bytes $Count))
    $response = Invoke-Modbus -HostName $TargetHost -PortNumber $Port -Unit $UnitId -Pdu $pdu.ToArray() -ConnectTimeoutMs $TimeoutMs
    if ($response[0] -ne 0x03) {
        throw ("Read failed. function=0x{0:X2}" -f $response[0])
    }
    $registers = New-Object System.Collections.Generic.List[int]
    for ($i = 0; $i -lt $Count; ++$i) {
        $offset = 2 + $i * 2
        $registers.Add((([int]$response[$offset] -shl 8) -bor [int]$response[$offset + 1]))
    }
    return $registers
}

function Write-Registers {
    param([int]$CanToNetAddress, [int[]]$Values)
    $protocolAddress = $CanToNetAddress - $AddressOffset
    $pdu = New-Object System.Collections.Generic.List[byte]
    $pdu.Add(0x10)
    $pdu.AddRange((To-U16Bytes $protocolAddress))
    $pdu.AddRange((To-U16Bytes $Values.Count))
    $pdu.Add([byte]($Values.Count * 2))
    foreach ($value in $Values) {
        $pdu.AddRange((To-U16Bytes $value))
    }
    $response = Invoke-Modbus -HostName $TargetHost -PortNumber $Port -Unit $UnitId -Pdu $pdu.ToArray() -ConnectTimeoutMs $TimeoutMs
    if ($response[0] -ne 0x10) {
        throw ("Write failed. function=0x{0:X2}" -f $response[0])
    }
}

function Format-Registers {
    param([System.Collections.Generic.List[int]]$Registers)
    ($Registers | ForEach-Object { '0x{0:X4}' -f $_ }) -join ' '
}

function Test-PortOpen {
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $task = $client.ConnectAsync($TargetHost, $Port)
        if (!$task.Wait($TimeoutMs)) {
            return $false
        }
        return $client.Connected
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

$serverScript = Join-Path $PSScriptRoot 'Start-CanToNetMockServer.ps1'
$serverJob = Start-Job -ScriptBlock {
    param($Script, $HostName, $ListenPort, $Unit, $Offset)
    & $Script -ListenHost $HostName -Port $ListenPort -UnitId $Unit -AddressOffset $Offset -MaxRequests 20 -IdleTimeoutMs 10000
} -ArgumentList $serverScript, $TargetHost, $Port, $UnitId, $AddressOffset

try {
    $open = $false
    for ($i = 0; $i -lt 50; ++$i) {
        Start-Sleep -Milliseconds 100
        if (Test-PortOpen) {
            $open = $true
            break
        }
    }
    if (!$open) {
        Receive-Job -Job $serverJob -Keep | ForEach-Object { Write-Host $_ }
        throw "Mock server did not open $TargetHost`:$Port"
    }

    Write-Host ("MOCK_TARGET={0}:{1}" -f $TargetHost, $Port)
    $fieldScript = Join-Path $PSScriptRoot 'Test-CanToNetFieldReady.ps1'
    & powershell -NoProfile -ExecutionPolicy Bypass -File $fieldScript `
        -TargetHost $TargetHost `
        -Port $Port `
        -UnitId $UnitId `
        -AddressOffset $AddressOffset `
        -TimeoutMs $TimeoutMs `
        -CanToNetAddress 50 `
        -RegisterCount 4
    if ($LASTEXITCODE -ne 0) {
        throw "Field-ready check failed against mock server."
    }

    $h1 = Read-Registers -CanToNetAddress 50 -Count 4
    $plane = Read-Registers -CanToNetAddress 54 -Count 4
    $selected = Read-Registers -CanToNetAddress 74 -Count 4
    Write-Host ("MOCK_READ_0x150={0}" -f (Format-Registers $h1))
    Write-Host ("MOCK_READ_0x152={0}" -f (Format-Registers $plane))
    Write-Host ("MOCK_READ_0x176={0}" -f (Format-Registers $selected))

    $writeValues = @(0x0010, 0x1234, 0x5678, 0xA100)
    Write-Registers -CanToNetAddress 104 -Values $writeValues
    $readBack = Read-Registers -CanToNetAddress 104 -Count 4
    Write-Host ("MOCK_WRITE_0x71={0}" -f (Format-Registers $readBack))
    for ($i = 0; $i -lt $writeValues.Count; ++$i) {
        if ($readBack[$i] -ne $writeValues[$i]) {
            throw 'Mock write/readback mismatch.'
        }
    }

    Write-Host 'MOCK_READ_WRITE=PASS'
    exit 0
} catch {
    Write-Host 'MOCK_READ_WRITE=FAIL'
    Write-Host ("ERROR={0}" -f $_.Exception.Message)
    exit 3
} finally {
    Stop-Job -Job $serverJob -ErrorAction SilentlyContinue | Out-Null
    Receive-Job -Job $serverJob -ErrorAction SilentlyContinue | ForEach-Object { Write-Host $_ }
    Remove-Job -Job $serverJob -Force -ErrorAction SilentlyContinue | Out-Null
}
