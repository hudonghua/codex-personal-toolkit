# CAN1 三臂传感器 ID 分配表

**文档版本**：V2026.06.22-协议定版-A1A2A3-H1选臂开钻版  
**工程**：MC_LCD - 7Control_V1.2（200A 屏）  
**总线**：CAN1（35 芯 5/17 脚）  
**源码依据**：`Src/CanOpen.c::Can1_RcvID_Cfg`、`Src/App_usr.c::Arm200A_CAN1_Sensor_Binding`  
**更新日期**：2026-06-22  

---

## 1. 定版结论

- 当前源码实际注册并读取 27 个 CAN1 输入 ID：三臂 26 个传感器 ID + `0x28F` 双轴倾角仪。
- 三臂传感器使用紧凑 ID 段，不再按旧文档的 `0x280/0x380` 大段分配：左臂 `0x181~0x189`，中臂 `0x192~0x199`，右臂 `0x1A1~0x1A9`。
- `0x189/0x199/0x1A9` 已在源码中作为三臂推进梁钻进深度读取，不再写“第二路油缸位移待定”。
- 传感器原始帧本版按源码定为 D0-D1 低字节在前的 `uint16 raw`；D2-D7 暂不参与算法计算。

---

## 2. ID 编码规则

| 臂 | ID 段 | 源码读取函数 | 节点数 |
|----|-------|--------------|--------|
| 左臂 | `0x181~0x189` | `Arm200A_ReadCan1Sensor` / `Arm200A_ReadCan1HoleDepth` | 9 |
| 中臂 | `0x192~0x199` | `Arm200A_ReadCan1Sensor` / `Arm200A_ReadCan1HoleDepth` | 8 |
| 右臂 | `0x1A1~0x1A9` | `Arm200A_ReadCan1Sensor` / `Arm200A_ReadCan1HoleDepth` | 9 |
| 倾角仪 | `0x28F` | `Arm200A_ReadCan1Biaxial` | 1 |

说明：中臂没有 root，自身 root 固定为 0，所以中臂从 `0x192` 开始读取 base。

---

## 3. 左臂（0x181~0x189）

| CAN ID | 传感器类型 | 正解字段 | `gArmLeftRaw` / 变量 | 单位/备注 |
|--------|------------|----------|----------------------|-----------|
| `0x181` | 编码器 | 根部旋转 | `root_raw` | 16bit 单圈角 raw |
| `0x182` | 编码器 | 基座回转 | `base_raw` | 16bit 单圈角 raw |
| `0x183` | 编码器 | 大臂摆动 | `boom_raw` | 16bit 单圈角 raw |
| `0x184` | 编码器 | D1 级转 | `d1_raw` | 16bit 单圈角 raw |
| `0x185` | 编码器 | E1 级转 | `e1_raw` | 16bit 单圈角 raw |
| `0x186` | 编码器 | F 级转 | `f_raw` | 16bit 单圈角 raw |
| `0x187` | 拉绳位移 | C-D 伸缩 | `cd_raw` | raw 换算为 mm |
| `0x188` | 油缸位移 | G-G1 伸缩 | `gg1_raw` | raw 换算为 mm |
| `0x189` | 推进梁深度 | 当前钻进深度 | `gArmLeftHoleDepthRaw`、`gArmLeftHoleDepthMm` | raw 换算为 mm，后续通过 `0x153` 发给上位机 |

---

## 4. 中臂（0x192~0x199）

| CAN ID | 传感器类型 | 正解字段 | `gArmMidRaw` / 变量 | 单位/备注 |
|--------|------------|----------|---------------------|-----------|
| `0x192` | 编码器 | 基座回转 | `base_raw` | 中臂无 root，root 固定为 0 |
| `0x193` | 编码器 | 大臂摆动 | `boom_raw` | 16bit 单圈角 raw |
| `0x194` | 编码器 | D1 级转 | `d1_raw` | 16bit 单圈角 raw |
| `0x195` | 编码器 | E1 级转 | `e1_raw` | 16bit 单圈角 raw |
| `0x196` | 编码器 | F 级转 | `f_raw` | 16bit 单圈角 raw |
| `0x197` | 拉绳位移 | C-D 伸缩 | `cd_raw` | raw 换算为 mm |
| `0x198` | 油缸位移 | G-G1 伸缩 | `gg1_raw` | raw 换算为 mm |
| `0x199` | 推进梁深度 | 当前钻进深度 | `gArmMidHoleDepthRaw`、`gArmMidHoleDepthMm` | raw 换算为 mm，后续通过 `0x153` 发给上位机 |

---

## 5. 右臂（0x1A1~0x1A9）

| CAN ID | 传感器类型 | 正解字段 | `gArmRightRaw` / 变量 | 单位/备注 |
|--------|------------|----------|-----------------------|-----------|
| `0x1A1` | 编码器 | 根部旋转 | `root_raw` | 16bit 单圈角 raw |
| `0x1A2` | 编码器 | 基座回转 | `base_raw` | 16bit 单圈角 raw |
| `0x1A3` | 编码器 | 大臂摆动 | `boom_raw` | 16bit 单圈角 raw |
| `0x1A4` | 编码器 | D1 级转 | `d1_raw` | 16bit 单圈角 raw |
| `0x1A5` | 编码器 | E1 级转 | `e1_raw` | 16bit 单圈角 raw |
| `0x1A6` | 编码器 | F 级转 | `f_raw` | 16bit 单圈角 raw |
| `0x1A7` | 拉绳位移 | C-D 伸缩 | `cd_raw` | raw 换算为 mm |
| `0x1A8` | 油缸位移 | G-G1 伸缩 | `gg1_raw` | raw 换算为 mm |
| `0x1A9` | 推进梁深度 | 当前钻进深度 | `gArmRightHoleDepthRaw`、`gArmRightHoleDepthMm` | raw 换算为 mm，后续通过 `0x153` 发给上位机 |

---

## 6. 双轴倾角仪（0x28F）

| CAN ID | 字节 | 含义 | 算法变量 |
|--------|------|------|----------|
| `0x28F` | D0-D1 | 车体 roll raw，低字节在前 | `body_roll_raw` |
| `0x28F` | D2-D3 | 车体 pitch raw，低字节在前 | `body_pitch_raw` |

`Arm200A_ReadCan1Biaxial()` 将该倾角值同步给左、中、右三臂的车体姿态输入。

---

## 7. 帧格式

### 编码器 / 拉绳 / 油缸 / 深度帧

| 字节 | 含义 |
|------|------|
| D0-D1 | `uint16 raw`，低字节在前 |
| D2-D7 | 本版不参与算法计算，可作为设备状态/计数扩展保留 |

源码换算路径：

- 编码器：`Arm200A_Raw16ToDeg(raw) * ratio`
- C-D 拉绳：`Arm200A_Raw16ToCdMm(raw)`
- G-G1 油缸：`Arm200A_Raw16ToGg1Mm(raw)`
- 推进梁深度：`Arm200A_ReadCan1HoleDepth()` 保存 raw 和 mm，发送 `0x153` 时使用 `Arm200A_HoleDepthSendValue()` 处理零点差值。

### 倾角仪帧

| 字节 | 含义 |
|------|------|
| D0-D1 | roll raw，低字节在前 |
| D2-D3 | pitch raw，低字节在前 |
| D4-D7 | 本版未用 |

---

## 8. 源码注册清单

`CanOpen.c::Can1_RcvID_Cfg()` 当前注册：

```c
0x181, 0x182, 0x183, 0x184, 0x185, 0x186, 0x187, 0x188, 0x189,
0x192, 0x193, 0x194, 0x195, 0x196, 0x197, 0x198, 0x199,
0x1A1, 0x1A2, 0x1A3, 0x1A4, 0x1A5, 0x1A6, 0x1A7, 0x1A8, 0x1A9,
0x28F
```