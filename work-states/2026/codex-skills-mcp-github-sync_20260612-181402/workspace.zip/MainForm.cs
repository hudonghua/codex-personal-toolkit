﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CanVariableMonitor;

public sealed class MainForm : Form
{
	private const string UpperComputerVersion = "V1.20";

	private const string AppDisplayName = "上位机监控";

	private readonly record struct ReadSegmentResult(bool Success, int Len, byte Status, ushort Value);

	private readonly record struct WriteSegmentResult(bool Success, int Len, byte Status, byte Command);

	private readonly record struct RuntimeControlResult(bool Success, byte Status, byte Mode);

	private sealed record CodeLineRender(int LineNumber, string Code, List<string> Values, bool IsTrueCondition);

	private enum ConditionEval
	{
		Unknown,
		False,
		True
	}

	private sealed record ThemePalette(string Name, Color Bg, Color Header, Color Panel, Color Surface, Color SurfaceAlt, Color GridHeader, Color Ink, Color Muted, Color Accent, Color Button, Color StatusOff);

	private sealed record FunctionSourceView(string FunctionName, string FilePath, int StartLine, IReadOnlyList<string> Lines, int StartIndex, int Length);

	private sealed record FunctionIndexEntry(string Name, string FilePath);

	private sealed record ProgramSearchResult(string Display, string FilePath, int LineNumber, string? FunctionName)
	{
		public override string ToString() => Display;
	}

	private sealed record ProgramInsightAction(string Kind, string Value);

	private readonly record struct PendingWatchUpdate(WatchItem Item, int Len, byte Status, uint Value, bool Timeout, bool Error);

	private sealed class Suggestion
	{
		public MapSymbol Symbol { get; }

		public Suggestion(MapSymbol symbol)
		{
			Symbol = symbol;
		}

		public override string ToString()
		{
			return Symbol.Name;
		}
	}

	private Color _bg = Color.FromArgb(9, 12, 18);

	private Color _header = Color.FromArgb(2, 6, 23);

	private Color _panel = Color.FromArgb(17, 24, 39);

	private Color _surface = Color.FromArgb(15, 23, 42);

	private Color _surfaceAlt = Color.FromArgb(20, 30, 48);

	private Color _gridHeader = Color.FromArgb(30, 41, 59);

	private Color _ink = Color.FromArgb(229, 231, 235);

	private Color _muted = Color.FromArgb(148, 163, 184);

	private Color _accent = Color.FromArgb(14, 165, 233);

	private Color _button = Color.FromArgb(30, 41, 59);

	private Color _statusOff = Color.FromArgb(75, 85, 99);

	private string _themeName = "工业黑金";

	private readonly BindingList<WatchItem> _watchItems = new BindingList<WatchItem>();

	private readonly BindingSource _source = new BindingSource();

	private readonly System.Windows.Forms.Timer _mapReloadTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _codeRefreshTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _valueRefreshTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _suggestionTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _programGraphDebounceTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _visibleDataRefreshTimer = new System.Windows.Forms.Timer();

	private readonly System.Windows.Forms.Timer _programInsightRefreshTimer = new System.Windows.Forms.Timer();

	private readonly string _defaultProfilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CanVariableMonitor", "monitor_profile.json");

	private readonly string _connectionStatePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CanVariableMonitor", "connection_status.txt");

	private readonly string _diagnosticLogPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CanVariableMonitor", "diagnostic.log");

	private readonly object _diagnosticLogLock = new object();

	private DateTime _lastLogTrimUtc = DateTime.MinValue;

	private DateTime _lastWatchContextMenuShownUtc = DateTime.MinValue;

	private Control? _lastWatchContextMenuOwner;

	private TextBox _mapPathBox;

	private TextBox _variableBox;

	private ListBox _suggestions;

	private DataGridView _grid;

	private TextBox _logBox;

	private Button _connectButton;

	private Button? _simulationButton;

	private Button _startButton;

	private Button _valueFormatButton;

	private TextBox _forceValueBox;

	private Button _writeValueButton;

	private Button _holdValueButton;

	private Button _releaseForceButton;

	private Button _runtimeRunButton;

	private Button _runtimePauseButton;

	private Button _runtimeStepButton;

	private Button _downloadButton;

	private NumericUpDown _intervalBox;

	private Label _statusLabel;

	private Label _firmwareVersionLabel;

	private Label _appVersionLabel;

	private Button _refreshButton;

	private ComboBox _themeBox;

	private Label _symbolCountLabel;

	private ListView _programInsightList;

	private Label _cycleEstimateLabel;

	private Label _programSummaryLabel;

	private Label _runtimeLocationLabel;

	private TextBox _programSearchBox;

	private ListBox _programSearchResults;

	private FlowChartView _flowChart;

	private Panel _programViewPanel;

	private Panel _programContentPanel;

	private RowStyle _programSearchResultsRow;

	private Panel _functionCodePanel;

	private RichTextBox _functionCodeBox;

	private Label _functionCodeTitle;

	private Button _functionBackButton;

	private RichTextBox _dataCodeBox;

	private Label _dataCodeTitle;

	private Label _visibleValuesLabel;

	private FunctionSourceView? _currentFunctionSource;

	private readonly Stack<FunctionSourceView> _functionHistory = new Stack<FunctionSourceView>();

	private readonly object _pendingWatchLock = new object();

	private readonly Dictionary<WatchItem, PendingWatchUpdate> _pendingWatchUpdates = new Dictionary<WatchItem, PendingWatchUpdate>();

	private Dictionary<string, FunctionIndexEntry> _functionIndex = new Dictionary<string, FunctionIndexEntry>(StringComparer.OrdinalIgnoreCase);

	private string _functionIndexRoot = "";

	private int _lastFunctionHoverCharIndex = -1;

	private string _lastFunctionHoverIdentifier = "";

	private bool _lastFunctionHoverNavigable;

	private string _lastFunctionCodeText = "";

	private string _lastDataCodeText = "";

	private string _lastVisibleValuesText = "";

	private string _lastVisibleConditionSignature = "";

	private string _lastVisibleRangeSignature = "";

	private DateTime _lastDataInlineRenderUtc;

	private bool _resetFunctionScrollOnNextRender;

	private string _activeProgramSearchKeyword = "";

	private int _activeProgramSearchLine;

	private string _focusedVariableName = "";

	private DateTime _lastFunctionWheelUtc;

	private DateTime _lastUiWheelUtc;

	private int _lastScopeHighlightSelectionStart = -1;

	private float _functionCodeFontSize = 10.5f;

	private HashSet<string> _currentFunctionIdentifiers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private SplitContainer _mainSplit;

	private SplitContainer _rightSplit;

	private List<MapSymbol> _symbols = new List<MapSymbol>();

	private Dictionary<string, MapSymbol> _symbolLookup = new Dictionary<string, MapSymbol>(StringComparer.OrdinalIgnoreCase);

	private Dictionary<string, MapSymbol> _symbolBaseLookup = new Dictionary<string, MapSymbol>(StringComparer.OrdinalIgnoreCase);

	private Dictionary<string, MapSymbol> _symbolTailLookup = new Dictionary<string, MapSymbol>(StringComparer.OrdinalIgnoreCase);

	private string _workDirectory = "";

	private string _mapFilePath = "";

	private DateTime _mapLastWrite;

	private ICanAdapter? _adapter;

	private string _preferredAdapterName = "";

	private bool _offlineSimulation;

	private readonly object _simulationLock = new object();

	private readonly Dictionary<string, uint> _simulatedValues = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, OfflineCDriver> _offlineCDrivers = new Dictionary<string, OfflineCDriver>(StringComparer.OrdinalIgnoreCase);

	private List<FunctionSourceView> _offlineApplicationSources = new List<FunctionSourceView>();

	private string _offlineApplicationSourceDirectory = "";

	private DateTime _lastOfflineApplicationWatchLogUtc = DateTime.MinValue;

	private DateTime _lastOfflineSimulationTickUtc = DateTime.MinValue;

	private CancellationTokenSource? _pollCts;

	private Task? _pollTask;

	private CancellationTokenSource? _downloadCts;

	private Task? _downloadTask;

	private byte _seq;

	private bool _running;

	private bool _profileLoaded;

	private bool _loadingProfile;

	private bool _monitorSessionOpen;

	private int _dragRowIndex = -1;

	private int _valueColumnIndex = -1;

	private int _forceColumnIndex = -1;

	private int _savedLeftPanelWidth;

	private int _savedMonitorPanelWidth;

	private List<int> _savedMonitorColumnWidths = new List<int>();

	private DateTime _programGraphLastSourceWrite;

	private DateTime _programGraphLastCheckUtc;

	private int _programGraphSourceCount;

	private bool _programGraphCheckPending;

	private int _programGraphAnalysisVersion;

	private ProgramGraphSnapshot? _programGraphSnapshot;

	private string _pendingProgramGraphDirectory = "";

	private string _activeProgramGraphDirectory = "";

	private ushort _lastTraceId = ushort.MaxValue;

	private bool _showHexValue;

	private int _targetCycleMs = 50;

	private readonly Dictionary<ushort, string> _traceLabels = new Dictionary<ushort, string>();

	private bool _functionCodeDirty;

	private bool _dataCodeDirty;

	private bool _refreshMapBusy;

	private DateTime _lastManualRefreshUtc;

	private bool _suppressFunctionScopeHighlight;

	private readonly List<(int Start, int Length)> _functionScopeHighlights = new List<(int Start, int Length)>();

	private string _lastProgramInsightSignature = "";

	private DateTime _lastProgramInsightRenderUtc = DateTime.MinValue;

	private DateTime _lastMonitorSendErrorLogUtc;

	private DateTime _lastWatchSnapshotErrorLogUtc;

	private DateTime _lastPollLoopErrorLogUtc;

	private int _monitorTxProbeRemaining;

	private int _consecutiveCanNoResponseCount;

	private int _noResponseStopRequested;

	private DateTime _lastNoResponseStopUtc = DateTime.MinValue;

	private int _controllerResponded;

	private readonly SemaphoreSlim _canRequestLock = new SemaphoreSlim(1, 1);

	private int _uiLogLineCount;

	private const int WmSetRedraw = 0x000B;

	private const int EmGetScrollPos = 0x04DD;

	private const int EmSetScrollPos = 0x04DE;

	private const int EmGetFirstVisibleLine = 0x00CE;

	private const int DataMirrorPaddingLines = 2;

	private const int MaxWatchItems = 100;

	private const int VisibleWatchTargetLimit = 40;

	private const int CurrentFunctionWatchTargetLimit = 80;

	private const int NoResponseDisplayMissCount = 3;

	private const int DefaultPollIntervalMs = 100;

	private const int CodeRenderRefreshMs = 80;

	private const int WatchValueFlushMs = 50;

	private const int DataInlineRefreshMs = 100;

	private const int ManualRefreshThrottleMs = 250;

	private const int NoResponseStopThreshold = 20;

	private const int NoResponseStopCooldownMs = 5000;

	private bool IsWatchCapacityLimited()
	{
		return !_offlineSimulation;
	}

	private const int FunctionCodeWheelDeferMs = 320;

	private const int UiValueWheelDeferMs = 260;

	private const int VisibleDataScrollDebounceMs = 120;

	private const int ProgramInsightRefreshMs = 360;

	private static int _memoryTrimPending;

	private static readonly Color CodeCommentColor = Color.FromArgb(74, 222, 128);

	private static readonly Color CodeFunctionColor = Color.FromArgb(96, 165, 250);

	private static readonly Color CodeKeywordColor = Color.FromArgb(244, 114, 182);

	private static readonly Color CodeValueColor = Color.FromArgb(8, 13, 22);

	private static readonly Color CodeValueBackColor = Color.FromArgb(251, 191, 36);

	private static readonly Color CodeTrueLineBackColor = Color.FromArgb(21, 128, 61);

	private static readonly Color CodeFocusVariableForeColor = Color.FromArgb(2, 6, 23);

	private static readonly Color CodeFocusVariableBackColor = Color.FromArgb(74, 222, 128);

	[DllImport("user32.dll")]
	private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

	[DllImport("user32.dll")]
	private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, ref Point lParam);

	private const uint MonitorRequestId = 2032u;

	private const uint MonitorResponseId = 2033u;

	private const int UiLogMaxLines = 120;

	private const long DiagnosticLogMaxBytes = 512 * 1024;

	private const int DiagnosticLogKeepLines = 2000;

	public MainForm()
	{
		Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
		Text = AppDisplayName;
		MinimumSize = new Size(1180, 760);
		base.StartPosition = FormStartPosition.CenterScreen;
		BackColor = _bg;
		Font = new Font("Microsoft YaHei UI", 9f);
		BuildUi();
		UpdateFirmwareVersionDisplay();
		ApplyTheme(_themeName);
		UpdateFirmwareVersionDisplay();
		LoadDefaultProfile();
		_mapReloadTimer.Interval = 1000;
		_mapReloadTimer.Tick += delegate
		{
			CheckMapReload();
			CheckProgramGraphReload();
		};
		_mapReloadTimer.Start();
		_codeRefreshTimer.Interval = CodeRenderRefreshMs;
		_codeRefreshTimer.Tick += delegate
		{
			if ((_functionCodeDirty || _dataCodeDirty) && _functionCodePanel != null && _functionCodePanel.Visible)
			{
				if (ShouldDeferFunctionCodeRefresh())
				{
					return;
				}
				bool renderFunction = _functionCodeDirty;
				bool renderData = _dataCodeDirty;
				_functionCodeDirty = false;
				_dataCodeDirty = false;
				if (renderFunction)
				{
					RenderFunctionSource();
				}
				else if (renderData)
				{
					RenderDataFunctionMirror(resetScroll: false);
				}
			}
		};
		_codeRefreshTimer.Start();
		_valueRefreshTimer.Interval = WatchValueFlushMs;
		_valueRefreshTimer.Tick += delegate
		{
			FlushPendingWatchUpdates();
		};
		_valueRefreshTimer.Start();
		_visibleDataRefreshTimer.Interval = VisibleDataScrollDebounceMs;
		_visibleDataRefreshTimer.Tick += delegate
		{
			_visibleDataRefreshTimer.Stop();
			if (ShouldDeferFunctionCodeRefresh())
			{
				ScheduleVisibleDataRefreshAfterScroll();
				return;
			}
			RefreshVisibleDataAfterScroll();
		};
		_programInsightRefreshTimer.Interval = ProgramInsightRefreshMs;
		_programInsightRefreshTimer.Tick += delegate
		{
			_programInsightRefreshTimer.Stop();
			RenderProgramInsightPanel(force: false);
		};
		_suggestionTimer.Interval = 160;
		_suggestionTimer.Tick += delegate
		{
			_suggestionTimer.Stop();
			RefreshSuggestions();
		};
		_programGraphDebounceTimer.Interval = 280;
		_programGraphDebounceTimer.Tick += delegate
		{
			_programGraphDebounceTimer.Stop();
			string directory = _pendingProgramGraphDirectory;
			if (directory.Length > 0)
			{
				StartProgramGraphAnalysis(directory);
			}
		};
		base.Shown += delegate
		{
			BeginInvoke(RefreshStartupProgramGraph);
		};
		Log("软件启动，内存 " + GetProcessMemoryText() + "。");
	}

	protected override void OnFormClosing(FormClosingEventArgs e)
	{
		CancelActiveDownload(waitForExit: true);
		SaveDefaultProfileQuietly();
		_mapReloadTimer.Stop();
		_mapReloadTimer.Dispose();
		_codeRefreshTimer.Stop();
		_codeRefreshTimer.Dispose();
		_valueRefreshTimer.Stop();
		_valueRefreshTimer.Dispose();
		_visibleDataRefreshTimer.Stop();
		_visibleDataRefreshTimer.Dispose();
		_suggestionTimer.Stop();
		_suggestionTimer.Dispose();
		_programInsightRefreshTimer.Stop();
		_programInsightRefreshTimer.Dispose();
		_programGraphDebounceTimer.Stop();
		_programGraphDebounceTimer.Dispose();
		StopPolling(waitForExit: true);
		_adapter?.Close();
		_adapter?.Dispose();
		_adapter = null;
		_canRequestLock.Dispose();
		_monitorSessionOpen = false;
		base.OnFormClosing(e);
	}

	private void BuildUi()
	{
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(10),
			BackColor = _bg
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 56f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 48f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		base.Controls.Add(tableLayoutPanel);
		tableLayoutPanel.Controls.Add(BuildHeader(), 0, 0);
		tableLayoutPanel.Controls.Add(BuildToolbar(), 0, 1);
		tableLayoutPanel.Controls.Add(BuildMainArea(), 0, 2);
	}

	private Control BuildHeader()
	{
		Panel header = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _header,
			Padding = new Padding(18, 8, 18, 8),
			Tag = "header"
		};
		Label value = new Label
		{
			Text = AppDisplayName,
			ForeColor = _ink,
			Font = new Font("Microsoft YaHei UI", 14f, FontStyle.Bold),
			AutoSize = true,
			Location = new Point(18, 4),
			Tag = "title"
		};
		_appVersionLabel = new Label
		{
			Text = BuildUpperComputerVersionDisplay(),
			ForeColor = _accent,
			Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold),
			AutoSize = true,
			Location = new Point(150, 10),
			Tag = "appVersion"
		};
		_firmwareVersionLabel = new Label
		{
			Text = BuildFirmwareVersionDisplay(""),
			ForeColor = _muted,
			Font = new Font("Microsoft YaHei UI", 8f),
			AutoSize = true,
			Location = new Point(22, 33),
			Tag = "small"
		};
		_statusLabel = new Label
		{
			Text = "未连接",
			ForeColor = _ink,
			TextAlign = ContentAlignment.MiddleCenter,
			BackColor = _statusOff,
			Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold),
			Size = new Size(102, 28),
			Anchor = (AnchorStyles.Top | AnchorStyles.Right),
			Location = new Point(base.Width - 132, 13)
		};
		header.Resize += delegate
		{
			_statusLabel.Location = new Point(header.Width - 124, 13);
		};
		header.Controls.Add(value);
		header.Controls.Add(_appVersionLabel);
		header.Controls.Add(_firmwareVersionLabel);
		header.Controls.Add(_statusLabel);
		return header;
	}

	private static string BuildUpperComputerVersionDisplay()
	{
		return "上位机版本： " + UpperComputerVersion;
	}

	private static string GetBundledFirmwareVersionText()
	{
		return FirmwareInstaller.FormatVersion(BundledFirmwareAgent.ReadVersion());
	}

	private static string BuildFirmwareVersionDisplay(string workDirectory)
	{
		string bundledVersion = GetBundledFirmwareVersionText();
		string installedAgent = FindInstalledAgentFile(workDirectory);
		if (installedAgent.Length == 0)
		{
			return "长沙康旭电子科技有限公司    工程固件：未安装    需加载";
		}

		string installedVersion = FirmwareInstaller.FormatVersion(FirmwareInstaller.ReadAgentVersion(installedAgent));
		if (!installedVersion.Equals(bundledVersion, StringComparison.OrdinalIgnoreCase))
		{
			return "长沙康旭电子科技有限公司    工程固件：" + installedVersion + "    需加载";
		}

		return "长沙康旭电子科技有限公司    工程固件：" + installedVersion + "    已同步";
	}

	private void UpdateFirmwareVersionDisplay()
	{
		string text = BuildFirmwareVersionDisplay(_workDirectory);
		if (_firmwareVersionLabel != null)
		{
			_firmwareVersionLabel.Text = text;
			_firmwareVersionLabel.ForeColor = IsWorkFirmwareVersionCurrent(_workDirectory)
				? _muted
				: Color.FromArgb(251, 191, 36);
		}
		if (_appVersionLabel != null)
		{
			_appVersionLabel.Text = BuildUpperComputerVersionDisplay();
			_appVersionLabel.ForeColor = _accent;
		}
		Text = AppDisplayName + " " + UpperComputerVersion;
		UpdateDownloadButtonState();
	}

	private void UpdateDownloadButtonState()
	{
		if (_downloadButton == null)
		{
			return;
		}

		bool enabled = IsWorkFirmwareVersionCurrent(_workDirectory);
		if (enabled)
		{
			_downloadButton.Text = "下载";
			_downloadButton.Enabled = true;
			ApplyButtonStyle(_downloadButton, "download");
		}
		else
		{
			_downloadButton.Text = "需加载";
			_downloadButton.Enabled = true;
			ApplyButtonStyle(_downloadButton, "blocked");
		}
	}

	private static bool IsWorkFirmwareVersionCurrent(string workDirectory)
	{
		string installedAgent = FindInstalledAgentFile(workDirectory);
		if (installedAgent.Length == 0)
		{
			return false;
		}

		string bundledVersion = GetBundledFirmwareVersionText();
		string installedVersion = FirmwareInstaller.FormatVersion(FirmwareInstaller.ReadAgentVersion(installedAgent));
		return installedVersion.Equals(bundledVersion, StringComparison.OrdinalIgnoreCase);
	}

	private static string ExtractWorkFirmwareVersionText(string workDirectory)
	{
		string installedAgent = FindInstalledAgentFile(workDirectory);
		if (installedAgent.Length == 0)
		{
			return "未安装";
		}
		return FirmwareInstaller.FormatVersion(FirmwareInstaller.ReadAgentVersion(installedAgent));
	}

	private static string FindInstalledAgentFile(string workDirectory)
	{
		if (string.IsNullOrWhiteSpace(workDirectory) || !Directory.Exists(workDirectory))
		{
			return "";
		}

		string direct = Path.Combine(workDirectory, "Src", "can_monitor_agent.c");
		if (File.Exists(direct))
		{
			return direct;
		}

		return Directory.EnumerateFiles(workDirectory, "can_monitor_agent.c", SearchOption.AllDirectories)
			.OrderBy(p => p.Length)
			.FirstOrDefault() ?? "";
	}

	private Control BuildToolbar()
	{
		Panel panel = CardPanel();
		panel.Margin = new Padding(0, 0, 0, 4);
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 6,
			RowCount = 1,
			Padding = new Padding(10, 5, 10, 5)
		};
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 46f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 240f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 440f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		_mapPathBox = new TextBox
		{
			Dock = DockStyle.Fill,
			PlaceholderText = "工作目录"
		};
		StyleTextBox(_mapPathBox);
		Button button = CommandButton("选择目录");
		MakeToolbarButton(button, "directory");
		button.Click += delegate
		{
			BrowseProjectDirectory();
		};
		_refreshButton = CommandButton("刷新");
		MakeToolbarButton(_refreshButton, "refresh");
		_refreshButton.Click += async delegate
		{
			await RefreshMapAsync();
		};
		Button installButton = CommandButton("加载固件");
		MakeToolbarButton(installButton, "firmware");
		installButton.Click += async delegate
		{
			await InstallFirmwareAgentAsync(installButton);
		};
		_downloadButton = CommandButton("下载");
		MakeToolbarButton(_downloadButton, "download");
		_downloadButton.Click += async delegate
		{
			await DownloadFirmwareAsync(_downloadButton);
		};
		_connectButton = CommandButton("连接");
		MakeToolbarButton(_connectButton, "connect");
		_connectButton.Click += delegate
		{
			ToggleConnect();
		};
		_simulationButton = CommandButton("演示");
		MakeToolbarButton(_simulationButton, "simulate");
		_simulationButton.Click += delegate
		{
			ToggleOfflineSimulation();
		};
		FlowLayoutPanel commandPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			Padding = new Padding(0, 4, 0, 0),
			Margin = Padding.Empty
		};
		button.Margin = new Padding(0, 0, 8, 0);
		_refreshButton.Margin = new Padding(0, 0, 8, 0);
		installButton.Margin = new Padding(0, 0, 8, 0);
		_downloadButton.Margin = new Padding(0, 0, 8, 0);
		_connectButton.Margin = new Padding(0, 0, 8, 0);
		_simulationButton.Margin = new Padding(0);
		commandPanel.Controls.Add(button);
		commandPanel.Controls.Add(_refreshButton);
		commandPanel.Controls.Add(installButton);
		commandPanel.Controls.Add(_downloadButton);
		commandPanel.Controls.Add(_connectButton);
		commandPanel.Controls.Add(_simulationButton);
		_intervalBox = new NumericUpDown
		{
			Minimum = 10m,
			Maximum = 1000m,
			Value = DefaultPollIntervalMs,
			Dock = DockStyle.None,
			Width = 78,
			Height = 24,
			Margin = new Padding(2, 2, 0, 0)
		};
		_intervalBox.ValueChanged += delegate
		{
			_targetCycleMs = (int)_intervalBox.Value;
			UpdateCycleEstimate();
			SaveDefaultProfileQuietly();
		};
		tableLayoutPanel.Controls.Add(SmallLabel("目录"), 0, 0);
		tableLayoutPanel.Controls.Add(_mapPathBox, 1, 0);
		tableLayoutPanel.Controls.Add(commandPanel, 2, 0);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			Padding = new Padding(0, 3, 0, 0),
			Margin = Padding.Empty
		};
		flowLayoutPanel.Controls.Add(SmallLabel("周期"));
		flowLayoutPanel.Controls.Add(_intervalBox);
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 4, 0);
		_themeBox = new ComboBox
		{
			Dock = DockStyle.None,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		_themeBox.Width = 132;
		_themeBox.Height = 26;
		_themeBox.Margin = new Padding(4, 2, 0, 0);
		_themeBox.Items.AddRange(new object[] { "工业黑金", "浅色工程", "深蓝仪表盘", "极简暗色", "设备控制台" });
		_themeBox.SelectedItem = _themeName;
		StyleComboBox(_themeBox);
		_themeBox.SelectedIndexChanged += delegate
		{
			if (_themeBox.SelectedItem is string themeName && !_themeName.Equals(themeName, StringComparison.Ordinal))
			{
				ApplyTheme(themeName);
				UpdateFirmwareVersionDisplay();
				SaveDefaultProfileQuietly();
			}
		};
		FlowLayoutPanel themePanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			Padding = new Padding(0, 3, 0, 0),
			Margin = Padding.Empty
		};
		Label themeLabel = SmallLabel("主题");
		themeLabel.Width = 42;
		themePanel.Controls.Add(themeLabel);
		themePanel.Controls.Add(_themeBox);
		tableLayoutPanel.Controls.Add(themePanel, 5, 0);
		panel.Controls.Add(tableLayoutPanel);
		return panel;
	}

	private Control BuildMainArea()
	{
		_mainSplit = new SplitContainer
		{
			Dock = DockStyle.Fill,
			SplitterWidth = 14,
			Panel1MinSize = 180,
			BackColor = GetSplitterColor("split-main"),
			Tag = "split-main"
		};
		_mainSplit.Paint += SplitContainerPaint;
		bool splitterReady = false;
		_mainSplit.SizeChanged += delegate
		{
			if (!splitterReady && _mainSplit.Width > 1120)
			{
				int savedLeftPanelWidth = GetSavedLeftPanelWidth();
				_mainSplit.SplitterDistance = ((savedLeftPanelWidth > 0) ? ClampMainSplitter(savedLeftPanelWidth) : ClampMainSplitter(220));
				splitterReady = true;
			}
		};
		_mainSplit.SplitterMoved += delegate
		{
			SaveDefaultProfileQuietly();
		};
		_mainSplit.Panel1.Controls.Add(BuildLeftPanel());
		_rightSplit = new SplitContainer
		{
			Dock = DockStyle.Fill,
			SplitterWidth = 14,
			BackColor = GetSplitterColor("split-right"),
			Tag = "split-right"
		};
		_rightSplit.Paint += SplitContainerPaint;
		bool rightReady = false;
		_rightSplit.SizeChanged += delegate
		{
			if (!rightReady && _rightSplit.Width > 760)
			{
				_rightSplit.Panel1MinSize = 300;
				_rightSplit.Panel2MinSize = 520;
				int savedMonitorPanelWidth = GetSavedMonitorPanelWidth();
				_rightSplit.SplitterDistance = ((savedMonitorPanelWidth > 0) ? ClampRightSplitter(savedMonitorPanelWidth) : ClampRightSplitter(360));
				rightReady = true;
			}
		};
		_rightSplit.SplitterMoved += delegate
		{
			SaveDefaultProfileQuietly();
		};
		_rightSplit.Panel1.Controls.Add(BuildGridPanel());
		_rightSplit.Panel2.Controls.Add(BuildBusinessPanel());
		_mainSplit.Panel2.Controls.Add(_rightSplit);
		return _mainSplit;
	}

	private int GetSavedLeftPanelWidth()
	{
		if (_savedLeftPanelWidth <= 0)
		{
			return 0;
		}
		return _savedLeftPanelWidth;
	}

	private int GetSavedMonitorPanelWidth()
	{
		if (_savedMonitorPanelWidth <= 0)
		{
			return 0;
		}
		return _savedMonitorPanelWidth;
	}

	private int ClampMainSplitter(int value)
	{
		if (_mainSplit.Width <= 0)
		{
			return value;
		}
		int max = Math.Max(_mainSplit.Panel1MinSize, _mainSplit.Width - 900);
		return Math.Clamp(value, _mainSplit.Panel1MinSize, max);
	}

	private int ClampRightSplitter(int value)
	{
		if (_rightSplit.Width <= 0)
		{
			return value;
		}
		int num = Math.Max(_rightSplit.Panel1MinSize, 300);
		int max = Math.Max(num, _rightSplit.Width - Math.Max(_rightSplit.Panel2MinSize, 520));
		return Math.Clamp(value, num, max);
	}

	private void ApplySavedSplitterDistances()
	{
		if (_mainSplit != null && _savedLeftPanelWidth > 0 && _mainSplit.Width > 0)
		{
			_mainSplit.SplitterDistance = ClampMainSplitter(_savedLeftPanelWidth);
		}
		if (_rightSplit != null && _savedMonitorPanelWidth > 0 && _rightSplit.Width > 0)
		{
			_rightSplit.SplitterDistance = ClampRightSplitter(_savedMonitorPanelWidth);
		}
	}

	private List<int> GetMonitorColumnWidths()
	{
		if (_grid == null)
		{
			return _savedMonitorColumnWidths.ToList();
		}
		return _grid.Columns.Cast<DataGridViewColumn>()
			.Select(column => Math.Clamp(column.Width, 36, 800))
			.ToList();
	}

	private void ApplySavedMonitorColumnWidths()
	{
		if (_grid == null || _savedMonitorColumnWidths.Count == 0)
		{
			return;
		}
		int count = Math.Min(_grid.Columns.Count, _savedMonitorColumnWidths.Count);
		for (int i = 0; i < count; i++)
		{
			int width = Math.Clamp(_savedMonitorColumnWidths[i], 36, 800);
			_grid.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			_grid.Columns[i].Width = width;
		}
	}

	private Control BuildLeftPanel()
	{
		Panel panel = CardPanel();
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			RowCount = 3,
			Padding = new Padding(10)
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28f));
		tableLayoutPanel.Controls.Add(SectionLabel("1 程序透视"), 0, 0);
		_programInsightList = CreateDenseListView();
		_programInsightList.HeaderStyle = ColumnHeaderStyle.None;
		_programInsightList.Columns.Add("项", 58);
		_programInsightList.Columns.Add("内容", 220);
		_programInsightList.DoubleClick += ProgramInsightListDoubleClick;
		_programInsightList.Resize += delegate { ResizeProgramInsightColumns(); };
		tableLayoutPanel.Controls.Add(_programInsightList, 0, 1);
		_symbolCountLabel = SmallLabel("未读取");
		tableLayoutPanel.Controls.Add(_symbolCountLabel, 0, 2);

		_variableBox = new TextBox { Visible = false };
		_suggestions = new ListBox { Visible = false };
		UpdateProgramInsightPanel(force: true);
		panel.Controls.Add(tableLayoutPanel);
		return panel;
	}

	private void ResizeProgramInsightColumns()
	{
		if (_programInsightList == null || _programInsightList.Columns.Count < 2)
		{
			return;
		}

		int firstWidth = Math.Clamp(_programInsightList.ClientSize.Width / 5, 46, 64);
		_programInsightList.Columns[0].Width = firstWidth;
		_programInsightList.Columns[1].Width = Math.Max(120, _programInsightList.ClientSize.Width - firstWidth - 6);
	}

	private void UpdateProgramInsightPanel(bool force = false)
	{
		if (force)
		{
			_programInsightRefreshTimer.Stop();
			RenderProgramInsightPanel(force: true);
			return;
		}

		if ((DateTime.UtcNow - _lastProgramInsightRenderUtc).TotalMilliseconds < ProgramInsightRefreshMs)
		{
			ScheduleProgramInsightRefresh();
			return;
		}

		RenderProgramInsightPanel(force: false);
	}

	private void ScheduleProgramInsightRefresh()
	{
		if (_programInsightList == null)
		{
			return;
		}

		_programInsightRefreshTimer.Stop();
		_programInsightRefreshTimer.Start();
	}

	private void RenderProgramInsightPanel(bool force = false)
	{
		if (_programInsightList == null)
		{
			return;
		}

		_lastProgramInsightRenderUtc = DateTime.UtcNow;
		List<ListViewItem> items = BuildProgramInsightItems();
		var signature = new StringBuilder();
		foreach (ListViewItem item in items)
		{
			signature.Append(item.Text).Append('|').Append(item.SubItems.Count > 1 ? item.SubItems[1].Text : "").Append('|').Append(item.Tag).Append('\n');
		}
		string signatureText = signature.ToString();
		if (!force && signatureText.Equals(_lastProgramInsightSignature, StringComparison.Ordinal))
		{
			return;
		}

		_lastProgramInsightSignature = signatureText;
		_programInsightList.BeginUpdate();
		try
		{
			_programInsightList.Items.Clear();
			_programInsightList.Items.AddRange(items.ToArray());
			ResizeProgramInsightColumns();
		}
		finally
		{
			_programInsightList.EndUpdate();
		}
	}

	private List<ListViewItem> BuildProgramInsightItems()
	{
		var items = new List<ListViewItem>();
		if (_currentFunctionSource != null)
		{
			BuildCurrentFunctionInsightItems(items);
		}
		else
		{
			BuildProgramHomeInsightItems(items);
		}

		if (items.Count == 0)
		{
			AddProgramInsightItem(items, "状态", "等待工程分析", "", null, _muted, _surface);
		}
		return items;
	}

	private void BuildProgramHomeInsightItems(List<ListViewItem> items)
	{
		AddFocusedVariableInsightItem(items);
		ProgramGraphSnapshot? snapshot = _programGraphSnapshot;
		if (snapshot == null || !snapshot.Success)
		{
			AddProgramInsightItem(items, "目录", string.IsNullOrWhiteSpace(_workDirectory) ? "未选择工作目录" : "正在读取代码", "", null, _muted, _surface);
			AddProgramInsightItem(items, "提示", "底部搜索框可搜函数/变量/代码", "", null, _muted, _surfaceAlt);
			return;
		}

		string entry = string.IsNullOrWhiteSpace(snapshot.StartFunction) ? "自动识别" : snapshot.StartFunction;
		ProgramInsightAction? entryAction = string.IsNullOrWhiteSpace(snapshot.StartFunction) ? null : new ProgramInsightAction("function", entry);
		AddProgramInsightItem(items, "入口", entry, entryAction == null ? "" : "双击进入", entryAction, _accent, _surfaceAlt);
		AddProgramInsightItem(items, "规模", $"{snapshot.CallGraphNodes.Count} 函数 / {snapshot.CallGraphEdges.Count} 调用", $"{snapshot.SourceFileCount} 源文件", null, _muted, _surface);

		foreach (ProgramCallGraphNode node in snapshot.CallGraphNodes
			.OrderByDescending(GetBusinessNodeScore)
			.ThenByDescending(n => n.Outgoing + n.Incoming)
			.ThenBy(n => n.Name, StringComparer.OrdinalIgnoreCase)
			.Take(18))
		{
			string detail = TrimInsightText(string.IsNullOrWhiteSpace(node.Summary) ? BuildNodeRelationText(node) : node.Summary, 42);
			AddProgramInsightItem(items, ClassifyFunctionKind(node.Name, node.Kind), node.Name, detail, new ProgramInsightAction("function", node.Name), GetFunctionKindColor(node.Name, node.Kind), _surface);
		}
	}

	private void BuildCurrentFunctionInsightItems(List<ListViewItem> items)
	{
		AddFocusedVariableInsightItem(items);
		FunctionSourceView? activeSource = _currentFunctionSource;
		if (activeSource == null)
		{
			return;
		}

		FunctionSourceView source = activeSource;
		ProgramCallGraphNode? currentNode = FindGraphNodeForFunction(source.FunctionName, source.FilePath);
		string currentDetail = currentNode != null && !string.IsNullOrWhiteSpace(currentNode.Summary)
			? currentNode.Summary
			: $"第 {source.StartLine} 行";
		AddProgramInsightItem(items, "当前", source.FunctionName, TrimInsightText(currentDetail, 46), new ProgramInsightAction("function", source.FunctionName), _accent, _surfaceAlt);

		EmbeddedCodeAnalysis semantic = EmbeddedCodeKnowledge.Analyze(
			source.FunctionName,
			source.FilePath,
			string.Join(Environment.NewLine, source.Lines));
		foreach (EmbeddedCodeInsight insight in semantic.Insights.Take(8))
		{
			ProgramInsightAction? action = insight.Kind.Equals("信号", StringComparison.OrdinalIgnoreCase)
				? new ProgramInsightAction("search", insight.Name)
				: null;
			Color foreColor = insight.Kind.Equals("信号", StringComparison.OrdinalIgnoreCase) ? CodeFunctionColor : _ink;
			AddProgramInsightItem(items, insight.Kind, insight.Name, TrimInsightText(insight.Detail, 44), action, foreColor, _surface);
		}

		if (currentNode != null)
		{
			foreach (ProgramCallGraphNode caller in GetGraphLinkedNodes(currentNode.Id, callers: true).Take(5))
			{
				AddProgramInsightItem(items, "上游", caller.Name, TrimInsightText(caller.Summary, 42), new ProgramInsightAction("function", caller.Name), GetFunctionKindColor(caller.Name, caller.Kind), _surface);
			}
			foreach (ProgramCallGraphNode callee in GetGraphLinkedNodes(currentNode.Id, callers: false).Take(10))
			{
				AddProgramInsightItem(items, "下游", callee.Name, TrimInsightText(callee.Summary, 42), new ProgramInsightAction("function", callee.Name), GetFunctionKindColor(callee.Name, callee.Kind), _surface);
			}
		}

		List<WatchItem> visibleWatchItems = GetVisibleWatchItems();
		foreach (WatchItem item in visibleWatchItems.Take(14))
		{
			string name = GetWatchDisplayName(item);
			AddProgramInsightItem(items, "可见值", name, FormatInlineWatchValue(item), new ProgramInsightAction("search", name), Color.FromArgb(17, 24, 39), CodeValueBackColor);
		}

		foreach (WatchItem item in GetCurrentFunctionWatchItems()
			.Where(item => !visibleWatchItems.Any(visible => visible.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase)))
			.Take(8))
		{
			string name = GetWatchDisplayName(item);
			AddProgramInsightItem(items, "本函数", name, FormatInlineWatchValue(item), new ProgramInsightAction("search", name), Color.FromArgb(17, 24, 39), CodeValueBackColor);
		}

		foreach (string identifier in BuildBusinessSignals().Take(12))
		{
			AddProgramInsightItem(items, "信号", identifier, ResolveInsightSymbolState(identifier), new ProgramInsightAction("search", identifier), _ink, _surface);
		}
	}

	private void AddFocusedVariableInsightItem(List<ListViewItem> items)
	{
		if (string.IsNullOrWhiteSpace(_focusedVariableName))
		{
			return;
		}

		string detail = GetFocusedVariableDetail(_focusedVariableName);
		AddProgramInsightItem(items, "锁定", _focusedVariableName, detail, new ProgramInsightAction("search", _focusedVariableName), CodeFocusVariableForeColor, CodeFocusVariableBackColor);
	}

	private string GetFocusedVariableDetail(string variableName)
	{
		WatchItem? item = FindWatchItemByIdentifier(variableName);
		if (item != null)
		{
			return FormatInlineWatchValue(item);
		}
		if (_symbolLookup.ContainsKey(variableName) || _symbolBaseLookup.ContainsKey(variableName) || _symbolTailLookup.ContainsKey(variableName))
		{
			return "可监控";
		}
		return "代码定位";
	}

	private WatchItem? FindWatchItemByIdentifier(string identifier)
	{
		if (string.IsNullOrWhiteSpace(identifier))
		{
			return null;
		}

		return _watchItems.FirstOrDefault(item =>
			item.Name.Equals(identifier, StringComparison.OrdinalIgnoreCase) ||
			GetWatchDisplayName(item).Equals(identifier, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierBase(item.Name).Equals(identifier, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierTail(item.Name).Equals(identifier, StringComparison.OrdinalIgnoreCase));
	}

	private bool WatchMatchesFocusedVariable(WatchItem item)
	{
		if (string.IsNullOrWhiteSpace(_focusedVariableName))
		{
			return false;
		}

		return item.Name.Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase) ||
			GetWatchDisplayName(item).Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierBase(item.Name).Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierTail(item.Name).Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase);
	}

	private void AddProgramInsightItem(List<ListViewItem> items, string kind, string name, string detail, ProgramInsightAction? action, Color foreColor, Color backColor)
	{
		string text = string.IsNullOrWhiteSpace(detail) ? name : name + "    " + detail;
		var item = new ListViewItem(kind)
		{
			BackColor = backColor,
			ForeColor = foreColor,
			Tag = action,
			UseItemStyleForSubItems = false,
			ToolTipText = text
		};
		item.SubItems.Add(text);
		item.SubItems[1].ForeColor = foreColor;
		item.SubItems[1].BackColor = backColor;
		items.Add(item);
	}

	private void ProgramInsightListDoubleClick(object? sender, EventArgs e)
	{
		if (_programInsightList?.SelectedItems.Count != 1 || _programInsightList.SelectedItems[0].Tag is not ProgramInsightAction action)
		{
			return;
		}

		if (action.Kind.Equals("search", StringComparison.OrdinalIgnoreCase))
		{
			FillProgramSearchFromCode(action.Value);
			return;
		}

		if (action.Kind.Equals("function", StringComparison.OrdinalIgnoreCase) &&
			!string.IsNullOrWhiteSpace(_workDirectory) &&
			Directory.Exists(_workDirectory) &&
			TryLoadFunctionSource(_workDirectory, action.Value, out FunctionSourceView? sourceView) &&
			sourceView != null)
		{
			ShowFunctionSource(sourceView, pushCurrent: _currentFunctionSource != null);
		}
	}

	private ProgramCallGraphNode? FindGraphNodeForFunction(string functionName, string filePath)
	{
		ProgramGraphSnapshot? snapshot = _programGraphSnapshot;
		if (snapshot == null || snapshot.CallGraphNodes.Count == 0)
		{
			return null;
		}

		ProgramCallGraphNode? sameFile = snapshot.CallGraphNodes.FirstOrDefault(n =>
			n.Name.Equals(functionName, StringComparison.OrdinalIgnoreCase) &&
			n.FilePath.Equals(filePath, StringComparison.OrdinalIgnoreCase));
		return sameFile ?? snapshot.CallGraphNodes.FirstOrDefault(n => n.Name.Equals(functionName, StringComparison.OrdinalIgnoreCase));
	}

	private IEnumerable<ProgramCallGraphNode> GetGraphLinkedNodes(string nodeId, bool callers)
	{
		ProgramGraphSnapshot? snapshot = _programGraphSnapshot;
		if (snapshot == null)
		{
			yield break;
		}

		Dictionary<string, ProgramCallGraphNode> nodes = snapshot.CallGraphNodes.ToDictionary(n => n.Id, StringComparer.OrdinalIgnoreCase);
		IEnumerable<ProgramCallGraphEdge> edges = callers
			? snapshot.CallGraphEdges.Where(e => e.ToId.Equals(nodeId, StringComparison.OrdinalIgnoreCase))
			: snapshot.CallGraphEdges.Where(e => e.FromId.Equals(nodeId, StringComparison.OrdinalIgnoreCase));
		foreach (ProgramCallGraphEdge edge in edges)
		{
			string linkedId = callers ? edge.FromId : edge.ToId;
			if (nodes.TryGetValue(linkedId, out ProgramCallGraphNode? node))
			{
				yield return node;
			}
		}
	}

	private List<string> BuildBusinessSignals()
	{
		IEnumerable<string> visibleIdentifiers = BuildIdentifierList(GetVisibleRawLines(DataMirrorPaddingLines));
		return visibleIdentifiers
			.Concat(_currentFunctionIdentifiers)
			.Where(IsBusinessIdentifier)
			.Distinct(StringComparer.OrdinalIgnoreCase)
			.OrderByDescending(name => _symbolLookup.ContainsKey(name) || _symbolBaseLookup.ContainsKey(name) || _symbolTailLookup.ContainsKey(name))
			.ThenBy(name => name, StringComparer.OrdinalIgnoreCase)
			.ToList();
	}

	private string ResolveInsightSymbolState(string identifier)
	{
		if (_watchItems.Any(item => GetWatchDisplayName(item).Equals(identifier, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierBase(item.Name).Equals(identifier, StringComparison.OrdinalIgnoreCase) ||
			GetIdentifierTail(item.Name).Equals(identifier, StringComparison.OrdinalIgnoreCase)))
		{
			return "已监控";
		}
		return _symbolLookup.ContainsKey(identifier) || _symbolBaseLookup.ContainsKey(identifier) || _symbolTailLookup.ContainsKey(identifier) ? "可监控" : "";
	}

	private static int GetBusinessNodeScore(ProgramCallGraphNode node)
	{
		return GetBusinessNameScore(node.Name) + GetBusinessNameScore(node.Summary) + (node.Outgoing > 0 ? 2 : 0);
	}

	private static int GetBusinessNameScore(string text)
	{
		if (string.IsNullOrWhiteSpace(text))
		{
			return 0;
		}

		string upper = text.ToUpperInvariant();
		int score = 0;
		string[] strongWords = { "MYLOGIC", "LOGIC", "APP_", "LCD", "DISP", "CAN", "CTRL", "DFS", "MOTOR", "VALVE", "PRESS", "PWM", "DO", "DI" };
		foreach (string word in strongWords)
		{
			if (upper.Contains(word, StringComparison.Ordinal))
			{
				score += 3;
			}
		}
		return score;
	}

	private static string ClassifyFunctionKind(string name, string graphKind = "")
	{
		if (!string.IsNullOrWhiteSpace(graphKind))
		{
			return graphKind switch
			{
				"main" => "入口",
				"disp" => "显示",
				"period10" => "周期",
				"timer" => "周期",
				"can" => "CAN",
				"io" => "IO",
				"storage" => "参数",
				"driver" => "底层",
				"business" => "业务",
				_ => "函数"
			};
		}

		string upper = name.ToUpperInvariant();
		if (upper.Contains("CAN", StringComparison.Ordinal))
		{
			return "CAN";
		}
		if (upper.Contains("LCD", StringComparison.Ordinal) || upper.Contains("DISP", StringComparison.Ordinal))
		{
			return "显示";
		}
		if (upper.Contains("LOGIC", StringComparison.Ordinal) || upper.Contains("CTRL", StringComparison.Ordinal) || upper.Contains("APP", StringComparison.Ordinal))
		{
			return "业务";
		}
		return "函数";
	}

	private Color GetFunctionKindColor(string name, string graphKind = "")
	{
		string kind = ClassifyFunctionKind(name, graphKind);
		return kind switch
		{
			"CAN" => Color.FromArgb(45, 212, 191),
			"显示" => Color.FromArgb(250, 204, 21),
			"业务" => CodeFunctionColor,
			"入口" => _accent,
			"周期" => Color.FromArgb(250, 204, 21),
			"IO" => Color.FromArgb(251, 146, 60),
			"参数" => Color.FromArgb(192, 132, 252),
			"底层" => _muted,
			_ => _ink
		};
	}

	private static bool IsBusinessIdentifier(string name)
	{
		if (name.Length < 3)
		{
			return false;
		}

		string upper = name.ToUpperInvariant();
		string[] words = { "LCD", "CAN", "DI", "DO", "PWM", "MOTOR", "VALVE", "PRESS", "DLY", "FLG", "SET", "STA", "ERR", "TIME", "COUNT", "TEMP", "MAIN" };
		return words.Any(word => upper.Contains(word, StringComparison.Ordinal));
	}

	private static string BuildNodeRelationText(ProgramCallGraphNode node)
	{
		return $"入 {node.Incoming} / 出 {node.Outgoing}";
	}

	private static string TrimInsightText(string text, int maxLength)
	{
		if (string.IsNullOrWhiteSpace(text))
		{
			return "";
		}

		string compact = Regex.Replace(text.Trim(), @"\s+", " ");
		return compact.Length <= maxLength ? compact : compact.Substring(0, Math.Max(0, maxLength - 1)) + "...";
	}

	private Control BuildGridPanel()
	{
		Panel panel = CardPanel();
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			RowCount = 3,
			Padding = new Padding(10)
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 72f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.Controls.Add(SectionLabel("2 看数值"), 0, 0);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = true
		};
		_startButton = CommandButton("开始监控");
		_startButton.Size = new Size(92, 30);
		ApplyButtonStyle(_startButton, "monitorStart");
		_startButton.Click += delegate
		{
			TogglePolling();
		};
		_startButton.Margin = new Padding(0, 2, 6, 0);
		flowLayoutPanel.Controls.Add(_startButton);
		_valueFormatButton = PlainButton("10进制");
		_valueFormatButton.Size = new Size(64, 28);
		_valueFormatButton.Margin = new Padding(0, 3, 6, 0);
		_valueFormatButton.Click += delegate
		{
			ToggleValueDisplayMode();
		};
		flowLayoutPanel.Controls.Add(_valueFormatButton);
		UpdateValueFormatButton();
		Label forceLabel = SmallLabel("强制");
		forceLabel.Width = 36;
		forceLabel.Margin = new Padding(0, 6, 2, 0);
		flowLayoutPanel.Controls.Add(forceLabel);
		_forceValueBox = new TextBox
		{
			Width = 72,
			Height = 28,
			Margin = new Padding(0, 3, 6, 0)
		};
		StyleTextBox(_forceValueBox);
		flowLayoutPanel.Controls.Add(_forceValueBox);
		_writeValueButton = PlainButton("写入");
		_writeValueButton.Size = new Size(52, 28);
		_writeValueButton.Margin = new Padding(0, 3, 6, 0);
		_writeValueButton.Click += async delegate
		{
			await WriteSelectedValueAsync(force: false);
		};
		flowLayoutPanel.Controls.Add(_writeValueButton);
		_holdValueButton = PlainButton("保持");
		_holdValueButton.Size = new Size(52, 28);
		_holdValueButton.Margin = new Padding(0, 3, 6, 0);
		_holdValueButton.Click += async delegate
		{
			await WriteSelectedValueAsync(force: true);
		};
		flowLayoutPanel.Controls.Add(_holdValueButton);
		_releaseForceButton = PlainButton("释放");
		_releaseForceButton.Size = new Size(52, 28);
		_releaseForceButton.Margin = new Padding(0, 3, 6, 0);
		_releaseForceButton.Click += async delegate
		{
			await ReleaseSelectedForceAsync();
		};
		flowLayoutPanel.Controls.Add(_releaseForceButton);
		_runtimeRunButton = PlainButton("运行");
		_runtimeRunButton.Size = new Size(52, 28);
		_runtimeRunButton.Margin = new Padding(0, 3, 6, 0);
		_runtimeRunButton.Click += async delegate
		{
			await SendRuntimeControlAsync(MonitorProtocol.RuntimeRun, "运行");
		};
		flowLayoutPanel.Controls.Add(_runtimeRunButton);
		_runtimePauseButton = PlainButton("暂停");
		_runtimePauseButton.Size = new Size(52, 28);
		_runtimePauseButton.Margin = new Padding(0, 3, 6, 0);
		_runtimePauseButton.Click += async delegate
		{
			await SendRuntimeControlAsync(MonitorProtocol.RuntimePause, "暂停");
		};
		flowLayoutPanel.Controls.Add(_runtimePauseButton);
		_runtimeStepButton = PlainButton("单步");
		_runtimeStepButton.Size = new Size(52, 28);
		_runtimeStepButton.Margin = new Padding(0, 3, 6, 0);
		_runtimeStepButton.Click += async delegate
		{
			await SendRuntimeControlAsync(MonitorProtocol.RuntimeStep, "单步");
		};
		flowLayoutPanel.Controls.Add(_runtimeStepButton);
		_cycleEstimateLabel = SmallLabel("无变量");
		_cycleEstimateLabel.Width = 110;
		_cycleEstimateLabel.Margin = new Padding(0, 6, 0, 0);
		flowLayoutPanel.Controls.Add(_cycleEstimateLabel);
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 0, 1);
		_source.DataSource = _watchItems;
		_grid = new DataGridView
		{
			Dock = DockStyle.Fill,
			AutoGenerateColumns = false,
			AllowUserToAddRows = false,
			AllowUserToResizeRows = false,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			MultiSelect = true,
			AllowDrop = true,
			BackgroundColor = _panel,
			BorderStyle = BorderStyle.None,
			RowHeadersVisible = false,
			DataSource = _source,
			EnableHeadersVisualStyles = false,
			ClipboardCopyMode = DataGridViewClipboardCopyMode.Disable,
			Tag = "grid"
		};
		_grid.ColumnHeadersDefaultCellStyle.BackColor = _gridHeader;
		_grid.ColumnHeadersDefaultCellStyle.ForeColor = _ink;
		_grid.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold);
		_grid.DefaultCellStyle.BackColor = _surface;
		_grid.DefaultCellStyle.ForeColor = _ink;
		_grid.DefaultCellStyle.SelectionBackColor = _accent;
		_grid.DefaultCellStyle.SelectionForeColor = _ink;
		_grid.AlternatingRowsDefaultCellStyle.BackColor = _surfaceAlt;
		_grid.GridColor = _gridHeader;
		EnableDoubleBuffer(_grid);
		_grid.Columns.Add(new DataGridViewCheckBoxColumn
		{
			HeaderText = "监控",
			DataPropertyName = "Enabled",
			Width = 48
		});
		_grid.Columns.Add(new DataGridViewTextBoxColumn
		{
			HeaderText = "变量",
			DataPropertyName = "Name",
			Width = 260
		});
		DataGridViewTextBoxColumn sizeColumn = new DataGridViewTextBoxColumn
		{
			HeaderText = "字节",
			DataPropertyName = "Size",
			Width = 52,
			Visible = false
		};
		_grid.Columns.Add(sizeColumn);
		_grid.Columns.Add(new DataGridViewTextBoxColumn
		{
			HeaderText = "值(10)",
			DataPropertyName = "DisplayValue",
			Width = 120
		});
		_valueColumnIndex = _grid.Columns.Count - 1;
		_grid.Columns.Add(new DataGridViewTextBoxColumn
		{
			HeaderText = "强制",
			DataPropertyName = "ForceText",
			Width = 62
		});
		_forceColumnIndex = _grid.Columns.Count - 1;
		DataGridViewColumnCollection columns = _grid.Columns;
		if (_savedMonitorColumnWidths.Count == 0)
		{
			columns[_valueColumnIndex].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		}
		_grid.Columns.Add(new DataGridViewButtonColumn
		{
			HeaderText = "",
			Text = "×",
			UseColumnTextForButtonValue = true,
			Width = 34
		});
		ApplySavedMonitorColumnWidths();
		_grid.ColumnWidthChanged += delegate
		{
			SaveDefaultProfileQuietly();
		};
		_grid.ColumnHeaderMouseClick += GridColumnHeaderMouseClick;
		_grid.CellContentClick += GridCellContentClick;
		_grid.SelectionChanged += GridSelectionChanged;
		_grid.KeyDown += GridKeyDown;
		_grid.CurrentCellDirtyStateChanged += delegate
		{
			if (_grid.IsCurrentCellDirty)
			{
				_grid.CommitEdit(DataGridViewDataErrorContexts.Commit);
			}
		};
		_grid.CellValueChanged += delegate(object? _, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0)
			{
				UpdateCycleEstimate();
				SaveDefaultProfileQuietly();
			}
		};
		_grid.CellDoubleClick += delegate(object? _, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && _grid.Rows[e.RowIndex].DataBoundItem is WatchItem watchItem)
			{
				ToggleExpandRows(new WatchItem[1] { watchItem });
				UpdateCycleEstimate();
				SaveDefaultProfileQuietly();
			}
		};
		_grid.MouseDown += GridMouseDown;
		_grid.MouseUp += GridMouseUp;
		_grid.ContextMenuStrip = CreateGridWatchContextMenu();
		_grid.MouseMove += GridMouseMove;
		_grid.DragOver += GridDragOver;
		_grid.DragDrop += GridDragDrop;
		_grid.Visible = false;
		tableLayoutPanel.Controls.Add(BuildDataMirrorPanel(), 0, 2);
		panel.Controls.Add(tableLayoutPanel);
		UpdateCycleEstimate();
		return panel;
	}

	private Control BuildDataMirrorPanel()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _surface,
			Tag = "surface"
		};
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Padding = new Padding(0),
			BackColor = _surface
		};
		layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
		layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		_dataCodeTitle = new Label
		{
			Dock = DockStyle.Fill,
			Text = "跟随 3 看程序",
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(8, 0, 8, 0),
			ForeColor = _ink,
			BackColor = _gridHeader,
			Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold)
		};
		_visibleValuesLabel = new Label
		{
			Visible = false,
			Text = "可见变量：无",
		};
		_dataCodeBox = new FastCodeRichTextBox
		{
			Dock = DockStyle.Fill,
			ReadOnly = true,
			BorderStyle = BorderStyle.None,
			WordWrap = false,
			DetectUrls = false,
			HideSelection = false,
			BackColor = _surface,
			ForeColor = _ink,
			Font = new Font("Consolas", _functionCodeFontSize),
			ScrollBars = RichTextBoxScrollBars.Both
		};
		if (_dataCodeBox is FastCodeRichTextBox fastCodeBox)
		{
			fastCodeBox.ImmediateWheel += delegate
			{
				MarkUiWheelActivity();
			};
		}
		_dataCodeBox.MouseDown += CodeBoxMouseDown;
		_dataCodeBox.MouseUp += CodeBoxMouseUp;
		_dataCodeBox.MouseDoubleClick += CodeBoxMouseDoubleClick;
		_dataCodeBox.KeyDown += CodeBoxKeyDown;
		_dataCodeBox.ContextMenuStrip = CreateCodeWatchContextMenu(_dataCodeBox);
		EnableDoubleBuffer(_dataCodeBox);
		layout.Controls.Add(_dataCodeTitle, 0, 0);
		layout.Controls.Add(_dataCodeBox, 0, 1);
		panel.Controls.Add(layout);
		return panel;
	}

	private Control BuildBusinessPanel()
	{
		Panel panel = CardPanel();
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			RowCount = 6,
			Padding = new Padding(10)
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
		_programSearchResultsRow = new RowStyle(SizeType.Absolute, 0f);
		tableLayoutPanel.RowStyles.Add(_programSearchResultsRow);
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
		tableLayoutPanel.Controls.Add(SectionLabel("3 看程序"), 0, 0);
		TableLayoutPanel searchLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = new Padding(0),
			Padding = new Padding(1),
			BackColor = _gridHeader,
			Tag = "searchBar"
		};
		searchLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		searchLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 84f));
		searchLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 62f));
		_programSearchBox = new TextBox
		{
			Dock = DockStyle.Fill,
			PlaceholderText = "全局搜索函数/变量/代码",
			Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold),
			Margin = new Padding(0, 1, 4, 1)
		};
		StyleTextBox(_programSearchBox);
		_programSearchBox.Tag = "searchInput";
		_programSearchBox.BackColor = _surfaceAlt;
		_programSearchBox.KeyDown += ProgramSearchBoxKeyDown;
		Button searchButton = CommandButton("搜索");
		ApplyButtonStyle(searchButton, "search");
		searchButton.Size = new Size(78, 36);
		searchButton.Margin = new Padding(0, 1, 4, 1);
		searchButton.Click += delegate { RunProgramSearch(); };
		Button clearSearchButton = PlainButton("清空");
		clearSearchButton.Size = new Size(58, 32);
		clearSearchButton.Margin = new Padding(0, 3, 0, 3);
		clearSearchButton.Click += delegate
		{
			_programSearchBox.Clear();
			SetProgramSearchResultsVisible(false);
			_programSearchResults.Items.Clear();
			ClearProgramSearchHighlight();
		};
		searchLayout.Controls.Add(_programSearchBox, 0, 0);
		searchLayout.Controls.Add(searchButton, 1, 0);
		searchLayout.Controls.Add(clearSearchButton, 2, 0);
		_runtimeLocationLabel = new Label
		{
			Dock = DockStyle.Fill,
			Text = "MyLogic_1ms",
			ForeColor = _ink,
			BackColor = _surface,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(10, 0, 10, 0),
			Font = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Bold),
			Tag = "surface"
		};
		tableLayoutPanel.Controls.Add(_runtimeLocationLabel, 0, 1);
		_flowChart = new FlowChartView
		{
			Dock = DockStyle.Fill,
			Tag = "flowchart"
		};
		_flowChart.NodeClick += FlowChartNodeClick;
		_flowChart.NodeDoubleClick += FlowChartNodeClick;
		_programViewPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _surface,
			Tag = "surface"
		};
		_programSearchResults = new ListBox
		{
			Dock = DockStyle.Fill,
			Visible = false,
			IntegralHeight = false,
			BackColor = _surfaceAlt,
			ForeColor = _ink,
			BorderStyle = BorderStyle.FixedSingle,
			Font = new Font("Microsoft YaHei UI", 8.5f)
		};
		_programSearchResults.DoubleClick += ProgramSearchResultsDoubleClick;
		_programContentPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _surface,
			Tag = "surface"
		};
		_functionCodePanel = BuildFunctionCodePanel();
		_programContentPanel.Controls.Add(_flowChart);
		_programContentPanel.Controls.Add(_functionCodePanel);
		_programViewPanel.Controls.Add(_programContentPanel);
		_functionCodePanel.Visible = false;
		_flowChart.BringToFront();
		tableLayoutPanel.Controls.Add(_programViewPanel, 0, 2);
		tableLayoutPanel.Controls.Add(searchLayout, 0, 3);
		tableLayoutPanel.Controls.Add(_programSearchResults, 0, 4);
		_programSummaryLabel = SmallLabel("未生成图谱");
		_programSummaryLabel.Dock = DockStyle.Fill;
		tableLayoutPanel.Controls.Add(_programSummaryLabel, 0, 5);
		panel.Controls.Add(tableLayoutPanel);
		return panel;
	}

	private Panel BuildFunctionCodePanel()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _surface,
			Tag = "surface"
		};
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			Padding = new Padding(0),
			BackColor = _surface
		};
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 62f));
		layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 32f));
		layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		_functionCodeTitle = new Label
		{
			Dock = DockStyle.Fill,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(8, 0, 8, 0),
			ForeColor = _ink,
			BackColor = _gridHeader,
			Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold)
		};
		_functionBackButton = new Button
		{
			Dock = DockStyle.Fill,
			Text = "返回",
			FlatStyle = FlatStyle.Flat,
			BackColor = _button,
			ForeColor = _ink,
			Font = new Font("Microsoft YaHei UI", 8.5f),
			Tag = "button"
		};
		_functionBackButton.FlatAppearance.BorderColor = _gridHeader;
		_functionBackButton.Click += delegate
		{
			NavigateFunctionBack();
		};
		_functionCodeBox = new FastCodeRichTextBox
		{
			Dock = DockStyle.Fill,
			ReadOnly = true,
			BorderStyle = BorderStyle.None,
			WordWrap = false,
			DetectUrls = false,
			HideSelection = false,
			BackColor = _surface,
			ForeColor = _ink,
			Font = new Font("Consolas", _functionCodeFontSize),
			ScrollBars = RichTextBoxScrollBars.Both
		};
		if (_functionCodeBox is FastCodeRichTextBox fastCodeBox)
		{
			fastCodeBox.ControlMouseWheel += FunctionCodeBoxMouseWheel;
			fastCodeBox.ImmediateWheel += delegate
			{
				MarkUiWheelActivity();
			};
		}
		_functionCodeBox.MouseDown += CodeBoxMouseDown;
		_functionCodeBox.MouseUp += CodeBoxMouseUp;
		_functionCodeBox.MouseClick += FunctionCodeBoxMouseClick;
		_functionCodeBox.MouseDoubleClick += CodeBoxMouseDoubleClick;
		_functionCodeBox.MouseMove += FunctionCodeBoxMouseMove;
		_functionCodeBox.SelectionChanged += FunctionCodeBoxSelectionChanged;
		_functionCodeBox.KeyDown += CodeBoxKeyDown;
		_functionCodeBox.ContextMenuStrip = CreateCodeWatchContextMenu(_functionCodeBox);
		_functionCodeBox.VScroll += delegate
		{
			MarkUiWheelActivity();
			ScheduleVisibleDataRefreshAfterScroll();
		};
		_functionCodeBox.MouseWheel += delegate
		{
			MarkUiWheelActivity();
			ScheduleVisibleDataRefreshAfterScroll();
		};
		_functionCodeBox.MouseLeave += delegate
		{
			if (_functionCodeBox != null)
			{
				ClearFunctionHoverCache();
				_functionCodeBox.Cursor = Cursors.IBeam;
			}
		};
		EnableDoubleBuffer(_functionCodeBox);
		layout.Controls.Add(_functionCodeTitle, 0, 0);
		layout.Controls.Add(_functionBackButton, 1, 0);
		layout.Controls.Add(_functionCodeBox, 0, 1);
		layout.SetColumnSpan(_functionCodeBox, 2);
		panel.Controls.Add(layout);
		return panel;
	}

	private ListView CreateDenseListView()
	{
		ListView obj = new ListView
		{
			Dock = DockStyle.Fill,
			View = View.Details,
			FullRowSelect = true,
			GridLines = false,
			BorderStyle = BorderStyle.None,
			HeaderStyle = ColumnHeaderStyle.Nonclickable,
			BackColor = _surface,
			ForeColor = _ink,
			Font = new Font("Microsoft YaHei UI", 8.5f),
			Tag = "list"
		};
		EnableDoubleBuffer(obj);
		return obj;
	}

	private Control BuildLogArea()
	{
		Panel panel = CardPanel();
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			RowCount = 2,
			Padding = new Padding(14, 10, 14, 14)
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 24f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.Controls.Add(SectionLabel("日志"), 0, 0);
		_logBox = new TextBox
		{
			Dock = DockStyle.Fill,
			Multiline = true,
			ReadOnly = true,
			ScrollBars = ScrollBars.Vertical,
			BackColor = _surface,
			ForeColor = _ink,
			BorderStyle = BorderStyle.None,
			Font = new Font("Consolas", 9f),
			Tag = "input"
		};
		tableLayoutPanel.Controls.Add(_logBox, 0, 1);
		panel.Controls.Add(tableLayoutPanel);
		return panel;
	}

	private void BrowseProjectDirectory()
	{
		using FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
		{
			Description = "请选择 Keil 工程目录",
			UseDescriptionForTitle = true
		};
		if (folderBrowserDialog.ShowDialog(this) == DialogResult.OK)
		{
			SetWorkDirectory(folderBrowserDialog.SelectedPath, loadMap: true);
		}
	}

	private Task RefreshMapAsync()
	{
		DateTime now = DateTime.UtcNow;
		if (_refreshMapBusy || (now - _lastManualRefreshUtc).TotalMilliseconds < ManualRefreshThrottleMs)
		{
			Log("刷新请求已合并，正在处理当前工作目录。");
			return Task.CompletedTask;
		}

		_refreshMapBusy = true;
		_lastManualRefreshUtc = now;
		if (_refreshButton != null)
		{
			_refreshButton.Enabled = false;
			_refreshButton.Text = "刷新中";
			ApplyButtonStyle(_refreshButton, "working");
		}

		Stopwatch stopwatch = Stopwatch.StartNew();
		try
		{
			string workDirectoryFromUi = GetWorkDirectoryFromUi();
			if (workDirectoryFromUi.Length == 0)
			{
				Log("请选择工作目录。");
			}
			else if (Directory.Exists(workDirectoryFromUi))
			{
				ClearOfflineSimulationProgramCache();
				SetWorkDirectory(workDirectoryFromUi, loadMap: false);
				ClearFunctionIndex();
				LoadLatestMapFromDirectory(workDirectoryFromUi);
				UpdateFirmwareVersionDisplay();
				RefreshCurrentFunctionSourceFromDisk(logResult: true);
				RefreshProgramGraphPanel(workDirectoryFromUi, force: true);
				WarmFunctionIndex(workDirectoryFromUi);
				LogPerformance("刷新完成：已重新读取当前工作目录", stopwatch);
			}
			else if (File.Exists(workDirectoryFromUi))
			{
				ClearOfflineSimulationProgramCache();
				_mapFilePath = workDirectoryFromUi;
				_workDirectory = Path.GetDirectoryName(workDirectoryFromUi) ?? "";
				_mapPathBox.Text = _workDirectory;
				LoadMapFile(workDirectoryFromUi);
				if (_workDirectory.Length > 0 && Directory.Exists(_workDirectory))
				{
					ClearFunctionIndex();
					UpdateFirmwareVersionDisplay();
					RefreshCurrentFunctionSourceFromDisk(logResult: true);
					RefreshProgramGraphPanel(_workDirectory, force: true);
					WarmFunctionIndex(_workDirectory);
					LogPerformance("刷新完成：已重新读取当前工作目录", stopwatch);
				}
			}
			else
			{
				Log("工作目录不存在：" + workDirectoryFromUi);
			}
		}
		finally
		{
			_refreshMapBusy = false;
			if (_refreshButton != null && !_refreshButton.IsDisposed)
			{
				_refreshButton.Text = "刷新";
				_refreshButton.Enabled = true;
				ApplyButtonStyle(_refreshButton, "refresh");
			}
		}
		return Task.CompletedTask;
	}

	private void SetWorkDirectory(string directory, bool loadMap)
	{
		bool directoryChanged = !_workDirectory.Equals(directory, StringComparison.OrdinalIgnoreCase);
		if (directoryChanged)
		{
			ClearOfflineSimulationProgramCache();
			ClearFunctionIndex();
			_mapFilePath = "";
			_mapLastWrite = default(DateTime);
			_symbols.Clear();
			_symbolLookup.Clear();
			_symbolBaseLookup.Clear();
			_symbolTailLookup.Clear();
			_suggestions?.Items.Clear();
			if (_symbolCountLabel != null)
			{
				_symbolCountLabel.Text = "未读取";
			}
			_programGraphSnapshot = null;
			_lastProgramInsightSignature = "";
			UpdateProgramInsightPanel(force: true);
		}
		_workDirectory = directory;
		_mapPathBox.Text = directory;
		UpdateFirmwareVersionDisplay();
		Log("工作目录：" + directory);
		SaveDefaultProfileQuietly();
		if (loadMap)
		{
			LoadLatestMapFromDirectory(directory);
			RefreshProgramGraphPanel(directory);
		}
		if (directoryChanged || loadMap)
		{
			WarmFunctionIndex(directory);
		}
	}

	private string GetWorkDirectoryFromUi()
	{
		string text = _mapPathBox.Text.Trim('"', ' ');
		if (text.Length > 0 && (Directory.Exists(text) || File.Exists(text)))
		{
			return text;
		}
		if (_workDirectory.Length > 0 && Directory.Exists(_workDirectory))
		{
			return _workDirectory;
		}
		return text;
	}

	private void LoadLatestMapFromDirectory(string directory)
	{
		string text = FindLatestAxfFile(directory);
		if (text != null)
		{
			if (KeilAxfParser.TryParse(text, out List<MapSymbol> symbols, out string message))
			{
				_symbols = symbols;
				RebuildSymbolIndexes();
				RefreshWatchMetadataFromSymbols();
				_mapFilePath = text;
				_mapLastWrite = File.GetLastWriteTimeUtc(text);
				_symbolCountLabel.Text = $"已读取 {_symbols.Count} 个 RAM 变量";
				Log(message);
				SaveDefaultProfileQuietly();
				RefreshSuggestions();
				return;
			}
			Log("AXF 调试信息读取失败，改用 map：" + message);
		}
		string text2 = FindLatestMapFile(directory);
		if (text2 == null)
		{
			Log("没有找到 .map 文件，请先编译 Keil 工程。");
			return;
		}
		_mapFilePath = text2;
		LoadMapFile(text2);
	}

	private void LoadMapFromTextBox()
	{
		string text = _mapPathBox.Text.Trim('"', ' ');
		if (text.Length == 0)
		{
			Log("请选择变量文件。");
			return;
		}
		if (Directory.Exists(text))
		{
			LoadLatestMapFromDirectory(text);
			return;
		}
		_mapFilePath = text;
		_workDirectory = Path.GetDirectoryName(text) ?? "";
		_mapPathBox.Text = _workDirectory;
		LoadMapFile(text);
	}

	private void LoadMapFile(string path)
	{
		try
		{
			if (Path.GetExtension(path).Equals(".axf", StringComparison.OrdinalIgnoreCase))
			{
				if (!KeilAxfParser.TryParse(path, out List<MapSymbol> symbols, out string message))
				{
					throw new InvalidOperationException(message);
				}
				_symbols = symbols;
				Log(message);
			}
			else
			{
				_symbols = KeilMapParser.Parse(path);
				Log($"变量文件已读取：{Path.GetFileName(path)}，RAM 变量 {_symbols.Count} 个。");
			}
			RebuildSymbolIndexes();
			RefreshWatchMetadataFromSymbols();
			_mapLastWrite = File.GetLastWriteTimeUtc(path);
			_symbolCountLabel.Text = $"已读取 {_symbols.Count} 个 RAM 变量";
			SaveDefaultProfileQuietly();
			RefreshSuggestions();
			ScheduleMemoryTrim();
		}
		catch (Exception ex)
		{
			Log("读取变量文件失败：" + ex.Message);
		}
	}

	private void RebuildSymbolIndexes()
	{
		_symbolLookup = _symbols.ToDictionary(s => s.Name, StringComparer.OrdinalIgnoreCase);
		_symbolBaseLookup = new Dictionary<string, MapSymbol>(StringComparer.OrdinalIgnoreCase);
		var tailCandidates = new Dictionary<string, MapSymbol?>(StringComparer.OrdinalIgnoreCase);
		foreach (MapSymbol symbol in _symbols.OrderBy(s => s.Name.Length))
		{
			string baseName = GetIdentifierBase(symbol.Name);
			if (baseName.Length > 0 && !_symbolBaseLookup.ContainsKey(baseName))
			{
				_symbolBaseLookup[baseName] = symbol;
			}

			string tailName = GetIdentifierTail(symbol.Name);
			if (tailName.Length == 0)
			{
				continue;
			}
			if (!tailCandidates.ContainsKey(tailName))
			{
				tailCandidates[tailName] = symbol;
			}
			else
			{
				tailCandidates[tailName] = null;
			}
		}
		_symbolTailLookup = tailCandidates
			.Where(pair => pair.Value != null)
			.ToDictionary(pair => pair.Key, pair => pair.Value!, StringComparer.OrdinalIgnoreCase);
	}

	private void RefreshWatchMetadataFromSymbols()
	{
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (WatchItem watchItem2 in _watchItems)
		{
			if (watchItem2.IsChild)
			{
				continue;
			}
			string key = watchItem2.Name;
			uint result = 0u;
			int num = watchItem2.Name.IndexOf('+', StringComparison.Ordinal);
			if (num > 0)
			{
				key = watchItem2.Name.Substring(0, num);
				string name = watchItem2.Name;
				int num2 = num + 1;
				if (!uint.TryParse(name.Substring(num2, name.Length - num2), out result))
				{
					result = 0u;
				}
			}
			if (_symbolLookup.TryGetValue(key, out MapSymbol value))
			{
				int num3 = Math.Max(1, value.Size - (int)result);
				watchItem2.Address = value.Address + result;
				watchItem2.Size = num3;
				watchItem2.TotalSize = num3;
				watchItem2.TypeName = value.TypeName;
				watchItem2.IsExpandable = result == 0 && KeilMapParser.IsExpandable(value, _symbols);
				ResetTransientWatchState(watchItem2);
				if (!watchItem2.IsExpandable)
				{
					watchItem2.ExpandMode = "";
					hashSet.Add(watchItem2.Name);
				}
			}
		}
		if (hashSet.Count > 0)
		{
			for (int num4 = _watchItems.Count - 1; num4 >= 0; num4--)
			{
				WatchItem watchItem = _watchItems[num4];
				if (watchItem.IsChild && hashSet.Contains(watchItem.ParentName))
				{
					_watchItems.RemoveAt(num4);
				}
			}
		}
		_source.ResetBindings(metadataChanged: false);
	}

	private void CheckMapReload()
	{
		if (_mapFilePath.Length != 0 && File.Exists(_mapFilePath))
		{
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(_mapFilePath);
			if (_mapLastWrite != default(DateTime) && lastWriteTimeUtc > _mapLastWrite)
			{
				Log("检测到变量文件更新，自动重新读取。");
				LoadMapFile(_mapFilePath);
				if (_workDirectory.Length > 0 && Directory.Exists(_workDirectory))
				{
					RefreshProgramGraphPanel(_workDirectory);
				}
			}
		}
	}

	private void CheckProgramGraphReload()
	{
		if (_programGraphCheckPending || _workDirectory.Length == 0 || !Directory.Exists(_workDirectory))
		{
			return;
		}
		DateTime now = DateTime.UtcNow;
		if ((now - _programGraphLastCheckUtc).TotalSeconds < 8)
		{
			return;
		}
		_programGraphLastCheckUtc = now;
		_programGraphCheckPending = true;
		string root = _workDirectory;
		Task.Run(() =>
		{
			DateTime latestWrite = GetLatestSourceWriteUtc(root, out int sourceCount);
			return (Root: root, LatestWrite: latestWrite, SourceCount: sourceCount);
		}).ContinueWith(task =>
		{
			if (IsDisposed)
			{
				return;
			}
			try
			{
				BeginInvoke((Action)(() =>
				{
					_programGraphCheckPending = false;
					if (task.Status != TaskStatus.RanToCompletion ||
						!_workDirectory.Equals(task.Result.Root, StringComparison.OrdinalIgnoreCase) ||
						task.Result.SourceCount == 0)
					{
						return;
					}
					if (_programGraphLastSourceWrite == default(DateTime))
					{
						_programGraphLastSourceWrite = task.Result.LatestWrite;
						_programGraphSourceCount = task.Result.SourceCount;
						return;
					}
					if (task.Result.LatestWrite > _programGraphLastSourceWrite || task.Result.SourceCount != _programGraphSourceCount)
					{
						Log("检测到源码变化，自动刷新程序框架。");
						ClearFunctionIndex();
						RefreshCurrentFunctionSourceFromDisk(logResult: false);
						RefreshProgramGraphPanel(_workDirectory, force: true);
					}
				}));
			}
			catch
			{
				_programGraphCheckPending = false;
			}
		}, TaskScheduler.Default);
	}

	private static DateTime GetLatestSourceWriteUtc(string root, out int sourceCount)
	{
		sourceCount = 0;
		DateTime latest = default(DateTime);
		var ignored = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
		{
			".git", ".svn", ".vs", "bin", "obj", "Debug", "Release", "Listings", "Objects", "RTE", "__pycache__"
		};
		var pending = new Stack<string>();
		pending.Push(root);
		while (pending.Count > 0)
		{
			string directory = pending.Pop();
			IEnumerable<string> children;
			try
			{
				children = Directory.EnumerateDirectories(directory);
			}
			catch
			{
				continue;
			}
			foreach (string child in children)
			{
				if (!ignored.Contains(Path.GetFileName(child), StringComparer.OrdinalIgnoreCase))
				{
					pending.Push(child);
				}
			}
			IEnumerable<string> files;
			try
			{
				files = Directory.EnumerateFiles(directory);
			}
			catch
			{
				continue;
			}
			foreach (string file in files)
			{
				string extension = Path.GetExtension(file);
				if (!extension.Equals(".c", StringComparison.OrdinalIgnoreCase) &&
					!extension.Equals(".h", StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				sourceCount++;
				DateTime write = File.GetLastWriteTimeUtc(file);
				if (write > latest)
				{
					latest = write;
				}
			}
		}
		return latest;
	}

	private void RefreshSuggestions()
	{
		if (_suggestions == null || _variableBox == null || !_suggestions.Visible)
		{
			return;
		}
		_suggestions.BeginUpdate();
		_suggestions.Items.Clear();
		foreach (MapSymbol item in FuzzyMatcher.Search(_symbols, _variableBox.Text))
		{
			_suggestions.Items.Add(new Suggestion(item));
		}
		_suggestions.EndUpdate();
	}

	private void ScheduleRefreshSuggestions()
	{
		if (_suggestionTimer == null)
		{
			RefreshSuggestions();
			return;
		}
		_suggestionTimer.Stop();
		_suggestionTimer.Start();
	}

	private void AddTypedVariable()
	{
		string text = _variableBox.Text.Trim();
		if (text.Length == 0 && _suggestions.SelectedItem is Suggestion suggestion)
		{
			text = suggestion.Symbol.Name;
		}
		if (text.Length == 0 && _suggestions.Items.Count > 0)
		{
			text = ((Suggestion)_suggestions.Items[0]).Symbol.Name;
		}
		AddVariableText(text);
	}

	private void AddSelectedSuggestion()
	{
		if (_suggestions.SelectedItem is Suggestion suggestion)
		{
			AddVariableText(suggestion.Symbol.Name);
		}
	}

	private void AddVariableText(string text)
	{
		WatchItem item;
		string error;
		if (KeilMapParser.TryResolve(text, _symbolLookup, out item, out error))
		{
			if (_watchItems.Any((WatchItem x) => x.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase)))
			{
				Log("变量已存在：" + item.Name);
				return;
			}
			if (!EnsureWatchCapacityForCurrentContext(out int removed))
			{
				Log($"已达到 {MaxWatchItems} 个变量上限，当前窗口没有可让出的变量。");
				return;
			}
			if (removed > 0)
			{
				Log($"当前窗口变量优先：已移出 {removed} 个不可见变量。");
			}
			item.AutoVisible = false;
			_watchItems.Add(item);
			UpdateCycleEstimate();
			SaveDefaultProfileQuietly();
			MarkFunctionCodeDirty();
			FocusVariableAcrossPanels(GetWatchDisplayName(item), updateSearchBox: true);
			Log($"添加变量：{item.Name}，{item.Size} 字节。");
		}
		else
		{
			Log($"添加失败：{text}，{error}。");
		}
	}

	private void AutoWatchVariablesForFunction(FunctionSourceView sourceView)
	{
		if (_symbolLookup.Count == 0 || sourceView.Lines.Count == 0)
		{
			return;
		}

		List<string> lines = sourceView.Lines.ToList();
		List<string> identifiers = BuildFunctionAutoWatchIdentifiers(lines);
		if (identifiers.Count == 0)
		{
			return;
		}

		var functionIdentifiers = identifiers.ToHashSet(StringComparer.OrdinalIgnoreCase);
		var existing = BuildExistingWatchAliasSet();
		int currentFunctionCount = _watchItems.Count(item => item.Enabled && IsWatchVisibleInRange(item, functionIdentifiers, lines));
		int added = 0;
		int removed = 0;
		foreach (string identifier in identifiers)
		{
			if (IsWatchCapacityLimited() && currentFunctionCount >= CurrentFunctionWatchTargetLimit)
			{
				break;
			}
			if (existing.Contains(identifier))
			{
				continue;
			}
			if (!TryResolveSourceIdentifierToWatchItem(identifier, existing, out WatchItem item, out string matchedName))
			{
				continue;
			}
			int removedNow = 0;
			if (IsWatchCapacityLimited() && !EnsureWatchCapacityForVisibleRange(functionIdentifiers, lines, out removedNow))
			{
				break;
			}
			if (removedNow > 0)
			{
				removed += removedNow;
				existing = BuildExistingWatchAliasSet();
				if (existing.Contains(identifier))
				{
					continue;
				}
			}

			item.AutoVisible = true;
			_watchItems.Add(item);
			AddWatchAliases(existing, item.Name);
			existing.Add(matchedName);
			added++;
			currentFunctionCount++;
		}

		if (added > 0 || removed > 0)
		{
			UpdateCycleEstimate();
			_lastVisibleValuesText = "";
			_lastDataCodeText = "";
			if (removed > 0)
			{
				Log($"当前函数联动：已移出 {removed} 个无关变量。");
			}
		}
	}

	private void RemoveSelectedRows()
	{
		List<WatchItem> selectedWatchItems = GetSelectedWatchItems();
		foreach (WatchItem item in selectedWatchItems)
		{
			RemoveWatchItem(item);
		}
		if (selectedWatchItems.Count > 0)
		{
			UpdateCycleEstimate();
			SaveDefaultProfileQuietly();
			MarkFunctionCodeDirty();
		}
	}

	private void GridCellContentClick(object? sender, DataGridViewCellEventArgs e)
	{
		if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && _grid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && _grid.Rows[e.RowIndex].DataBoundItem is WatchItem item)
		{
			RemoveWatchItem(item);
			UpdateCycleEstimate();
			SaveDefaultProfileQuietly();
			MarkFunctionCodeDirty();
		}
	}

	private void GridSelectionChanged(object? sender, EventArgs e)
	{
		if (_grid == null || _grid.CurrentRow?.DataBoundItem is not WatchItem item)
		{
			return;
		}

		string name = GetWatchDisplayName(item);
		FocusVariableAcrossPanels(name.Length > 0 ? name : item.Name, updateSearchBox: true);
		if (_forceValueBox != null && !_forceValueBox.Focused)
		{
			_forceValueBox.Text = item.ValueDec.Length > 0 ? item.ValueDec : item.DisplayValue;
		}
	}

	private void GridKeyDown(object? sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.C)
		{
			List<string> list = (from item in GetSelectedWatchItems()
				orderby _watchItems.IndexOf(item)
				select item.Name into name
				where !string.IsNullOrWhiteSpace(name)
				select name).Distinct<string>(StringComparer.OrdinalIgnoreCase).ToList();
			if (list.Count == 0 && _grid.CurrentRow?.DataBoundItem is WatchItem watchItem)
			{
				list.Add(watchItem.Name);
			}
			if (list.Count > 0)
			{
				Clipboard.SetText(string.Join(Environment.NewLine, list));
			}
			e.SuppressKeyPress = true;
			e.Handled = true;
		}
	}

	private void RemoveWatchItem(WatchItem item)
	{
		if (!item.IsChild)
		{
			for (int num = _watchItems.Count - 1; num >= 0; num--)
			{
				if (_watchItems[num].IsChild && _watchItems[num].ParentName.Equals(item.Name, StringComparison.OrdinalIgnoreCase))
				{
					_watchItems.RemoveAt(num);
				}
			}
		}
		_watchItems.Remove(item);
	}

	private void ExpandSelected()
	{
		ToggleExpandRows(GetSelectedWatchItems());
	}

	private List<WatchItem> GetSelectedWatchItems()
	{
		List<WatchItem> list = (from DataGridViewRow r in _grid.SelectedRows
			select r.DataBoundItem as WatchItem into x
			where x != null
			select x).Cast<WatchItem>().ToList();
		if (list.Count == 0 && _grid.CurrentRow?.DataBoundItem is WatchItem item)
		{
			list.Add(item);
		}
		return list.DistinctBy<WatchItem, string>((WatchItem x) => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
	}

	private void ToggleExpandRows(IEnumerable<WatchItem> selected)
	{
		List<WatchItem> list = (from x in selected.Select(GetExpandableParent)
			where x?.IsExpandable ?? false
			select x).Cast<WatchItem>().DistinctBy<WatchItem, string>((WatchItem x) => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
		if (list.Count == 0)
		{
			Log("请选择数组或结构体变量再展开。");
			return;
		}
		bool flag = false;
		foreach (WatchItem item in list)
		{
			if (HasChildRows(item.Name))
			{
				RemoveChildRows(item.Name);
				item.ExpandMode = "";
				flag = true;
			}
			else
			{
				bool flag2 = ExpandWatchFields(item);
				if (!flag2)
				{
					ExpandWatchItem(item, GuessExpandUnit(item));
					flag2 = HasChildRows(item.Name);
				}
				flag = flag || flag2;
			}
		}
		if (!flag)
		{
			Log("没有可展开的子项。");
			return;
		}
		UpdateCycleEstimate();
		SaveDefaultProfileQuietly();
	}

	private void ExpandRows(IEnumerable<WatchItem> selected, int unitSize)
	{
		List<WatchItem> list = (from x in selected.Select(GetExpandableParent)
			where x?.IsExpandable ?? false
			select x).Cast<WatchItem>().DistinctBy<WatchItem, string>((WatchItem x) => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
		if (list.Count == 0)
		{
			Log("请选择数组或结构体变量再展开。");
			return;
		}
		bool flag = false;
		foreach (WatchItem item in list)
		{
			if (unitSize == 0)
			{
				bool flag2 = ExpandWatchFields(item);
				if (!flag2)
				{
					ExpandWatchItem(item, GuessExpandUnit(item));
					flag2 = true;
				}
				flag = flag || flag2;
			}
			else
			{
				ExpandWatchItem(item, unitSize);
				flag = true;
			}
		}
		if (!flag)
		{
			Log("没有可展开的子项。");
			return;
		}
		UpdateCycleEstimate();
		SaveDefaultProfileQuietly();
	}

	private WatchItem? GetExpandableParent(WatchItem item)
	{
		WatchItem item2 = item;
		if (!item2.IsChild)
		{
			return item2;
		}
		return _watchItems.FirstOrDefault((WatchItem x) => !x.IsChild && x.Name.Equals(item2.ParentName, StringComparison.OrdinalIgnoreCase));
	}

	private int GuessExpandUnit(WatchItem parent)
	{
		string key = parent.Name.Split('+')[0];
		if (_symbolLookup.TryGetValue(key, out MapSymbol value))
		{
			string typeName = value.TypeName;
			if (typeName.Contains("short", StringComparison.OrdinalIgnoreCase) || typeName.Contains("uint16", StringComparison.OrdinalIgnoreCase) || typeName.Contains("int16", StringComparison.OrdinalIgnoreCase))
			{
				return 2;
			}
		}
		return 1;
	}

	private bool ExpandWatchFields(WatchItem parent)
	{
		WatchItem parent2 = parent;
		if (_watchItems.IndexOf(parent2) < 0)
		{
			return false;
		}
		string fieldPrefix = parent2.Name + ".";
		string arrayPrefix = parent2.Name + "[";
		uint parentEnd = parent2.Address + (uint)Math.Max(parent2.TotalSize, parent2.Size);
		List<MapSymbol> list = (from s in _symbols.Where((MapSymbol s) => (s.Name.StartsWith(fieldPrefix, StringComparison.OrdinalIgnoreCase) || s.Name.StartsWith(arrayPrefix, StringComparison.OrdinalIgnoreCase)) && s.Address >= parent2.Address && s.Address < parentEnd).Where(delegate(MapSymbol s)
			{
				string text;
				if (!s.Name.StartsWith(fieldPrefix, StringComparison.OrdinalIgnoreCase))
				{
					string name = s.Name;
					int length = parent2.Name.Length;
					text = name.Substring(length, name.Length - length);
				}
				else
				{
					string name = s.Name;
					int length = fieldPrefix.Length;
					text = name.Substring(length, name.Length - length);
				}
				string text2 = text;
				return text2.Length > 0 && !text2.Contains('.');
			})
			orderby s.Address
			select s).ToList();
		if (list.Count == 0)
		{
			return false;
		}
		RemoveChildRows(parent2.Name);
		parent2.ExpandMode = "fields";
		int num = _watchItems.IndexOf(parent2) + 1;
		int num2 = IsWatchCapacityLimited() ? Math.Max(0, MaxWatchItems - _watchItems.Count) : int.MaxValue;
		int num3 = 0;
		foreach (MapSymbol item in list)
		{
			if (num3 >= num2)
			{
				if (IsWatchCapacityLimited())
				{
					Log($"已展开到 {MaxWatchItems} 个监控变量上限。");
				}
				break;
			}
			_watchItems.Insert(num + num3, new WatchItem
			{
				Enabled = parent2.Enabled,
				Name = item.Name,
				Address = item.Address,
				Size = item.Size,
				TotalSize = item.Size,
				TypeName = item.TypeName,
				IsExpandable = KeilMapParser.IsExpandable(item, _symbols),
				IsChild = true,
				ParentName = parent2.Name,
				Status = "待读取"
			});
			num3++;
		}
		return num3 > 0;
	}

	private void ExpandWatchItem(WatchItem parent, int unitSize)
	{
		if (_watchItems.IndexOf(parent) < 0)
		{
			return;
		}
		RemoveChildRows(parent.Name);
		parent.ExpandMode = ((unitSize == 1) ? "byte" : "word");
		int num = _watchItems.IndexOf(parent) + 1;
		int num2 = IsWatchCapacityLimited() ? Math.Max(0, MaxWatchItems - _watchItems.Count) : int.MaxValue;
		int num3 = 0;
		for (int i = 0; i < parent.TotalSize; i += unitSize)
		{
			if (num3 >= num2)
			{
				break;
			}
			int num4 = Math.Min(unitSize, parent.TotalSize - i);
			string name = ((num4 == 2) ? $"{parent.Name}[{i}..{i + 1}]" : $"{parent.Name}[{i}]");
			_watchItems.Insert(num + num3, new WatchItem
			{
				Enabled = parent.Enabled,
				Name = name,
				Address = parent.Address + (uint)i,
				Size = num4,
				TotalSize = num4,
				TypeName = parent.TypeName,
				IsChild = true,
				ParentName = parent.Name,
				Status = "待读取"
			});
			num3++;
		}
		if (num3 == 0)
		{
			Log("没有可展开的子项。");
		}
		else if (IsWatchCapacityLimited() && num3 * unitSize < parent.TotalSize)
		{
			Log($"已展开到 {MaxWatchItems} 个监控变量上限。");
		}
	}

	private bool HasChildRows(string parentName)
	{
		return _watchItems.Any((WatchItem x) => x.IsChild && x.ParentName.Equals(parentName, StringComparison.OrdinalIgnoreCase));
	}

	private void RemoveChildRows(string parentName)
	{
		for (int num = _watchItems.Count - 1; num >= 0; num--)
		{
			if (_watchItems[num].IsChild && _watchItems[num].ParentName.Equals(parentName, StringComparison.OrdinalIgnoreCase))
			{
				_watchItems.RemoveAt(num);
			}
		}
	}

	private void CollapseSelectedRows()
	{
		HashSet<string> hashSet = (from x in (from DataGridViewRow r in _grid.SelectedRows
				select r.DataBoundItem as WatchItem into x
				where x != null
				select x).Cast<WatchItem>().ToList()
			select (!x.IsChild) ? x.Name : x.ParentName into x
			where x.Length > 0
			select x).Distinct<string>(StringComparer.OrdinalIgnoreCase).ToHashSet<string>(StringComparer.OrdinalIgnoreCase);
		if (hashSet.Count == 0 && _grid.CurrentRow?.DataBoundItem is WatchItem item)
		{
			hashSet.Add(item.IsChild ? item.ParentName : item.Name);
		}
		if (hashSet.Count == 0)
		{
			return;
		}
		for (int num = _watchItems.Count - 1; num >= 0; num--)
		{
			WatchItem watchItem = _watchItems[num];
			if (watchItem.IsChild && hashSet.Contains(watchItem.ParentName))
			{
				_watchItems.RemoveAt(num);
			}
			else if (!watchItem.IsChild && hashSet.Contains(watchItem.Name))
			{
				watchItem.ExpandMode = "";
			}
		}
		UpdateCycleEstimate();
		SaveDefaultProfileQuietly();
	}

	private void GridMouseDown(object? sender, MouseEventArgs e)
	{
		DataGridView.HitTestInfo hitTestInfo = _grid.HitTest(e.X, e.Y);
		if (e.Button == MouseButtons.Right)
		{
			_dragRowIndex = -1;
			ShowGridWatchContextMenu(e.Location);
			return;
		}

		_dragRowIndex = e.Button == MouseButtons.Left && hitTestInfo.RowIndex >= 0 ? hitTestInfo.RowIndex : -1;
	}

	private void GridMouseUp(object? sender, MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Right)
		{
			ShowGridWatchContextMenu(e.Location);
		}
	}

	private ContextMenuStrip CreateGridWatchContextMenu()
	{
		ContextMenuStrip menu = new ContextMenuStrip();
		menu.Opening += delegate(object? sender, CancelEventArgs e)
		{
			e.Cancel = true;
			if (ShouldSuppressAutomaticWatchContextMenu(_grid))
			{
				return;
			}
			ShowGridWatchContextMenu(_grid.PointToClient(Cursor.Position));
		};
		return menu;
	}

	private void ShowGridWatchContextMenu(Point location)
	{
		DataGridView.HitTestInfo hitTestInfo = _grid.HitTest(location.X, location.Y);
		if (hitTestInfo.RowIndex >= 0 && hitTestInfo.RowIndex < _grid.Rows.Count && _grid.Rows[hitTestInfo.RowIndex].DataBoundItem is WatchItem item)
		{
			_grid.ClearSelection();
			_grid.Rows[hitTestInfo.RowIndex].Selected = true;
			int columnIndex = hitTestInfo.ColumnIndex >= 0 ? hitTestInfo.ColumnIndex : 0;
			if (_grid.Columns.Count > 0)
			{
				_grid.CurrentCell = _grid.Rows[hitTestInfo.RowIndex].Cells[Math.Min(columnIndex, _grid.Columns.Count - 1)];
			}
			ShowWatchContextMenu(item, item.Name, _grid, location);
			return;
		}

		ShowWatchContextMenu(null, "", _grid, location);
	}

	private void GridMouseMove(object? sender, MouseEventArgs e)
	{
		if ((e.Button & MouseButtons.Left) == MouseButtons.Left && _dragRowIndex >= 0)
		{
			_grid.DoDragDrop(_grid.Rows[_dragRowIndex], DragDropEffects.Move);
		}
	}

	private void GridDragOver(object? sender, DragEventArgs e)
	{
		e.Effect = DragDropEffects.Move;
	}

	private void GridDragDrop(object? sender, DragEventArgs e)
	{
		if (_dragRowIndex < 0 || _dragRowIndex >= _watchItems.Count)
		{
			return;
		}
		Point point = _grid.PointToClient(new Point(e.X, e.Y));
		int num = _grid.HitTest(point.X, point.Y).RowIndex;
		if (num < 0)
		{
			num = _watchItems.Count - 1;
		}
		if (num != _dragRowIndex)
		{
			WatchItem item = _watchItems[_dragRowIndex];
			_watchItems.RemoveAt(_dragRowIndex);
			if (num > _dragRowIndex)
			{
				num--;
			}
			num = Math.Clamp(num, 0, _watchItems.Count);
			_watchItems.Insert(num, item);
			_grid.ClearSelection();
			if (num < _grid.Rows.Count)
			{
				_grid.Rows[num].Selected = true;
			}
			SaveDefaultProfileQuietly();
			_dragRowIndex = -1;
		}
	}

	private void UpdateCycleEstimate()
	{
		if (_cycleEstimateLabel != null)
		{
			int num = _watchItems.Count((WatchItem x) => x.Enabled);
			if (num == 0)
			{
				_cycleEstimateLabel.Text = "无变量";
				return;
			}
			int num2 = Math.Max(10, _targetCycleMs);
			_cycleEstimateLabel.Text = $"{num} 项 / {num2}ms";
		}
	}

	private void ToggleConnect()
	{
		if (_offlineSimulation)
		{
			StopOfflineSimulation();
		}

		if (_adapter != null)
		{
			StopPolling(waitForExit: true);
			_adapter.Dispose();
			_adapter = null;
			_monitorSessionOpen = false;
			ResetCanHealthCounters();
			_connectButton.Text = "连接";
			ApplyButtonStyle(_connectButton, "connect");
			_statusLabel.Text = "未连接";
			_statusLabel.BackColor = _statusOff;
			Log("CAN 已断开。");
			WriteConnectionState("未连接");
			return;
		}
		try
		{
			if (!CanAdapterFactory.TryOpenAvailable(out ICanAdapter adapter, out string message, preferredName: _preferredAdapterName))
			{
				_connectButton.Text = "连接";
				ApplyButtonStyle(_connectButton, "connect");
				_statusLabel.Text = "未连接";
				_statusLabel.BackColor = _statusOff;
				Log("未连接：" + message);
				WriteConnectionState("未连接：" + message);
				return;
			}
			if (adapter == null)
			{
				throw new InvalidOperationException("未检测到 CAN 工具");
			}
			_adapter = adapter;
			ResetCanHealthCounters();
			_connectButton.Text = "断开";
			ApplyButtonStyle(_connectButton, "waiting");
			MarkWaitingForControllerResponse(adapter);
			if (!_running)
			{
				StartPolling();
			}
		}
		catch (Exception ex)
		{
			_adapter?.Dispose();
			_adapter = null;
			_monitorSessionOpen = false;
			ResetCanHealthCounters();
			_connectButton.Text = "连接";
			ApplyButtonStyle(_connectButton, "connect");
			Log("连接失败：" + ex.Message);
			WriteConnectionState("连接失败：" + ex);
		}
	}

	private void ToggleOfflineSimulation()
	{
		if (_offlineSimulation)
		{
			StopOfflineSimulation();
			return;
		}

		StopPolling(waitForExit: true, sendCloseFrame: false);
		_adapter?.Dispose();
		_adapter = null;
		_monitorSessionOpen = true;
		_offlineSimulation = true;
		ResetCanHealthCounters();
		if (_connectButton != null)
		{
			_connectButton.Text = "连接";
			ApplyButtonStyle(_connectButton, "connect");
		}
		if (_simulationButton != null)
		{
			_simulationButton.Text = "退出演示";
			ApplyButtonStyle(_simulationButton, "working");
		}
		if (_statusLabel != null)
		{
			_statusLabel.Text = "离线演示";
			_statusLabel.BackColor = _gridHeader;
		}
		WriteConnectionState("离线演示");
		ClearOfflineSimulationProgramCache();
		Log("离线演示已开启：不连接 CAN；按应用层入口运行可识别的 C 逻辑。");
		if (!_running)
		{
			StartPolling();
		}
	}

	private void StopOfflineSimulation()
	{
		if (!_offlineSimulation)
		{
			return;
		}

		StopPolling(waitForExit: true, sendCloseFrame: false);
		_offlineSimulation = false;
		_monitorSessionOpen = false;
		ClearOfflineSimulationProgramCache();
		if (_simulationButton != null)
		{
			_simulationButton.Text = "演示";
			ApplyButtonStyle(_simulationButton, "simulate");
		}
		if (_statusLabel != null)
		{
			_statusLabel.Text = "未连接";
			_statusLabel.BackColor = _statusOff;
		}
		WriteConnectionState("未连接");
		Log("离线演示已关闭。");
	}

	private void WriteConnectionState(string message)
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(_connectionStatePath));
			File.WriteAllText(_connectionStatePath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine + message, new UTF8Encoding(false));
		}
		catch
		{
		}
	}

	private void RefreshStartupProgramGraph()
	{
		string directory = GetWorkDirectoryFromUi();
		if (directory.Length > 0 && Directory.Exists(directory))
		{
			RefreshProgramGraphPanel(directory);
		}
	}

	private void TogglePolling()
	{
		if (_running)
		{
			StopPolling();
		}
		else
		{
			StartPolling();
		}
	}

	private void StartPolling()
	{
		if (_adapter == null && !_offlineSimulation)
		{
			ToggleConnect();
			if (_adapter == null || _running)
			{
				return;
			}
		}
		_pollCts = new CancellationTokenSource();
		_running = true;
		_startButton.Text = "停止监控";
		ApplyButtonStyle(_startButton, "monitorStop");
		_monitorTxProbeRemaining = 3;
		ResetCanHealthCounters();
		if (_offlineSimulation)
		{
			EnsureOfflineApplicationWatchItems();
		}
		CancellationToken token = _pollCts.Token;
		_pollTask = Task.Run(async delegate
		{
			if (!_offlineSimulation && !SendMonitorSession(open: true))
			{
				StopPollingStateFromWorker("监控未启动：调试打开指令发送失败。");
				return;
			}
			if (_offlineSimulation)
			{
				_monitorSessionOpen = true;
			}
			await PollLoop(token).ConfigureAwait(continueOnCapturedContext: false);
		}, token);
		Log(_offlineSimulation ? "离线演示已启动：应用层入口会持续运行，代码窗口只负责观察变量。" : "监控已启动。");
	}

	private void StopPolling(bool waitForExit = false, bool sendCloseFrame = true)
	{
		if (_running && sendCloseFrame)
		{
			SendMonitorSession(open: false);
		}
		CancellationTokenSource pollCts = _pollCts;
		Task pollTask = _pollTask;
		pollCts?.Cancel();
		if (waitForExit && pollTask != null)
		{
			try
			{
				pollTask.Wait(600);
			}
			catch (AggregateException ex) when (ex.InnerExceptions.All((Exception x) => x is OperationCanceledException || x is TaskCanceledException))
			{
			}
			catch (OperationCanceledException)
			{
			}
		}
		pollCts?.Dispose();
		_pollCts = null;
		_pollTask = null;
		_running = false;
		if (_startButton != null)
		{
			_startButton.Text = "开始监控";
			ApplyButtonStyle(_startButton, "monitorStart");
		}
	}

	private async Task PollLoop(CancellationToken token)
	{
		_ = 4;
		try
		{
			while (!token.IsCancellationRequested)
			{
				try
				{
					List<WatchItem> list = GetEnabledWatchSnapshot();
					if (list.Count == 0)
					{
						await PollTrace(token).ConfigureAwait(continueOnCapturedContext: false);
						await Task.Delay(100, token).ConfigureAwait(continueOnCapturedContext: false);
						continue;
					}
					int targetCycleMs = Math.Max(10, Volatile.Read(ref _targetCycleMs));
					DateTime cycleStart = DateTime.UtcNow;
					if (_offlineSimulation)
					{
						RunOfflineLightSimulationTick(list);
					}
					for (int i = 0; i < list.Count; i++)
					{
						if (token.IsCancellationRequested)
						{
							break;
						}
						DateTime itemStart = cycleStart.AddTicks(TimeSpan.FromMilliseconds((double)targetCycleMs * (double)i / (double)list.Count).Ticks);
						TimeSpan itemDelay = itemStart - DateTime.UtcNow;
						if (itemDelay.TotalMilliseconds >= 1.0)
						{
							await Task.Delay(itemDelay, token).ConfigureAwait(continueOnCapturedContext: false);
						}
						WatchItem item = list[i];
						await PollOne(item, token).ConfigureAwait(continueOnCapturedContext: false);
					}
					await PollTrace(token).ConfigureAwait(continueOnCapturedContext: false);
					TimeSpan cycleDelay = TimeSpan.FromMilliseconds(targetCycleMs) - (DateTime.UtcNow - cycleStart);
					if (cycleDelay.TotalMilliseconds >= 1.0)
					{
						await Task.Delay(cycleDelay, token).ConfigureAwait(continueOnCapturedContext: false);
					}
				}
				catch (OperationCanceledException) when (token.IsCancellationRequested)
				{
					break;
				}
				catch (Exception ex)
				{
					LogPollLoopError(ex);
					await Task.Delay(80, token).ConfigureAwait(continueOnCapturedContext: false);
				}
			}
		}
		catch (OperationCanceledException)
		{
		}
	}

	private void StopPollingStateFromWorker(string message)
	{
		void Apply()
		{
			_running = false;
			_monitorSessionOpen = false;
			if (_startButton != null && !_startButton.IsDisposed)
			{
				_startButton.Text = "开始监控";
				ApplyButtonStyle(_startButton, "monitorStart");
			}
			Log(message);
		}

		try
		{
			if (IsHandleCreated && InvokeRequired)
			{
				BeginInvoke((Action)Apply);
			}
			else
			{
				Apply();
			}
		}
		catch
		{
			_running = false;
			_monitorSessionOpen = false;
		}
	}

	private List<WatchItem> GetEnabledWatchSnapshot()
	{
		try
		{
			bool capacityLimited = IsWatchCapacityLimited();
			int limit = capacityLimited ? MaxWatchItems : int.MaxValue;
			List<WatchItem> list = new List<WatchItem>(capacityLimited ? Math.Min(MaxWatchItems, _watchItems.Count) : _watchItems.Count);
			int count = _watchItems.Count;
			for (int i = 0; i < count && list.Count < limit; i++)
			{
				WatchItem item = _watchItems[i];
				if (item.Enabled)
				{
					list.Add(item);
				}
			}
			return list;
		}
		catch (Exception ex)
		{
			LogWatchSnapshotError(ex);
			return new List<WatchItem>();
		}
	}

	private bool SendMonitorSession(bool open)
	{
		if (_offlineSimulation)
		{
			_monitorSessionOpen = open;
			return true;
		}

		ICanAdapter adapter = _adapter;
		if (adapter == null)
		{
			return false;
		}
		if (open && _monitorSessionOpen)
		{
			return true;
		}
		if (!open && !_monitorSessionOpen)
		{
			return true;
		}
		byte seq = ++_seq;
		byte[] data = (open ? MonitorProtocol.BuildOpenRequest(seq) : MonitorProtocol.BuildCloseRequest(seq));
		if (!TrySendMonitorFrame(adapter, data, open ? "打开监控" : "关闭监控"))
		{
			return false;
		}
		_monitorSessionOpen = open;
		return true;
	}

	private bool TrySendMonitorFrame(ICanAdapter adapter, byte[] data, string purpose)
	{
		try
		{
			bool shouldProbe = _monitorTxProbeRemaining > 0;
			if (shouldProbe)
			{
				Log("准备发送监控请求：" + purpose + "。");
			}
			adapter.Send(new CanFrame(MonitorRequestId, 8, data));
			if (shouldProbe)
			{
				_monitorTxProbeRemaining--;
				Log("监控请求已发送：" + purpose + "。");
			}
			return true;
		}
		catch (Exception ex)
		{
			LogMonitorSendError(purpose, ex);
			return false;
		}
	}

	private void LogMonitorSendError(string purpose, Exception ex)
	{
		DateTime now = DateTime.UtcNow;
		if ((now - _lastMonitorSendErrorLogUtc).TotalSeconds < 2)
		{
			return;
		}
		_lastMonitorSendErrorLogUtc = now;
		Log("调试指令发送失败：" + purpose + "，" + ex.Message);
	}

	private void LogWatchSnapshotError(Exception ex)
	{
		DateTime now = DateTime.UtcNow;
		if ((now - _lastWatchSnapshotErrorLogUtc).TotalSeconds < 2)
		{
			return;
		}
		_lastWatchSnapshotErrorLogUtc = now;
		Log("监控列表读取冲突，已跳过本轮：" + ex.Message);
	}

	private void LogPollLoopError(Exception ex)
	{
		DateTime now = DateTime.UtcNow;
		if ((now - _lastPollLoopErrorLogUtc).TotalSeconds < 2)
		{
			return;
		}
		_lastPollLoopErrorLogUtc = now;
		Log("监控线程异常，已自动继续：" + ex.Message);
	}

	private void NoteCanResponse()
	{
		Interlocked.Exchange(ref _consecutiveCanNoResponseCount, 0);
		if (Interlocked.Exchange(ref _controllerResponded, 1) == 0)
		{
			MarkControllerResponded();
		}
	}

	private void NoteCanNoResponse(string reason)
	{
		if (!_running || _adapter == null)
		{
			return;
		}

		int count = Interlocked.Increment(ref _consecutiveCanNoResponseCount);
		if (count < NoResponseStopThreshold)
		{
			return;
		}

		DateTime now = DateTime.UtcNow;
		if ((now - _lastNoResponseStopUtc).TotalMilliseconds < NoResponseStopCooldownMs)
		{
			return;
		}

		if (Interlocked.Exchange(ref _noResponseStopRequested, 1) != 0)
		{
			return;
		}

		_lastNoResponseStopUtc = now;
		try
		{
			if (!IsHandleCreated || IsDisposed)
			{
				Interlocked.Exchange(ref _noResponseStopRequested, 0);
				return;
			}

			BeginInvoke(new Action(() => _ = StopCanAfterNoResponseAsync(reason, count)));
		}
		catch
		{
			Interlocked.Exchange(ref _noResponseStopRequested, 0);
		}
	}

	private async Task StopCanAfterNoResponseAsync(string reason, int count)
	{
		try
		{
			if (_adapter == null)
			{
				return;
			}

			string adapterName = _adapter.Name;
			Log($"CAN 连续无回信，已停止监控：{reason}，{count} 次。请检查控制器电源、CAN 线、固件后手动连接。");
			StopPolling(waitForExit: false, sendCloseFrame: false);
			await Task.Delay(140).ConfigureAwait(true);
			if (_adapter != null)
			{
				try
				{
					_adapter.Dispose();
				}
				catch (Exception ex)
				{
					Log("释放 CAN 适配器失败：" + ex.Message);
				}
				_adapter = null;
			}
			_monitorSessionOpen = false;
			if (_connectButton != null && !_connectButton.IsDisposed)
			{
				_connectButton.Text = "连接";
				ApplyButtonStyle(_connectButton, "connect");
			}
			if (_statusLabel != null && !_statusLabel.IsDisposed)
			{
				_statusLabel.Text = "无回信";
				_statusLabel.BackColor = _statusOff;
			}
			WriteConnectionState("无回信，已停止监控：" + adapterName);
		}
		finally
		{
			ResetCanHealthCounters();
			Interlocked.Exchange(ref _noResponseStopRequested, 0);
		}
	}

	private void ResetCanHealthCounters()
	{
		Interlocked.Exchange(ref _consecutiveCanNoResponseCount, 0);
		Interlocked.Exchange(ref _controllerResponded, 0);
	}

	private void MarkWaitingForControllerResponse(ICanAdapter adapter)
	{
		if (_connectButton != null && !_connectButton.IsDisposed)
		{
			ApplyButtonStyle(_connectButton, "waiting");
		}
		if (_statusLabel != null)
		{
			_statusLabel.Text = "等待回信";
			_statusLabel.BackColor = _statusOff;
		}
		Log("CAN 工具已打开：" + adapter.Name + "，等待控制器回信。");
		WriteConnectionState("等待控制器回信：" + adapter.Name);
	}

	private void MarkControllerResponded()
	{
		void Apply()
		{
			ICanAdapter? adapter = _adapter;
			if (adapter == null)
			{
				return;
			}

			if (_statusLabel != null)
			{
				_statusLabel.Text = adapter.Name;
				_statusLabel.BackColor = _accent;
			}
			if (_connectButton != null && !_connectButton.IsDisposed)
			{
				_connectButton.Text = "断开";
				ApplyButtonStyle(_connectButton, "disconnect");
			}
			_preferredAdapterName = adapter.Name;
			Log("控制器已回信，连接成功：" + adapter.Name + "。");
			WriteConnectionState("已连接：" + adapter.Name);
		}

		try
		{
			if (IsHandleCreated && InvokeRequired)
			{
				BeginInvoke((Action)Apply);
			}
			else
			{
				Apply();
			}
		}
		catch
		{
		}
	}

	private async Task PollOne(WatchItem item, CancellationToken token)
	{
		if (_offlineSimulation)
		{
			UpdateItem(item, Math.Clamp(item.Size, 1, 4), 0, GetSimulatedValue(item));
			await Task.Yield();
			return;
		}

		ICanAdapter adapter = _adapter;
		if (adapter == null)
		{
			return;
		}
		try
		{
			if (item.Size == 4 && !item.IsExpandable)
			{
				ReadSegmentResult low = await TryReadSegment(adapter, item.Address, 2, token).ConfigureAwait(continueOnCapturedContext: false);
				if (!low.Success)
				{
					MarkTimeout(item);
					return;
				}
				if (low.Status != 0)
				{
					UpdateItem(item, low.Len, low.Status, low.Value);
					return;
				}
				ReadSegmentResult readSegmentResult = await TryReadSegment(adapter, item.Address + 2, 2, token).ConfigureAwait(continueOnCapturedContext: false);
				if (!readSegmentResult.Success)
				{
					MarkTimeout(item);
					return;
				}
				if (readSegmentResult.Status != 0)
				{
					UpdateItem(item, readSegmentResult.Len, readSegmentResult.Status, readSegmentResult.Value);
					return;
				}
				uint value = (uint)(low.Value | (readSegmentResult.Value << 16));
				UpdateItem(item, 4, 0, value);
				return;
			}
			int len = Math.Clamp(item.Size, 1, 2);
			ReadSegmentResult readSegmentResult2 = await TryReadSegment(adapter, item.Address, len, token).ConfigureAwait(continueOnCapturedContext: false);
			if (readSegmentResult2.Success)
			{
				UpdateItem(item, readSegmentResult2.Len, readSegmentResult2.Status, readSegmentResult2.Value);
				return;
			}
			MarkTimeout(item);
		}
		catch (Exception ex)
		{
			MarkError(item, ex.Message);
			await Task.Delay(100, token).ConfigureAwait(continueOnCapturedContext: false);
		}
	}

	private uint NextSimulatedValue(WatchItem item)
	{
		int bytes = Math.Clamp(item.Size, 1, 4);
		lock (_simulationLock)
		{
			if (!_simulatedValues.TryGetValue(item.Name, out uint value))
			{
				value = MaskRawValue(item.Address ^ (uint)StableNameSeed(item.Name), bytes);
			}

			if (!item.ForceActive)
			{
				value = MaskRawValue(value + (uint)(StableNameSeed(item.Name) % 5 + 1), bytes);
				_simulatedValues[item.Name] = value;
			}

			return value;
		}
	}

	private uint GetSimulatedValue(WatchItem item)
	{
		int bytes = Math.Clamp(item.Size, 1, 4);
		lock (_simulationLock)
		{
			if (!_simulatedValues.TryGetValue(item.Name, out uint value))
			{
				value = 0;
				_simulatedValues[item.Name] = value;
			}

			return MaskRawValue(value, bytes);
		}
	}

	private void ClearOfflineSimulationProgramCache()
	{
		lock (_simulationLock)
		{
			_offlineCDrivers.Clear();
			_offlineApplicationSources = new List<FunctionSourceView>();
			_offlineApplicationSourceDirectory = "";
		}
	}

	private void EnsureOfflineApplicationWatchItems()
	{
		if (!_offlineSimulation || _symbolLookup.Count == 0)
		{
			return;
		}

		IReadOnlyList<FunctionSourceView> sources = GetOfflineApplicationSources();
		if (sources.Count == 0)
		{
			return;
		}

		HashSet<string> existing = BuildExistingWatchAliasSet();
		int added = 0;
		foreach (string identifier in sources
			.SelectMany(source => BuildFunctionAutoWatchIdentifiers(source.Lines))
			.Where(identifier => identifier.Length > 0 && !IsCKeywordToken(identifier))
			.Distinct(StringComparer.OrdinalIgnoreCase))
		{
			if (!TryResolveSourceIdentifierToWatchItem(identifier, existing, out WatchItem item, out string matchedName))
			{
				continue;
			}

			item.AutoVisible = true;
			_watchItems.Add(item);
			AddWatchAliases(existing, item.Name);
			existing.Add(matchedName);
			added++;
		}

		if (added == 0)
		{
			return;
		}

		UpdateCycleEstimate();
		SaveDefaultProfileQuietly();
		MarkFunctionCodeDirty();
		DateTime now = DateTime.UtcNow;
		if ((now - _lastOfflineApplicationWatchLogUtc).TotalSeconds >= 2)
		{
			_lastOfflineApplicationWatchLogUtc = now;
			Log($"离线应用层：已自动加入 {added} 个入口变量。");
		}
	}

	private IReadOnlyList<FunctionSourceView> GetOfflineApplicationSources()
	{
		string directory = _workDirectory;
		if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
		{
			return _currentFunctionSource == null
				? Array.Empty<FunctionSourceView>()
				: new[] { _currentFunctionSource };
		}

		lock (_simulationLock)
		{
			if (_offlineApplicationSources.Count > 0 &&
				_offlineApplicationSourceDirectory.Equals(directory, StringComparison.OrdinalIgnoreCase))
			{
				return _offlineApplicationSources.ToList();
			}
		}

		List<FunctionSourceView> sources = BuildOfflineApplicationSources(directory);
		if (sources.Count == 0 && _currentFunctionSource != null)
		{
			sources.Add(_currentFunctionSource);
		}

		lock (_simulationLock)
		{
			_offlineApplicationSourceDirectory = directory;
			_offlineApplicationSources = sources;
			return _offlineApplicationSources.ToList();
		}
	}

	private List<FunctionSourceView> BuildOfflineApplicationSources(string directory)
	{
		var sources = new List<FunctionSourceView>();
		var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		bool TryAdd(string functionName)
		{
			if (string.IsNullOrWhiteSpace(functionName) ||
				IsCKeyword(functionName) ||
				!seen.Add(functionName))
			{
				return false;
			}

			if (!TryLoadFunctionSource(directory, functionName, out FunctionSourceView? source) || source == null)
			{
				return false;
			}

			sources.Add(source);
			return true;
		}

		int primaryCount = 0;
		foreach (string name in new[]
		{
			"MyLogic_1ms",
			"MyLogic_10ms",
			"MyLogic",
			"Disp_main",
			"LCD_Disp",
			"Lcd_Disp",
			"App_Display",
			"Main_Display"
		})
		{
			if (TryAdd(name))
			{
				primaryCount++;
			}
		}

		if (primaryCount > 0)
		{
			return sources;
		}

		ProgramGraphSnapshot? snapshot = _programGraphSnapshot;
		if (snapshot != null && snapshot.Success)
		{
			TryAdd(snapshot.StartFunction);
			foreach (ProgramFrameworkStep step in snapshot.FrameworkSteps.Take(16))
			{
				TryAdd(step.FunctionName);
				TryAdd(step.Name);
				if (sources.Count >= 12)
				{
					break;
				}
			}
			foreach (ProgramCallGraphNode node in snapshot.CallGraphNodes
				.Where(node => node.Level <= 1 && !node.Kind.Equals("driver", StringComparison.OrdinalIgnoreCase))
				.Take(12))
			{
				TryAdd(node.Name);
				if (sources.Count >= 12)
				{
					break;
				}
			}
			foreach (ProgramFunctionInfo function in snapshot.HotFunctions.Take(12))
			{
				TryAdd(function.Name);
				if (sources.Count >= 12)
				{
					break;
				}
			}
		}

		return sources;
	}

	private string? ResolveOfflineFunctionSourceText(string functionName)
	{
		if (string.IsNullOrWhiteSpace(_workDirectory) || !Directory.Exists(_workDirectory))
		{
			return null;
		}

		return TryLoadFunctionSource(_workDirectory, functionName, out FunctionSourceView? source) && source != null
			? string.Join("\n", source.Lines)
			: null;
	}

	private void RunOfflineLightSimulationTick(IReadOnlyList<WatchItem> watchItems)
	{
		if (!_offlineSimulation || watchItems.Count == 0)
		{
			return;
		}

		DateTime now = DateTime.UtcNow;
		if ((now - _lastOfflineSimulationTickUtc).TotalMilliseconds < Math.Max(10, Volatile.Read(ref _targetCycleMs)) - 1)
		{
			return;
		}
		_lastOfflineSimulationTickUtc = now;

		IReadOnlyList<FunctionSourceView> sources = GetOfflineApplicationSources();
		if (sources.Count == 0)
		{
			return;
		}

		Dictionary<string, WatchItem> aliases = BuildWatchAliasMap(watchItems);
		lock (_simulationLock)
		{
			foreach (WatchItem item in watchItems)
			{
				if (!_simulatedValues.ContainsKey(item.Name))
				{
					_simulatedValues[item.Name] = 0;
				}
			}

			foreach (FunctionSourceView source in sources)
			{
				if (source.Lines.Count == 0)
				{
					continue;
				}

				string key = source.FilePath + "|" + source.FunctionName;
				if (!_offlineCDrivers.TryGetValue(key, out OfflineCDriver driver))
				{
					driver = new OfflineCDriver();
					_offlineCDrivers[key] = driver;
				}

				if (driver.TryRun(
					source.FunctionName,
					source.FilePath,
					source.Lines,
					watchItems,
					GetOfflineNumericValue,
					SetOfflineNumericValue,
					ResolveOfflineFunctionSourceText,
					_programGraphLastSourceWrite.Ticks.ToString()))
				{
					continue;
				}

				ExecuteOfflineLightSimulationLines(source.Lines, 0, source.Lines.Count - 1, aliases, 0);
			}
		}
	}

	private static Dictionary<string, WatchItem> BuildWatchAliasMap(IEnumerable<WatchItem> watchItems)
	{
		Dictionary<string, WatchItem> map = new Dictionary<string, WatchItem>(StringComparer.OrdinalIgnoreCase);
		foreach (WatchItem item in watchItems.Where(item => item.Enabled))
		{
			foreach (string alias in WatchIdentifierAliases(item.Name))
			{
				if (!map.ContainsKey(alias))
				{
					map.Add(alias, item);
				}
			}
		}
		return map;
	}

	private void ExecuteOfflineLightSimulationLines(
		IReadOnlyList<string> lines,
		int start,
		int end,
		Dictionary<string, WatchItem> aliases,
		int depth)
	{
		if (depth > 8)
		{
			return;
		}

		for (int i = Math.Max(0, start); i <= end && i < lines.Count; i++)
		{
			string line = StripLineComment(lines[i]).Trim();
			if (line.Length == 0 || line == "{" || line == "}")
			{
				continue;
			}

			if (Regex.IsMatch(line, @"^\s*(else\b|for\b|while\b|switch\b|return\b|break\b|continue\b)"))
			{
				continue;
			}

			string? expr = ExtractIfExpression(line);
			if (expr != null)
			{
				ConditionEval condition = EvaluateOfflineSimulationExpression(expr, aliases);
				string afterIf = GetTextAfterIfExpression(line);
				if (afterIf.Length > 0 && afterIf != "{")
				{
					if (condition == ConditionEval.True)
					{
						ExecuteOfflineSimulationStatement(afterIf, aliases);
					}
					continue;
				}

				int bodyStart = FindNextExecutableLine(lines, i + 1, end);
				if (bodyStart < 0)
				{
					continue;
				}

				if (LineOpensBlock(lines[bodyStart]))
				{
					int close = FindMatchingCloseBrace(lines, bodyStart, end);
					if (condition == ConditionEval.True && close > bodyStart)
					{
						ExecuteOfflineLightSimulationLines(lines, bodyStart + 1, close - 1, aliases, depth + 1);
					}
					if (close > i)
					{
						i = close;
					}
					continue;
				}

				if (condition == ConditionEval.True)
				{
					ExecuteOfflineSimulationStatement(lines[bodyStart], aliases);
				}
				i = Math.Max(i, bodyStart);
				continue;
			}

			ExecuteOfflineSimulationStatement(line, aliases);
		}
	}

	private void ExecuteOfflineSimulationStatement(string rawLine, Dictionary<string, WatchItem> aliases)
	{
		string line = StripLineComment(rawLine).Trim();
		if (line.Length == 0)
		{
			return;
		}

		line = line.Trim('{', '}').Trim();
		if (line.Length == 0 || LooksLikeFunctionOnlyStatement(line))
		{
			return;
		}

		Match postfix = Regex.Match(line, @"^(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?<op>\+\+|--)\s*;?$");
		if (postfix.Success && TryResolveOfflineWatch(postfix.Groups["name"].Value, aliases, out WatchItem item))
		{
			long value = GetOfflineSignedValue(item);
			value += postfix.Groups["op"].Value == "++" ? 1 : -1;
			SetOfflineSignedValue(item, value);
			return;
		}

		Match prefix = Regex.Match(line, @"^(?<op>\+\+|--)\s*(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*;?$");
		if (prefix.Success && TryResolveOfflineWatch(prefix.Groups["name"].Value, aliases, out item))
		{
			long value = GetOfflineSignedValue(item);
			value += prefix.Groups["op"].Value == "++" ? 1 : -1;
			SetOfflineSignedValue(item, value);
			return;
		}

		Match compound = Regex.Match(line, @"^(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?<op>\+=|-=)\s*(?<expr>[^;]+)\s*;?$");
		if (compound.Success && TryResolveOfflineWatch(compound.Groups["name"].Value, aliases, out item) &&
			TryEvaluateOfflineArithmetic(compound.Groups["expr"].Value, aliases, out long delta))
		{
			long value = GetOfflineSignedValue(item);
			value += compound.Groups["op"].Value == "+=" ? delta : -delta;
			SetOfflineSignedValue(item, value);
			return;
		}

		Match assign = Regex.Match(line, @"^(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?<expr>[^;]+)\s*;?$");
		if (assign.Success && TryResolveOfflineWatch(assign.Groups["name"].Value, aliases, out item) &&
			TryEvaluateOfflineArithmetic(assign.Groups["expr"].Value, aliases, out long assigned))
		{
			SetOfflineSignedValue(item, assigned);
		}
	}

	private static bool LooksLikeFunctionOnlyStatement(string line)
	{
		return Regex.IsMatch(line, @"^[A-Za-z_][A-Za-z0-9_]*\s*\(");
	}

	private static string StripLineComment(string line)
	{
		int comment = line.IndexOf("//", StringComparison.Ordinal);
		return comment >= 0 ? line.Substring(0, comment) : line;
	}

	private static string GetTextAfterIfExpression(string line)
	{
		Match match = Regex.Match(line, @"^\s*if\b");
		if (!match.Success)
		{
			return "";
		}
		int open = line.IndexOf('(', match.Index + match.Length);
		if (open < 0)
		{
			return "";
		}
		int depth = 0;
		for (int i = open; i < line.Length; i++)
		{
			if (line[i] == '(')
			{
				depth++;
			}
			else if (line[i] == ')')
			{
				depth--;
				if (depth == 0)
				{
					return line.Substring(i + 1).Trim();
				}
			}
		}
		return "";
	}

	private static int FindNextExecutableLine(IReadOnlyList<string> lines, int start, int end)
	{
		for (int i = start; i <= end && i < lines.Count; i++)
		{
			string line = StripLineComment(lines[i]).Trim();
			if (line.Length == 0)
			{
				continue;
			}
			return i;
		}
		return -1;
	}

	private static bool LineOpensBlock(string line)
	{
		return StripLineComment(line).Contains('{', StringComparison.Ordinal);
	}

	private static int FindMatchingCloseBrace(IReadOnlyList<string> lines, int openLine, int end)
	{
		int depth = 0;
		for (int i = openLine; i <= end && i < lines.Count; i++)
		{
			string line = StripLineComment(lines[i]);
			foreach (char c in line)
			{
				if (c == '{')
				{
					depth++;
				}
				else if (c == '}')
				{
					depth--;
					if (depth == 0)
					{
						return i;
					}
				}
			}
		}
		return -1;
	}

	private ConditionEval EvaluateOfflineSimulationExpression(string expr, Dictionary<string, WatchItem> aliases)
	{
		bool hasUnknown = false;
		foreach (string orPart in Regex.Split(expr, @"\|\|"))
		{
			bool andOk = true;
			bool andUnknown = false;
			foreach (string andPart in Regex.Split(orPart, @"&&"))
			{
				ConditionEval part = EvaluateOfflineSimulationCondition(andPart, aliases);
				if (part == ConditionEval.False)
				{
					andOk = false;
					break;
				}
				if (part == ConditionEval.Unknown)
				{
					andUnknown = true;
				}
			}
			if (andOk && !andUnknown)
			{
				return ConditionEval.True;
			}
			hasUnknown |= andUnknown;
		}
		return hasUnknown ? ConditionEval.Unknown : ConditionEval.False;
	}

	private ConditionEval EvaluateOfflineSimulationCondition(string expression, Dictionary<string, WatchItem> aliases)
	{
		string text = expression.Trim();
		if (text.Length == 0)
		{
			return ConditionEval.Unknown;
		}

		while (text.StartsWith("(", StringComparison.Ordinal) && text.EndsWith(")", StringComparison.Ordinal) && HasBalancedOuterParentheses(text))
		{
			text = text.Substring(1, text.Length - 2).Trim();
		}

		bool inverted = false;
		while (text.StartsWith("!", StringComparison.Ordinal))
		{
			inverted = !inverted;
			text = text.Substring(1).Trim();
		}

		ConditionEval result = EvaluateOfflineSimulationConditionCore(text, aliases);
		if (result == ConditionEval.Unknown)
		{
			return result;
		}
		if (!inverted)
		{
			return result;
		}
		return result == ConditionEval.True ? ConditionEval.False : ConditionEval.True;
	}

	private ConditionEval EvaluateOfflineSimulationConditionCore(string text, Dictionary<string, WatchItem> aliases)
	{
		Match compare = Regex.Match(text, @"^(?<left>[A-Za-z_][A-Za-z0-9_]*)\s*(?<op>==|!=|>=|<=|>|<)\s*(?<right>-?(?:0x[0-9A-Fa-f]+|\d+|[A-Za-z_][A-Za-z0-9_]*))$");
		if (compare.Success)
		{
			if (!TryEvaluateOfflineArithmetic(compare.Groups["left"].Value, aliases, out long left) ||
				!TryEvaluateOfflineArithmetic(compare.Groups["right"].Value, aliases, out long right))
			{
				return ConditionEval.Unknown;
			}

			bool value = compare.Groups["op"].Value switch
			{
				"==" => left == right,
				"!=" => left != right,
				">=" => left >= right,
				"<=" => left <= right,
				">" => left > right,
				"<" => left < right,
				_ => false
			};
			return value ? ConditionEval.True : ConditionEval.False;
		}

		if (!TryEvaluateOfflineArithmetic(text, aliases, out long result))
		{
			return ConditionEval.Unknown;
		}
		return result != 0 ? ConditionEval.True : ConditionEval.False;
	}

	private bool TryEvaluateOfflineArithmetic(string expr, Dictionary<string, WatchItem> aliases, out long value)
	{
		value = 0;
		string text = expr.Trim();
		if (TryParseIntegerLiteral(text, out value))
		{
			return true;
		}
		if (TryResolveOfflineWatch(text, aliases, out WatchItem item))
		{
			value = GetOfflineSignedValue(item);
			return true;
		}

		Match binary = Regex.Match(text, @"^(?<left>-?(?:0x[0-9A-Fa-f]+|\d+|[A-Za-z_][A-Za-z0-9_]*))\s*(?<op>\+|-)\s*(?<right>-?(?:0x[0-9A-Fa-f]+|\d+|[A-Za-z_][A-Za-z0-9_]*))$");
		if (!binary.Success)
		{
			return false;
		}
		if (!TryEvaluateOfflineArithmetic(binary.Groups["left"].Value, aliases, out long left) ||
			!TryEvaluateOfflineArithmetic(binary.Groups["right"].Value, aliases, out long right))
		{
			return false;
		}
		value = binary.Groups["op"].Value == "+" ? left + right : left - right;
		return true;
	}

	private static bool TryResolveOfflineWatch(string name, Dictionary<string, WatchItem> aliases, out WatchItem item)
	{
		item = null!;
		string baseName = GetIdentifierBase(name);
		return baseName.Length > 0 && aliases.TryGetValue(baseName, out item);
	}

	private long GetOfflineSignedValue(WatchItem item)
	{
		int bytes = Math.Clamp(item.Size, 1, 4);
		if (!_simulatedValues.TryGetValue(item.Name, out uint raw))
		{
			raw = 0;
			_simulatedValues[item.Name] = 0;
		}
		raw = MaskRawValue(raw, bytes);
		return IsSignedWatchItem(item) ? ToSignedValue(raw, bytes) : raw;
	}

	private double GetOfflineNumericValue(WatchItem item)
	{
		int bytes = Math.Clamp(item.Size, 1, 4);
		if (!_simulatedValues.TryGetValue(item.Name, out uint raw))
		{
			raw = 0;
			_simulatedValues[item.Name] = 0;
		}

		raw = MaskRawValue(raw, bytes);
		if (IsFloatWatchItem(item) && bytes == 4)
		{
			float value = BitConverter.UInt32BitsToSingle(raw);
			return float.IsFinite(value) ? value : 0.0;
		}

		return IsSignedWatchItem(item) ? ToSignedValue(raw, bytes) : raw;
	}

	private void SetOfflineSignedValue(WatchItem item, long value)
	{
		if (item.ForceActive)
		{
			return;
		}

		int bytes = Math.Clamp(item.Size, 1, 4);
		uint raw = unchecked((uint)value);
		_simulatedValues[item.Name] = MaskRawValue(raw, bytes);
	}

	private void SetOfflineNumericValue(WatchItem item, double value)
	{
		if (item.ForceActive)
		{
			return;
		}

		int bytes = Math.Clamp(item.Size, 1, 4);
		uint raw;
		if (IsFloatWatchItem(item) && bytes == 4)
		{
			raw = BitConverter.SingleToUInt32Bits((float)value);
		}
		else
		{
			raw = unchecked((uint)(long)Math.Round(value, MidpointRounding.AwayFromZero));
		}
		_simulatedValues[item.Name] = MaskRawValue(raw, bytes);
	}

	private void SetSimulatedValue(WatchItem item, uint rawValue)
	{
		int bytes = Math.Clamp(item.Size, 1, 4);
		lock (_simulationLock)
		{
			_simulatedValues[item.Name] = MaskRawValue(rawValue, bytes);
		}
	}

	private static int StableNameSeed(string name)
	{
		unchecked
		{
			int seed = 17;
			foreach (char ch in name)
			{
				seed = seed * 31 + ch;
			}
			return seed & 0x7FFFFFFF;
		}
	}

	private async Task<ReadSegmentResult> TryReadSegment(ICanAdapter adapter, uint address, int len, CancellationToken token)
	{
		await _canRequestLock.WaitAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			byte seq = ++_seq;
			byte[] data = MonitorProtocol.BuildReadRequest(seq, address, len);
			if (!TrySendMonitorFrame(adapter, data, "读取变量"))
			{
				NoteCanNoResponse("发送失败");
				return new ReadSegmentResult(Success: false, 0, byte.MaxValue, 0);
			}
			DateTime deadline = DateTime.UtcNow.AddMilliseconds(80.0);
			while (DateTime.UtcNow < deadline && !token.IsCancellationRequested)
			{
				int num = 0;
				CanFrame frame;
				while (num++ < 64 && DateTime.UtcNow < deadline && !token.IsCancellationRequested && adapter.TryReceive(out frame))
				{
					if (frame.Id == MonitorResponseId && MonitorProtocol.TryParseReadAck(frame, seq, out var len2, out var status, out var value))
					{
						NoteCanResponse();
						return new ReadSegmentResult(Success: true, len2, status, value);
					}
				}
				await Task.Delay(2, token).ConfigureAwait(continueOnCapturedContext: false);
			}
			if (!token.IsCancellationRequested)
			{
				NoteCanNoResponse("读取变量");
			}
			return new ReadSegmentResult(Success: false, 0, byte.MaxValue, 0);
		}
		finally
		{
			_canRequestLock.Release();
		}
	}

	private WatchItem? GetSelectedForceTarget()
	{
		if (_grid == null)
		{
			return null;
		}

		if (_grid.CurrentRow?.DataBoundItem is WatchItem current)
		{
			return current;
		}

		return GetSelectedWatchItems().FirstOrDefault();
	}

	private async Task WriteSelectedValueAsync(bool force)
	{
		WatchItem? item = GetSelectedForceTarget();
		if (item == null)
		{
			Log("请选择一个变量再强制。");
			return;
		}

		await WriteWatchValueAsync(item, _forceValueBox?.Text ?? "", force).ConfigureAwait(true);
	}

	private async Task PromptAndWriteWatchValueAsync(WatchItem item, bool force)
	{
		string currentValue = item.ValueDec.Length > 0 ? item.ValueDec : (item.ValueHex.Length > 0 ? item.ValueHex : "0");
		string? valueText = PromptWatchValue(item, force, currentValue);
		if (valueText == null)
		{
			return;
		}

		await WriteWatchValueAsync(item, valueText, force).ConfigureAwait(true);
	}

	private async Task WriteWatchValueAsync(WatchItem item, string valueText, bool force)
	{
		if (!TryParseForceValue(item, valueText, out uint rawValue, out string error))
		{
			Log("强制值无效：" + error);
			return;
		}

		if (!EnsureAdapterForDebugCommand())
		{
			return;
		}

		SetForceButtonsEnabled(false);
		try
		{
			bool ok = await WriteValueToControllerAsync(item, rawValue, force).ConfigureAwait(true);
			if (!ok)
			{
				return;
			}

			int valueBytes = Math.Clamp(item.Size, 1, 4);
			item.RawValue = MaskRawValue(rawValue, valueBytes);
			item.ValueDec = FormatDecimalRawValue(item, item.RawValue, valueBytes);
			item.ValueHex = "0x" + item.RawValue.ToString("X" + HexDigitsForBytes(valueBytes));
			item.DisplayValue = FormatValue(item);
			item.ForceActive = force;
			item.ForceText = force ? "保持" : "";
			RefreshValueCell(item);
			RefreshForceCell(item);
			MarkFunctionCodeDirty(item);
			UpdateProgramInsightPanel();
			Log((force ? "已保持：" : "已写入：") + GetWatchDisplayName(item) + " = " + item.DisplayValue);
		}
		finally
		{
			SetForceButtonsEnabled(true);
		}
	}

	private async Task<bool> WriteValueToControllerAsync(WatchItem item, uint rawValue, bool force)
	{
		if (_offlineSimulation)
		{
			SetSimulatedValue(item, rawValue);
			await Task.Yield();
			return true;
		}

		ICanAdapter? adapter = _adapter;
		if (adapter == null)
		{
			return false;
		}

		if (!SendMonitorSession(open: true))
		{
			Log("强制失败：监控会话未打开。");
			return false;
		}

		int bytes = Math.Clamp(item.Size, 1, 4);
		if (bytes == 1)
		{
			return await SendWriteSegmentAsync(adapter, item.Address, 1, (ushort)(rawValue & 0xFF), force, CancellationToken.None).ConfigureAwait(true);
		}

		if (bytes == 2 || bytes == 3)
		{
			return await SendWriteSegmentAsync(adapter, item.Address, 2, (ushort)(rawValue & 0xFFFF), force, CancellationToken.None).ConfigureAwait(true);
		}

		bool low = await SendWriteSegmentAsync(adapter, item.Address, 2, (ushort)(rawValue & 0xFFFF), force, CancellationToken.None).ConfigureAwait(true);
		if (!low)
		{
			return false;
		}

		return await SendWriteSegmentAsync(adapter, item.Address + 2, 2, (ushort)((rawValue >> 16) & 0xFFFF), force, CancellationToken.None).ConfigureAwait(true);
	}

	private async Task<bool> SendWriteSegmentAsync(ICanAdapter adapter, uint address, int len, ushort value, bool force, CancellationToken token)
	{
		await _canRequestLock.WaitAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			byte seq = ++_seq;
			byte[] data = MonitorProtocol.BuildWriteRequest(seq, address, len, value, force);
			if (!TrySendMonitorFrame(adapter, data, force ? "保持变量" : "写入变量"))
			{
				return false;
			}

			DateTime deadline = DateTime.UtcNow.AddMilliseconds(180.0);
			while (DateTime.UtcNow < deadline && !token.IsCancellationRequested)
			{
				int num = 0;
				CanFrame frame;
				while (num++ < 64 && DateTime.UtcNow < deadline && !token.IsCancellationRequested && adapter.TryReceive(out frame))
				{
					if (frame.Id == MonitorResponseId && MonitorProtocol.TryParseWriteAck(frame, seq, out byte status, out int ackLen, out byte command))
					{
						NoteCanResponse();
						if (status == 0)
						{
							return true;
						}

						Log("强制失败：" + BuildWriteStatusText(status) + $"，地址 0x{address:X8}，长度 {ackLen}。");
						return false;
					}
				}
				await Task.Delay(2, token).ConfigureAwait(continueOnCapturedContext: false);
			}

			NoteCanNoResponse(force ? "保持变量" : "写入变量");
			Log("强制失败：控制器无回信。");
			return false;
		}
		finally
		{
			_canRequestLock.Release();
		}
	}

	private async Task ReleaseSelectedForceAsync()
	{
		WatchItem? item = GetSelectedForceTarget();
		if (item == null)
		{
			Log("请选择一个变量再释放。");
			return;
		}

		await ReleaseWatchForceAsync(item).ConfigureAwait(true);
	}

	private async Task ReleaseWatchForceAsync(WatchItem item)
	{
		if (!EnsureAdapterForDebugCommand())
		{
			return;
		}

		SetForceButtonsEnabled(false);
		try
		{
			bool ok = await ReleaseForceForItemAsync(item).ConfigureAwait(true);
			if (!ok)
			{
				return;
			}

			item.ForceActive = false;
			item.ForceText = "";
			RefreshForceCell(item);
			MarkFunctionCodeDirty(item);
			UpdateProgramInsightPanel();
			Log("已释放强制：" + GetWatchDisplayName(item));
		}
		finally
		{
			SetForceButtonsEnabled(true);
		}
	}

	private async Task<bool> ReleaseForceForItemAsync(WatchItem item)
	{
		if (_offlineSimulation)
		{
			await Task.Yield();
			return true;
		}

		ICanAdapter? adapter = _adapter;
		if (adapter == null)
		{
			return false;
		}

		if (!SendMonitorSession(open: true))
		{
			Log("释放失败：监控会话未打开。");
			return false;
		}

		bool ok = await SendReleaseSegmentAsync(adapter, item.Address, CancellationToken.None).ConfigureAwait(true);
		if (!ok)
		{
			return false;
		}

		if (Math.Clamp(item.Size, 1, 4) == 4)
		{
			ok = await SendReleaseSegmentAsync(adapter, item.Address + 2, CancellationToken.None).ConfigureAwait(true);
		}

		return ok;
	}

	private async Task<bool> SendReleaseSegmentAsync(ICanAdapter adapter, uint address, CancellationToken token)
	{
		await _canRequestLock.WaitAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			byte seq = ++_seq;
			byte[] data = MonitorProtocol.BuildReleaseForceRequest(seq, address);
			if (!TrySendMonitorFrame(adapter, data, "释放强制"))
			{
				return false;
			}

			DateTime deadline = DateTime.UtcNow.AddMilliseconds(180.0);
			while (DateTime.UtcNow < deadline && !token.IsCancellationRequested)
			{
				int num = 0;
				CanFrame frame;
				while (num++ < 64 && DateTime.UtcNow < deadline && !token.IsCancellationRequested && adapter.TryReceive(out frame))
				{
					if (frame.Id == MonitorResponseId && MonitorProtocol.TryParseWriteAck(frame, seq, out byte status, out _, out _))
					{
						NoteCanResponse();
						if (status == 0)
						{
							return true;
						}

						Log("释放失败：" + BuildWriteStatusText(status) + $"，地址 0x{address:X8}。");
						return false;
					}
				}
				await Task.Delay(2, token).ConfigureAwait(continueOnCapturedContext: false);
			}

			NoteCanNoResponse("释放强制");
			Log("释放失败：控制器无回信。");
			return false;
		}
		finally
		{
			_canRequestLock.Release();
		}
	}

	private async Task SendRuntimeControlAsync(byte mode, string text)
	{
		if (_offlineSimulation)
		{
			Log("离线演示不控制真实程序，业务" + text + "命令需连接控制器后才生效。");
			return;
		}

		if (!EnsureAdapterForDebugCommand())
		{
			return;
		}

		ICanAdapter? adapter = _adapter;
		if (adapter == null)
		{
			return;
		}

		if (!SendMonitorSession(open: true))
		{
			Log(text + "失败：监控会话未打开。");
			return;
		}

		RuntimeControlResult result = await SendRuntimeControlRequestAsync(adapter, mode, CancellationToken.None).ConfigureAwait(true);
		if (!result.Success)
		{
			Log(text + "失败：控制器无回信。");
			return;
		}

		if (result.Status != 0)
		{
			Log(text + "失败：控制器返回状态 " + result.Status + "。");
			return;
		}

		Log("已发送业务" + text + "命令。业务入口接入 CanMonitor_BusinessGate() 后生效。");
	}

	private async Task<RuntimeControlResult> SendRuntimeControlRequestAsync(ICanAdapter adapter, byte mode, CancellationToken token)
	{
		await _canRequestLock.WaitAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			byte seq = ++_seq;
			byte[] data = MonitorProtocol.BuildRuntimeControlRequest(seq, mode);
			if (!TrySendMonitorFrame(adapter, data, "业务运行控制"))
			{
				return new RuntimeControlResult(false, byte.MaxValue, mode);
			}

			DateTime deadline = DateTime.UtcNow.AddMilliseconds(180.0);
			while (DateTime.UtcNow < deadline && !token.IsCancellationRequested)
			{
				int num = 0;
				CanFrame frame;
				while (num++ < 64 && DateTime.UtcNow < deadline && !token.IsCancellationRequested && adapter.TryReceive(out frame))
				{
					if (frame.Id == MonitorResponseId && MonitorProtocol.TryParseRuntimeControlAck(frame, seq, out byte status, out byte ackMode))
					{
						NoteCanResponse();
						return new RuntimeControlResult(true, status, ackMode);
					}
				}
				await Task.Delay(2, token).ConfigureAwait(continueOnCapturedContext: false);
			}

			NoteCanNoResponse("业务运行控制");
			return new RuntimeControlResult(false, byte.MaxValue, mode);
		}
		finally
		{
			_canRequestLock.Release();
		}
	}

	private bool EnsureAdapterForDebugCommand()
	{
		if (_offlineSimulation)
		{
			return true;
		}

		if (_adapter != null)
		{
			return true;
		}

		ToggleConnect();
		if (_adapter != null)
		{
			return true;
		}

		Log("未连接：无法发送强制/单步命令。");
		return false;
	}

	private void SetForceButtonsEnabled(bool enabled)
	{
		if (_writeValueButton != null)
		{
			_writeValueButton.Enabled = enabled;
		}
		if (_holdValueButton != null)
		{
			_holdValueButton.Enabled = enabled;
		}
		if (_releaseForceButton != null)
		{
			_releaseForceButton.Enabled = enabled;
		}
		if (_runtimeRunButton != null)
		{
			_runtimeRunButton.Enabled = enabled;
		}
		if (_runtimePauseButton != null)
		{
			_runtimePauseButton.Enabled = enabled;
		}
		if (_runtimeStepButton != null)
		{
			_runtimeStepButton.Enabled = enabled;
		}
	}

	private string? PromptWatchValue(WatchItem item, bool force, string currentValue)
	{
		using Form dialog = new Form
		{
			Text = force ? "保持变量" : "写入变量",
			FormBorderStyle = FormBorderStyle.FixedDialog,
			StartPosition = FormStartPosition.CenterParent,
			MinimizeBox = false,
			MaximizeBox = false,
			ClientSize = new Size(360, 130),
			BackColor = _panel,
			ForeColor = _ink,
			Font = new Font("Microsoft YaHei UI", 9f),
			ShowInTaskbar = false
		};

		Label nameLabel = new Label
		{
			Text = GetWatchDisplayName(item),
			AutoSize = false,
			Location = new Point(14, 12),
			Size = new Size(332, 24),
			ForeColor = _ink,
			BackColor = Color.Transparent,
			Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold)
		};
		Label hintLabel = new Label
		{
			Text = force ? "保持为" : "写入一次",
			AutoSize = false,
			Location = new Point(14, 42),
			Size = new Size(70, 24),
			ForeColor = _muted,
			BackColor = Color.Transparent
		};
		TextBox valueBox = new TextBox
		{
			Location = new Point(88, 40),
			Size = new Size(258, 24),
			Text = currentValue
		};
		StyleTextBox(valueBox);

		Button okButton = PlainButton(force ? "保持" : "写入");
		okButton.Size = new Size(72, 28);
		okButton.Location = new Point(186, 86);
		okButton.DialogResult = DialogResult.OK;
		ApplyButtonStyle(okButton, "accent");

		Button cancelButton = PlainButton("取消");
		cancelButton.Size = new Size(72, 28);
		cancelButton.Location = new Point(274, 86);
		cancelButton.DialogResult = DialogResult.Cancel;

		dialog.Controls.Add(nameLabel);
		dialog.Controls.Add(hintLabel);
		dialog.Controls.Add(valueBox);
		dialog.Controls.Add(okButton);
		dialog.Controls.Add(cancelButton);
		dialog.AcceptButton = okButton;
		dialog.CancelButton = cancelButton;

		dialog.Shown += delegate
		{
			valueBox.Focus();
			valueBox.SelectAll();
		};

		return dialog.ShowDialog(this) == DialogResult.OK ? valueBox.Text.Trim() : null;
	}

	private bool TryParseForceValue(WatchItem item, string text, out uint rawValue, out string error)
	{
		rawValue = 0;
		error = "";
		string valueText = text.Trim();
		if (valueText.Length == 0)
		{
			error = "请输入数值";
			return false;
		}

		int bytes = Math.Clamp(item.Size, 1, 4);
		int bits = bytes * 8;
		bool signed = IsSignedWatchItem(item);
		if (valueText.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
		{
			if (!ulong.TryParse(valueText.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out ulong hexValue))
			{
				error = "16进制格式错误";
				return false;
			}

			ulong maxHex = bits == 32 ? 0xFFFFFFFFUL : ((1UL << bits) - 1UL);
			if (hexValue > maxHex)
			{
				error = "数值超出 " + bytes + " 字节范围";
				return false;
			}

			rawValue = (uint)hexValue;
			return true;
		}

		if (IsFloatWatchItem(item) && bytes == 4)
		{
			if (!double.TryParse(valueText, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double floatValue) &&
				!double.TryParse(valueText, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.CurrentCulture, out floatValue))
			{
				error = "浮点数格式错误";
				return false;
			}

			rawValue = BitConverter.SingleToUInt32Bits((float)floatValue);
			return true;
		}

		if (!long.TryParse(valueText, out long signedValue))
		{
			error = "请输入十进制或 0x 开头的 16 进制";
			return false;
		}

		if (signed)
		{
			long min = -(1L << (bits - 1));
			long max = (1L << (bits - 1)) - 1L;
			if (bits == 32)
			{
				min = int.MinValue;
				max = int.MaxValue;
			}
			if (signedValue < min || signedValue > max)
			{
				error = $"有符号范围 {min} 到 {max}";
				return false;
			}

			rawValue = signedValue < 0
				? (uint)((bits == 32 ? 0x100000000L : (1L << bits)) + signedValue)
				: (uint)signedValue;
			return true;
		}

		long unsignedMax = bits == 32 ? uint.MaxValue : ((1L << bits) - 1L);
		if (signedValue < 0 || signedValue > unsignedMax)
		{
			error = $"无符号范围 0 到 {unsignedMax}";
			return false;
		}

		rawValue = (uint)signedValue;
		return true;
	}

	private static string BuildWriteStatusText(byte status)
	{
		return status switch
		{
			0 => "成功",
			1 => "地址不在 RAM",
			2 => "长度不支持",
			3 => "强制表已满",
			4 => "监控会话未打开",
			_ => "状态 " + status,
		};
	}

	private async Task PollTrace(CancellationToken token)
	{
		ICanAdapter adapter = _adapter;
		if (adapter == null)
		{
			return;
		}
		await _canRequestLock.WaitAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		try
		{
			byte seq = ++_seq;
			byte[] data = MonitorProtocol.BuildTraceRequest(seq);
			if (!TrySendMonitorFrame(adapter, data, "读取运行位置"))
			{
				NoteCanNoResponse("发送运行位置失败");
				return;
			}
			DateTime deadline = DateTime.UtcNow.AddMilliseconds(60.0);
			while (DateTime.UtcNow < deadline && !token.IsCancellationRequested)
			{
				int num = 0;
				CanFrame frame;
				while (num++ < 64 && DateTime.UtcNow < deadline && !token.IsCancellationRequested && adapter.TryReceive(out frame))
				{
					if (frame.Id == MonitorResponseId && MonitorProtocol.TryParseTraceAck(frame, seq, out var traceId))
					{
						NoteCanResponse();
						UpdateTrace(traceId);
						return;
					}
				}
				await Task.Delay(2, token).ConfigureAwait(continueOnCapturedContext: false);
			}
			if (!token.IsCancellationRequested)
			{
				NoteCanNoResponse("运行位置");
			}
		}
		catch
		{
			NoteCanNoResponse("运行位置异常");
		}
		finally
		{
			_canRequestLock.Release();
		}
	}

	private void UpdateTrace(ushort traceId)
	{
		if (traceId == _lastTraceId)
		{
			return;
		}
		_lastTraceId = traceId;
		BeginInvoke(delegate
		{
			if (_runtimeLocationLabel != null)
			{
				string value;
				if (traceId == 0)
				{
					_runtimeLocationLabel.Text = GetProgramEntryDisplayName();
				}
				else if (traceId == 8193)
				{
					_runtimeLocationLabel.Text = "主循环";
				}
				else if (_traceLabels.TryGetValue(traceId, out value) && !string.IsNullOrWhiteSpace(value))
				{
					_runtimeLocationLabel.Text = value;
				}
				else
				{
					_runtimeLocationLabel.Text = "运行中";
				}
				if (traceId != 0)
				{
					HighlightTraceRows(traceId);
				}
			}
		});
	}

	private void HighlightTraceRows(ushort traceId)
	{
		_flowChart?.SetHighlight(traceId);
	}

	private void FlowChartNodeClick(object? sender, FlowChartNode node)
	{
		try
		{
			List<string> candidates = ExtractFunctionNameCandidates(node).ToList();
			if (candidates.Count == 0)
			{
				Log("该节点没有可打开的函数。");
				return;
			}
			if (string.IsNullOrWhiteSpace(_workDirectory) || !Directory.Exists(_workDirectory))
			{
				Log("工作目录无效，无法打开函数：" + candidates[0]);
				return;
			}
			ClearProgramSearchHighlight();

			foreach (string functionName in candidates)
			{
				if (TryLoadFunctionSource(_workDirectory, functionName, out FunctionSourceView? sourceView) && sourceView != null)
				{
					_functionHistory.Clear();
					ShowFunctionSource(sourceView);
					Log($"已进入函数：{functionName}  {sourceView.FilePath}:{sourceView.StartLine}");
					return;
				}
			}

			Log("未找到函数位置：" + string.Join(" / ", candidates.Take(4)));
		}
		catch (Exception ex)
		{
			Log("打开函数失败：" + ex.Message);
		}
	}

	private static IEnumerable<string> ExtractFunctionNameCandidates(FlowChartNode node)
	{
		var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		if (!string.IsNullOrWhiteSpace(node.FunctionName) && used.Add(node.FunctionName))
		{
			yield return node.FunctionName;
		}

		foreach (Match match in Regex.Matches(node.Text, @"[A-Za-z_][A-Za-z0-9_]*"))
		{
			string name = match.Value;
			if (name.Length < 2)
			{
				continue;
			}
			if (used.Add(name))
			{
				yield return name;
			}
		}
	}

	private bool TryLoadFunctionSource(string root, string functionName, out FunctionSourceView? sourceView)
	{
		EnsureFunctionIndex(root);
		if (_functionIndex.TryGetValue(functionName, out FunctionIndexEntry? entry) &&
			TryLoadFunctionSourceFromFile(entry.FilePath, functionName, out sourceView))
		{
			return true;
		}

		foreach (string file in EnumerateSourceFilesForOpen(root))
		{
			if (TryLoadFunctionSourceFromFile(file, functionName, out sourceView))
			{
				return true;
			}
		}
		sourceView = null;
		return false;
	}

	private bool TryLoadFunctionSourceFromFile(string file, string functionName, out FunctionSourceView? sourceView)
	{
		string text;
		try
		{
			text = ReadSourceText(file);
		}
		catch
		{
			sourceView = null;
			return false;
		}

		Match match = FindFunctionDefinitionMatch(text, functionName);
		if (!match.Success)
		{
			sourceView = null;
			return false;
		}
		int lineStart = text.LastIndexOf('\n', match.Index);
		lineStart = lineStart < 0 ? 0 : lineStart + 1;
		int openBrace = SkipTriviaAndComments(text, match.Index + match.Length);
		int closeBrace = FindMatchingBrace(text, openBrace);
		if (openBrace < 0 || closeBrace < 0)
		{
			sourceView = null;
			return false;
		}
		int startLine = 1 + text.Take(lineStart).Count(c => c == '\n');
		string sourceText = text.Substring(lineStart, closeBrace - lineStart + 1).Replace("\r\n", "\n").Replace('\r', '\n');
		sourceView = new FunctionSourceView(functionName, file, startLine, sourceText.Split('\n'), lineStart, closeBrace - lineStart + 1);
		return true;
	}

	private bool RefreshCurrentFunctionSourceFromDisk(bool logResult)
	{
		if (_currentFunctionSource == null || _functionCodePanel == null || !_functionCodePanel.Visible)
		{
			return false;
		}

		FunctionSourceView oldSource = _currentFunctionSource;
		if (!File.Exists(oldSource.FilePath))
		{
			if (logResult)
			{
				Log("当前代码文件不存在，无法刷新：" + oldSource.FilePath);
			}
			return false;
		}

		bool loaded = TryLoadFunctionSourceFromFile(oldSource.FilePath, oldSource.FunctionName, out FunctionSourceView? refreshed) && refreshed != null;
		if (!loaded)
		{
			loaded = TryLoadSourceSnippet(oldSource.FilePath, oldSource.StartLine, out refreshed) && refreshed != null;
		}
		if (!loaded || refreshed == null)
		{
			if (logResult)
			{
				Log("当前代码页未找到可刷新内容：" + oldSource.FunctionName);
			}
			return false;
		}

		_currentFunctionSource = refreshed;
		_currentFunctionIdentifiers = BuildIdentifierSet(refreshed.Lines);
		_lastFunctionCodeText = "";
		_lastDataCodeText = "";
		_lastVisibleValuesText = "";
		_lastVisibleConditionSignature = "";
		_lastVisibleRangeSignature = "";
		_resetFunctionScrollOnNextRender = false;
		if (_functionCodeTitle != null)
		{
			string relativePath = GetRelativePathSafe(_workDirectory, refreshed.FilePath);
			_functionCodeTitle.Text = $"{refreshed.FunctionName}    {relativePath}:{refreshed.StartLine}";
		}
		RenderFunctionSource();
		if (logResult)
		{
			Log("当前代码页已刷新：" + refreshed.FunctionName);
		}
		return true;
	}

	private void EnsureFunctionIndex(string root)
	{
		if (_functionIndex.Count > 0 && _functionIndexRoot.Equals(root, StringComparison.OrdinalIgnoreCase))
		{
			return;
		}

		BuildFunctionIndex(root);
	}

	private void ClearFunctionIndex()
	{
		_functionIndex.Clear();
		_functionIndexRoot = "";
		ClearFunctionHoverCache();
	}

	private void BuildFunctionIndex(string root)
	{
		_functionIndex = BuildFunctionIndexSnapshot(root);
		_functionIndexRoot = root;
		ClearFunctionHoverCache();
	}

	private void WarmFunctionIndex(string root)
	{
		if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root))
		{
			return;
		}

		Task.Run(() => BuildFunctionIndexSnapshot(root)).ContinueWith(task =>
		{
			if (task.Status != TaskStatus.RanToCompletion || IsDisposed)
			{
				return;
			}

			try
			{
				BeginInvoke((Action)(() =>
				{
					if (_workDirectory.Equals(root, StringComparison.OrdinalIgnoreCase) &&
						(_functionIndex.Count == 0 || !_functionIndexRoot.Equals(root, StringComparison.OrdinalIgnoreCase)))
					{
						_functionIndex = task.Result;
						_functionIndexRoot = root;
						ClearFunctionHoverCache();
					}
				}));
			}
			catch
			{
			}
		}, TaskScheduler.Default);
	}

	private static Dictionary<string, FunctionIndexEntry> BuildFunctionIndexSnapshot(string root)
	{
		var index = new Dictionary<string, FunctionIndexEntry>(StringComparer.OrdinalIgnoreCase);
		foreach (string file in EnumerateSourceFilesForOpen(root))
		{
			string text;
			try
			{
				text = ReadSourceText(file);
			}
			catch
			{
				continue;
			}

			foreach (Match match in Regex.Matches(text, @"(?m)^[\t ]*(?:[A-Za-z_][A-Za-z0-9_\s\*\(\),\[\]]+?[\s\*]+)?(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)", RegexOptions.IgnoreCase))
			{
				string name = match.Groups["name"].Value;
				if (name.Length == 0 || IsCKeyword(name))
				{
					continue;
				}

				int afterSignature = SkipTriviaAndComments(text, match.Index + match.Length);
				if (afterSignature < text.Length && text[afterSignature] == '{' && !index.ContainsKey(name))
				{
					index[name] = new FunctionIndexEntry(name, file);
				}
			}
		}

		return index;
	}

	private void ClearFunctionHoverCache()
	{
		_lastFunctionHoverCharIndex = -1;
		_lastFunctionHoverIdentifier = "";
		_lastFunctionHoverNavigable = false;
	}

	private static bool IsCKeyword(string name)
	{
		return IsCKeywordToken(name.ToLowerInvariant());
	}

	private static bool IsCKeywordToken(string name)
	{
		return name.Equals("auto", StringComparison.Ordinal) ||
			name.Equals("break", StringComparison.Ordinal) ||
			name.Equals("case", StringComparison.Ordinal) ||
			name.Equals("char", StringComparison.Ordinal) ||
			name.Equals("const", StringComparison.Ordinal) ||
			name.Equals("continue", StringComparison.Ordinal) ||
			name.Equals("default", StringComparison.Ordinal) ||
			name.Equals("do", StringComparison.Ordinal) ||
			name.Equals("double", StringComparison.Ordinal) ||
			name.Equals("else", StringComparison.Ordinal) ||
			name.Equals("enum", StringComparison.Ordinal) ||
			name.Equals("extern", StringComparison.Ordinal) ||
			name.Equals("float", StringComparison.Ordinal) ||
			name.Equals("for", StringComparison.Ordinal) ||
			name.Equals("goto", StringComparison.Ordinal) ||
			name.Equals("if", StringComparison.Ordinal) ||
			name.Equals("int", StringComparison.Ordinal) ||
			name.Equals("long", StringComparison.Ordinal) ||
			name.Equals("register", StringComparison.Ordinal) ||
			name.Equals("return", StringComparison.Ordinal) ||
			name.Equals("short", StringComparison.Ordinal) ||
			name.Equals("signed", StringComparison.Ordinal) ||
			name.Equals("sizeof", StringComparison.Ordinal) ||
			name.Equals("static", StringComparison.Ordinal) ||
			name.Equals("struct", StringComparison.Ordinal) ||
			name.Equals("switch", StringComparison.Ordinal) ||
			name.Equals("typedef", StringComparison.Ordinal) ||
			name.Equals("union", StringComparison.Ordinal) ||
			name.Equals("unsigned", StringComparison.Ordinal) ||
			name.Equals("void", StringComparison.Ordinal) ||
			name.Equals("volatile", StringComparison.Ordinal) ||
			name.Equals("while", StringComparison.Ordinal);
	}

	private static Match FindFunctionDefinitionMatch(string text, string functionName)
	{
		if (IsCKeyword(functionName))
		{
			return Match.Empty;
		}

		foreach (Match match in Regex.Matches(text, $@"\b{Regex.Escape(functionName)}\s*\([^;{{}}]*\)", RegexOptions.IgnoreCase))
		{
			int afterSignature = SkipTriviaAndComments(text, match.Index + match.Length);
			if (afterSignature < text.Length && text[afterSignature] == '{')
			{
				return match;
			}
		}

		return Match.Empty;
	}

	private static int SkipTriviaAndComments(string text, int index)
	{
		int i = index;
		while (i < text.Length)
		{
			while (i < text.Length && char.IsWhiteSpace(text[i]))
			{
				i++;
			}

			if (i + 1 < text.Length && text[i] == '/' && text[i + 1] == '/')
			{
				i += 2;
				while (i < text.Length && text[i] != '\n')
				{
					i++;
				}
				continue;
			}

			if (i + 1 < text.Length && text[i] == '/' && text[i + 1] == '*')
			{
				i += 2;
				while (i + 1 < text.Length && !(text[i] == '*' && text[i + 1] == '/'))
				{
					i++;
				}
				if (i + 1 < text.Length)
				{
					i += 2;
				}
				continue;
			}

			break;
		}

		return i;
	}

	private static string ReadSourceText(string filePath)
	{
		return ReadSourceText(filePath, out _);
	}

	private static string ReadSourceText(string filePath, out Encoding encoding)
	{
		byte[] bytes = File.ReadAllBytes(filePath);
		if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
		{
			encoding = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true);
			return Encoding.UTF8.GetString(bytes);
		}
		if (bytes.Length >= 2)
		{
			if (bytes[0] == 0xFF && bytes[1] == 0xFE)
			{
				encoding = Encoding.Unicode;
				return Encoding.Unicode.GetString(bytes);
			}
			if (bytes[0] == 0xFE && bytes[1] == 0xFF)
			{
				encoding = Encoding.BigEndianUnicode;
				return Encoding.BigEndianUnicode.GetString(bytes);
			}
		}
		try
		{
			encoding = new UTF8Encoding(false, true);
			return encoding.GetString(bytes);
		}
		catch (DecoderFallbackException)
		{
			encoding = Encoding.GetEncoding("GB18030");
			return encoding.GetString(bytes);
		}
	}

	private static int FindMatchingBrace(string text, int openBrace)
	{
		if (openBrace < 0 || openBrace >= text.Length)
		{
			return -1;
		}
		int depth = 0;
		bool inLineComment = false;
		bool inBlockComment = false;
		bool inString = false;
		bool inChar = false;
		bool escape = false;
		for (int i = openBrace; i < text.Length; i++)
		{
			char c = text[i];
			char next = i + 1 < text.Length ? text[i + 1] : '\0';
			if (inLineComment)
			{
				if (c == '\n')
				{
					inLineComment = false;
				}
				continue;
			}
			if (inBlockComment)
			{
				if (c == '*' && next == '/')
				{
					inBlockComment = false;
					i++;
				}
				continue;
			}
			if (inString || inChar)
			{
				if (escape)
				{
					escape = false;
					continue;
				}
				if (c == '\\')
				{
					escape = true;
					continue;
				}
				if (inString && c == '"')
				{
					inString = false;
				}
				else if (inChar && c == '\'')
				{
					inChar = false;
				}
				continue;
			}
			if (c == '/' && next == '/')
			{
				inLineComment = true;
				i++;
				continue;
			}
			if (c == '/' && next == '*')
			{
				inBlockComment = true;
				i++;
				continue;
			}
			if (c == '"')
			{
				inString = true;
				continue;
			}
			if (c == '\'')
			{
				inChar = true;
				continue;
			}
			if (c == '{')
			{
				depth++;
			}
			else if (c == '}')
			{
				depth--;
				if (depth == 0)
				{
					return i;
				}
			}
		}
		return -1;
	}

	private void ShowFunctionSource(FunctionSourceView sourceView, bool pushCurrent = false)
	{
		if (pushCurrent && _currentFunctionSource != null)
		{
			_functionHistory.Push(_currentFunctionSource);
		}
		_currentFunctionSource = sourceView;
		_currentFunctionIdentifiers = BuildIdentifierSet(sourceView.Lines);
		if (_activeProgramSearchLine > 0 && _activeProgramSearchLine < sourceView.StartLine)
		{
			_activeProgramSearchLine = sourceView.StartLine;
		}
		_lastFunctionCodeText = "";
		_lastDataCodeText = "";
		_lastVisibleValuesText = "";
		_lastVisibleConditionSignature = "";
		_lastVisibleRangeSignature = "";
		_lastScopeHighlightSelectionStart = -1;
		_resetFunctionScrollOnNextRender = true;
		if (_functionCodeTitle != null)
		{
			string relativePath = GetRelativePathSafe(_workDirectory, sourceView.FilePath);
			_functionCodeTitle.Text = $"{sourceView.FunctionName}    {relativePath}:{sourceView.StartLine}";
		}
		_functionCodePanel.Visible = true;
		_functionCodePanel.BringToFront();
		_flowChart.Visible = false;
		_flowChart.SetAnimationEnabled(false);
		_runtimeLocationLabel.Text = sourceView.FunctionName;
		AutoWatchVariablesForFunction(sourceView);
		UpdateFunctionBackButton();
		RenderFunctionSource();
		UpdateProgramInsightPanel(force: true);
	}

	private void ShowProgramGraph()
	{
		_currentFunctionSource = null;
		_currentFunctionIdentifiers.Clear();
		_functionHistory.Clear();
		_lastFunctionCodeText = "";
		_lastDataCodeText = "";
		_lastVisibleValuesText = "";
		_lastVisibleConditionSignature = "";
		_lastVisibleRangeSignature = "";
		_functionCodeDirty = false;
		_dataCodeDirty = false;
		_functionCodePanel.Visible = false;
		if (_dataCodeTitle != null)
		{
			_dataCodeTitle.Text = "跟随 3 看程序";
		}
		if (_dataCodeBox != null)
		{
			_dataCodeBox.Clear();
		}
		if (_visibleValuesLabel != null)
		{
			_visibleValuesLabel.Text = "可见变量：无";
		}
		_flowChart.Visible = true;
		_flowChart.BringToFront();
		_flowChart.SetAnimationEnabled(false);
		if (_lastTraceId == ushort.MaxValue || _lastTraceId == 0)
		{
			_runtimeLocationLabel.Text = GetProgramEntryDisplayName();
		}
		UpdateProgramInsightPanel(force: true);
	}

	private void NavigateFunctionBack()
	{
		if (_functionHistory.Count > 0)
		{
			FunctionSourceView previous = _functionHistory.Pop();
			ShowFunctionSource(previous);
			return;
		}

		ShowProgramGraph();
	}

	private void UpdateFunctionBackButton()
	{
		if (_functionBackButton == null)
		{
			return;
		}

		_functionBackButton.Text = _functionHistory.Count > 0 ? "上级" : "返回";
	}

	private void MarkFunctionCodeDirty(WatchItem? changedItem = null)
	{
		if (_currentFunctionSource == null || _functionCodePanel == null || !_functionCodePanel.Visible)
		{
			return;
		}
		if (changedItem != null && !CurrentFunctionMentionsWatch(changedItem))
		{
			return;
		}
		_dataCodeDirty = true;
	}

	private void MarkUiWheelActivity()
	{
		DateTime now = DateTime.UtcNow;
		_lastFunctionWheelUtc = now;
		_lastUiWheelUtc = now;
	}

	private bool ShouldDeferFunctionCodeRefresh()
	{
		return (DateTime.UtcNow - _lastFunctionWheelUtc).TotalMilliseconds < FunctionCodeWheelDeferMs;
	}

	private bool ShouldDeferUiValueRefresh()
	{
		return (DateTime.UtcNow - _lastUiWheelUtc).TotalMilliseconds < UiValueWheelDeferMs;
	}

	private bool CurrentFunctionMentionsWatch(WatchItem item)
	{
		if (_currentFunctionIdentifiers.Count == 0)
		{
			return false;
		}

		if (IdentifierSetContainsWatch(_currentFunctionIdentifiers, item.Name))
		{
			return true;
		}

		return item.IsChild && item.ParentName.Length > 0 && IdentifierSetContainsWatch(_currentFunctionIdentifiers, item.ParentName);
	}

	private bool VisibleRangeMentionsWatch(WatchItem item)
	{
		return VisibleRangeMentionsWatch(item, GetVisibleRawLines(DataMirrorPaddingLines));
	}

	private bool VisibleRangeMentionsWatch(WatchItem item, IEnumerable<string> lines)
	{
		if (_currentFunctionSource == null)
		{
			return false;
		}

		foreach (string line in lines)
		{
			if (LineMentionsWatch(line, item.Name) ||
				(item.IsChild && item.ParentName.Length > 0 && LineMentionsWatch(line, item.ParentName)))
			{
				return true;
			}
		}
		return false;
	}

	private static bool IdentifierSetContainsWatch(HashSet<string> identifiers, string watchName)
	{
		if (string.IsNullOrWhiteSpace(watchName))
		{
			return false;
		}

		return WatchIdentifierAliases(watchName).Any(identifiers.Contains);
	}

	private static string GetIdentifierBase(string text)
	{
		if (string.IsNullOrWhiteSpace(text) || !IsIdentifierStart(text[0]))
		{
			return "";
		}
		int end = 1;
		while (end < text.Length && IsIdentifierChar(text[end]))
		{
			end++;
		}
		return text.Substring(0, end);
	}

	private static string GetIdentifierTail(string text)
	{
		if (string.IsNullOrWhiteSpace(text))
		{
			return "";
		}

		string value = text.Trim();
		while (value.EndsWith("]", StringComparison.Ordinal))
		{
			int bracket = value.LastIndexOf('[');
			if (bracket < 0)
			{
				break;
			}
			value = value.Substring(0, bracket).TrimEnd();
		}

		for (int end = value.Length - 1; end >= 0; end--)
		{
			if (!IsIdentifierChar(value[end]))
			{
				continue;
			}

			int start = end;
			while (start > 0 && IsIdentifierChar(value[start - 1]))
			{
				start--;
			}
			string tail = value.Substring(start, end - start + 1);
			return IsIdentifierStart(tail[0]) ? tail : "";
		}

		return "";
	}

	private static IEnumerable<string> WatchIdentifierAliases(string watchName)
	{
		if (string.IsNullOrWhiteSpace(watchName))
		{
			yield break;
		}

		if (watchName.All(IsIdentifierChar))
		{
			yield return watchName;
		}

		string baseName = GetIdentifierBase(watchName);
		if (baseName.Length > 0)
		{
			yield return baseName;
		}

		string tailName = GetIdentifierTail(watchName);
		if (tailName.Length > 0 && !tailName.Equals(baseName, StringComparison.OrdinalIgnoreCase))
		{
			yield return tailName;
		}
	}

	private static string GetWatchDisplayName(WatchItem item)
	{
		string tailName = GetIdentifierTail(item.Name);
		if (tailName.Length > 0)
		{
			return tailName;
		}

		string baseName = GetIdentifierBase(item.Name);
		return baseName.Length > 0 ? baseName : item.Name;
	}

	private static HashSet<string> BuildIdentifierSet(IEnumerable<string> lines)
	{
		return BuildIdentifierList(lines).ToHashSet(StringComparer.OrdinalIgnoreCase);
	}

	private static List<string> BuildIdentifierList(IEnumerable<string> lines)
	{
		var identifiers = new List<string>();
		var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (string line in lines)
		{
			for (int i = 0; i < line.Length; i++)
			{
				if (!IsIdentifierStart(line[i]))
				{
					continue;
				}
				int start = i;
				i++;
				while (i < line.Length && IsIdentifierChar(line[i]))
				{
					i++;
				}
				string identifier = line.Substring(start, i - start);
				if (seen.Add(identifier))
				{
					identifiers.Add(identifier);
				}
				i--;
			}
		}
		return identifiers;
	}

	private static List<string> BuildFunctionAutoWatchIdentifiers(IReadOnlyList<string> lines)
	{
		string text = string.Join(Environment.NewLine, lines);
		var identifiers = new List<string>();
		var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		void Add(string identifier)
		{
			if (string.IsNullOrWhiteSpace(identifier) ||
				IsCKeywordToken(identifier) ||
				!seen.Add(identifier))
			{
				return;
			}
			identifiers.Add(identifier);
		}

		foreach (string signal in EmbeddedCodeKnowledge.ExtractBusinessSignals(text))
		{
			Add(signal);
		}
		foreach (string identifier in BuildIdentifierList(lines))
		{
			Add(identifier);
		}
		return identifiers;
	}

	private void CodeBoxMouseDoubleClick(object? sender, MouseEventArgs e)
	{
		if (sender is not RichTextBox codeBox || codeBox.TextLength == 0)
		{
			return;
		}
		int index = codeBox.GetCharIndexFromPosition(e.Location);
		if (!TryGetIdentifierAt(codeBox.Text, index, out int start, out int length, out string identifier))
		{
			return;
		}
		codeBox.SelectionStart = start;
		codeBox.SelectionLength = length;

		if ((ModifierKeys & Keys.Control) != Keys.Control)
		{
			FillProgramSearchFromCode(identifier);
		}
	}

	private void CodeBoxMouseDown(object? sender, MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Right || sender is not RichTextBox codeBox)
		{
			return;
		}

		ShowCodeWatchContextMenu(codeBox, e.Location);
	}

	private void CodeBoxMouseUp(object? sender, MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Right || sender is not RichTextBox codeBox)
		{
			return;
		}

		ShowCodeWatchContextMenu(codeBox, e.Location);
	}

	private ContextMenuStrip CreateCodeWatchContextMenu(RichTextBox codeBox)
	{
		ContextMenuStrip menu = new ContextMenuStrip();
		menu.Opening += delegate(object? sender, CancelEventArgs e)
		{
			e.Cancel = true;
			if (ShouldSuppressAutomaticWatchContextMenu(codeBox))
			{
				return;
			}
			ShowCodeWatchContextMenu(codeBox, codeBox.PointToClient(Cursor.Position));
		};
		return menu;
	}

	private void FunctionCodeBoxMouseClick(object? sender, MouseEventArgs e)
	{
		if (e.Button != MouseButtons.Left || (ModifierKeys & Keys.Control) != Keys.Control)
		{
			return;
		}
		TryEnterFunctionAtPoint(e.Location, selectIdentifier: true);
	}

	private void ShowCodeWatchContextMenu(RichTextBox codeBox, Point location)
	{
		int index = codeBox.GetCharIndexFromPosition(location);
		if (!TryGetIdentifierAt(codeBox.Text, index, out int start, out int length, out string identifier) &&
			!TryGetNearestWatchIdentifier(codeBox.Text, index, out start, out length, out identifier))
		{
			ShowWatchContextMenu(null, "", codeBox, location);
			return;
		}

		codeBox.SelectionStart = start;
		codeBox.SelectionLength = length;
		FocusVariableAcrossPanels(identifier, updateSearchBox: true);
		TryResolveWatchContextTarget(identifier, null, addIfMissing: false, out WatchItem? item, out _);
		ShowWatchContextMenu(item, identifier, codeBox, location);
	}

	private bool TryGetNearestWatchIdentifier(string text, int index, out int start, out int length, out string identifier)
	{
		start = 0;
		length = 0;
		identifier = "";
		if (text.Length == 0)
		{
			return false;
		}

		int safeIndex = Math.Clamp(index, 0, text.Length - 1);
		int lineStart = text.LastIndexOf('\n', safeIndex);
		lineStart = lineStart < 0 ? 0 : lineStart + 1;
		int lineEnd = text.IndexOf('\n', safeIndex);
		lineEnd = lineEnd < 0 ? text.Length : lineEnd;
		if (lineEnd <= lineStart)
		{
			return false;
		}

		foreach (int candidateIndex in BuildNearbyIdentifierProbeOrder(safeIndex, lineStart, lineEnd))
		{
			if (!TryGetIdentifierAt(text, candidateIndex, out int candidateStart, out int candidateLength, out string candidate))
			{
				continue;
			}

			if (IsCKeyword(candidate))
			{
				continue;
			}

			if (FindWatchItemByIdentifier(candidate) != null || TryFindSymbolForSourceIdentifier(candidate, out _))
			{
				start = candidateStart;
				length = candidateLength;
				identifier = candidate;
				return true;
			}
		}

		return false;
	}

	private static IEnumerable<int> BuildNearbyIdentifierProbeOrder(int index, int lineStart, int lineEnd)
	{
		HashSet<int> yielded = new HashSet<int>();
		int left = Math.Clamp(index, lineStart, Math.Max(lineStart, lineEnd - 1));
		int right = left + 1;
		for (int step = 0; step < 96 && (left >= lineStart || right < lineEnd); step++)
		{
			if (left >= lineStart && yielded.Add(left))
			{
				yield return left;
				left--;
			}
			if (right < lineEnd && yielded.Add(right))
			{
				yield return right;
				right++;
			}
		}
	}

	private void ShowWatchContextMenu(WatchItem? item, string identifier, Control owner, Point location)
	{
		if (!TryBeginWatchContextMenu(owner))
		{
			return;
		}

		string displayName = item != null ? GetWatchDisplayName(item) : NormalizeFocusedVariableName(identifier);
		if (string.IsNullOrWhiteSpace(displayName))
		{
			displayName = string.IsNullOrWhiteSpace(identifier) ? "未选中变量" : identifier;
		}

		bool canWatch = !string.IsNullOrWhiteSpace(identifier) &&
			(item != null || TryResolveWatchContextTarget(identifier, null, addIfMissing: false, out _, out _));
		ContextMenuStrip menu = new ContextMenuStrip
		{
			BackColor = _surface,
			ForeColor = _ink,
			ShowImageMargin = false
		};
		menu.Closed += delegate
		{
			try
			{
				if (!IsDisposed && IsHandleCreated)
				{
					BeginInvoke((Action)(() => menu.Dispose()));
				}
				else
				{
					menu.Dispose();
				}
			}
			catch (InvalidOperationException)
			{
				menu.Dispose();
			}
		};

		ToolStripMenuItem titleItem = new ToolStripMenuItem("变量：" + displayName)
		{
			Enabled = false
		};
		menu.Items.Add(titleItem);
		menu.Items.Add(new ToolStripSeparator());

		ToolStripMenuItem writeOnce = new ToolStripMenuItem("写入一次...");
		writeOnce.Enabled = canWatch;
		writeOnce.Click += async delegate
		{
			if (TryResolveWatchContextTarget(identifier, item, addIfMissing: true, out WatchItem? target, out string error) && target != null)
			{
				await PromptAndWriteWatchValueAsync(target, force: false).ConfigureAwait(true);
			}
			else
			{
				Log("写入失败：" + error);
			}
		};
		menu.Items.Add(writeOnce);

		ToolStripMenuItem holdValue = new ToolStripMenuItem("保持为...");
		holdValue.Enabled = canWatch;
		holdValue.Click += async delegate
		{
			if (TryResolveWatchContextTarget(identifier, item, addIfMissing: true, out WatchItem? target, out string error) && target != null)
			{
				await PromptAndWriteWatchValueAsync(target, force: true).ConfigureAwait(true);
			}
			else
			{
				Log("保持失败：" + error);
			}
		};
		menu.Items.Add(holdValue);

		ToolStripMenuItem releaseValue = new ToolStripMenuItem("释放保持");
		releaseValue.Enabled = canWatch;
		releaseValue.Click += async delegate
		{
			if (TryResolveWatchContextTarget(identifier, item, addIfMissing: true, out WatchItem? target, out string error) && target != null)
			{
				await ReleaseWatchForceAsync(target).ConfigureAwait(true);
			}
			else
			{
				Log("释放失败：" + error);
			}
		};
		menu.Items.Add(releaseValue);

		menu.Items.Add(new ToolStripSeparator());
		ToolStripMenuItem copyName = new ToolStripMenuItem("复制变量名");
		copyName.Enabled = !string.IsNullOrWhiteSpace(identifier) || item != null;
		copyName.Click += delegate
		{
			if (!string.IsNullOrWhiteSpace(displayName) && !displayName.Equals("未选中变量", StringComparison.Ordinal))
			{
				Clipboard.SetText(displayName);
			}
		};
		menu.Items.Add(copyName);

		if (!canWatch)
		{
			ToolStripMenuItem unavailable = new ToolStripMenuItem("该变量不可监控")
			{
				Enabled = false
			};
			menu.Items.Insert(2, unavailable);
		}

		menu.Show(owner, location);
	}

	private bool TryBeginWatchContextMenu(Control owner)
	{
		DateTime now = DateTime.UtcNow;
		if (ReferenceEquals(_lastWatchContextMenuOwner, owner) &&
			(now - _lastWatchContextMenuShownUtc).TotalMilliseconds < 800)
		{
			return false;
		}

		_lastWatchContextMenuOwner = owner;
		_lastWatchContextMenuShownUtc = now;
		return true;
	}

	private bool ShouldSuppressAutomaticWatchContextMenu(Control owner)
	{
		return ReferenceEquals(_lastWatchContextMenuOwner, owner) &&
			(DateTime.UtcNow - _lastWatchContextMenuShownUtc).TotalMilliseconds < 800;
	}

	private bool TryResolveWatchContextTarget(string identifier, WatchItem? knownItem, bool addIfMissing, out WatchItem? item, out string error)
	{
		item = null;
		error = "";
		string name = NormalizeFocusedVariableName(identifier);
		if (knownItem != null)
		{
			if (!addIfMissing || _watchItems.Contains(knownItem))
			{
				item = knownItem;
				return true;
			}

			name = knownItem.Name;
		}

		if (name.Length == 0)
		{
			error = "没有选中变量";
			return false;
		}

		WatchItem? existing = FindWatchItemByIdentifier(name);
		if (existing != null)
		{
			item = existing;
			return true;
		}

		if (!TryFindSymbolForSourceIdentifier(name, out MapSymbol symbol))
		{
			error = "map 中没有该变量";
			return false;
		}

		if (!KeilMapParser.TryResolve(symbol.Name, _symbolLookup, out WatchItem resolved, out error))
		{
			return false;
		}

		if (!addIfMissing)
		{
			item = resolved;
			return true;
		}

		if (!EnsureWatchCapacityForCurrentContext(out int removed))
		{
			error = $"已达到 {MaxWatchItems} 个变量上限";
			return false;
		}

		if (removed > 0)
		{
			Log($"当前窗口变量优先：已移出 {removed} 个不可见变量。");
		}

		resolved.AutoVisible = false;
		_watchItems.Add(resolved);
		UpdateCycleEstimate();
		SaveDefaultProfileQuietly();
		MarkFunctionCodeDirty(resolved);
		FocusVariableAcrossPanels(GetWatchDisplayName(resolved), updateSearchBox: true);
		Log("已加入监控：" + resolved.Name);
		item = resolved;
		return true;
	}

	private bool TryEnterFunctionAtPoint(Point location, bool selectIdentifier)
	{
		if (_functionCodeBox == null || _functionCodeBox.TextLength == 0)
		{
			return false;
		}
		int index = _functionCodeBox.GetCharIndexFromPosition(location);
		if (!TryGetIdentifierAt(_functionCodeBox.Text, index, out int start, out int length, out string identifier))
		{
			return false;
		}
		if (selectIdentifier)
		{
			_functionCodeBox.SelectionStart = start;
			_functionCodeBox.SelectionLength = length;
		}
		if (_currentFunctionSource == null ||
			identifier.Equals(_currentFunctionSource.FunctionName, StringComparison.OrdinalIgnoreCase) ||
			string.IsNullOrWhiteSpace(_workDirectory) ||
			!Directory.Exists(_workDirectory) ||
			!TryLoadFunctionSource(_workDirectory, identifier, out FunctionSourceView? nestedSource) ||
			nestedSource == null)
		{
			return false;
		}

		ShowFunctionSource(nestedSource, pushCurrent: true);
		Log($"已进入函数：{identifier}  {nestedSource.FilePath}:{nestedSource.StartLine}");
		return true;
	}

	private void FillProgramSearchFromCode(string identifier)
	{
		if (_programSearchBox == null || string.IsNullOrWhiteSpace(identifier))
		{
			return;
		}
		_programSearchBox.Text = identifier;
		_programSearchBox.SelectionStart = 0;
		_programSearchBox.SelectionLength = identifier.Length;
		FocusVariableAcrossPanels(identifier, updateSearchBox: false);
	}

	private void FocusVariableAcrossPanels(string identifier, bool updateSearchBox)
	{
		string variableName = NormalizeFocusedVariableName(identifier);
		if (variableName.Length == 0)
		{
			return;
		}

		bool changed = !_focusedVariableName.Equals(variableName, StringComparison.OrdinalIgnoreCase);
		_focusedVariableName = variableName;
		_activeProgramSearchKeyword = variableName;
		_activeProgramSearchLine = 0;
		if (updateSearchBox && _programSearchBox != null)
		{
			_programSearchBox.Text = variableName;
			_programSearchBox.SelectionStart = 0;
			_programSearchBox.SelectionLength = variableName.Length;
		}
		if (_currentFunctionSource != null && _functionCodePanel != null && _functionCodePanel.Visible)
		{
			_lastFunctionCodeText = "";
			_lastDataCodeText = "";
			RenderFunctionSource();
		}
		else
		{
			ApplyProgramSearchHighlight();
		}
		UpdateProgramInsightPanel(changed);
	}

	private static string NormalizeFocusedVariableName(string identifier)
	{
		string value = identifier.Trim();
		if (value.Length == 0)
		{
			return "";
		}

		Match match = Regex.Match(value, @"[A-Za-z_][A-Za-z0-9_]*");
		return match.Success ? match.Value : "";
	}

	private void FunctionCodeBoxMouseMove(object? sender, MouseEventArgs e)
	{
		if (_functionCodeBox == null || _functionCodeBox.TextLength == 0)
		{
			return;
		}

		int index = _functionCodeBox.GetCharIndexFromPosition(e.Location);
		bool ctrlPressed = (ModifierKeys & Keys.Control) == Keys.Control;
		if (index == _lastFunctionHoverCharIndex)
		{
			_functionCodeBox.Cursor = ctrlPressed && _lastFunctionHoverNavigable ? Cursors.Hand : Cursors.IBeam;
			return;
		}

		_lastFunctionHoverCharIndex = index;
		_lastFunctionHoverIdentifier = "";
		_lastFunctionHoverNavigable = false;

		if (TryGetIdentifierAt(_functionCodeBox.Text, index, out _, out _, out string identifier))
		{
			_lastFunctionHoverIdentifier = identifier;
			_lastFunctionHoverNavigable =
				IsKnownFunctionName(identifier) &&
				(_currentFunctionSource == null || !identifier.Equals(_currentFunctionSource.FunctionName, StringComparison.OrdinalIgnoreCase));
		}

		_functionCodeBox.Cursor = ctrlPressed && _lastFunctionHoverNavigable ? Cursors.Hand : Cursors.IBeam;
	}

	private void CodeBoxKeyDown(object? sender, KeyEventArgs e)
	{
		if (e.Control && e.KeyCode == Keys.C && sender is RichTextBox codeBox)
		{
			if (!string.IsNullOrEmpty(codeBox.SelectedText))
			{
				Clipboard.SetText(codeBox.SelectedText);
				e.SuppressKeyPress = true;
				e.Handled = true;
			}
			return;
		}

		if (e.Control && e.KeyCode == Keys.F)
		{
			_programSearchBox?.Focus();
			_programSearchBox?.SelectAll();
			e.SuppressKeyPress = true;
			e.Handled = true;
		}
	}

	private void FunctionCodeBoxMouseWheel(object? sender, MouseEventArgs e)
	{
		if (_functionCodeBox == null || (ModifierKeys & Keys.Control) != Keys.Control)
		{
			return;
		}

		AdjustFunctionCodeFont(e.Delta > 0 ? 0.5f : -0.5f);
	}

	private void AdjustFunctionCodeFont(float delta)
	{
		if (_functionCodeBox == null)
		{
			return;
		}

		float nextSize = Math.Clamp(_functionCodeFontSize + delta, 8f, 22f);
		if (Math.Abs(nextSize - _functionCodeFontSize) < 0.01f)
		{
			return;
		}

		int selectionStart = _functionCodeBox.SelectionStart;
		Point scrollPosition = Point.Empty;
		bool hasHandle = _functionCodeBox.IsHandleCreated;
		if (hasHandle)
		{
			SendMessage(_functionCodeBox.Handle, EmGetScrollPos, IntPtr.Zero, ref scrollPosition);
			SendMessage(_functionCodeBox.Handle, WmSetRedraw, IntPtr.Zero, IntPtr.Zero);
		}

		try
		{
			_functionCodeFontSize = nextSize;
			_functionCodeBox.Font = new Font("Consolas", _functionCodeFontSize);
			if (_dataCodeBox != null)
			{
				_dataCodeBox.Font = new Font("Consolas", _functionCodeFontSize);
			}
			_lastFunctionCodeText = "";
			_lastDataCodeText = "";
			RenderFunctionSource();
			_functionCodeBox.SelectionStart = Math.Min(selectionStart, _functionCodeBox.TextLength);
			_functionCodeBox.SelectionLength = 0;
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, EmSetScrollPos, IntPtr.Zero, ref scrollPosition);
			}
		}
		finally
		{
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, WmSetRedraw, new IntPtr(1), IntPtr.Zero);
			}
			_functionCodeBox.Invalidate();
		}

		SaveDefaultProfileQuietly();
	}

	private void FunctionCodeBoxSelectionChanged(object? sender, EventArgs e)
	{
		if (_suppressFunctionScopeHighlight || _functionCodeBox == null || _functionCodeBox.TextLength == 0)
		{
			return;
		}
		if (_lastScopeHighlightSelectionStart == _functionCodeBox.SelectionStart)
		{
			return;
		}
		_lastScopeHighlightSelectionStart = _functionCodeBox.SelectionStart;
		HighlightCurrentScope();
	}

	private void SelectApproximateLineInFunction(int absoluteLine)
	{
		if (_currentFunctionSource == null || _functionCodeBox == null)
		{
			return;
		}
		int relativeLine = Math.Max(0, absoluteLine - _currentFunctionSource.StartLine);
		string text = _functionCodeBox.Text;
		int index = 0;
		for (int i = 0; i < relativeLine && index < text.Length; i++)
		{
			int next = text.IndexOf('\n', index);
			if (next < 0)
			{
				break;
			}
			index = next + 1;
		}
		_functionCodeBox.SelectionStart = Math.Clamp(index, 0, _functionCodeBox.TextLength);
		_functionCodeBox.SelectionLength = 0;
		_functionCodeBox.Focus();
		_functionCodeBox.ScrollToCaret();
		ApplyProgramSearchHighlight();
		SelectActiveSearchMatchOnLine();
	}

	private void ClearProgramSearchHighlight()
	{
		_activeProgramSearchKeyword = "";
		_activeProgramSearchLine = 0;
		_focusedVariableName = "";
		if (_currentFunctionSource != null && _functionCodeBox != null && _functionCodePanel != null && _functionCodePanel.Visible)
		{
			_lastFunctionCodeText = "";
			_lastDataCodeText = "";
			RenderFunctionSource();
		}
		UpdateProgramInsightPanel(force: true);
	}

	private void ApplyProgramSearchHighlight()
	{
		if (_functionCodeBox == null || _functionCodeBox.TextLength == 0)
		{
			return;
		}
		if (string.IsNullOrWhiteSpace(_activeProgramSearchKeyword) && _activeProgramSearchLine <= 0)
		{
			return;
		}

		int selectionStart = _functionCodeBox.SelectionStart;
		int selectionLength = _functionCodeBox.SelectionLength;
		Point scrollPosition = Point.Empty;
		bool hasHandle = _functionCodeBox.IsHandleCreated;
		if (hasHandle)
		{
			SendMessage(_functionCodeBox.Handle, EmGetScrollPos, IntPtr.Zero, ref scrollPosition);
			SendMessage(_functionCodeBox.Handle, WmSetRedraw, IntPtr.Zero, IntPtr.Zero);
		}

		_suppressFunctionScopeHighlight = true;
		try
		{
			Color lineColor = Color.FromArgb(64, 55, 26);
			Color matchColor = _activeProgramSearchKeyword.Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase)
				? CodeFocusVariableBackColor
				: Color.FromArgb(135, 88, 18);
			(int Start, int Length)? lineRange = FindDisplayedLineRange(_activeProgramSearchLine);
			if (lineRange.HasValue)
			{
				_functionCodeBox.Select(lineRange.Value.Start, lineRange.Value.Length);
				_functionCodeBox.SelectionBackColor = lineColor;
				HighlightKeywordRanges(lineRange.Value.Start, lineRange.Value.Length, _activeProgramSearchKeyword, matchColor);
			}
			else if (!string.IsNullOrWhiteSpace(_activeProgramSearchKeyword))
			{
				HighlightKeywordRanges(0, _functionCodeBox.TextLength, _activeProgramSearchKeyword, matchColor);
			}

			_functionCodeBox.Select(Math.Min(selectionStart, _functionCodeBox.TextLength), Math.Min(selectionLength, Math.Max(0, _functionCodeBox.TextLength - selectionStart)));
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, EmSetScrollPos, IntPtr.Zero, ref scrollPosition);
			}
		}
		finally
		{
			_suppressFunctionScopeHighlight = false;
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, WmSetRedraw, new IntPtr(1), IntPtr.Zero);
			}
			_functionCodeBox.Invalidate();
		}
	}

	private void SelectActiveSearchMatchOnLine()
	{
		if (_functionCodeBox == null || string.IsNullOrWhiteSpace(_activeProgramSearchKeyword))
		{
			return;
		}

		(int Start, int Length)? lineRange = FindDisplayedLineRange(_activeProgramSearchLine);
		if (!lineRange.HasValue)
		{
			return;
		}

		string text = _functionCodeBox.Text;
		int index = text.IndexOf(_activeProgramSearchKeyword, lineRange.Value.Start, lineRange.Value.Length, StringComparison.OrdinalIgnoreCase);
		if (index < 0)
		{
			return;
		}
		_functionCodeBox.Select(index, _activeProgramSearchKeyword.Length);
		_functionCodeBox.ScrollToCaret();
	}

	private (int Start, int Length)? FindDisplayedLineRange(int absoluteLine)
	{
		if (_functionCodeBox == null || absoluteLine <= 0)
		{
			return null;
		}
		string prefix = absoluteLine.ToString().PadLeft(5) + "  ";
		string text = _functionCodeBox.Text;
		int start = text.IndexOf(prefix, StringComparison.Ordinal);
		if (start < 0)
		{
			return null;
		}
		int end = text.IndexOf('\n', start);
		if (end < 0)
		{
			end = text.Length;
		}
		return (start, Math.Max(0, end - start));
	}

	private void HighlightKeywordRanges(int start, int length, string keyword, Color color)
	{
		if (_functionCodeBox == null || string.IsNullOrWhiteSpace(keyword) || length <= 0)
		{
			return;
		}
		string text = _functionCodeBox.Text;
		int end = Math.Min(text.Length, start + length);
		int index = start;
		while (index < end)
		{
			int match = text.IndexOf(keyword, index, end - index, StringComparison.OrdinalIgnoreCase);
			if (match < 0)
			{
				break;
			}
			_functionCodeBox.Select(match, Math.Min(keyword.Length, end - match));
			_functionCodeBox.SelectionBackColor = color;
			index = match + Math.Max(1, keyword.Length);
		}
	}

	private void HighlightCurrentScope()
	{
		if (_functionCodeBox == null || _functionCodeBox.TextLength == 0)
		{
			return;
		}
		int selectionStart = _functionCodeBox.SelectionStart;
		int selectionLength = _functionCodeBox.SelectionLength;
		Point scrollPosition = Point.Empty;
		bool hasHandle = _functionCodeBox.IsHandleCreated;
		if (hasHandle)
		{
			SendMessage(_functionCodeBox.Handle, EmGetScrollPos, IntPtr.Zero, ref scrollPosition);
			SendMessage(_functionCodeBox.Handle, WmSetRedraw, IntPtr.Zero, IntPtr.Zero);
		}
		_suppressFunctionScopeHighlight = true;
		try
		{
			foreach ((int start, int length) in _functionScopeHighlights)
			{
				if (start >= 0 && start + length <= _functionCodeBox.TextLength)
				{
					_functionCodeBox.Select(start, length);
					_functionCodeBox.SelectionBackColor = _surface;
				}
			}
			_functionScopeHighlights.Clear();
			(int Open, int Close)? pair = FindScopePairAt(_functionCodeBox.Text, selectionStart);
			if (pair.HasValue)
			{
				Color highlight = Color.FromArgb(92, 77, 24);
				_functionScopeHighlights.Add((pair.Value.Open, 1));
				_functionScopeHighlights.Add((pair.Value.Close, 1));
				_functionCodeBox.Select(pair.Value.Open, 1);
				_functionCodeBox.SelectionBackColor = highlight;
				_functionCodeBox.Select(pair.Value.Close, 1);
				_functionCodeBox.SelectionBackColor = highlight;
			}
			_functionCodeBox.Select(Math.Min(selectionStart, _functionCodeBox.TextLength), Math.Min(selectionLength, Math.Max(0, _functionCodeBox.TextLength - selectionStart)));
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, EmSetScrollPos, IntPtr.Zero, ref scrollPosition);
			}
		}
		finally
		{
			_suppressFunctionScopeHighlight = false;
			if (hasHandle)
			{
				SendMessage(_functionCodeBox.Handle, WmSetRedraw, new IntPtr(1), IntPtr.Zero);
			}
			_functionCodeBox.Invalidate();
		}
	}

	private static (int Open, int Close)? FindScopePairAt(string text, int caret)
	{
		List<(int Open, int Close)> pairs = BuildScopePairs(text);
		if (pairs.Count == 0)
		{
			return null;
		}
		int pos = Math.Clamp(caret, 0, Math.Max(0, text.Length - 1));
		return pairs
			.Where(p => p.Open == pos || p.Close == pos || p.Open == pos - 1 || p.Close == pos - 1 || (p.Open < pos && p.Close > pos))
			.OrderBy(p => p.Close - p.Open)
			.Cast<(int Open, int Close)?>()
			.FirstOrDefault();
	}

	private static List<(int Open, int Close)> BuildScopePairs(string text)
	{
		var pairs = new List<(int Open, int Close)>();
		var stack = new Stack<(char Ch, int Index)>();
		bool inLineComment = false;
		bool inBlockComment = false;
		bool inString = false;
		bool inChar = false;
		bool escape = false;
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			char next = i + 1 < text.Length ? text[i + 1] : '\0';
			if (inLineComment)
			{
				if (c == '\n') inLineComment = false;
				continue;
			}
			if (inBlockComment)
			{
				if (c == '*' && next == '/')
				{
					inBlockComment = false;
					i++;
				}
				continue;
			}
			if (inString || inChar)
			{
				if (escape)
				{
					escape = false;
					continue;
				}
				if (c == '\\')
				{
					escape = true;
					continue;
				}
				if (inString && c == '"') inString = false;
				else if (inChar && c == '\'') inChar = false;
				continue;
			}
			if (c == '/' && next == '/')
			{
				inLineComment = true;
				i++;
				continue;
			}
			if (c == '/' && next == '*')
			{
				inBlockComment = true;
				i++;
				continue;
			}
			if (c == '"')
			{
				inString = true;
				continue;
			}
			if (c == '\'')
			{
				inChar = true;
				continue;
			}
			if (c == '(' || c == '{')
			{
				stack.Push((c, i));
			}
			else if (c == ')' || c == '}')
			{
				char open = c == ')' ? '(' : '{';
				if (stack.Count > 0 && stack.Peek().Ch == open)
				{
					var item = stack.Pop();
					pairs.Add((item.Index, i));
				}
			}
		}
		return pairs;
	}

	private bool IsKnownFunctionName(string identifier)
	{
		if (string.IsNullOrWhiteSpace(_workDirectory) || !Directory.Exists(_workDirectory))
		{
			return false;
		}

		EnsureFunctionIndex(_workDirectory);
		return _functionIndex.ContainsKey(identifier);
	}

	private void ProgramSearchBoxKeyDown(object? sender, KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Enter)
		{
			RunProgramSearch();
			e.SuppressKeyPress = true;
		}
	}

	private void SetProgramSearchResultsVisible(bool visible)
	{
		if (_programSearchResults == null || _programSearchResultsRow == null)
		{
			return;
		}
		_programSearchResults.Visible = visible;
		_programSearchResultsRow.Height = visible ? 128f : 0f;
	}

	private void RunProgramSearch()
	{
		if (_programSearchBox == null || _programSearchResults == null)
		{
			return;
		}
		string keyword = _programSearchBox.Text.Trim();
		_programSearchResults.Items.Clear();
		if (keyword.Length == 0)
		{
			SetProgramSearchResultsVisible(false);
			ClearProgramSearchHighlight();
			return;
		}
		if (string.IsNullOrWhiteSpace(_workDirectory) || !Directory.Exists(_workDirectory))
		{
			Log("请先选择工作目录。");
			return;
		}

		FocusVariableAcrossPanels(keyword, updateSearchBox: false);
		foreach (ProgramSearchResult result in SearchProgramSource(_workDirectory, keyword).Take(80))
		{
			_programSearchResults.Items.Add(result);
		}
		SetProgramSearchResultsVisible(_programSearchResults.Items.Count > 0);
		Log(_programSearchResults.Items.Count == 0 ? "未找到：" + keyword : $"搜索到 {_programSearchResults.Items.Count} 项：" + keyword);
	}

	private IEnumerable<ProgramSearchResult> SearchProgramSource(string root, string keyword)
	{
		EnsureFunctionIndex(root);
		foreach (FunctionIndexEntry entry in _functionIndex.Values
			.Where(f => f.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase))
			.OrderBy(f => f.Name)
			.Take(30))
		{
			yield return new ProgramSearchResult("函数  " + entry.Name + "    " + GetRelativePathSafe(root, entry.FilePath), entry.FilePath, 1, entry.Name);
		}

		foreach (string file in EnumerateSourceFilesForOpen(root))
		{
			string text;
			try
			{
				text = ReadSourceText(file);
			}
			catch
			{
				continue;
			}
			string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
			for (int i = 0; i < lines.Length; i++)
			{
				string line = lines[i];
				if (line.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) < 0)
				{
					continue;
				}
				string display = $"{GetRelativePathSafe(root, file)}:{i + 1}    {line.Trim()}";
				yield return new ProgramSearchResult(display, file, i + 1, FindFunctionNameAtLine(text, i + 1));
			}
		}
	}

	private void ProgramSearchResultsDoubleClick(object? sender, EventArgs e)
	{
		if (_programSearchResults?.SelectedItem is not ProgramSearchResult result)
		{
			return;
		}
		string keyword = _programSearchBox?.Text.Trim() ?? "";
		_activeProgramSearchKeyword = keyword;
		_activeProgramSearchLine = result.LineNumber;
		if (!string.IsNullOrWhiteSpace(result.FunctionName) &&
			TryLoadFunctionSourceFromFile(result.FilePath, result.FunctionName, out FunctionSourceView? functionSource) &&
			functionSource != null)
		{
			ShowFunctionSource(functionSource, pushCurrent: _currentFunctionSource != null);
			SelectApproximateLineInFunction(result.LineNumber);
			return;
		}
		if (TryLoadNearestFunctionSource(result.FilePath, result.LineNumber, out FunctionSourceView? nearest) && nearest != null)
		{
			ShowFunctionSource(nearest, pushCurrent: _currentFunctionSource != null);
			SelectApproximateLineInFunction(result.LineNumber);
			return;
		}
		if (TryLoadSourceSnippet(result.FilePath, result.LineNumber, out FunctionSourceView? snippet) && snippet != null)
		{
			ShowFunctionSource(snippet, pushCurrent: _currentFunctionSource != null);
			SelectApproximateLineInFunction(result.LineNumber);
		}
	}

	private static string? FindFunctionNameAtLine(string text, int lineNumber)
	{
		string normalized = text.Replace("\r\n", "\n").Replace('\r', '\n');
		int charIndex = 0;
		for (int i = 1; i < lineNumber && charIndex < normalized.Length; i++)
		{
			int next = normalized.IndexOf('\n', charIndex);
			if (next < 0)
			{
				break;
			}
			charIndex = next + 1;
		}
		Match? best = null;
		foreach (Match match in Regex.Matches(normalized, @"(?m)^[\t ]*(?:[A-Za-z_][A-Za-z0-9_\s\*\(\),\[\]]+?[\s\*]+)?(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)", RegexOptions.IgnoreCase))
		{
			string name = match.Groups["name"].Value;
			if (IsCKeyword(name))
			{
				continue;
			}
			int afterSignature = SkipTriviaAndComments(normalized, match.Index + match.Length);
			if (afterSignature >= normalized.Length || normalized[afterSignature] != '{')
			{
				continue;
			}
			int close = FindMatchingBrace(normalized, afterSignature);
			if (match.Index <= charIndex && close >= charIndex)
			{
				best = match;
			}
		}
		return best?.Groups["name"].Value;
	}

	private bool TryLoadSourceSnippet(string file, int lineNumber, out FunctionSourceView? sourceView)
	{
		string text;
		try
		{
			text = ReadSourceText(file);
		}
		catch
		{
			sourceView = null;
			return false;
		}

		string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
		if (lines.Length == 0)
		{
			sourceView = null;
			return false;
		}

		int targetLine = Math.Clamp(lineNumber, 1, lines.Length);
		int startLine = Math.Max(1, targetLine - 12);
		int endLine = Math.Min(lines.Length, targetLine + 28);
		List<string> snippetLines = lines.Skip(startLine - 1).Take(endLine - startLine + 1).ToList();
		string title = Path.GetFileName(file);
		sourceView = new FunctionSourceView(title, file, startLine, snippetLines, 0, 0);
		return true;
	}

	private bool TryLoadNearestFunctionSource(string file, int lineNumber, out FunctionSourceView? sourceView)
	{
		string text;
		try
		{
			text = ReadSourceText(file);
		}
		catch
		{
			sourceView = null;
			return false;
		}
		string? functionName = FindFunctionNameAtLine(text, lineNumber);
		if (functionName != null)
		{
			return TryLoadFunctionSourceFromFile(file, functionName, out sourceView);
		}
		sourceView = null;
		return false;
	}

	private static bool IsIdentifierChar(char c)
	{
		return c == '_' || char.IsLetterOrDigit(c);
	}

	private static bool IsIdentifierStart(char c)
	{
		return c == '_' || char.IsLetter(c);
	}

	private static bool TryGetIdentifierAt(string text, int index, out int start, out int length, out string identifier)
	{
		start = 0;
		length = 0;
		identifier = "";
		if (index < 0 || index >= text.Length || !IsIdentifierChar(text[index]))
		{
			return false;
		}
		start = index;
		while (start > 0 && IsIdentifierChar(text[start - 1]))
		{
			start--;
		}
		int end = index;
		while (end + 1 < text.Length && IsIdentifierChar(text[end + 1]))
		{
			end++;
		}
		length = end - start + 1;
		identifier = text.Substring(start, length);
		return length > 0 && IsIdentifierStart(identifier[0]);
	}

	private void RenderFunctionSource()
	{
		if (_currentFunctionSource == null || _functionCodeBox == null)
		{
			return;
		}
		bool resetScroll = _resetFunctionScrollOnNextRender;
		_resetFunctionScrollOnNextRender = false;
		RenderFunctionSourceToBox(_functionCodeBox, includeValues: false, ref _lastFunctionCodeText, resetScroll, applySearchHighlight: true);
		RenderDataFunctionMirror(resetScroll);
	}

	private void RenderDataFunctionMirror(bool resetScroll)
	{
		if (_currentFunctionSource == null || _dataCodeBox == null)
		{
			return;
		}

		(int Start, int End) visibleRange = GetVisibleSourceLineRange(DataMirrorPaddingLines);
		AutoWatchVariablesForVisibleRange(visibleRange);
		UpdateVisibleValuesLabel(visibleRange);
		if (_dataCodeTitle != null)
		{
			string relativePath = GetRelativePathSafe(_workDirectory, _currentFunctionSource.FilePath);
			_dataCodeTitle.Text = BuildDataCodeTitle(relativePath, visibleRange);
		}

		RenderFunctionSourceToBox(_dataCodeBox, includeValues: true, ref _lastDataCodeText, resetScroll, applySearchHighlight: false, visibleRange);
		_lastVisibleRangeSignature = BuildVisibleRangeSignature(visibleRange);
		_lastVisibleConditionSignature = BuildVisibleConditionSignature(visibleRange);
		_lastDataInlineRenderUtc = DateTime.UtcNow;
		UpdateProgramInsightPanel();
	}

	private string BuildDataCodeTitle(string relativePath, (int Start, int End) visibleRange)
	{
		if (_currentFunctionSource == null)
		{
			return "跟随 3 看程序";
		}

		return $"{_currentFunctionSource.FunctionName}    {relativePath}:{visibleRange.Start}-{visibleRange.End}";
	}

	private void ScheduleVisibleDataRefreshAfterScroll()
	{
		if (_currentFunctionSource == null || _dataCodeBox == null || _functionCodePanel == null || !_functionCodePanel.Visible)
		{
			return;
		}

		_visibleDataRefreshTimer.Stop();
		_visibleDataRefreshTimer.Start();
	}

	private void RefreshVisibleDataAfterScroll()
	{
		if (_currentFunctionSource == null || _dataCodeBox == null)
		{
			return;
		}

		(int Start, int End) visibleRange = GetVisibleSourceLineRange(DataMirrorPaddingLines);
		bool addedWatch = AutoWatchVariablesForVisibleRange(visibleRange);
		UpdateVisibleValuesLabel(visibleRange);
		UpdateProgramInsightPanel();
		string rangeSignature = BuildVisibleRangeSignature(visibleRange);
		string conditionSignature = BuildVisibleConditionSignature(visibleRange);
		bool rangeChanged = !rangeSignature.Equals(_lastVisibleRangeSignature, StringComparison.Ordinal);
		bool conditionChanged = !conditionSignature.Equals(_lastVisibleConditionSignature, StringComparison.Ordinal);
		if (rangeChanged || conditionChanged || addedWatch)
		{
			_lastVisibleRangeSignature = rangeSignature;
			_lastVisibleConditionSignature = conditionSignature;
			_dataCodeDirty = true;
		}
	}

	private (int Start, int End) GetVisibleSourceLineRange(int padding = 1)
	{
		if (_currentFunctionSource == null)
		{
			return (0, 0);
		}

		int firstLine = 0;
		int lastLine = Math.Min(_currentFunctionSource.Lines.Count - 1, 60);
		if (_functionCodeBox != null && _functionCodeBox.IsHandleCreated && _functionCodeBox.TextLength > 0)
		{
			firstLine = Math.Max(0, SendMessage(_functionCodeBox.Handle, EmGetFirstVisibleLine, IntPtr.Zero, IntPtr.Zero).ToInt32());
			int bottomChar = _functionCodeBox.GetCharIndexFromPosition(new Point(Math.Max(1, _functionCodeBox.ClientSize.Width - 6), Math.Max(1, _functionCodeBox.ClientSize.Height - 6)));
			lastLine = Math.Max(firstLine, _functionCodeBox.GetLineFromCharIndex(bottomChar));
		}

		firstLine = Math.Clamp(firstLine - padding, 0, Math.Max(0, _currentFunctionSource.Lines.Count - 1));
		lastLine = Math.Clamp(lastLine + padding, firstLine, Math.Max(0, _currentFunctionSource.Lines.Count - 1));
		return (_currentFunctionSource.StartLine + firstLine, _currentFunctionSource.StartLine + lastLine);
	}

	private IEnumerable<string> GetVisibleRawLines(int padding = 1)
	{
		if (_currentFunctionSource == null)
		{
			yield break;
		}

		foreach (string line in GetRawLinesInSourceRange(GetVisibleSourceLineRange(padding)))
		{
			yield return line;
		}
	}

	private IEnumerable<string> GetRawLinesInSourceRange((int Start, int End) range)
	{
		if (_currentFunctionSource == null)
		{
			yield break;
		}

		int first = Math.Max(0, range.Start - _currentFunctionSource.StartLine);
		int last = Math.Min(_currentFunctionSource.Lines.Count - 1, range.End - _currentFunctionSource.StartLine);
		for (int i = first; i <= last; i++)
		{
			yield return _currentFunctionSource.Lines[i];
		}
	}

	private List<WatchItem> GetVisibleWatchItems()
	{
		return GetVisibleWatchItems(GetVisibleSourceLineRange(DataMirrorPaddingLines));
	}

	private List<WatchItem> GetVisibleWatchItems((int Start, int End) range)
	{
		List<string> lines = GetRawLinesInSourceRange(range).ToList();
		if (lines.Count == 0)
		{
			return new List<WatchItem>();
		}

		return _watchItems
			.Where(item => item.Enabled && lines.Any(line =>
				LineMentionsWatch(line, item.Name) ||
				(item.IsChild && item.ParentName.Length > 0 && LineMentionsWatch(line, item.ParentName))))
			.OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase)
			.ToList();
	}

	private bool AutoWatchVariablesForVisibleRange()
	{
		return AutoWatchVariablesForVisibleRange(GetVisibleSourceLineRange(DataMirrorPaddingLines));
	}

	private bool AutoWatchVariablesForVisibleRange((int Start, int End) range)
	{
		if (_symbolLookup.Count == 0)
		{
			return false;
		}

		List<string> lines = GetRawLinesInSourceRange(range).ToList();
		List<string> identifiers = BuildIdentifierList(lines)
			.Where(identifier => identifier.Length > 0 && !IsCKeywordToken(identifier))
			.ToList();
		if (identifiers.Count == 0)
		{
			return false;
		}

		var visibleIdentifiers = identifiers.ToHashSet(StringComparer.OrdinalIgnoreCase);
		int removed = 0;
		var existing = BuildExistingWatchAliasSet();
		int added = 0;
		foreach (string identifier in identifiers)
		{
			if (existing.Contains(identifier))
			{
				continue;
			}

			if (!TryResolveSourceIdentifierToWatchItem(identifier, existing, out WatchItem item, out string matchedName))
			{
				continue;
			}

			int removedNow = 0;
			if (IsWatchCapacityLimited() && !EnsureWatchCapacityForVisibleRange(visibleIdentifiers, lines, out removedNow))
			{
				break;
			}
			if (removedNow > 0)
			{
				removed += removedNow;
				existing = BuildExistingWatchAliasSet();
				if (existing.Contains(identifier))
				{
					continue;
				}
			}
			item.AutoVisible = true;
			_watchItems.Add(item);
			AddWatchAliases(existing, item.Name);
			existing.Add(matchedName);
			added++;
			if (IsWatchCapacityLimited() && GetVisibleWatchItems(range).Count >= VisibleWatchTargetLimit)
			{
				break;
			}
		}

		if (added > 0 || removed > 0)
		{
			UpdateCycleEstimate();
			_lastVisibleValuesText = "";
			_lastDataCodeText = "";
			if (removed > 0)
			{
				Log($"当前窗口变量优先：已移出 {removed} 个不可见变量。");
			}
		}
		return added > 0 || removed > 0;
	}

	private int PruneWatchItemsToVisibleRange(HashSet<string> visibleIdentifiers, IReadOnlyList<string> visibleLines)
	{
		if (visibleIdentifiers.Count == 0 || visibleLines.Count == 0 || _watchItems.Count == 0)
		{
			return 0;
		}

		int removed = 0;
		int i = _watchItems.Count - 1;
		while (i >= 0)
		{
			WatchItem item = _watchItems[i];
			if (IsWatchVisibleInRange(item, visibleIdentifiers, visibleLines))
			{
				i--;
				continue;
			}

			int before = _watchItems.Count;
			RemoveWatchItem(item);
			removed += Math.Max(1, before - _watchItems.Count);
			i = Math.Min(i - 1, _watchItems.Count - 1);
		}
		return removed;
	}

	private bool EnsureWatchCapacityForCurrentContext(out int removed)
	{
		removed = 0;
		if (!IsWatchCapacityLimited())
		{
			return true;
		}
		if (_watchItems.Count < MaxWatchItems)
		{
			return true;
		}

		List<string> lines = _currentFunctionSource == null
			? new List<string>()
			: GetRawLinesInSourceRange(GetVisibleSourceLineRange(DataMirrorPaddingLines)).ToList();
		HashSet<string> identifiers = BuildIdentifierSet(lines);
		return EnsureWatchCapacityForVisibleRange(identifiers, lines, out removed);
	}

	private bool EnsureWatchCapacityForVisibleRange(HashSet<string> visibleIdentifiers, IReadOnlyList<string> visibleLines, out int removed)
	{
		removed = 0;
		if (!IsWatchCapacityLimited())
		{
			return true;
		}
		if (_watchItems.Count < MaxWatchItems)
		{
			return true;
		}

		removed += RemoveInvisibleWatchItems(visibleIdentifiers, visibleLines, item => item.AutoVisible);
		if (_watchItems.Count < MaxWatchItems)
		{
			return true;
		}

		removed += RemoveInvisibleWatchItems(visibleIdentifiers, visibleLines, item => !item.AutoVisible);
		return _watchItems.Count < MaxWatchItems;
	}

	private int RemoveInvisibleWatchItems(HashSet<string> visibleIdentifiers, IReadOnlyList<string> visibleLines, Predicate<WatchItem> isCandidate)
	{
		int removed = 0;
		for (int i = _watchItems.Count - 1; i >= 0 && _watchItems.Count >= MaxWatchItems; i--)
		{
			WatchItem item = _watchItems[i];
			if (!isCandidate(item) ||
				IsWatchVisibleInRange(item, visibleIdentifiers, visibleLines) ||
				CurrentFunctionMentionsWatch(item))
			{
				continue;
			}

			int before = _watchItems.Count;
			RemoveWatchItem(item);
			removed += Math.Max(1, before - _watchItems.Count);
		}
		return removed;
	}

	private static bool IsWatchVisibleInRange(WatchItem item, HashSet<string> visibleIdentifiers, IReadOnlyList<string> visibleLines)
	{
		if (IdentifierSetContainsWatch(visibleIdentifiers, item.Name))
		{
			return true;
		}
		if (item.IsChild && item.ParentName.Length > 0 && IdentifierSetContainsWatch(visibleIdentifiers, item.ParentName))
		{
			return true;
		}

		foreach (string line in visibleLines)
		{
			if (LineMentionsWatch(line, item.Name) ||
				(item.IsChild && item.ParentName.Length > 0 && LineMentionsWatch(line, item.ParentName)))
			{
				return true;
			}
		}
		return false;
	}

	private bool TryFindSymbolForSourceIdentifier(string identifier, out MapSymbol symbol)
	{
		if (_symbolLookup.TryGetValue(identifier, out MapSymbol? exact))
		{
			symbol = exact;
			return true;
		}

		if (_symbolBaseLookup.TryGetValue(identifier, out MapSymbol? byBase))
		{
			symbol = byBase;
			return true;
		}

		if (_symbolTailLookup.TryGetValue(identifier, out MapSymbol? byTail))
		{
			symbol = byTail;
			return true;
		}

		if (identifier.Length >= 4)
		{
			List<MapSymbol> strongMatches = FuzzyMatcher.Search(_symbols, identifier, limit: 8)
				.Where(candidate => IsStrongSourceSymbolMatch(identifier, candidate.Name))
				.Take(2)
				.ToList();
			if (strongMatches.Count == 1)
			{
				symbol = strongMatches[0];
				return true;
			}
		}

		symbol = null!;
		return false;
	}

	private bool TryResolveSourceIdentifierToWatchItem(string identifier, HashSet<string> existingAliases, out WatchItem item, out string matchedName)
	{
		item = null!;
		matchedName = "";
		if (identifier.Length == 0 || existingAliases.Contains(identifier))
		{
			return false;
		}

		if (!TryFindSymbolForSourceIdentifier(identifier, out MapSymbol symbol))
		{
			return false;
		}

		if (!KeilMapParser.TryResolve(symbol.Name, _symbolLookup, out WatchItem resolvedItem, out _))
		{
			return false;
		}

		if (_watchItems.Any(existing => existing.Name.Equals(resolvedItem.Name, StringComparison.OrdinalIgnoreCase)))
		{
			return false;
		}

		item = resolvedItem;
		matchedName = symbol.Name;
		return true;
	}

	private static bool IsStrongSourceSymbolMatch(string identifier, string symbolName)
	{
		if (identifier.Length == 0 || symbolName.Length == 0)
		{
			return false;
		}

		if (symbolName.Equals(identifier, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}

		string baseName = GetIdentifierBase(symbolName);
		if (baseName.Equals(identifier, StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}

		string tailName = GetIdentifierTail(symbolName);
		return tailName.Equals(identifier, StringComparison.OrdinalIgnoreCase);
	}

	private HashSet<string> BuildExistingWatchAliasSet()
	{
		var aliases = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (WatchItem item in _watchItems)
		{
			AddWatchAliases(aliases, item.Name);
		}
		return aliases;
	}

	private static void AddWatchAliases(HashSet<string> aliases, string watchName)
	{
		foreach (string alias in WatchIdentifierAliases(watchName))
		{
			aliases.Add(alias);
		}
	}

	private void UpdateVisibleValuesLabel()
	{
		UpdateVisibleValuesLabel(GetVisibleSourceLineRange(DataMirrorPaddingLines));
	}

	private void UpdateVisibleValuesLabel((int Start, int End) range)
	{
		List<string> parts = GetVisibleWatchItems(range)
			.Select(item => GetWatchDisplayName(item) + "=" + FormatInlineWatchValue(item))
			.Distinct(StringComparer.OrdinalIgnoreCase)
			.Take(32)
			.ToList();
		string text = parts.Count == 0 ? "可见变量：无" : "可见变量：" + string.Join("    ", parts);
		if (text.Equals(_lastVisibleValuesText, StringComparison.Ordinal))
		{
			return;
		}

		_lastVisibleValuesText = text;
		UpdateProgramInsightPanel();
	}

	private string BuildVisibleConditionSignature()
	{
		return BuildVisibleConditionSignature(GetVisibleSourceLineRange(DataMirrorPaddingLines));
	}

	private string BuildVisibleConditionSignature((int Start, int End) range)
	{
		List<WatchItem> candidates = GetVisibleWatchItems(range);
		if (candidates.Count == 0)
		{
			return "";
		}

		StringBuilder builder = new StringBuilder();
		int lineNumber = range.Start;
		foreach (string line in GetRawLinesInSourceRange(range))
		{
			if (Regex.IsMatch(line, @"^\s*if\s*\("))
			{
				ConditionEval result = EvaluateIfCondition(line, candidates);
				builder.Append(lineNumber).Append(':').Append(result == ConditionEval.True ? '1' : result == ConditionEval.False ? '0' : '?').Append(';');
			}
			lineNumber++;
		}
		return builder.ToString();
	}

	private static string BuildVisibleRangeSignature((int Start, int End) range)
	{
		return range.Start.ToString() + ":" + range.End.ToString();
	}

	private List<WatchItem> GetCurrentFunctionWatchItems()
	{
		if (_currentFunctionIdentifiers.Count == 0)
		{
			return new List<WatchItem>();
		}

		return _watchItems
			.Where(item => item.Enabled && CurrentFunctionMentionsWatch(item))
			.OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase)
			.ToList();
	}

	private void RenderFunctionSourceToBox(
		RichTextBox targetBox,
		bool includeValues,
		ref string lastText,
		bool resetScroll,
		bool applySearchHighlight,
		(int Start, int End)? lineRange = null)
	{
		if (_currentFunctionSource == null || targetBox == null)
		{
			return;
		}

		List<CodeLineRender> renderedLines = BuildFunctionRenderLines(includeValues, out string nextText, lineRange);
		if (nextText.Equals(lastText, StringComparison.Ordinal))
		{
			if (resetScroll)
			{
				ResetCodeBoxScroll(targetBox);
			}
			return;
		}

		lastText = nextText;
		int oldSelection = resetScroll ? 0 : targetBox.SelectionStart;
		Point scrollPosition = Point.Empty;
		bool hasHandle = targetBox.IsHandleCreated;
		if (hasHandle)
		{
			if (!resetScroll)
			{
				SendMessage(targetBox.Handle, EmGetScrollPos, IntPtr.Zero, ref scrollPosition);
			}
			SendMessage(targetBox.Handle, WmSetRedraw, IntPtr.Zero, IntPtr.Zero);
		}
		targetBox.SuspendLayout();
		bool oldSuppressScopeHighlight = _suppressFunctionScopeHighlight;
		_suppressFunctionScopeHighlight = true;
		try
		{
			targetBox.Rtf = BuildFunctionSourceRtf(renderedLines, targetBox);
			if (targetBox.TextLength > 0)
			{
				targetBox.SelectionStart = Math.Min(oldSelection, targetBox.TextLength);
				targetBox.SelectionLength = 0;
			}
			if (hasHandle)
			{
				SendMessage(targetBox.Handle, EmSetScrollPos, IntPtr.Zero, ref scrollPosition);
			}
			if (resetScroll)
			{
				targetBox.SelectionStart = 0;
				targetBox.SelectionLength = 0;
				targetBox.ScrollToCaret();
			}
			if (applySearchHighlight)
			{
				ApplyProgramSearchHighlight();
			}
		}
		finally
		{
			_suppressFunctionScopeHighlight = oldSuppressScopeHighlight;
			if (hasHandle)
			{
				SendMessage(targetBox.Handle, WmSetRedraw, new IntPtr(1), IntPtr.Zero);
			}
			targetBox.ResumeLayout();
			targetBox.Invalidate();
		}
	}

	private List<CodeLineRender> BuildFunctionRenderLines(bool includeValues, out string plainText, (int Start, int End)? lineRange = null)
	{
		List<CodeLineRender> renderedLines = new List<CodeLineRender>();
		StringBuilder plainBuilder = new StringBuilder();
		int displayIndent = 0;
		if (_currentFunctionSource == null)
		{
			plainText = "";
			return renderedLines;
		}
		if (_currentFunctionSource.Lines.Count == 0)
		{
			plainText = "";
			return renderedLines;
		}

		int firstIndex = 0;
		int lastIndex = _currentFunctionSource.Lines.Count - 1;
		if (lineRange.HasValue)
		{
			firstIndex = Math.Clamp(lineRange.Value.Start - _currentFunctionSource.StartLine, 0, Math.Max(0, _currentFunctionSource.Lines.Count - 1));
			lastIndex = Math.Clamp(lineRange.Value.End - _currentFunctionSource.StartLine, firstIndex, Math.Max(0, _currentFunctionSource.Lines.Count - 1));
			for (int i = 0; i < firstIndex; i++)
			{
				_ = FormatCodeLineForDisplay(_currentFunctionSource.Lines[i], ref displayIndent);
			}
		}

		List<WatchItem> inlineCandidates = includeValues ? GetInlineWatchCandidates(lineRange) : new List<WatchItem>();
		for (int i = firstIndex; i <= lastIndex; i++)
		{
			int lineNumber = _currentFunctionSource.StartLine + i;
			string rawLine = _currentFunctionSource.Lines[i];
			string line = FormatCodeLineForDisplay(rawLine, ref displayIndent);
			List<string> values = includeValues ? BuildInlineWatchValues(rawLine, inlineCandidates) : new List<string>();
			if (includeValues && values.Count > 0)
			{
				line = InsertInlineWatchValues(line, inlineCandidates);
			}
			bool isTrueCondition = includeValues && EvaluateIfCondition(rawLine, inlineCandidates) == ConditionEval.True;
			renderedLines.Add(new CodeLineRender(lineNumber, line, values, isTrueCondition));
			plainBuilder.Append(lineNumber.ToString().PadLeft(5)).Append("  ").Append(line);
			if (isTrueCondition)
			{
				plainBuilder.Append("  /*条件成立*/");
			}
			plainBuilder.AppendLine();
		}

		plainText = plainBuilder.ToString();
		return renderedLines;
	}

	private void ResetCodeBoxScroll(RichTextBox targetBox)
	{
		if (targetBox == null || targetBox.TextLength == 0)
		{
			return;
		}
		targetBox.SelectionStart = 0;
		targetBox.SelectionLength = 0;
		targetBox.ScrollToCaret();
	}

	private void SyncDataCodeScrollFromProgram()
	{
		if (_functionCodeBox == null || _dataCodeBox == null || !_dataCodeBox.IsHandleCreated || !_functionCodeBox.IsHandleCreated)
		{
			return;
		}

		Point scrollPosition = Point.Empty;
		SendMessage(_functionCodeBox.Handle, EmGetScrollPos, IntPtr.Zero, ref scrollPosition);
		SendMessage(_dataCodeBox.Handle, EmSetScrollPos, IntPtr.Zero, ref scrollPosition);
		_dataCodeBox.Invalidate();
	}

	private string BuildFunctionSourceRtf(IEnumerable<CodeLineRender> renderedLines, RichTextBox targetBox)
	{
		var builder = new StringBuilder();
		builder.Append(@"{\rtf1\ansi\deff0");
		builder.Append(@"{\fonttbl{\f0 Consolas;}}");
		builder.Append(@"{\colortbl ;");
		AppendRtfColor(builder, _muted);
		AppendRtfColor(builder, _ink);
		AppendRtfColor(builder, _accent);
		AppendRtfColor(builder, CodeCommentColor);
		AppendRtfColor(builder, CodeFunctionColor);
		AppendRtfColor(builder, CodeKeywordColor);
		AppendRtfColor(builder, CodeValueColor);
		AppendRtfColor(builder, CodeValueBackColor);
		AppendRtfColor(builder, CodeTrueLineBackColor);
		AppendRtfColor(builder, CodeFocusVariableForeColor);
		AppendRtfColor(builder, CodeFocusVariableBackColor);
		builder.Append('}');
		builder.Append(@"\viewkind4\uc1\pard\f0\fs");
		builder.Append(Math.Max(16, (int)Math.Round(targetBox.Font.SizeInPoints * 2)));
		builder.Append(' ');

		bool inBlockComment = false;
		foreach (CodeLineRender renderedLine in renderedLines)
		{
			if (renderedLine.IsTrueCondition)
			{
				builder.Append(@"\highlight9 ");
			}
			AppendRtfText(builder, renderedLine.LineNumber.ToString().PadLeft(5) + "  ", 1);
			AppendHighlightedCodeRtf(builder, renderedLine.Code, ref inBlockComment, renderedLine.IsTrueCondition ? 9 : 0);
			if (renderedLine.IsTrueCondition)
			{
				builder.Append(@"\highlight0 ");
			}
			builder.Append(@"\par ");
		}
		builder.Append('}');
		return builder.ToString();
	}

	private static void AppendRtfColor(StringBuilder builder, Color color)
	{
		builder.Append(@"\red").Append(color.R)
			.Append(@"\green").Append(color.G)
			.Append(@"\blue").Append(color.B)
			.Append(';');
	}

	private static void AppendRtfText(StringBuilder builder, string text, int colorIndex)
	{
		AppendRtfText(builder, text, colorIndex, 0, 0);
	}

	private static void AppendRtfText(StringBuilder builder, string text, int colorIndex, int highlightIndex)
	{
		AppendRtfText(builder, text, colorIndex, highlightIndex, 0);
	}

	private static void AppendRtfText(StringBuilder builder, string text, int colorIndex, int highlightIndex, int restoreHighlightIndex)
	{
		builder.Append(@"\cf").Append(colorIndex).Append(' ');
		if (highlightIndex > 0)
		{
			builder.Append(@"\highlight").Append(highlightIndex).Append(' ');
		}
		foreach (char c in text)
		{
			switch (c)
			{
				case '\\':
					builder.Append(@"\\");
					break;
				case '{':
					builder.Append(@"\{");
					break;
				case '}':
					builder.Append(@"\}");
					break;
				case '\t':
					builder.Append(@"\tab ");
					break;
				default:
					if (c <= 0x7f)
					{
						builder.Append(c);
					}
					else
					{
						builder.Append(@"\u").Append(unchecked((short)c)).Append('?');
				}
				break;
			}
		}
		if (highlightIndex > 0)
		{
			builder.Append(@"\highlight").Append(restoreHighlightIndex).Append(' ');
		}
	}

	private void AppendHighlightedCodeRtf(StringBuilder builder, string text, ref bool inBlockComment, int lineHighlightIndex = 0)
	{
		int index = 0;
		while (index < text.Length)
		{
			if (inBlockComment)
			{
				int end = text.IndexOf("*/", index, StringComparison.Ordinal);
				if (end < 0)
				{
					AppendRtfText(builder, text.Substring(index), 4);
					return;
				}

				AppendRtfText(builder, text.Substring(index, end - index + 2), 4);
				index = end + 2;
				inBlockComment = false;
				continue;
			}

			CommentStart comment = FindNextCommentStart(text, index);
			int codeEnd = comment.Index >= 0 ? comment.Index : text.Length;
			if (codeEnd > index)
			{
				AppendCodeTokensRtf(builder, text.Substring(index, codeEnd - index), lineHighlightIndex);
			}

			if (comment.Index < 0)
			{
				return;
			}

			if (comment.IsLineComment)
			{
				AppendRtfText(builder, text.Substring(comment.Index), 4);
				return;
			}

			int blockEnd = text.IndexOf("*/", comment.Index + 2, StringComparison.Ordinal);
			if (blockEnd < 0)
			{
				AppendRtfText(builder, text.Substring(comment.Index), 4);
				inBlockComment = true;
				return;
			}

			AppendRtfText(builder, text.Substring(comment.Index, blockEnd - comment.Index + 2), 4);
			index = blockEnd + 2;
		}
	}

	private void AppendCodeTokensRtf(StringBuilder builder, string text, int lineHighlightIndex = 0)
	{
		int index = 0;
		while (index < text.Length)
		{
			if (text[index] == '[')
			{
				int close = text.IndexOf(']', index + 1);
				if (close > index && close - index <= 32)
				{
					AppendRtfText(builder, text.Substring(index, close - index + 1), 7, 8, lineHighlightIndex);
					index = close + 1;
					continue;
				}
			}

			if (!IsIdentifierStart(text[index]))
			{
				int start = index;
				index++;
				while (index < text.Length && !IsIdentifierStart(text[index]) && text[index] != '[')
				{
					index++;
				}
				AppendRtfText(builder, text.Substring(start, index - start), 2);
				continue;
			}

			int tokenStart = index;
			index++;
			while (index < text.Length && IsIdentifierChar(text[index]))
			{
				index++;
			}

			string token = text.Substring(tokenStart, index - tokenStart);
			int color = 2;
			if (IsFocusedVariableToken(token))
			{
				AppendRtfText(builder, token, 10, 11, lineHighlightIndex);
				continue;
			}
			if (IsCKeywordToken(token))
			{
				color = 6;
			}
			else if (LooksLikeFunctionCall(text, index))
			{
				color = 5;
			}
			AppendRtfText(builder, token, color);
		}
	}

	private bool IsFocusedVariableToken(string token)
	{
		return !string.IsNullOrWhiteSpace(_focusedVariableName) &&
			token.Equals(_focusedVariableName, StringComparison.OrdinalIgnoreCase);
	}

	private void AppendCodeText(string text, Color color)
	{
		_functionCodeBox.SelectionColor = color;
		_functionCodeBox.AppendText(text);
	}

	private void AppendHighlightedCodeText(string text, ref bool inBlockComment)
	{
		int index = 0;
		while (index < text.Length)
		{
			if (inBlockComment)
			{
				int end = text.IndexOf("*/", index, StringComparison.Ordinal);
				if (end < 0)
				{
					AppendCodeText(text.Substring(index), CodeCommentColor);
					return;
				}

				AppendCodeText(text.Substring(index, end - index + 2), CodeCommentColor);
				index = end + 2;
				inBlockComment = false;
				continue;
			}

			CommentStart comment = FindNextCommentStart(text, index);
			int codeEnd = comment.Index >= 0 ? comment.Index : text.Length;
			if (codeEnd > index)
			{
				AppendCodeTokens(text.Substring(index, codeEnd - index));
			}

			if (comment.Index < 0)
			{
				return;
			}

			if (comment.IsLineComment)
			{
				AppendCodeText(text.Substring(comment.Index), CodeCommentColor);
				return;
			}

			int blockEnd = text.IndexOf("*/", comment.Index + 2, StringComparison.Ordinal);
			if (blockEnd < 0)
			{
				AppendCodeText(text.Substring(comment.Index), CodeCommentColor);
				inBlockComment = true;
				return;
			}

			AppendCodeText(text.Substring(comment.Index, blockEnd - comment.Index + 2), CodeCommentColor);
			index = blockEnd + 2;
		}
	}

	private void AppendCodeTokens(string text)
	{
		int index = 0;
		while (index < text.Length)
		{
			if (!IsIdentifierStart(text[index]))
			{
				AppendCodeText(text[index].ToString(), _ink);
				index++;
				continue;
			}

			int start = index;
			index++;
			while (index < text.Length && IsIdentifierChar(text[index]))
			{
				index++;
			}

			string token = text.Substring(start, index - start);
			Color color = _ink;
			if (IsCKeywordToken(token))
			{
				color = CodeKeywordColor;
			}
			else if (LooksLikeFunctionCall(text, index))
			{
				color = CodeFunctionColor;
			}

			AppendCodeText(token, color);
		}
	}

	private readonly record struct CommentStart(int Index, bool IsLineComment);

	private static CommentStart FindNextCommentStart(string text, int start)
	{
		bool inString = false;
		bool inChar = false;
		bool escape = false;
		for (int i = start; i + 1 < text.Length; i++)
		{
			char c = text[i];
			char next = text[i + 1];
			if (escape)
			{
				escape = false;
				continue;
			}
			if (inString || inChar)
			{
				if (c == '\\')
				{
					escape = true;
					continue;
				}
				if (inString && c == '"')
				{
					inString = false;
				}
				else if (inChar && c == '\'')
				{
					inChar = false;
				}
				continue;
			}
			if (c == '"')
			{
				inString = true;
				continue;
			}
			if (c == '\'')
			{
				inChar = true;
				continue;
			}
			if (c == '/' && next == '/')
			{
				return new CommentStart(i, true);
			}
			if (c == '/' && next == '*')
			{
				return new CommentStart(i, false);
			}
		}

		return new CommentStart(-1, false);
	}

	private static bool LooksLikeFunctionCall(string text, int index)
	{
		int i = index;
		while (i < text.Length && char.IsWhiteSpace(text[i]))
		{
			i++;
		}
		return i < text.Length && text[i] == '(';
	}

	private static string FormatCodeLineForDisplay(string rawLine, ref int indent)
	{
		string expanded = ExpandTabs(rawLine).TrimEnd();
		string trimmed = expanded.Trim();
		if (trimmed.Length == 0)
		{
			return "";
		}

		int leadingCloseBraces = CountLeadingCloseBracesForDisplay(trimmed);
		if (leadingCloseBraces > 0)
		{
			indent = Math.Max(0, indent - leadingCloseBraces);
		}

		bool preprocessor = trimmed.StartsWith("#", StringComparison.Ordinal);
		bool switchLabel = trimmed.StartsWith("case ", StringComparison.Ordinal) || trimmed.StartsWith("default:", StringComparison.Ordinal);
		int lineIndent = preprocessor ? 0 : (switchLabel ? Math.Max(0, indent - 1) : indent);
		string result = new string(' ', lineIndent * 4) + trimmed;

		int delta = BraceDeltaForDisplay(trimmed, leadingCloseBraces);
		indent = Math.Max(0, indent + delta);
		return result;
	}

	private static int CountLeadingCloseBracesForDisplay(string line)
	{
		int count = 0;
		int index = 0;
		while (index < line.Length)
		{
			while (index < line.Length && char.IsWhiteSpace(line[index]))
			{
				index++;
			}
			if (index >= line.Length || line[index] != '}')
			{
				break;
			}
			count++;
			index++;
		}
		return count;
	}

	private static string ExpandTabs(string text)
	{
		var builder = new StringBuilder(text.Length + 16);
		int column = 0;
		foreach (char c in text)
		{
			if (c == '\t')
			{
				int spaces = 4 - (column % 4);
				builder.Append(' ', spaces);
				column += spaces;
			}
			else
			{
				builder.Append(c);
				column++;
			}
		}
		return builder.ToString();
	}

	private static int BraceDeltaForDisplay(string line, int skipLeadingCloseBraces = 0)
	{
		int delta = 0;
		int skippedLeadingCloseBraces = 0;
		bool inString = false;
		bool inChar = false;
		bool escape = false;
		for (int i = 0; i < line.Length; i++)
		{
			char c = line[i];
			char next = i + 1 < line.Length ? line[i + 1] : '\0';
			if (!inString && !inChar && c == '/' && next == '/')
			{
				break;
			}
			if (escape)
			{
				escape = false;
				continue;
			}
			if ((inString || inChar) && c == '\\')
			{
				escape = true;
				continue;
			}
			if (!inChar && c == '"')
			{
				inString = !inString;
				continue;
			}
			if (!inString && c == '\'')
			{
				inChar = !inChar;
				continue;
			}
			if (inString || inChar)
			{
				continue;
			}
			if (c == '{')
			{
				delta++;
			}
			else if (c == '}')
			{
				if (skippedLeadingCloseBraces < skipLeadingCloseBraces)
				{
					skippedLeadingCloseBraces++;
					continue;
				}
				delta--;
			}
		}
		return delta;
	}

	private List<WatchItem> GetInlineWatchCandidates((int Start, int End)? lineRange = null)
	{
		if (_watchItems.Count == 0)
		{
			return new List<WatchItem>();
		}

		List<WatchItem> visibleItems = lineRange.HasValue ? GetVisibleWatchItems(lineRange.Value) : GetVisibleWatchItems();
		if (visibleItems.Count > 0)
		{
			return visibleItems
				.OrderByDescending(x => x.Name.Length)
				.ToList();
		}

		return _watchItems
			.Where(x => x.Enabled)
			.OrderByDescending(x => x.Name.Length)
			.ToList();
	}

	private List<string> BuildInlineWatchValues(string line, IReadOnlyList<WatchItem> candidates)
	{
		if (candidates.Count == 0 || string.IsNullOrWhiteSpace(line))
		{
			return new List<string>();
		}
		var result = new List<string>();
		var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (WatchItem item in candidates)
		{
			if (result.Count >= 6)
			{
				break;
			}
			string token = FindWatchTokenInLine(line, item.Name);
			if (token.Length == 0 || !seen.Add(token))
			{
				continue;
			}
			result.Add(token + "=" + FormatInlineWatchValue(item));
		}
		return result;
	}

	private static string InsertInlineWatchValues(string line, IReadOnlyList<WatchItem> candidates)
	{
		if (candidates.Count == 0 || string.IsNullOrWhiteSpace(line))
		{
			return line;
		}

		string result = line;
		var inserted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		int count = 0;
		foreach (WatchItem item in candidates)
		{
			if (count >= 6)
			{
				continue;
			}

			string token = FindWatchTokenInLine(result, item.Name);
			if (token.Length == 0)
			{
				continue;
			}
			if (!inserted.Add(token))
			{
				continue;
			}

			string marker = " [" + FormatInlineWatchValue(item) + "]";
			if (result.IndexOf(token + marker, StringComparison.OrdinalIgnoreCase) >= 0)
			{
				continue;
			}

			int index = FindIdentifierIndex(result, token);
			if (index < 0)
			{
				continue;
			}

			result = result.Insert(index + token.Length, marker);
			count++;
		}
		return result;
	}

	private static string FormatInlineWatchValue(WatchItem item)
	{
		if (!string.IsNullOrWhiteSpace(item.DisplayValue))
		{
			return item.DisplayValue;
		}
		if (!string.IsNullOrWhiteSpace(item.ValueDec))
		{
			return item.ValueDec;
		}
		if (!string.IsNullOrWhiteSpace(item.ValueHex))
		{
			return item.ValueHex;
		}
		return "等待";
	}

	private ConditionEval EvaluateIfCondition(string line, IReadOnlyList<WatchItem> candidates)
	{
		return EvaluateIfConditionCore(line, candidates);
	}

	private static ConditionEval EvaluateIfConditionCore(string line, IReadOnlyList<WatchItem> candidates)
	{
		if (candidates.Count == 0 || string.IsNullOrWhiteSpace(line))
		{
			return ConditionEval.Unknown;
		}

		string? expr = ExtractIfExpression(line);
		if (expr == null)
		{
			return ConditionEval.Unknown;
		}

		int comment = expr.IndexOf("//", StringComparison.Ordinal);
		if (comment >= 0)
		{
			expr = expr.Substring(0, comment);
		}

		return EvaluateSimpleBooleanExpression(expr, candidates);
	}

	private static string? ExtractIfExpression(string line)
	{
		Match match = Regex.Match(line, @"^\s*if\b");
		if (!match.Success)
		{
			return null;
		}

		int open = line.IndexOf('(', match.Index + match.Length);
		if (open < 0)
		{
			return null;
		}

		int depth = 0;
		bool inString = false;
		bool inChar = false;
		bool escape = false;
		for (int i = open; i < line.Length; i++)
		{
			char c = line[i];
			if (escape)
			{
				escape = false;
				continue;
			}
			if ((inString || inChar) && c == '\\')
			{
				escape = true;
				continue;
			}
			if (!inChar && c == '"')
			{
				inString = !inString;
				continue;
			}
			if (!inString && c == '\'')
			{
				inChar = !inChar;
				continue;
			}
			if (inString || inChar)
			{
				continue;
			}
			if (c == '(')
			{
				depth++;
			}
			else if (c == ')')
			{
				depth--;
				if (depth == 0)
				{
					return line.Substring(open + 1, i - open - 1);
				}
			}
		}

		return null;
	}

	private static ConditionEval EvaluateSimpleBooleanExpression(string expr, IReadOnlyList<WatchItem> candidates)
	{
		bool hasUnknown = false;
		string[] orParts = Regex.Split(expr, @"\|\|");
		foreach (string orPart in orParts)
		{
			bool andFailed = false;
			bool andUnknown = false;
			string[] andParts = Regex.Split(orPart, @"&&");
			foreach (string andPart in andParts)
			{
				ConditionEval part = EvaluateSimpleCondition(andPart, candidates);
				if (part == ConditionEval.False)
				{
					andFailed = true;
					break;
				}
				if (part == ConditionEval.Unknown)
				{
					andUnknown = true;
				}
			}
			if (!andFailed && !andUnknown)
			{
				return ConditionEval.True;
			}
			if (!andFailed && andUnknown)
			{
				hasUnknown = true;
			}
		}
		return hasUnknown ? ConditionEval.Unknown : ConditionEval.False;
	}

	private static ConditionEval EvaluateSimpleCondition(string expression, IReadOnlyList<WatchItem> candidates)
	{
		string text = expression.Trim();
		if (text.Length == 0)
		{
			return ConditionEval.Unknown;
		}

		while (text.StartsWith("(", StringComparison.Ordinal) && text.EndsWith(")", StringComparison.Ordinal) && HasBalancedOuterParentheses(text))
		{
			text = text.Substring(1, text.Length - 2).Trim();
		}

		bool inverted = false;
		while (text.StartsWith("!", StringComparison.Ordinal))
		{
			inverted = !inverted;
			text = text.Substring(1).Trim();
		}

		ConditionEval value = EvaluateSimpleConditionCore(text, candidates);
		if (value == ConditionEval.Unknown)
		{
			return ConditionEval.Unknown;
		}
		if (!inverted)
		{
			return value;
		}
		return value == ConditionEval.True ? ConditionEval.False : ConditionEval.True;
	}

	private static ConditionEval EvaluateSimpleConditionCore(string text, IReadOnlyList<WatchItem> candidates)
	{
		Match compare = Regex.Match(text, @"^(?<left>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)?)\s*(?<op>==|!=|>=|<=|>|<)\s*(?<right>-?(?:0x[0-9A-Fa-f]+|\d+))$");
		if (compare.Success)
		{
			if (!TryGetWatchCurrentNumericValue(compare.Groups["left"].Value, candidates, out long left) ||
				!TryParseIntegerLiteral(compare.Groups["right"].Value, out long right))
			{
				return ConditionEval.Unknown;
			}

			bool result = compare.Groups["op"].Value switch
			{
				"==" => left == right,
				"!=" => left != right,
				">=" => left >= right,
				"<=" => left <= right,
				">" => left > right,
				"<" => left < right,
				_ => false
			};
			return result ? ConditionEval.True : ConditionEval.False;
		}

		Match symbol = Regex.Match(text, @"^[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)?$");
		if (!symbol.Success)
		{
			return ConditionEval.Unknown;
		}
		if (!TryGetWatchCurrentNumericValue(symbol.Value, candidates, out long value))
		{
			return ConditionEval.Unknown;
		}
		return value != 0 ? ConditionEval.True : ConditionEval.False;
	}

	private static bool HasBalancedOuterParentheses(string text)
	{
		int depth = 0;
		for (int i = 0; i < text.Length; i++)
		{
			if (text[i] == '(')
			{
				depth++;
			}
			else if (text[i] == ')')
			{
				depth--;
				if (depth == 0 && i < text.Length - 1)
				{
					return false;
				}
			}
		}
		return depth == 0;
	}

	private static bool TryGetWatchCurrentNumericValue(string name, IReadOnlyList<WatchItem> candidates, out long value)
	{
		value = 0;
		string baseName = GetIdentifierBase(name);
		if (baseName.Length == 0)
		{
			return false;
		}

		List<WatchItem> matches = candidates
			.Where(item => item.Enabled && WatchIdentifierAliases(item.Name).Any(alias => alias.Equals(baseName, StringComparison.OrdinalIgnoreCase)))
			.Distinct()
			.ToList();
		if (matches.Count > 1)
		{
			List<WatchItem> exactMatches = matches
				.Where(item =>
					item.Name.Equals(baseName, StringComparison.OrdinalIgnoreCase) ||
					GetWatchDisplayName(item).Equals(baseName, StringComparison.OrdinalIgnoreCase))
				.ToList();
			if (exactMatches.Count == 1)
			{
				matches = exactMatches;
			}
		}

		WatchItem? item = matches.Count == 1 ? matches[0] : null;
		if (item == null)
		{
			return false;
		}

		if (!item.Status.Equals("正常", StringComparison.Ordinal) || !item.LastUpdate.HasValue)
		{
			return false;
		}

		if (!string.IsNullOrWhiteSpace(item.ValueDec) && long.TryParse(item.ValueDec, out value))
		{
			return true;
		}

		return false;
	}

	private static bool TryParseIntegerLiteral(string text, out long value)
	{
		text = text.Trim();
		if (text.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
		{
			return long.TryParse(text.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out value);
		}
		return long.TryParse(text, out value);
	}

	private static string FindWatchTokenInLine(string line, string watchName)
	{
		if (string.IsNullOrWhiteSpace(line) || string.IsNullOrWhiteSpace(watchName))
		{
			return "";
		}

		foreach (string alias in WatchIdentifierAliases(watchName).OrderByDescending(x => x.Length))
		{
			if (FindIdentifierIndex(line, alias) >= 0)
			{
				return alias;
			}
		}

		return "";
	}

	private static bool LineMentionsWatch(string line, string watchName)
	{
		if (string.IsNullOrWhiteSpace(line) || string.IsNullOrWhiteSpace(watchName))
		{
			return false;
		}
		return WatchIdentifierAliases(watchName).Any(alias => ContainsIdentifier(line, alias));
	}

	private static bool ContainsIdentifier(string line, string identifier)
	{
		return FindIdentifierIndex(line, identifier) >= 0;
	}

	private static int FindIdentifierIndex(string line, string identifier)
	{
		if (identifier.Length == 0 || line.Length < identifier.Length)
		{
			return -1;
		}
		int index = 0;
		while (index <= line.Length - identifier.Length)
		{
			int found = line.IndexOf(identifier, index, StringComparison.OrdinalIgnoreCase);
			if (found < 0)
			{
				return -1;
			}
			int before = found - 1;
			int after = found + identifier.Length;
			bool leftOk = before < 0 || !IsIdentifierChar(line[before]);
			bool rightOk = after >= line.Length || !IsIdentifierChar(line[after]);
			if (leftOk && rightOk)
			{
				return found;
			}
			index = found + 1;
		}
		return -1;
	}

	private static string GetRelativePathSafe(string root, string filePath)
	{
		try
		{
			if (!string.IsNullOrWhiteSpace(root))
			{
				return Path.GetRelativePath(root, filePath);
			}
		}
		catch
		{
		}
		return filePath;
	}

	private static IEnumerable<string> EnumerateSourceFilesForOpen(string root)
	{
		var pending = new Stack<string>();
		pending.Push(root);
		string[] ignored = { ".git", ".svn", ".vs", "bin", "obj", "Debug", "Release", "Listings", "Objects", "RTE", "__pycache__" };
		while (pending.Count > 0)
		{
			string directory = pending.Pop();
			IEnumerable<string> children;
			try
			{
				children = Directory.EnumerateDirectories(directory);
			}
			catch
			{
				continue;
			}
			foreach (string child in children)
			{
				if (!ignored.Contains(Path.GetFileName(child), StringComparer.OrdinalIgnoreCase))
				{
					pending.Push(child);
				}
			}
			IEnumerable<string> files;
			try
			{
				files = Directory.EnumerateFiles(directory);
			}
			catch
			{
				continue;
			}
			foreach (string file in files)
			{
				string extension = Path.GetExtension(file);
				if (extension.Equals(".c", StringComparison.OrdinalIgnoreCase) || extension.Equals(".h", StringComparison.OrdinalIgnoreCase))
				{
					yield return file;
				}
			}
		}
	}

	private void UpdateItem(WatchItem item, int len, byte status, uint value)
	{
		QueueWatchUpdate(new PendingWatchUpdate(item, len, status, value, Timeout: false, Error: false));
	}

	private void MarkTimeout(WatchItem item)
	{
		QueueWatchUpdate(new PendingWatchUpdate(item, 0, 0, 0, Timeout: true, Error: false));
	}

	private void MarkError(WatchItem item, string message)
	{
		QueueWatchUpdate(new PendingWatchUpdate(item, 0, 0, 0, Timeout: false, Error: true));
	}

	private void QueueWatchUpdate(PendingWatchUpdate update)
	{
		lock (_pendingWatchLock)
		{
			_pendingWatchUpdates[update.Item] = update;
		}
	}

	private void FlushPendingWatchUpdates()
	{
		if (ShouldDeferUiValueRefresh())
		{
			return;
		}

		List<PendingWatchUpdate> updates;
		lock (_pendingWatchLock)
		{
			if (_pendingWatchUpdates.Count == 0)
			{
				return;
			}
			updates = _pendingWatchUpdates.Values.ToList();
			_pendingWatchUpdates.Clear();
		}

		bool sourceNeedsRefresh = false;
		bool insightNeedsRefresh = false;
		List<string>? visibleRefreshLines = null;
		DateTime now = DateTime.Now;
		_grid.SuspendLayout();
		try
		{
			foreach (PendingWatchUpdate update in updates)
			{
				WatchItem item = update.Item;
				if (_watchItems.IndexOf(item) < 0)
				{
					continue;
				}

				if (update.Timeout)
				{
					item.MissCount++;
					if (item.MissCount < NoResponseDisplayMissCount)
					{
						item.Status = "等待响应";
					}
					else
					{
						item.Status = $"无响应 x{item.MissCount}";
						if (!item.DisplayValue.Equals(item.Status, StringComparison.Ordinal))
						{
							item.DisplayValue = item.Status;
							RefreshValueCell(item);
							insightNeedsRefresh |= WatchMatchesFocusedVariable(item);
							visibleRefreshLines ??= GetVisibleRawLines(DataMirrorPaddingLines).ToList();
							sourceNeedsRefresh |= VisibleRangeMentionsWatch(item, visibleRefreshLines);
						}
					}
					continue;
				}

				if (update.Error)
				{
					item.Status = "通信异常";
					continue;
				}

				item.MissCount = 0;
				if (update.Status == 0)
				{
					int valueBytes = EffectiveValueBytes(item, update.Len);
					uint rawValue = MaskRawValue(update.Value, valueBytes);
					string displayValue = item.DisplayValue;
					item.RawValue = rawValue;
					item.ValueDec = FormatDecimalRawValue(item, rawValue, valueBytes);
					item.ValueHex = "0x" + rawValue.ToString("X" + HexDigitsForBytes(valueBytes));
					item.DisplayValue = FormatValue(item);
					if (!displayValue.Equals(item.DisplayValue, StringComparison.Ordinal))
					{
						RefreshValueCell(item);
						insightNeedsRefresh |= WatchMatchesFocusedVariable(item);
						visibleRefreshLines ??= GetVisibleRawLines(DataMirrorPaddingLines).ToList();
						sourceNeedsRefresh |= VisibleRangeMentionsWatch(item, visibleRefreshLines);
					}
					item.Status = "正常";
					item.LastUpdate = now;
				}
				else
				{
					item.Status = update.Status switch
					{
						1 => "变量无效", 
						2 => "长度不支持", 
						_ => "读取失败", 
					};
				}
			}
		}
		finally
		{
			_grid.ResumeLayout();
		}

		if (sourceNeedsRefresh)
		{
			UpdateVisibleValuesLabel();
			string conditionSignature = BuildVisibleConditionSignature();
			bool conditionChanged = !conditionSignature.Equals(_lastVisibleConditionSignature, StringComparison.Ordinal);
			bool inlineStale = (DateTime.UtcNow - _lastDataInlineRenderUtc).TotalMilliseconds > DataInlineRefreshMs;
			if (conditionChanged || inlineStale)
			{
				_lastVisibleConditionSignature = conditionSignature;
				_dataCodeDirty = true;
			}
		}
		if (insightNeedsRefresh)
		{
			UpdateProgramInsightPanel();
		}
	}

	private void GridColumnHeaderMouseClick(object? sender, DataGridViewCellMouseEventArgs e)
	{
		if (e.ColumnIndex < 0 || _grid.Columns[e.ColumnIndex].DataPropertyName != "DisplayValue")
		{
			return;
		}
		ToggleValueDisplayMode();
	}

	private void ToggleValueDisplayMode()
	{
		_showHexValue = !_showHexValue;
		if (_valueColumnIndex >= 0 && _valueColumnIndex < _grid.Columns.Count)
		{
			_grid.Columns[_valueColumnIndex].HeaderText = (_showHexValue ? "值(16)" : "值(10)");
		}
		foreach (WatchItem watchItem in _watchItems)
		{
			watchItem.DisplayValue = FormatValue(watchItem);
			RefreshValueCell(watchItem);
		}
		UpdateValueFormatButton();
		MarkFunctionCodeDirty();
		SaveDefaultProfileQuietly();
	}

	private void UpdateValueFormatButton()
	{
		if (_valueFormatButton == null || _valueFormatButton.IsDisposed)
		{
			return;
		}

		_valueFormatButton.Text = _showHexValue ? "16进制" : "10进制";
		_valueFormatButton.BackColor = _showHexValue ? _gridHeader : _button;
		_valueFormatButton.ForeColor = _ink;
		_valueFormatButton.FlatStyle = FlatStyle.Flat;
		_valueFormatButton.FlatAppearance.BorderColor = _gridHeader;
	}

	private string FormatValue(WatchItem item)
	{
		if (item.ValueDec.Length == 0 && item.ValueHex.Length == 0)
		{
			return "";
		}
		if (item.RawValue == 0 && uint.TryParse(item.ValueDec, out var result))
		{
			item.RawValue = result;
		}
		if (!_showHexValue)
		{
			if (item.ValueDec.Length > 0)
			{
				return item.ValueDec;
			}
			int valueBytes = EffectiveValueBytes(item, Math.Clamp(item.Size, 1, 4));
			return FormatDecimalRawValue(item, MaskRawValue(item.RawValue, valueBytes), valueBytes);
		}
		if (item.ValueHex.Length > 0)
		{
			return item.ValueHex;
		}
		int num = HexDigitsForBytes(Math.Clamp(item.Size, 1, 4));
		return "0x" + item.RawValue.ToString("X" + num);
	}

	private static int EffectiveValueBytes(WatchItem item, int reportedLen)
	{
		if (reportedLen > 0)
		{
			return Math.Clamp(reportedLen, 1, 4);
		}
		return Math.Clamp(item.Size, 1, 4);
	}

	private static uint MaskRawValue(uint rawValue, int bytes)
	{
		return Math.Clamp(bytes, 1, 4) switch
		{
			1 => rawValue & 0xFFu,
			2 => rawValue & 0xFFFFu,
			3 => rawValue & 0xFFFFFFu,
			_ => rawValue,
		};
	}

	private static string FormatDecimalRawValue(WatchItem item, uint rawValue, int bytes)
	{
		int valueBytes = EffectiveValueBytes(item, bytes);
		uint masked = MaskRawValue(rawValue, valueBytes);
		if (IsFloatWatchItem(item) && valueBytes == 4)
		{
			float value = BitConverter.UInt32BitsToSingle(masked);
			return float.IsFinite(value) ? FormatFloatValue(value) : "0";
		}

		if (!IsSignedWatchItem(item))
		{
			return masked.ToString();
		}

		return ToSignedValue(masked, valueBytes).ToString();
	}

	private static string FormatFloatValue(float value)
	{
		if (Math.Abs(value) >= 1000f || (Math.Abs(value) > 0f && Math.Abs(value) < 0.01f))
		{
			return value.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
		}

		return value.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
	}

	private static long ToSignedValue(uint rawValue, int bytes)
	{
		int bits = Math.Clamp(bytes, 1, 4) * 8;
		long value = rawValue & (bits == 32 ? 0xFFFFFFFFL : ((1L << bits) - 1L));
		long signBit = 1L << (bits - 1);
		if ((value & signBit) != 0)
		{
			value -= 1L << bits;
		}
		return value;
	}

	private static bool IsSignedWatchItem(WatchItem item)
	{
		string typeName = item.TypeName.Trim();
		if (typeName.Length == 0)
		{
			return false;
		}

		string t = Regex.Replace(typeName, @"\b(const|volatile|static|extern|register)\b", "", RegexOptions.IgnoreCase);
		t = Regex.Replace(t, @"\s+", " ").Trim().ToLowerInvariant();
		if (t.Length == 0)
		{
			return false;
		}

		if (Regex.IsMatch(t, @"\b(unsigned|uint|uint8_t|uint16_t|uint32_t|uint64_t|u8|u16|u32|u64|byte|word|dword|qword|bool|boolean)\b") ||
			t.Contains("uint", StringComparison.OrdinalIgnoreCase) ||
			t.Contains("uchar", StringComparison.OrdinalIgnoreCase) ||
			t.Contains("ushort", StringComparison.OrdinalIgnoreCase) ||
			t.Contains("ulong", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}

		if (Regex.IsMatch(t, @"\b(signed|int8_t|int16_t|int32_t|int64_t|sint8|sint16|sint32|s8|s16|s32|s64|short|int|long|enum)\b"))
		{
			return true;
		}

		return false;
	}

	private static bool IsFloatWatchItem(WatchItem item)
	{
		string typeName = item.TypeName.Trim();
		return typeName.Equals("float", StringComparison.OrdinalIgnoreCase) ||
			typeName.Equals("double", StringComparison.OrdinalIgnoreCase) ||
			Regex.IsMatch(typeName, @"\b(float|double)\b", RegexOptions.IgnoreCase);
	}

	private void ResetTransientWatchState(WatchItem item)
	{
		item.MissCount = 0;
		item.Status = "待读取";
		item.ForceActive = false;
		item.ForceText = "";
		item.DisplayValue = FormatValue(item);
	}

	private static int HexDigitsForBytes(int bytes)
	{
		return Math.Clamp(bytes, 1, 4) * 2;
	}

	private void RefreshValueCell(WatchItem item)
	{
		int num = _watchItems.IndexOf(item);
		if (num >= 0 && _valueColumnIndex >= 0 && num < _grid.Rows.Count)
		{
			DataGridViewCell dataGridViewCell = _grid.Rows[num].Cells[_valueColumnIndex];
			dataGridViewCell.Value = item.DisplayValue;
			_grid.InvalidateCell(dataGridViewCell);
		}
	}

	private void RefreshForceCell(WatchItem item)
	{
		int num = _watchItems.IndexOf(item);
		if (num >= 0 && _forceColumnIndex >= 0 && num < _grid.Rows.Count)
		{
			DataGridViewCell cell = _grid.Rows[num].Cells[_forceColumnIndex];
			cell.Value = item.ForceText;
			_grid.InvalidateCell(cell);
		}
	}

	private void SaveProfileAs()
	{
		using SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "变量列表 (*.json)|*.json",
			FileName = "monitor_profile.json"
		};
		if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
		{
			SaveProfile(saveFileDialog.FileName);
		}
	}

	private void LoadProfileFromFile()
	{
		using OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "变量列表 (*.json)|*.json"
		};
		if (openFileDialog.ShowDialog(this) == DialogResult.OK)
		{
			LoadProfile(openFileDialog.FileName);
		}
	}

	private void GenerateProgramGraph()
	{
		string text = GetWorkDirectoryFromUi();
		if (text.Length == 0 || !Directory.Exists(text))
		{
			using FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				Description = "请选择 Keil 工程目录",
				UseDescriptionForTitle = true
			};
			if (folderBrowserDialog.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			text = folderBrowserDialog.SelectedPath;
			SetWorkDirectory(text, loadMap: true);
		}
		try
		{
			RefreshProgramGraphPanel(text);
		}
		catch (Exception ex)
		{
			Log("生成程序图谱失败：" + ex.Message);
		}
	}

	private void RefreshProgramGraphPanel(string directory, bool force = false)
	{
		if (_flowChart == null || _programSummaryLabel == null || _runtimeLocationLabel == null)
		{
			return;
		}
		if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
		{
			return;
		}

		if (force)
		{
			_activeProgramGraphDirectory = "";
		}
		_pendingProgramGraphDirectory = directory;
		_programGraphDebounceTimer.Stop();
		_programGraphDebounceTimer.Start();
	}

	private void StartProgramGraphAnalysis(string directory)
	{
		if (_flowChart == null || _programSummaryLabel == null || _runtimeLocationLabel == null)
		{
			return;
		}
		if (string.IsNullOrWhiteSpace(directory) || !Directory.Exists(directory))
		{
			return;
		}
		if (_activeProgramGraphDirectory.Equals(directory, StringComparison.OrdinalIgnoreCase))
		{
			return;
		}

		_activeProgramGraphDirectory = directory;
		int version = Interlocked.Increment(ref _programGraphAnalysisVersion);
		_runtimeLocationLabel.Text = "正在分析工程";
		_programSummaryLabel.Text = "正在生成程序框架...";
		Task.Run(() =>
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			DateTime latestWrite = GetLatestSourceWriteUtc(directory, out int sourceCount);
			ProgramGraphSnapshot snapshot = ProgramGraphGenerator.Analyze(directory);
			stopwatch.Stop();
			return (Directory: directory, LatestWrite: latestWrite, SourceCount: sourceCount, Snapshot: snapshot, ElapsedMs: stopwatch.ElapsedMilliseconds);
		}).ContinueWith(task =>
		{
			if (IsDisposed)
			{
				return;
			}
			try
			{
				BeginInvoke((Action)(() =>
				{
					if (_activeProgramGraphDirectory.Equals(task.Status == TaskStatus.RanToCompletion ? task.Result.Directory : directory, StringComparison.OrdinalIgnoreCase))
					{
						_activeProgramGraphDirectory = "";
					}
					if (version != _programGraphAnalysisVersion || task.Status != TaskStatus.RanToCompletion)
					{
						return;
					}
					ApplyProgramGraphSnapshot(task.Result.Directory, task.Result.LatestWrite, task.Result.SourceCount, task.Result.Snapshot, task.Result.ElapsedMs);
				}));
			}
			catch
			{
			}
		}, TaskScheduler.Default);
	}

	private void ApplyProgramGraphSnapshot(string directory, DateTime latestWrite, int sourceCount, ProgramGraphSnapshot programGraphSnapshot, long elapsedMs)
	{
		_programGraphLastSourceWrite = latestWrite;
		_programGraphSourceCount = sourceCount;
		_programGraphSnapshot = programGraphSnapshot;
		ClearOfflineSimulationProgramCache();
		if (_offlineSimulation)
		{
			EnsureOfflineApplicationWatchItems();
		}
		_traceLabels.Clear();
		if (!programGraphSnapshot.Success)
		{
			_runtimeLocationLabel.Text = "等待工程分析";
			_programSummaryLabel.Text = programGraphSnapshot.Message;
			_flowChart?.SetGraph(
				new[] { new FlowChartNode("msg", "等待工程分析\n选择工作目录后自动生成", new RectangleF(24, 24, 220, 68), 0) },
				Array.Empty<FlowChartEdge>());
			Log(programGraphSnapshot.Message);
			UpdateProgramInsightPanel(force: true);
			return;
		}
		_lastTraceId = ushort.MaxValue;
		string entryName = string.IsNullOrWhiteSpace(programGraphSnapshot.StartFunction) ? "自动识别" : programGraphSnapshot.StartFunction;
		_runtimeLocationLabel.Text = GetProgramEntryDisplayName(programGraphSnapshot, entryName);
		_programSummaryLabel.Text = programGraphSnapshot.CallGraphNodes.Count > 0
			? $"入口 {entryName}    {programGraphSnapshot.CallGraphNodes.Count} 个函数    {programGraphSnapshot.CallGraphEdges.Count} 条调用"
			: $"入口 {entryName}    {programGraphSnapshot.FrameworkSteps.Count} 个节点";
		IReadOnlyList<ProgramFrameworkStep> frameworkSteps = programGraphSnapshot.FrameworkSteps;
		if (frameworkSteps.Count == 0)
		{
			frameworkSteps = programGraphSnapshot.FlowFunctions
				.Select(f => new ProgramFrameworkStep(f.Name, f.Summary, f.TraceId, f.Name, f.Summary))
				.ToList();
		}
		if (programGraphSnapshot.CallGraphNodes.Count > 0)
		{
			UpdateCallRelationChart(programGraphSnapshot.CallGraphNodes, programGraphSnapshot.CallGraphEdges);
		}
		else
		{
			UpdateFlowChart(frameworkSteps);
		}
		foreach (ProgramFrameworkStep step in frameworkSteps)
		{
			_traceLabels[step.TraceId] = step.Name;
		}
		foreach (ProgramCallGraphNode node in programGraphSnapshot.CallGraphNodes)
		{
			_traceLabels[node.TraceId] = node.Name;
		}
		foreach (ProgramFunctionInfo hotFunction in programGraphSnapshot.HotFunctions)
		{
			_traceLabels[hotFunction.TraceId] = hotFunction.Name;
		}
		Log($"{programGraphSnapshot.Message}，分析耗时 {elapsedMs} ms，内存 {GetProcessMemoryText()}。");
		UpdateProgramInsightPanel(force: true);
		ScheduleMemoryTrim();
	}

	private string GetProgramEntryDisplayName()
	{
		return GetProgramEntryDisplayName(_programGraphSnapshot, "");
	}

	private static string GetProgramEntryDisplayName(ProgramGraphSnapshot? snapshot, string fallback)
	{
		if (snapshot != null)
		{
			string preferred = FindPreferredEntryName(snapshot);
			if (!string.IsNullOrWhiteSpace(preferred))
			{
				return preferred;
			}
		}

		return string.IsNullOrWhiteSpace(fallback) || fallback.Equals("自动识别", StringComparison.OrdinalIgnoreCase)
			? "MyLogic_1ms"
			: fallback;
	}

	private static string FindPreferredEntryName(ProgramGraphSnapshot snapshot)
	{
		string[] preferredNames = { "MyLogic_1ms", "MyLogic_10ms" };
		foreach (string preferred in preferredNames)
		{
			ProgramFrameworkStep? stepMatch = snapshot.FrameworkSteps.FirstOrDefault(step =>
				step.Name.Equals(preferred, StringComparison.OrdinalIgnoreCase) ||
				step.FunctionName.Equals(preferred, StringComparison.OrdinalIgnoreCase));
			string match = stepMatch?.Name ?? stepMatch?.FunctionName ?? "";
			if (!string.IsNullOrWhiteSpace(match))
			{
				return match;
			}

			ProgramFunctionInfo? functionMatch = snapshot.FlowFunctions.FirstOrDefault(function =>
				function.Name.Equals(preferred, StringComparison.OrdinalIgnoreCase));
			match = functionMatch?.Name ?? "";
			if (!string.IsNullOrWhiteSpace(match))
			{
				return match;
			}

			ProgramCallGraphNode? nodeMatch = snapshot.CallGraphNodes.FirstOrDefault(node =>
				node.Name.Equals(preferred, StringComparison.OrdinalIgnoreCase));
			match = nodeMatch?.Name ?? "";
			if (!string.IsNullOrWhiteSpace(match))
			{
				return match;
			}
		}

		if (!string.IsNullOrWhiteSpace(snapshot.StartFunction))
		{
			return snapshot.StartFunction;
		}

		return snapshot.FrameworkSteps.FirstOrDefault()?.Name
			?? snapshot.FlowFunctions.FirstOrDefault()?.Name
			?? snapshot.CallGraphNodes.FirstOrDefault()?.Name
			?? "";
	}

	private static void ScheduleMemoryTrim()
	{
		if (Interlocked.Exchange(ref _memoryTrimPending, 1) == 1)
		{
			return;
		}

		Task.Run(async () =>
		{
			try
			{
				await Task.Delay(900).ConfigureAwait(false);
				GC.Collect(2, GCCollectionMode.Optimized, blocking: false, compacting: false);
			}
			finally
			{
				Interlocked.Exchange(ref _memoryTrimPending, 0);
			}
		});
	}

	private void UpdateFlowChart(IReadOnlyList<ProgramFrameworkStep> frameworkSteps)
	{
		if (_flowChart == null)
		{
			return;
		}
		(IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges) graph =
			LooksLikeMainLoopProject(frameworkSteps) ? BuildMainLoopFlowChart(frameworkSteps) : BuildGenericFlowChart(frameworkSteps);
		_flowChart.SetGraph(graph.nodes, graph.edges);
		if (_lastTraceId != ushort.MaxValue)
		{
			_flowChart.SetHighlight(_lastTraceId);
		}
	}

	private void UpdateCallRelationChart(
		IReadOnlyList<ProgramCallGraphNode> graphNodes,
		IReadOnlyList<ProgramCallGraphEdge> graphEdges)
	{
		if (_flowChart == null)
		{
			return;
		}

		(IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges) graph = BuildCallRelationFlowChart(graphNodes, graphEdges);
		_flowChart.SetGraph(graph.nodes, graph.edges);
		if (_lastTraceId != ushort.MaxValue)
		{
			_flowChart.SetHighlight(_lastTraceId);
		}
	}

	private static (IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges) BuildCallRelationFlowChart(
		IReadOnlyList<ProgramCallGraphNode> graphNodes,
		IReadOnlyList<ProgramCallGraphEdge> graphEdges)
	{
		if (graphNodes.Count == 0)
		{
			return (
				new[] { new FlowChartNode("empty", "未识别到函数调用关系\n选择工程目录后自动分析", new RectangleF(24, 24, 250, 72), 0) },
				Array.Empty<FlowChartEdge>());
		}

		var nodes = new List<FlowChartNode>();
		var levelGroups = graphNodes
			.GroupBy(n => n.Level)
			.OrderBy(g => g.Key)
			.ToList();
		const float xGap = 252f;
		const float yGap = 96f;
		const float nodeWidth = 214f;
		const float nodeHeight = 76f;
		foreach (IGrouping<int, ProgramCallGraphNode> group in levelGroups)
		{
			List<ProgramCallGraphNode> levelNodes = group
				.OrderByDescending(n => n.Outgoing)
				.ThenByDescending(n => n.Incoming)
				.ThenBy(n => n.Name, StringComparer.OrdinalIgnoreCase)
				.ToList();
			float x = 26 + group.Key * xGap;
			for (int i = 0; i < levelNodes.Count; i++)
			{
				ProgramCallGraphNode node = levelNodes[i];
				string detail = string.IsNullOrWhiteSpace(node.Summary) ? node.Name : node.Summary;
				string text = $"{node.Name}\n{detail}";
				nodes.Add(new FlowChartNode(
					node.Id,
					text,
					new RectangleF(x, 24 + i * yGap, nodeWidth, nodeHeight),
					node.TraceId,
					node.Name,
					node.Kind));
			}
		}

		var nodeIds = nodes.Select(n => n.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
		var edges = graphEdges
			.Where(e => nodeIds.Contains(e.FromId) && nodeIds.Contains(e.ToId))
			.Select(e => new FlowChartEdge(e.FromId, e.ToId))
			.ToList();
		return (nodes, edges);
	}

	private static bool LooksLikeMainLoopProject(IReadOnlyList<ProgramFrameworkStep> steps)
	{
		string[] names = steps.Select(s => s.FunctionName).ToArray();
		return names.Contains("App_JiTing", StringComparer.OrdinalIgnoreCase) ||
			names.Contains("app_Ctrl", StringComparer.OrdinalIgnoreCase) ||
			names.Contains("Usr_Can_Rcv", StringComparer.OrdinalIgnoreCase);
	}

	private static (IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges) BuildMainLoopFlowChart(IReadOnlyList<ProgramFrameworkStep> steps)
	{
		var trace = steps
			.GroupBy(s => s.FunctionName, StringComparer.OrdinalIgnoreCase)
			.ToDictionary(g => g.Key, g => g.First().TraceId, StringComparer.OrdinalIgnoreCase);
		ushort T(string name, ushort fallback)
		{
			return trace.TryGetValue(name, out ushort value) ? value : fallback;
		}
		FlowChartNode N(string id, string text, float x, float y, ushort traceId = 0, float w = 158, float h = 46, string functionName = "", string kind = "normal")
		{
			return new FlowChartNode(id, text, new RectangleF(x, y, w, h), traceId, functionName, kind);
		}

		var nodes = new List<FlowChartNode>
		{
			N("A", "上电启动", 420, 16, kind: "main"),
			N("B", "SystemInit", 420, 78, kind: "main"),
			N("C", "Sys_Usr_Init\nIO/CAN/UART/ADC/PWM", 420, 140, 0, 188, 50, kind: "main"),
			N("D", "Can1_RcvID_Cfg\n业务 CAN + 监控 ID", 420, 206, 0, 188, 50, kind: "can"),
			N("E", "while(1)\n主循环", 435, 276, 0, 158, 50, kind: "main"),
			N("F", "CAN 异常诊断\nCan_ask_rx", 28, 374, T("Can_ask_rx", 0x2140), functionName: "Can_ask_rx", kind: "can"),
			N("G", "1ms 标志\ngT0Flg", 230, 374, kind: "timer"),
			N("H", "急停/遥控/超时\n条件判断", 230, 442, 0, 168, 52),
			N("I", "App_JiTing\n急停处理", 118, 526, T("App_JiTing", 0x2101), functionName: "App_JiTing"),
			N("J", "app_Logic\n逻辑联锁", 118, 594, T("app_Logic", 0x2103), functionName: "app_Logic"),
			N("K", "app_Ctrl\n主业务控制", 332, 526, T("app_Ctrl", 0x2102), functionName: "app_Ctrl"),
			N("L", "app_Logic\n逻辑联锁", 332, 594, T("app_Logic", 0x2103), functionName: "app_Logic"),
			N("M", "app_ctrl_dfs\nDFS 控制", 332, 662, T("app_ctrl_dfs", 0x2104), functionName: "app_ctrl_dfs"),
			N("N", "App_PWM\nPWM 输出", 332, 730, T("App_PWM", 0x2105), functionName: "App_PWM"),
			N("O", "10ms 标志\ngT010msFlg", 540, 374, kind: "period10"),
			N("P", "Usr_Can_Rcv\n接收 CAN + 变量监控", 540, 442, T("Usr_Can_Rcv", 0x2110), 188, 52, "Usr_Can_Rcv", "can"),
			N("Q", "Usr_Can_Send\n发送业务 CAN", 540, 526, T("Usr_Can_Send", 0x2111), functionName: "Usr_Can_Send", kind: "can"),
			N("R", "Can_Rcv_Dly\n接收超时倒计时", 540, 594, T("Can_Rcv_Dly", 0x2112), 178, 50, "Can_Rcv_Dly", "period10"),
			N("S", "WDT_Feed / WDTFeed\n喂狗", 540, 662, T("WDT_Feed", 0x2113), 178, 50, "WDT_Feed"),
			N("T", "CAN1RxDone\n中断接收标志", 778, 374, kind: "can"),
			N("U", "Can_Prog_Rcv\nCAN 中断缓存处理", 778, 442, T("Can_Prog_Rcv", 0x2114), 178, 52, "Can_Prog_Rcv", "can"),
			N("V", "UART 接收", 28, 662),
			N("W", "Uart0_WL_Rcv\n无线遥控接收", 28, 730, T("Uart0_WL_Rcv", 0x2120), 178, 50, "Uart0_WL_Rcv"),
			N("X", "Uart0_WL_Send\n回发遥控器", 28, 798, T("Uart0_WL_Send", 0x2121), 178, 50, "Uart0_WL_Send"),
			N("Y", "秒标志\ngT0SFlg", 778, 594),
			N("Z", "Save_Info_Prog / wl_reset\n保存参数/无线恢复", 778, 662, T("Save_Info_Prog", 0x2130), 198, 52, "Save_Info_Prog")
		};
		var edges = new List<FlowChartEdge>
		{
			new("A", "B"), new("B", "C"), new("C", "D"), new("D", "E"),
			new("E", "F"), new("E", "G"), new("G", "H"),
			new("H", "I", "是"), new("I", "J"),
			new("H", "K", "否"), new("K", "L"), new("L", "M"), new("M", "N"),
			new("E", "O"), new("O", "P"), new("P", "Q"), new("Q", "R"), new("R", "S"),
			new("E", "T"), new("T", "U"),
			new("E", "V"), new("V", "W"), new("W", "X"),
			new("E", "Y"), new("Y", "Z")
		};
		return (nodes, edges);
	}

	private static (IReadOnlyList<FlowChartNode> nodes, IReadOnlyList<FlowChartEdge> edges) BuildGenericFlowChart(IReadOnlyList<ProgramFrameworkStep> steps)
	{
		if (steps.Count == 0)
		{
			return (
				new[] { new FlowChartNode("empty", "未识别到业务流程\n选择工程目录后自动分析", new RectangleF(24, 24, 230, 72), 0) },
				Array.Empty<FlowChartEdge>());
		}

		var nodes = new List<FlowChartNode>();
		var edges = new List<FlowChartEdge>();
		int count = Math.Min(steps.Count, 24);
		for (int i = 0; i < count; i++)
		{
			ProgramFrameworkStep step = steps[i];
			string id = "N" + i;
			nodes.Add(new FlowChartNode(
				id,
				step.Name + "\n" + step.Detail,
				new RectangleF(80, 24 + i * 72, 230, 52),
				step.TraceId,
				step.FunctionName,
				ClassifyFlowNodeKind(step.FunctionName, step.Name, step.Detail)));
			if (i > 0)
			{
				edges.Add(new FlowChartEdge("N" + (i - 1), id));
			}
		}
		return (nodes, edges);
	}

	private static string ClassifyFlowNodeKind(string functionName, string name, string detail)
	{
		string combined = functionName + " " + name + " " + detail;
		if (combined.Contains("main", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("while", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("SystemInit", StringComparison.OrdinalIgnoreCase))
		{
			return "main";
		}
		if (combined.Contains("disp", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("display", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("lcd", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("LCD_WR_Data2B", StringComparison.OrdinalIgnoreCase))
		{
			return "disp";
		}
		if (combined.Contains("10ms", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("T010ms", StringComparison.OrdinalIgnoreCase) ||
			combined.Contains("MyLogic_10ms", StringComparison.OrdinalIgnoreCase))
		{
			return "period10";
		}
		if (combined.Contains("CAN", StringComparison.OrdinalIgnoreCase))
		{
			return "can";
		}
		return "normal";
	}

	private async Task InstallFirmwareAgentAsync(Button installButton)
	{
		string text = GetWorkDirectoryFromUi();
		if (text.Length == 0 || !Directory.Exists(text))
		{
			using FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				Description = "请选择工作目录",
				UseDescriptionForTitle = true
			};
			if (folderBrowserDialog.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			text = folderBrowserDialog.SelectedPath;
			SetWorkDirectory(text, loadMap: true);
		}
		string text2;
		try
		{
			text2 = BundledFirmwareAgent.WriteTempCopy();
		}
		catch (Exception ex)
		{
			Log("没有找到内置固件文件：" + ex.Message);
			return;
		}
		try
		{
			installButton.Enabled = false;
			installButton.Text = "安装中";
			ApplyButtonStyle(installButton, "working");
			Log("开始安装固件：" + text);
			FirmwareInstallResult firmwareInstallResult = await Task.Run(() => FirmwareInstaller.Install(text, text2));
			foreach (string message in firmwareInstallResult.Messages)
			{
				Log(message);
			}
			LoadLatestMapFromDirectory(text);
			RefreshProgramGraphPanel(text);
			UpdateFirmwareVersionDisplay();
			if (!firmwareInstallResult.Success)
			{
				Log("固件安装未完全完成，请查看上面的提示。");
			}
		}
		catch (Exception ex)
		{
			Log("安装固件失败：" + ex.Message);
		}
		finally
		{
			installButton.Text = "加载固件";
			installButton.Enabled = true;
			ApplyButtonStyle(installButton, "firmware");
		}
	}

	private void CancelActiveDownload(bool waitForExit = false)
	{
		CancellationTokenSource? downloadCts = _downloadCts;
		if (downloadCts == null)
		{
			return;
		}

		try
		{
			downloadCts.Cancel();
		}
		catch (ObjectDisposedException)
		{
		}

		Task? downloadTask = _downloadTask;
		if (waitForExit && downloadTask != null && !downloadTask.IsCompleted)
		{
			try
			{
				downloadTask.Wait(1200);
			}
			catch (AggregateException ex) when (ex.InnerExceptions.All((Exception x) => x is OperationCanceledException || x is TaskCanceledException))
			{
			}
			catch (OperationCanceledException)
			{
			}
		}
	}

	private async Task DownloadFirmwareAsync(Button downloadButton)
	{
		if (_downloadTask != null && !_downloadTask.IsCompleted)
		{
			Log("下载未开始：已有下载任务正在进行。");
			return;
		}

		string text = GetWorkDirectoryFromUi();
		if (text.Length == 0 || !Directory.Exists(text))
		{
			using FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
			{
				Description = "请选择工作目录",
				UseDescriptionForTitle = true
			};
			if (folderBrowserDialog.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			text = folderBrowserDialog.SelectedPath;
			SetWorkDirectory(text, loadMap: true);
		}

		if (!IsWorkFirmwareVersionCurrent(text))
		{
			UpdateFirmwareVersionDisplay();
			Log("下载未开始：当前工程固件未同步，请先加载固件。");
			return;
		}

		CancellationTokenSource downloadCts = new CancellationTokenSource();
		CancellationToken token = downloadCts.Token;
		Task? workerTask = null;
		ICanAdapter? reusableAdapter = null;
		_downloadCts = downloadCts;

		try
		{
			downloadButton.Enabled = false;
			downloadButton.Text = "下载中";
			ApplyButtonStyle(downloadButton, "downloadBusy");
			Log("开始读取下载文件：" + text);
			StopPolling(waitForExit: true);
			reusableAdapter = _adapter;
			string preferredDownloadAdapter = reusableAdapter?.Name ?? _preferredAdapterName;
			_adapter = null;
			_monitorSessionOpen = false;
			ResetCanHealthCounters();
			_connectButton.Text = "连接";
			ApplyButtonStyle(_connectButton, "connect");
			_statusLabel.Text = "下载中";
			_statusLabel.BackColor = _accent;

			FirmwareBinaryResult binaryResult = await Task.Run(() => FirmwareInstaller.BuildBinaryForDownload(text), token);
			token.ThrowIfCancellationRequested();
			foreach (string message in binaryResult.Messages)
			{
				Log(message);
			}
			if (!binaryResult.Success)
			{
				Log("下载未开始：没有找到有效 bin 文件。");
				return;
			}

			_statusLabel.Text = "0%";
			IProgress<string> progress = new Progress<string>(UpdateDownloadProgress);
			ICanAdapter? firstDownloadAdapter = reusableAdapter;
			reusableAdapter = null;
			workerTask = Task.Run(() =>
			{
				string? deprioritizedAdapterName = null;
				Exception? lastError = null;
				int maxAttempts = firstDownloadAdapter == null ? 2 : 3;
				for (int attempt = 1; attempt <= maxAttempts; attempt++)
				{
					token.ThrowIfCancellationRequested();
					ICanAdapter? adapter = null;
					if (firstDownloadAdapter != null)
					{
						adapter = firstDownloadAdapter;
						firstDownloadAdapter = null;
						CanAdapterDiagnostics.Write("Download reusing opened CAN adapter: " + adapter.Name);
					}
					else
					{
						string? preferredName = attempt == 1 ? preferredDownloadAdapter : null;
						if (!CanAdapterFactory.TryOpenAvailable(out adapter, out string message, deprioritizedAdapterName, preferredName) || adapter == null)
						{
							throw new InvalidOperationException("未连接：" + message);
						}
					}

					using (adapter)
					{
						try
						{
							_preferredAdapterName = adapter.Name;
							CanFirmwareDownloader.Download(adapter, binaryResult.BinPath, text, progress, token);
							return;
						}
						catch (TimeoutException ex) when (attempt < 2 && !token.IsCancellationRequested)
						{
							lastError = ex;
							deprioritizedAdapterName = adapter.Name;
							CanAdapterDiagnostics.Write("Download timeout on " + adapter.Name + ", retrying another adapter.");
						}
					}
				}

				throw lastError ?? new TimeoutException("下载超时。");
			});
			_downloadTask = workerTask;
			await workerTask;
			token.ThrowIfCancellationRequested();
			_statusLabel.Text = "100%";
			_statusLabel.BackColor = _accent;
			Log("下载完成。");
			WriteConnectionState("下载完成");
		}
		catch (OperationCanceledException)
		{
			Log("下载已取消。");
			WriteConnectionState("下载取消");
			if (!IsDisposed && !Disposing)
			{
				_statusLabel.Text = "未连接";
				_statusLabel.BackColor = _statusOff;
			}
		}
		catch (Exception ex)
		{
			_statusLabel.Text = "未连接";
			_statusLabel.BackColor = _statusOff;
			Log("下载失败：" + ex.Message);
			WriteConnectionState("下载失败：" + ex);
		}
		finally
		{
			reusableAdapter?.Dispose();
			if (ReferenceEquals(_downloadCts, downloadCts))
			{
				_downloadCts = null;
			}
			if (ReferenceEquals(_downloadTask, workerTask))
			{
				_downloadTask = null;
			}
			downloadCts.Dispose();
			if (!IsDisposed && !Disposing && _adapter == null)
			{
				_connectButton.Text = "连接";
			}
			if (!IsDisposed && !Disposing)
			{
				UpdateDownloadButtonState();
			}
		}
	}

	private void UpdateDownloadProgress(string message)
	{
		if (string.IsNullOrWhiteSpace(message))
		{
			return;
		}

		string text = message.Trim();
		if (!text.StartsWith("下载进度：", StringComparison.Ordinal))
		{
			return;
		}

		string percentText = text.Substring("下载进度：".Length).Trim();
		if (_statusLabel != null)
		{
			_statusLabel.Text = percentText;
			_statusLabel.BackColor = _accent;
		}
		Log(text);
	}

	private static string? FindLatestMapFile(string root)
	{
		return Directory.EnumerateFiles(root, "*.map", SearchOption.AllDirectories).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
	}

	private static string? FindLatestAxfFile(string root)
	{
		return Directory.EnumerateFiles(root, "*.axf", SearchOption.AllDirectories).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
	}

	private void LoadDefaultProfile()
	{
		if (File.Exists(_defaultProfilePath))
		{
			LoadProfile(_defaultProfilePath);
			if (_workDirectory.Length == 0)
			{
				_profileLoaded = true;
				TryLoadStartupWorkDirectory();
			}
			return;
		}
		_profileLoaded = true;
		TryLoadStartupWorkDirectory();
	}

	private void TryLoadStartupWorkDirectory()
	{
		foreach (string arg in Environment.GetCommandLineArgs().Skip(1))
		{
			string directory = arg.Trim('"', ' ');
			if (Directory.Exists(directory))
			{
				SetWorkDirectory(directory, loadMap: true);
				return;
			}
		}
		string workdirFile = Path.Combine(AppContext.BaseDirectory, "workdir.txt");
		if (!File.Exists(workdirFile))
		{
			return;
		}
		string text = File.ReadLines(workdirFile).FirstOrDefault(line => !string.IsNullOrWhiteSpace(line))?.Trim('"', ' ') ?? "";
		if (text.Length == 0)
		{
			return;
		}
		if (!Path.IsPathRooted(text))
		{
			text = Path.Combine(AppContext.BaseDirectory, text);
		}
		if (Directory.Exists(text))
		{
			SetWorkDirectory(text, loadMap: true);
		}
	}

	private void SaveProfile(string path)
	{
		MonitorProfile value = new MonitorProfile
		{
			WorkDirectory = _workDirectory,
			MapPath = _mapFilePath,
			Adapter = _adapter?.Name ?? "",
			ThemeName = _themeName,
			RequestId = 2032u,
			ResponseId = 2033u,
			PollIntervalMs = _targetCycleMs,
			ShowHexValue = _showHexValue,
			LeftPanelWidth = (_mainSplit?.SplitterDistance ?? _savedLeftPanelWidth),
			MonitorPanelWidth = (_rightSplit?.SplitterDistance ?? _savedMonitorPanelWidth),
			FunctionCodeFontSize = _functionCodeFontSize,
			MonitorColumnWidths = GetMonitorColumnWidths(),
			Variables = BuildProfileVariables()
		};
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		File.WriteAllText(path, JsonSerializer.Serialize(value, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
		Directory.CreateDirectory(Path.GetDirectoryName(_defaultProfilePath));
		File.WriteAllText(_defaultProfilePath, JsonSerializer.Serialize(value, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
		Log("变量列表已保存：" + path);
	}

	private void SaveDefaultProfileQuietly()
	{
		try
		{
			if (!_profileLoaded || _loadingProfile)
			{
				return;
			}
			MonitorProfile? monitorProfile = null;
			if (File.Exists(_defaultProfilePath))
			{
				try
				{
					monitorProfile = JsonSerializer.Deserialize<MonitorProfile>(File.ReadAllText(_defaultProfilePath));
				}
				catch
				{
				}
			}
			string workDirectory = _workDirectory;
			string mapPath = _mapFilePath;
			if (workDirectory.Length == 0 && !string.IsNullOrWhiteSpace(monitorProfile?.WorkDirectory))
			{
				workDirectory = monitorProfile.WorkDirectory;
			}
			if (mapPath.Length == 0 && !string.IsNullOrWhiteSpace(monitorProfile?.MapPath))
			{
				mapPath = monitorProfile.MapPath;
			}
			MonitorProfile value = new MonitorProfile
			{
				WorkDirectory = workDirectory,
				MapPath = mapPath,
				Adapter = _adapter?.Name ?? "",
				ThemeName = _themeName,
				RequestId = 2032u,
				ResponseId = 2033u,
				PollIntervalMs = _targetCycleMs,
				ShowHexValue = _showHexValue,
				LeftPanelWidth = (_mainSplit?.SplitterDistance ?? _savedLeftPanelWidth),
				MonitorPanelWidth = (_rightSplit?.SplitterDistance ?? _savedMonitorPanelWidth),
				FunctionCodeFontSize = _functionCodeFontSize,
				MonitorColumnWidths = GetMonitorColumnWidths(),
				Variables = BuildProfileVariables()
			};
			Directory.CreateDirectory(Path.GetDirectoryName(_defaultProfilePath));
			File.WriteAllText(_defaultProfilePath, JsonSerializer.Serialize(value, new JsonSerializerOptions
			{
				WriteIndented = true
			}));
		}
		catch
		{
		}
	}

	private List<WatchItem> BuildProfileVariables()
	{
		return _watchItems.Select(CloneWatchItemForProfile).ToList();
	}

	private WatchItem CloneWatchItemForProfile(WatchItem item)
	{
		var clone = new WatchItem
		{
			Enabled = item.Enabled,
			Name = item.Name,
			Address = item.Address,
			Size = item.Size,
			TotalSize = item.TotalSize,
			TypeName = item.TypeName,
			IsExpandable = item.IsExpandable,
			IsChild = item.IsChild,
			ParentName = item.ParentName,
			ExpandMode = item.ExpandMode,
			ValueDec = item.ValueDec,
			ValueHex = item.ValueHex,
			RawValue = item.RawValue,
			LastUpdate = item.LastUpdate,
			Status = "待读取"
		};
		clone.DisplayValue = FormatValue(clone);
		return clone;
	}

	private void LoadProfile(string path)
	{
		bool loadedProfile = false;
		try
		{
			_loadingProfile = true;
			MonitorProfile monitorProfile = JsonSerializer.Deserialize<MonitorProfile>(File.ReadAllText(path));
			if (monitorProfile == null)
			{
				return;
			}
			loadedProfile = true;
			if (!string.IsNullOrWhiteSpace(monitorProfile.ThemeName))
			{
				ApplyTheme(monitorProfile.ThemeName);
				if (_themeBox != null)
				{
					_themeBox.SelectedItem = _themeName;
				}
				UpdateFirmwareVersionDisplay();
			}
			string text = monitorProfile.WorkDirectory;
			if (text.Length == 0 && File.Exists(monitorProfile.MapPath))
			{
				text = Path.GetDirectoryName(monitorProfile.MapPath) ?? "";
			}
			if (text.Length > 0 && Directory.Exists(text))
			{
				SetWorkDirectory(text, loadMap: false);
			}
			_intervalBox.Value = Math.Clamp(monitorProfile.PollIntervalMs, (int)_intervalBox.Minimum, (int)_intervalBox.Maximum);
			_targetCycleMs = (int)_intervalBox.Value;
			_showHexValue = monitorProfile.ShowHexValue;
			_functionCodeFontSize = Math.Clamp(monitorProfile.FunctionCodeFontSize, 8f, 22f);
			if (_functionCodeBox != null)
			{
				_functionCodeBox.Font = new Font("Consolas", _functionCodeFontSize);
			}
			if (_dataCodeBox != null)
			{
				_dataCodeBox.Font = new Font("Consolas", _functionCodeFontSize);
			}
			_savedLeftPanelWidth = monitorProfile.LeftPanelWidth;
			_savedMonitorPanelWidth = monitorProfile.MonitorPanelWidth;
			_savedMonitorColumnWidths = monitorProfile.MonitorColumnWidths?.ToList() ?? new List<int>();
			ApplySavedSplitterDistances();
			ApplySavedMonitorColumnWidths();
			if (_grid != null)
			{
				DataGridViewColumn dataGridViewColumn = _grid.Columns.Cast<DataGridViewColumn>().FirstOrDefault((DataGridViewColumn x) => x.DataPropertyName == "DisplayValue");
				if (dataGridViewColumn != null)
				{
					dataGridViewColumn.HeaderText = (_showHexValue ? "值(16)" : "值(10)");
				}
			}
			UpdateValueFormatButton();
			_watchItems.Clear();
			foreach (WatchItem item in monitorProfile.Variables)
			{
				ResetTransientWatchState(item);
				_watchItems.Add(item);
			}
			UpdateCycleEstimate();
			if (File.Exists(monitorProfile.MapPath))
			{
				_mapFilePath = monitorProfile.MapPath;
				LoadMapFile(monitorProfile.MapPath);
			}
			else if (_workDirectory.Length > 0 && Directory.Exists(_workDirectory))
			{
				LoadLatestMapFromDirectory(_workDirectory);
			}
			if (_workDirectory.Length > 0 && Directory.Exists(_workDirectory))
			{
				RefreshProgramGraphPanel(_workDirectory);
			}
			Log("变量列表已加载：" + path);
		}
		catch (Exception ex)
		{
			Log("加载变量列表失败：" + ex.Message);
		}
		finally
		{
			_loadingProfile = false;
			_profileLoaded = true;
			if (loadedProfile)
			{
				SaveDefaultProfileQuietly();
			}
		}
	}

	private void Log(string text)
	{
		string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {text}";
		WriteDiagnosticLog(line);
		if (_logBox == null || _logBox.IsDisposed)
		{
			return;
		}

		void Append()
		{
			if (_logBox == null || _logBox.IsDisposed || !_logBox.Visible)
			{
				return;
			}
			_logBox.AppendText(line + Environment.NewLine);
			_uiLogLineCount++;
			TrimUiLogIfNeeded();
		}

		try
		{
			if (_logBox.InvokeRequired)
			{
				BeginInvoke((Action)Append);
			}
			else
			{
				Append();
			}
		}
		catch
		{
		}
	}

	private void LogPerformance(string text, Stopwatch stopwatch)
	{
		stopwatch.Stop();
		Log($"{text}，耗时 {stopwatch.ElapsedMilliseconds} ms，内存 {GetProcessMemoryText()}。");
	}

	private static string GetProcessMemoryText()
	{
		try
		{
			using Process process = Process.GetCurrentProcess();
			return (process.WorkingSet64 / 1024d / 1024d).ToString("F1") + " MB";
		}
		catch
		{
			return "未知";
		}
	}

	private void WriteDiagnosticLog(string line)
	{
		try
		{
			lock (_diagnosticLogLock)
			{
				string? dir = Path.GetDirectoryName(_diagnosticLogPath);
				if (!string.IsNullOrWhiteSpace(dir))
				{
					Directory.CreateDirectory(dir);
				}
				File.AppendAllText(_diagnosticLogPath, line + Environment.NewLine, Encoding.UTF8);
				TrimDiagnosticLogIfNeeded();
			}
		}
		catch (Exception ex)
		{
			LogPollLoopError(ex);
		}
	}

	private void TrimDiagnosticLogIfNeeded()
	{
		DateTime now = DateTime.UtcNow;
		if ((now - _lastLogTrimUtc).TotalSeconds < 10)
		{
			return;
		}
		_lastLogTrimUtc = now;
		FileInfo fileInfo = new FileInfo(_diagnosticLogPath);
		if (!fileInfo.Exists || fileInfo.Length <= DiagnosticLogMaxBytes)
		{
			return;
		}

		string[] lines = File.ReadAllLines(_diagnosticLogPath, Encoding.UTF8);
		IEnumerable<string> tail = lines.Length > DiagnosticLogKeepLines
			? lines.Skip(lines.Length - DiagnosticLogKeepLines)
			: lines;
		File.WriteAllLines(_diagnosticLogPath, tail, Encoding.UTF8);
	}

	private void TrimUiLogIfNeeded()
	{
		if (_logBox == null || _uiLogLineCount <= UiLogMaxLines)
		{
			return;
		}

		string[] lines = _logBox.Lines;
		if (lines.Length <= UiLogMaxLines)
		{
			_uiLogLineCount = lines.Length;
			return;
		}

		string[] tail = lines.Skip(Math.Max(0, lines.Length - UiLogMaxLines)).ToArray();
		_logBox.Lines = tail;
		_uiLogLineCount = tail.Length;
		_logBox.SelectionStart = _logBox.TextLength;
		_logBox.ScrollToCaret();
	}

	private Panel CardPanel()
	{
		return new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = _panel,
			Padding = new Padding(1),
			Margin = new Padding(0, 0, 0, 10),
			Tag = "card"
		};
	}

	private Button AccentButton(string text)
	{
		return new Button
		{
			Text = text,
			AutoSize = false,
			Size = new Size(92, 30),
			BackColor = _accent,
			ForeColor = Color.White,
			FlatStyle = FlatStyle.Flat,
			Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold),
			Tag = "accent"
		};
	}

	private sealed class ReadableButton : Button
	{
		private bool _hover;
		private bool _pressed;

		public ReadableButton()
		{
			SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
		}

		protected override void OnMouseEnter(EventArgs e)
		{
			_hover = true;
			Invalidate();
			base.OnMouseEnter(e);
		}

		protected override void OnMouseLeave(EventArgs e)
		{
			_hover = false;
			_pressed = false;
			Invalidate();
			base.OnMouseLeave(e);
		}

		protected override void OnMouseDown(MouseEventArgs mevent)
		{
			_pressed = true;
			Invalidate();
			base.OnMouseDown(mevent);
		}

		protected override void OnMouseUp(MouseEventArgs mevent)
		{
			_pressed = false;
			Invalidate();
			base.OnMouseUp(mevent);
		}

		protected override void OnPaint(PaintEventArgs pevent)
		{
			Color back = _pressed
				? FlatAppearance.MouseDownBackColor
				: (_hover ? FlatAppearance.MouseOverBackColor : BackColor);
			if (!Enabled)
			{
				back = BackColor;
			}

			Rectangle rect = ClientRectangle;
			using (SolidBrush brush = new SolidBrush(back))
			{
				pevent.Graphics.FillRectangle(brush, rect);
			}

			int borderSize = Math.Max(1, FlatAppearance.BorderSize);
			ControlPaint.DrawBorder(
				pevent.Graphics,
				rect,
				FlatAppearance.BorderColor,
				borderSize,
				ButtonBorderStyle.Solid,
				FlatAppearance.BorderColor,
				borderSize,
				ButtonBorderStyle.Solid,
				FlatAppearance.BorderColor,
				borderSize,
				ButtonBorderStyle.Solid,
				FlatAppearance.BorderColor,
				borderSize,
				ButtonBorderStyle.Solid);

			Rectangle textRect = Rectangle.Inflate(rect, -3, -1);
			TextRenderer.DrawText(
				pevent.Graphics,
				Text,
				Font,
				textRect,
				ForeColor,
				TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding);

			if (Focused && ShowFocusCues)
			{
				ControlPaint.DrawFocusRectangle(pevent.Graphics, Rectangle.Inflate(rect, -4, -4));
			}
		}
	}

	private Button CommandButton(string text)
	{
		Font font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
		int width = Math.Max(52, Math.Min(92, TextRenderer.MeasureText(text, font).Width + 20));
		Button button = new ReadableButton
		{
			Text = text,
			AutoSize = false,
			Size = new Size(width, 26),
			BackColor = _accent,
			ForeColor = Color.White,
			FlatStyle = FlatStyle.Flat,
			Font = font,
			Margin = new Padding(0),
			Cursor = Cursors.Hand,
			TextAlign = ContentAlignment.MiddleCenter,
			UseVisualStyleBackColor = false,
			Padding = Padding.Empty,
			Tag = "command"
		};
		button.FlatAppearance.BorderColor = Color.FromArgb(226, 232, 240);
		button.FlatAppearance.BorderSize = 2;
		button.FlatAppearance.MouseOverBackColor = _accent;
		button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(_accent);
		return button;
	}

	private void MakeToolbarButton(Button button, string style)
	{
		button.Dock = DockStyle.None;
		button.Anchor = AnchorStyles.None;
		button.Margin = new Padding(0);
		button.MinimumSize = new Size(0, 26);
		button.Height = 26;
		ApplyButtonStyle(button, style);
	}

	private Button PlainButton(string text)
	{
		return new Button
		{
			Text = text,
			AutoSize = false,
			Size = new Size(104, 30),
			BackColor = _button,
			ForeColor = _ink,
			FlatStyle = FlatStyle.Flat,
			Tag = "plain"
		};
	}

	private void ApplyButtonStyle(Button button, string style)
	{
		if (IsProminentButtonStyle(style))
		{
			Color color = GetProminentButtonColor(style);
			button.BackColor = color;
			button.ForeColor = Color.White;
			button.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
			button.FlatStyle = FlatStyle.Flat;
			button.Cursor = Cursors.Hand;
			button.UseVisualStyleBackColor = false;
			button.UseCompatibleTextRendering = false;
			button.Padding = Padding.Empty;
			button.FlatAppearance.BorderColor = GetProminentButtonBorderColor(style);
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = MixColor(color, Color.White, 0.08f);
			button.FlatAppearance.MouseDownBackColor = MixColor(color, Color.Black, 0.18f);
			button.Tag = style;
		}
		else if (style == "command")
		{
			button.BackColor = Color.FromArgb(51, 65, 85);
			button.ForeColor = Color.White;
			button.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
			button.Cursor = Cursors.Hand;
			button.UseVisualStyleBackColor = false;
			button.UseCompatibleTextRendering = false;
			button.Padding = Padding.Empty;
			button.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = Color.FromArgb(71, 85, 105);
			button.FlatAppearance.MouseDownBackColor = Color.FromArgb(30, 41, 59);
			button.Tag = "command";
		}
		else if (style == "accent")
		{
			button.BackColor = _accent;
			button.ForeColor = Color.White;
			button.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Bold);
			button.Cursor = Cursors.Hand;
			button.UseVisualStyleBackColor = false;
			button.FlatAppearance.BorderColor = ControlPaint.Light(_accent);
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(_accent);
			button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(_accent);
			button.Tag = "accent";
		}
		else if (style == "disabled")
		{
			button.BackColor = _gridHeader;
			button.ForeColor = _muted;
			button.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular);
			button.Cursor = Cursors.Default;
			button.UseVisualStyleBackColor = false;
			button.FlatAppearance.BorderColor = _gridHeader;
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = _gridHeader;
			button.FlatAppearance.MouseDownBackColor = _gridHeader;
			button.Tag = "disabled";
		}
		else
		{
			button.BackColor = _button;
			button.ForeColor = _ink;
			button.Font = new Font("Microsoft YaHei UI", 9f, FontStyle.Regular);
			button.Cursor = Cursors.Hand;
			button.UseVisualStyleBackColor = false;
			button.FlatAppearance.BorderColor = _gridHeader;
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(_button);
			button.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(_button);
			button.Tag = "plain";
		}
	}

	private static bool IsProminentButtonStyle(string style)
	{
		return style is "directory" or "refresh" or "firmware" or "blocked" or "download" or "downloadBusy" or "connect" or "disconnect" or "waiting" or "simulate" or "monitorStart" or "monitorStop" or "search" or "working";
	}

	private Color GetProminentButtonColor(string style)
	{
		return style switch
		{
			"waiting" or "working" or "simulate" or "downloadBusy" or "blocked" => Color.FromArgb(71, 85, 105),
			"disconnect" or "monitorStop" => Color.FromArgb(63, 78, 101),
			_ => Color.FromArgb(51, 65, 85)
		};
	}

	private static Color GetProminentButtonBorderColor(string style)
	{
		return style switch
		{
			"waiting" or "working" or "simulate" or "downloadBusy" or "blocked" => Color.FromArgb(203, 213, 225),
			_ => Color.FromArgb(148, 163, 184)
		};
	}

	private static Color MixColor(Color from, Color to, float ratio)
	{
		ratio = Math.Max(0f, Math.Min(1f, ratio));
		int r = (int)Math.Round(from.R + (to.R - from.R) * ratio);
		int g = (int)Math.Round(from.G + (to.G - from.G) * ratio);
		int b = (int)Math.Round(from.B + (to.B - from.B) * ratio);
		return Color.FromArgb(r, g, b);
	}

	private void StyleTextBox(TextBox box)
	{
		box.BackColor = _surface;
		box.ForeColor = _ink;
		box.BorderStyle = BorderStyle.FixedSingle;
		box.Tag = "input";
	}

	private void StyleComboBox(ComboBox box)
	{
		box.BackColor = _surface;
		box.ForeColor = _ink;
		box.Tag = "input";
	}

	private Label SmallLabel(string text)
	{
		return new Label
		{
			Text = text,
			ForeColor = _muted,
			AutoSize = false,
			TextAlign = ContentAlignment.MiddleLeft,
			Width = Math.Max(52, text.Length * 12),
			Height = 30,
			Margin = new Padding(4, 0, 4, 0),
			Tag = "small"
		};
	}

	private Label SectionLabel(string text)
	{
		return new Label
		{
			Text = text,
			ForeColor = _ink,
			Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold),
			Dock = DockStyle.Fill,
			TextAlign = ContentAlignment.MiddleLeft,
			Tag = "section"
		};
	}

	private static NumericUpDown HexUpDown(int value)
	{
		return new NumericUpDown
		{
			Minimum = 0m,
			Maximum = 2047m,
			Value = value,
			Hexadecimal = true,
			Width = 76,
			BackColor = Color.FromArgb(15, 23, 42),
			ForeColor = Color.FromArgb(226, 232, 240),
			Tag = "input"
		};
	}

	private static void EnableDoubleBuffer(Control control)
	{
		try
		{
			typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(control, true, null);
		}
		catch
		{
		}
	}

	private void SplitContainerPaint(object? sender, PaintEventArgs e)
	{
		if (sender is not SplitContainer splitContainer)
		{
			return;
		}

		Rectangle splitter = splitContainer.SplitterRectangle;
		if (splitter.Width <= 0 || splitter.Height <= 0)
		{
			return;
		}

		Color color = GetSplitterColor(splitContainer.Tag);
		using SolidBrush fill = new SolidBrush(color);
		e.Graphics.FillRectangle(fill, splitter);

		using Pen border = new Pen(ControlPaint.Dark(color), 1f);
		e.Graphics.DrawRectangle(border, Rectangle.Inflate(splitter, -1, -1));

		Rectangle stripe = splitter;
		if (splitContainer.Orientation == Orientation.Vertical)
		{
			stripe.X = splitter.X + splitter.Width / 2 - 1;
			stripe.Width = 2;
		}
		else
		{
			stripe.Y = splitter.Y + splitter.Height / 2 - 1;
			stripe.Height = 2;
		}

		using SolidBrush stripeBrush = new SolidBrush(Color.FromArgb(190, Color.White));
		e.Graphics.FillRectangle(stripeBrush, stripe);
	}

	private Color GetSplitterColor(object? tag)
	{
		if (object.Equals(tag, "split-right"))
		{
			Color amber = Color.FromArgb(245, 158, 11);
			return ColorDistance(_accent, amber) < 90 ? Color.FromArgb(34, 197, 94) : amber;
		}

		return _accent;
	}

	private static int ColorDistance(Color left, Color right)
	{
		int red = left.R - right.R;
		int green = left.G - right.G;
		int blue = left.B - right.B;
		return (int)Math.Sqrt(red * red + green * green + blue * blue);
	}

	private void ApplyTheme(string name)
	{
		ThemePalette theme = GetTheme(name);
		_themeName = theme.Name;
		_bg = theme.Bg;
		_header = theme.Header;
		_panel = theme.Panel;
		_surface = theme.Surface;
		_surfaceAlt = theme.SurfaceAlt;
		_gridHeader = theme.GridHeader;
		_ink = theme.Ink;
		_muted = theme.Muted;
		_accent = theme.Accent;
		_button = theme.Button;
		_statusOff = theme.StatusOff;
		BackColor = _bg;
		ApplyThemeToControl(this);
		UpdateValueFormatButton();
		UpdateProgramInsightPanel(force: true);
		UpdateDownloadButtonState();
	}

	private void ApplyThemeToControl(Control control)
	{
		if (control is SplitContainer splitContainer)
		{
			splitContainer.BackColor = GetSplitterColor(splitContainer.Tag);
			splitContainer.Invalidate();
		}
		else if (control is FlowChartView flowChart)
		{
			flowChart.SetPalette(_surface, _surfaceAlt, _ink, _muted, _accent, _gridHeader);
		}
		else if (!(control is DataGridView grid))
		{
			if (!(control is RichTextBox richTextBox))
			{
				if (!(control is TextBox textBox))
				{
					if (!(control is ComboBox comboBox))
					{
						if (!(control is NumericUpDown numericUpDown))
						{
							if (!(control is CheckBox checkBox))
							{
								if (!(control is Button button))
								{
									if (!(control is Label label))
									{
										if (!(control is ListBox listBox))
										{
											if (!(control is ListView listView))
											{
												if (!(control is TableLayoutPanel tableLayoutPanel))
												{
													if (!(control is FlowLayoutPanel flowLayoutPanel))
													{
														if (control is Panel panel)
														{
															panel.BackColor = object.Equals(panel.Tag, "header") ? _header : (object.Equals(panel.Tag, "surface") ? _surface : _panel);
														}
													}
													else
													{
														flowLayoutPanel.BackColor = Color.Transparent;
													}
												}
												else
												{
													tableLayoutPanel.BackColor = object.Equals(tableLayoutPanel.Tag, "searchBar")
														? _gridHeader
														: ((tableLayoutPanel.Parent == this) ? _bg : Color.Transparent);
												}
											}
											else
											{
												listView.BackColor = _surface;
												listView.ForeColor = _ink;
											}
										}
										else
										{
											listBox.BackColor = _surface;
											listBox.ForeColor = _ink;
										}
									}
									else if (label == _statusLabel)
									{
										label.ForeColor = Color.White;
										label.BackColor = _offlineSimulation ? _gridHeader : ((_adapter == null) ? _statusOff : _accent);
									}
									else if (object.Equals(label.Tag, "runtime"))
									{
										label.ForeColor = Color.White;
										label.BackColor = _accent;
									}
									else if (label == _visibleValuesLabel)
									{
										label.ForeColor = Color.FromArgb(17, 24, 39);
										label.BackColor = CodeValueBackColor;
									}
									else if (object.Equals(label.Tag, "small"))
									{
										label.ForeColor = _muted;
										label.BackColor = Color.Transparent;
									}
									else if (object.Equals(label.Tag, "appVersion"))
									{
										label.ForeColor = _accent;
										label.BackColor = Color.Transparent;
									}
									else
									{
										label.ForeColor = _ink;
										label.BackColor = Color.Transparent;
									}
								}
								else
								{
									ApplyButtonStyle(button, button.Tag as string ?? "plain");
								}
							}
							else
							{
								checkBox.BackColor = _panel;
								checkBox.ForeColor = _muted;
							}
						}
						else
						{
							numericUpDown.BackColor = _surface;
							numericUpDown.ForeColor = _ink;
						}
					}
					else
					{
						comboBox.BackColor = _surface;
						comboBox.ForeColor = _ink;
					}
				}
				else
				{
					textBox.BackColor = object.Equals(textBox.Tag, "searchInput") ? _surfaceAlt : _surface;
					textBox.ForeColor = _ink;
				}
			}
			else
			{
				richTextBox.BackColor = _surface;
				richTextBox.ForeColor = _ink;
			}
		}
		else
		{
			ApplyGridTheme(grid);
		}
		foreach (Control control2 in control.Controls)
		{
			ApplyThemeToControl(control2);
		}
	}

	private void ApplyGridTheme(DataGridView grid)
	{
		grid.BackgroundColor = _panel;
		grid.GridColor = _gridHeader;
		grid.ColumnHeadersDefaultCellStyle.BackColor = _gridHeader;
		grid.ColumnHeadersDefaultCellStyle.ForeColor = _ink;
		grid.DefaultCellStyle.BackColor = _surface;
		grid.DefaultCellStyle.ForeColor = _ink;
		grid.DefaultCellStyle.SelectionBackColor = _accent;
		grid.DefaultCellStyle.SelectionForeColor = Color.White;
		grid.AlternatingRowsDefaultCellStyle.BackColor = _surfaceAlt;
		grid.RowHeadersDefaultCellStyle.BackColor = _gridHeader;
		grid.RowHeadersDefaultCellStyle.ForeColor = _ink;
	}

	private static ThemePalette GetTheme(string name)
	{
		return name switch
		{
			"浅色工程" => new ThemePalette("浅色工程", Color.FromArgb(241, 245, 249), Color.FromArgb(255, 255, 255), Color.FromArgb(255, 255, 255), Color.FromArgb(248, 250, 252), Color.FromArgb(239, 246, 255), Color.FromArgb(226, 232, 240), Color.FromArgb(15, 23, 42), Color.FromArgb(100, 116, 139), Color.FromArgb(37, 99, 235), Color.FromArgb(226, 232, 240), Color.FromArgb(148, 163, 184)), 
			"深蓝仪表盘" => new ThemePalette("深蓝仪表盘", Color.FromArgb(5, 18, 35), Color.FromArgb(7, 31, 58), Color.FromArgb(10, 35, 66), Color.FromArgb(8, 27, 52), Color.FromArgb(12, 44, 78), Color.FromArgb(18, 72, 118), Color.FromArgb(226, 246, 255), Color.FromArgb(125, 179, 214), Color.FromArgb(0, 180, 216), Color.FromArgb(20, 65, 105), Color.FromArgb(56, 83, 116)), 
			"极简暗色" => new ThemePalette("极简暗色", Color.FromArgb(16, 16, 16), Color.FromArgb(24, 24, 24), Color.FromArgb(28, 28, 28), Color.FromArgb(22, 22, 22), Color.FromArgb(35, 35, 35), Color.FromArgb(48, 48, 48), Color.FromArgb(238, 238, 238), Color.FromArgb(160, 160, 160), Color.FromArgb(110, 168, 254), Color.FromArgb(42, 42, 42), Color.FromArgb(76, 76, 76)), 
			"设备控制台" => new ThemePalette("设备控制台", Color.FromArgb(22, 31, 28), Color.FromArgb(30, 43, 38), Color.FromArgb(39, 51, 46), Color.FromArgb(23, 38, 33), Color.FromArgb(31, 49, 42), Color.FromArgb(64, 82, 73), Color.FromArgb(224, 238, 224), Color.FromArgb(154, 174, 158), Color.FromArgb(88, 190, 120), Color.FromArgb(56, 70, 62), Color.FromArgb(91, 105, 96)), 
			_ => new ThemePalette("工业黑金", Color.FromArgb(10, 10, 12), Color.FromArgb(22, 18, 12), Color.FromArgb(25, 25, 28), Color.FromArgb(18, 18, 20), Color.FromArgb(33, 30, 24), Color.FromArgb(58, 50, 34), Color.FromArgb(244, 238, 225), Color.FromArgb(184, 171, 145), Color.FromArgb(212, 151, 39), Color.FromArgb(55, 48, 36), Color.FromArgb(92, 81, 61)), 
		};
	}
}
