/********************************************************************
*  
*  APP_BUS  �� ���� �йصĹ��ܺ���  IIC SPI CAN UART ��
*  ���ܣ�
*
********************************************************************/

#ifndef __APP_BUS_H_
#define __APP_BUS_H_


#include "config.h"



/****************************************************************************************/

///////////////////////////////     IIC ������ַ	 ////////////////////////////										  
#define AT24_ADDR			0x06
#define X1226_ADDR			0xde	//0xDE

#define AT24C_WRCMD  		0xA0
#define AT24C_RDCMD   		0xA1

///////////////////////////////     �ⲿ EEPROM �ռ����	 ////////////////////////////										  

//#define  EX_STCNT_SITE  	50000
#define  EX_EEPROM_SIZE			0x8000		// 32 KB��ƽ��Ϊ 2 ��  243C256
#define  EX_SYSINFO_STADDR		0x10		// SysInfo --- 8 Byte
//#define  EX_SYSINFO_STADDR		0x00		// SysInfo --- 8 Byte
#define  EX_OVERTABLE_STADDR	0x20		// ������Ϣ�� OverInfoTable --- 8 Byte
#define  EX_OV_H_TABLE_STADDR	0x30		// ���ؽ����ť������OvHandInfoTable --- 8 Byte
#define  EX_BDINFO_STADDR		0x80		// BDInfo1 ---- 64 Byte
#define  EX_BDINFO_STADDR2		(EX_BDINFO_STADDR+0x40)		// BDInfo2 ---- 64 Byte
#define  EX_WT_STADDR			(0x60)		// worktime ---- 12Byte

#define  EX_PWMBDINFO_STADDR		0x100		// PWM_BD ---- 256 Byte
#define  EX_OVER_INFO_STADDR	0x200		// ������Ϣ�洢��ʼλ��
#define  EX_OVER_INFO_SIZE		32			// ������Ϣ�洢���ȣ�100����¼
#define  EX_OV_H_INFO_STADDR	0x1200		// ���ؽ�������洢��ʼλ��
#define  EX_OV_H_INFO_SIZE		16//24		// ���ؽ�������洢���ȣ�100����¼

#define  OVER_INFO_NUM			60			// ��¼������ش���, < 128 

///////////////////////////////     UART ���� ֡ͷ����		/////////////////////////////
#define  UART_H1				0xFE
#define  UART_H2				0xFD

#define  UART_LEN				4			// �������ݵĳ��� 2+1+8+1=12

#define  SYSINFO_HEAD0			0x5a
#define  SYSINFO_HEAD1			0xa5



typedef struct
{
	unsigned char vHead[2];
	unsigned char vCANID;
	unsigned char vCANID2;
	unsigned char vBps;
	unsigned char vBps2;
	unsigned char vWLID[4];				// ����ͨ�ţ�ϵͳ��Ե�ID
	unsigned char vCycle;				// �������� n * 10 ms
	unsigned char vCycle2;				// �������� n * 10 ms
	unsigned char vRsv;
	unsigned char vRsv2;

	unsigned char vChkSum;
}*pSysInfo,SysInfo;

////  ϵͳʱ��
typedef struct 
{
	unsigned char  vSec;				// ��
	unsigned char  vMin;				// ��
	unsigned char  vHour;				// ʱ
	unsigned char  vDay;				// ��
	unsigned char  vMon;				// ��
	unsigned char  vYear;				// ��
	unsigned char  vWeek;				// ��
	unsigned char  vY2K;				// ���ͣ�19/ 20 h
}*pSysTime, SysTime;

extern SysInfo gSysInfo[2];

extern unsigned char gID;
extern unsigned char gID2;
extern unsigned int  gCanSCycle;
extern SysTime  gSysTime;
extern SysTime  gSysTime0;
extern uchar x12026_st ;



/****************************************************************************************/


void Can_Prog_Rcv(unsigned int vFlag);

uchar I2C_Write_B(uchar device,uint address,uchar bytedata);//��slaveд��1�ֽ����� 
uchar I2C_Read_B(uchar device,uint address);

uchar ReadRTC_ST(void); 			   //��ʱ��״̬ 
uchar ReadRTC(void); 			   //��ʱ�� 
uchar WriteRTC(uchar nian,uchar yue,uchar ri,uchar shi,uchar fen,uchar miao); //дʱ�� 
void x12027_chk(void);

unsigned char AT24_Read_Str(unsigned int byte_addr, unsigned char *buff, unsigned char num);
unsigned char AT24_Write_Page(unsigned int byte_addr, unsigned char *buff, unsigned char num);
//unsigned char  Sys_Read_Len(void);
//void Sys_Write_Len(unsigned char vPowerFlg);

void Sys_Param_Init(unsigned char vID, unsigned char vID2);
void BD_Patam_Init(void);
unsigned char  Sys_Read_BD(void);
void Sys_Write_BD(void);
void BD2_Patam_Init(void);
unsigned char  Sys_Read_BD2(void);
void Sys_Write_BD2(void);
unsigned char  Sys_Read_WT(void);
void Sys_Write_WT(void);
 
void Sys_Write_PwmBD(void);
unsigned char  Sys_Read_PwmBD(void);
unsigned char  Sys_Read_Info(void);
void Sys_Save_Info(void);



unsigned long AT24_Read_ULong(unsigned int byte_addr);
unsigned char AT24_Write_ULong(unsigned int byte_addr, unsigned long wData);




#endif  //__APP_BUS_H_
