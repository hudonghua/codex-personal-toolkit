#ifndef __TEA_h__
#define __TEA_h__


//TEA���ܺ���
void btea_encrypt( unsigned char* buf, unsigned char len, unsigned char* key );
//TEA���ܺ���
void btea_decrpyt( unsigned char* buf, unsigned char len, unsigned char* key );


#endif

